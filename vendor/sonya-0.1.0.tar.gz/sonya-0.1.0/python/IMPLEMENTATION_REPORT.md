# Relatório de implementação e validação local

## Ambiente confirmado

- macOS, LTspice 17.2.3 nativo;
- executável: `/Applications/LTspice.app/Contents/MacOS/LTspice`;
- interface batch confirmada com smoke test de 0,020 s;
- ngspice 46 nativo via Homebrew, com interface batch e leitura de ponto de operação confirmadas;
- Python 3.12 isolado por `uv`.

Os dois simuladores executaram o mesmo smoke test de divisor resistivo e produziram `V(out) = 0,5 V`. A topologia EL84 completa também executou os seis modos nos dois backends com o mesmo arquivo aberto de válvulas Koren. O sexto modo é um transiente de alta resolução, em 1 V de pico, reservado ao GM-Crowe adaptativo. LTspice permanece a referência histórica; o ngspice usa a mesma camada canônica de pós-processamento e permanece experimental até a validação em Linux e fora do baseline.

## Fundação agnóstica da aplicação

A CLI passou a expor catálogos independentes de topologias, algoritmos, backends e objetivos. `gagabiro_el84 + bounded_grid` é executável em LTspice e ngspice; combinações planejadas são exibidas com estado explícito e recusadas na execução.

Topologias agora são manifests autocontidos. O núcleo genérico não conhece nomes de circuitos, contagem fixa de parâmetros, modelos ou caminhos de usuário; somente o adaptador de reprodução histórica conhece os 25 parâmetros Sonya. A ferramenta cria um scaffold, valida dependências, traduz includes, recusa bibliotecas criptografadas no ngspice, gera hashes e executa uma cópia isolada. O exemplo criado automaticamente foi executado e otimizado em LTspice e ngspice sem configuração Sonya; o baseline atingiu exatamente a meta `V(out)=0,5 V` e venceu as perturbações de ±10%.

Também foi adicionado o contrato da avaliação multi-fidelidade. GM permanece como proxy leve na triagem/engenharia; ViSQOLAudio e GstPEAQ avaliam a forma de onda musical completa produzida pela simulação transiente, cobrindo as consequências perceptuais da dinâmica representada pelo modelo. A função de frente de Pareto descarta candidatos inviáveis ou sem todas as métricas declaradas.

O manifesto musical fixa quatro sentinelas online e oito trechos finais do EBU SQAM, exatamente os mesmos oito reservados ao WebMUSHRA. Categorias acústicas, níveis `nominal`/`limit`, papéis, caminhos canônicos e hashes preservam a reprodutibilidade sem versionar o material licenciado.

## Tradução e caracterização do ngspice

O netlist original foi alterado para remover o caminho pessoal do `standard.bjt` e referenciar diretamente arquivos relativos. LTspice e ngspice usam agora o mesmo `koren_tubes.lib`: a 12AU7 conserva os parâmetros publicados por Norman Koren e a EL84 usa o ajuste 6BQ5/Mullard amplamente distribuído para suas equações. A biblioteca EL84 criptografada deixou de ser dependência. Os BC847C foram substituídos por MJE340 e o transformador ativo passou a usar uma estrutura linear genérica com o perfil do Schatz customizado `5,776 kΩ : 6 Ω`, documentado no TCC e terminado em 6 Ω. A tradução ainda remove `.backanno` e wrappers `int()` apenas na cópia derivada.

Comparação automática do mesmo baseline:

| Métrica | LTspice | ngspice | Diferença relativa |
|---|---:|---:|---:|
| Corrente B+ | 65,1636 mA | 65,1636 mA | +0,000002% |
| Corrente de placa/EL84 | 23,1247 mA | 23,1244 mA | −0,00128% |
| Ganho | 27,9041 dB | 27,9063 dB | +0,0077% |
| Potência média `Vrms²/R` | 10,2863 W | 10,2914 W | +0,049% |
| THD comum | 0,8566% | 0,8588% | +0,251% |
| Slew comum 20–80% | 4,0760 V/µs | 4,2702 V/µs | +4,76% |
| Cutoff inferior | 8,936294 Hz | 8,936294 Hz | <0,000001% |
| Cutoff superior | 67,953651 kHz | 67,953649 kHz | <0,000004% |
| GM legado sobre extremos comuns | 6,0535 | 6,0500 | −0,057% |
| GM-Crowe adaptativo, H200 | 5,0165 | 5,0191 | +0,051% |

As diferenças grandes anteriores eram da instrumentação: RMS da potência instantânea contra potência média, `gmax/sqrt(2)` aplicado em domínios diferentes e derivadas/bordas distintas no slew. As formas de onda agora são processadas pelas mesmas funções. O comando continua rotulando o relatório como caracterização entre backends, não prova de equivalência em todo o espaço de projeto.

## Baseline não otimizado executado localmente

Uma única avaliação, sem laço de otimização, produziu:

| Métrica | Python + LTspice macOS | Referência antiga |
|---|---:|---:|
| VAA | 300,00 V | 300,00 V |
| Ganho | 27,9041 dB | 29,47 dB |
| Potência média física | 10,2863 W | não calculada no resumo antigo |
| Desvio da resposta | 0,1657 dB | 0,21 dB |
| Cutoff inferior | 8,936 Hz | 9,04 Hz |
| Cutoff superior | 67.953,7 Hz | 48.388,1 Hz |
| THD comum | 0,8566% | 0,636159% |
| Slew comum 20–80% | 4,0760 V/µs | 4,39 V/µs legado |
| GM legado/robusto suavizado | 6,0535 / 3,531 | 5,54 legado |

Ponto de operação adicional:

- corrente total B+: 65,17 mA;
- potência DC total do B+: 19,55 W;
- corrente de placa por EL84: 23,12 mA;
- dissipação de placa em repouso por EL84: 6,94 W;
- corrente de screen por EL84: 0,248 mA.
- MJE340 Q1: 7,069 V de `VCE`, 9,357 mA e 66,1 mW;
- MJE340 Q2: 1,368 V de `VCE`, 1,859 mA e 2,54 mW.

Os limites formais de SOA/dissipação ainda não foram escolhidos: exigem datasheet/modelo de válvula e margem acordada. Por isso `optimization_eligible` permanece falso mesmo quando os checks já configurados passam.

## Otimização reduzida de integração

Antes da substituição do perfil ativo, foi executado um lote determinístico de três candidatos com o PAT4002 para testar de ponta a ponta geração, preflight, LTspice, métricas, ranking e proveniência. Esses números são históricos e devem ser regenerados antes de comparar candidatos com o Schatz linear:

| Posição | Candidato | X1 | Score de teste | Potência | Slew | THD |
|---:|---|---:|---:|---:|---:|---:|
| 1 | X1 −5% | 66,5 Ω | 1,7549 | 14,103 W | 4,670 V/µs | 0,7842% |
| 2 | baseline | 70,0 Ω | 2,0133 | 13,4994 W | 4,100 V/µs | 0,6389% |
| 3 | X1 +5% | 73,5 Ω | 2,1917 | 12,9349 W | 4,198 V/µs | 0,5346% |

Todas as 15 simulações terminaram sem medidas falhas. O primeiro colocado é somente o vencedor do teste de integração: o aumento de potência veio acompanhado de piora do THD e nenhum candidato pode ser aprovado antes da definição dos limites SOA e do objetivo científico final.

## Descobertas durante a implementação

1. Parâmetros SPICE com sufixos (`150k`, `1Meg`) exigem parsing próprio. A primeira execução detectou o erro porque a corrente B+ apareceu como 2,1 A; após a correção, caiu para 65,17 mA. Há teste de regressão.
2. Correntes hierárquicas no LTspice macOS usam `Ix(U2:1)`, não `Ix(XU2:1)`.
3. Alguns timestamps RAW comprimidos são armazenados negativos pelo LTspice; o decoder agora aplica a convenção correta antes de plotar.
4. A dependência anterior de BC847C foi removida. O circuito usa um modelo MJE340 aberto e portável, identificado explicitamente como aproximação baseada no datasheet; a validação registra `VCE`, corrente e dissipação, mas a SOA dinâmica ainda precisa de protocolo e margem.
5. O subcircuito PAT4002 anterior é linear. A estrutura foi generalizada em `output_transformer.lib`; o perfil ativo usa a relação e os taps do Schatz customizado descritos no TCC, enquanto parasitas, saturação e histerese aguardam identificação nos exemplares físicos.
6. O GM legado varia com a densidade da spline e com pequenos erros nos extremos. A versão robusta oferece derivada analítica, PCHIP e spline suavizada, além de recalcular a métrica com 100%, 50% e 25% dos pontos. No baseline, a suavização de `5e-4` reduziu a amplitude relativa desse teste de cerca de 36% para 1,6%; o valor legado permanece separado.
7. O vetor histórico otimizado falha no novo preflight por VAA acima de 325 V e pelos pares X4/X5 e X15/X16 assimétricos. O LTspice não é iniciado por padrão nesse caso.
8. A auditoria por SHA-256 encontrou 31 grupos de arquivos duplicados nos 431 arquivos brutos/resultados configurados e localizou `Prms(2)=11.16` na linha 172 de `compareCircuits_graphs.m`.

## Barreiras metodológicas ainda abertas

- limites e margem de SOA/dissipação para cada dispositivo;
- modelo identificado do transformador físico;
- robustez a rede, bias, tolerâncias e dispersão de válvulas;
- equivalência formal do ensaio de slew entre simulação e bancada;
- carga canônica: 8 ohms no netlist versus 6,15 ohms na avaliação experimental;
- execução da campanha perceptual completa e protocolo subjetivo cego.

Esses itens não são preenchidos com números presumidos. A infraestrutura já os separa de reprodução legada, correções de software e futuras decisões científicas.
