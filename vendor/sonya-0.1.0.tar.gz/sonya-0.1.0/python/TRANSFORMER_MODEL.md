# Modelo do transformador de saída

## Decisão atual

O transformador ativo da topologia `gagabiro_el84` usa `OUTPUT_TRANSFORMER_UL`, um subcircuito linear e portável entre LTspice e ngspice. A estrutura elétrica fica em `ModelsLTspice/output_transformer.lib`; os valores ativos ficam em `Circuits/Audio/gagabiro_el84/transformer_schatz_5776.inc` e no perfil legível pela aplicação [`configs/transformers/schatz_custom_5776_4_6_8.yaml`](configs/transformers/schatz_custom_5776_4_6_8.yaml).

Esse perfil representa os transformadores físicos projetados para o amplificador do TCC e posteriormente reutilizados no Gagabiro. O TCC fornece duas evidências relevantes:

- na página 63 impressa (página 65 do PDF), o projeto parte de um modelo push-pull ultralinear `6,6 kΩ : 8 Ω` e usa uma carga de `7 Ω` para refletir aproximadamente `5,775 kΩ`;
- na página 87 impressa (página 89 do PDF), o transformador físico da Schatz é descrito como `5,776 kΩ`, com taps secundários para diferentes impedâncias; o próprio texto usa explicitamente os taps de `4 Ω` e `6 Ω`.

O equivalente ativo seleciona `5,776 kΩ : 6 Ω`, um tap explicitamente documentado, e usa uma carga de `6 Ω`. O modelo define a razão de indutâncias como `ZSEC/ZPRI`; com a carga igual ao tap nominal, a impedância refletida é `6 × (5776/6) = 5776 Ω`. O contexto de projeto também menciona secundário/carga de `8 Ω`, mas o texto extraído não enumera explicitamente esse tap no transformador físico; ele permanece no perfil apenas como inferência aguardando confirmação na troca de e-mails. Os taps alternativos ainda não são terminais simultâneos do subcircuito.

O PAT4002 histórico não era não linear. Ele seguia a construção apresentada por Norman Koren: segmentos de indutância constante mutuamente acoplados, indutância de fuga e capacitância primária. Essa formulação é útil para resposta em frequência e transformação de impedância, mas não produz saturação, remanência nem histerese. O próprio artigo de Koren descreve esse tipo de equivalente na seção de transformadores de saída: [Improved Vacuum-Tube Models for SPICE Simulations](https://normankoren.com/Audio/Tubemodspice_article.html).

O documento não informa indutância primária, fuga, capacitância, DCR, perda de núcleo nem a posição percentual exata do tap ultralinear. Para que o equivalente linear continue executável, `535 H`, `3,699606 mH`, `613 pF` e o tap UL de `40%` foram mantidos como **substitutos provisórios** do antigo PAT4002. Cada campo é marcado como `surrogate` ou `assumed`; eles não são apresentados como especificação da Schatz nem como medição dos exemplares.

As resistências DC dos enrolamentos e a perda do núcleo continuam explicitamente não identificadas; o modelo preserva o caso ideal nesses campos em vez de inventar números. A troca de e-mails citada pelo autor ainda não está no diretório `docs/`; quando for adicionada, ela poderá confirmar potência nominal, banda, posição do tap UL e dados construtivos antes dos ensaios.

O antigo baseline PAT4002 permanece disponível para reprodução histórica em [`configs/transformers/pat4002.yaml`](configs/transformers/pat4002.yaml), mas deixou de ser o perfil ativo. Sua relação `5878:5 Ω` terminada em `8 Ω` refletia aproximadamente `9,40 kΩ`, incompatível com o transformador físico descrito no TCC.

## Candidato de hardware

A primeira opção para uma implementação nova é o **EDCOR CXPP25-6.6K na variante de 8 Ω**. O fabricante declara primário push-pull de `6,6 kΩ`, potência de `25 W`, taps de screen em `40%`, enrolamento intercalado e resposta de `20 Hz–20 kHz`. Isso combina melhor com a carga de 8 Ω do netlist e dá margem sobre os aproximadamente 13,5 W simulados: [página oficial do CXPP25-6.6K](https://edcorusa.com/products/cxpp25-6-6k-25w-6-6k-ohms-push-pull-tube-output-transformer).

Como alternativa de catálogo, o **Hammond 1620/1620A** oferece `6,6 kΩ`, `20 W`, secundários `4/8/16 Ω` e a família usa taps ultralineares de `40%`; a série é especificada em `30 Hz–30 kHz` a plena potência: [série push-pull 1608–1650](https://www.hammfg.com/electronics/transformers/classic/1608-1650).

Nenhum deles entra na simulação apenas com esses números de catálogo. O perfil [`configs/transformers/edcor_cxpp25_6k6_8.yaml`](configs/transformers/edcor_cxpp25_6k6_8.yaml) registra o EDCOR como candidato, mas permanece `linear_ready: false` até medir indutância primária, fuga e capacitância no exemplar. O Schatz customizado é preferível porque corresponde ao hardware existente e à especificação do projeto, mesmo que seus parasitas ainda sejam provisórios.

## Por que a opção não linear será identificada nos exemplares

LTspice e ngspice têm mecanismos não lineares diferentes. LTspice oferece núcleo de Chan e modelos comportamentais; ngspice oferece o magnetic core do XSPICE, inclusive modos PWL e de histerese. Um acoplamento `K` comum, por si só, não modela saturação/histerese, e modelos de indutores não lineares não são intercambiáveis automaticamente entre os dois simuladores. Referências: [transformadores no LTspice](https://www.analog.com/en/resources/technical-articles/using-transformers-in-ltspice-switcher-cadiii.html) e [documentação do magnetic core XSPICE](https://ngspice.sourceforge.io/xspice/XSpice_CodeModelSubsysSoftwareDesign.pdf).

A opção principal será, portanto, um modelo comportamental identificado nos terminais e descrito pelos mesmos parâmetros físicos/ensaios nos dois backends. Adaptadores Chan e XSPICE poderão ser usados para conferir o ajuste, mas não serão tratados como a definição canônica do transformador.

Essa escolha também resolve o caso em que não conhecemos o número de espiras ou a geometria do núcleo. A integral da tensão fornece o fluxo concatenado `λ = ∫v dt`; a relação histórica entre `λ` e corrente pode ser ajustada diretamente a partir das formas de onda medidas. Se número de espiras, área efetiva e caminho magnético forem conhecidos, o mesmo ensaio pode ser convertido em uma curva B-H física.

## Medições necessárias

| Parâmetro/ensaio | Como será usado | Estado atual |
|---|---|---|
| relação de tensão e posições dos taps | relação de espiras e segmentação UL | nominal, não verificado |
| DCR de cada meia-primária e meia-secundária | perdas de cobre e assimetria | medir |
| indutância primária em vários níveis e frequências, secundário aberto | magnetização e início de saturação | medir |
| indutância de fuga, secundário em curto | acoplamento e resposta de alta frequência | nominal derivado; medir |
| impedância/fase em varredura | capacitâncias e perdas dependentes de frequência | medir |
| corrente a vazio, forma de onda completa, em vários `V/f` | não linearidade, saturação e histerese terminal | medir |
| indutância incremental sob polarização/assimetria DC | tolerância ao desbalanceamento do push-pull | medir |
| transferência e distorção com carga, nível e frequência variados | validação final do modelo | medir |
| espiras, área efetiva, caminho magnético e laço B-H | parametrização física, se acessível | opcional |

As medições de alta tensão exigem fonte isolada, instrumentação e procedimento de bancada adequados. A identificação inicial deve usar baixa tensão; a extrapolação só será aceita depois de confrontada com ensaios controlados no regime de interesse.

## Uso pela CLI

Inspecione o perfil ativo baseado no TCC:

```bash
sonya transformer show configs/transformers/schatz_custom_5776_4_6_8.yaml
```

O perfil `pat4002.yaml` permanece disponível apenas para reprodução do baseline histórico.

Inspecione o candidato de hardware e veja exatamente quais campos ainda faltam:

```bash
sonya transformer show configs/transformers/edcor_cxpp25_6k6_8.yaml
```

Crie um perfil vazio para outro transformador:

```bash
sonya transformer init meu_transformador --output ./meu_transformador.yaml
```

Depois de preencher os valores lineares medidos, gere o include portável:

```bash
sonya transformer render ./meu_transformador.yaml --output ./meu_transformador.inc
```

O comando informa separadamente `linear_ready`, `losses_identified` e `nonlinear_ready`. Assim, um modelo nominal pode servir à integração sem ser confundido com um transformador fisicamente identificado.

## Pendências para a versão não linear

1. construir o fixture e salvar formas de onda cruas com configuração, temperatura e exemplar;
2. ajustar primeiro o equivalente linear completo, incluindo DCR e perdas;
3. ajustar a relação não linear de fluxo concatenado, corrente e história;
4. gerar adaptadores LTspice/ngspice a partir do mesmo conjunto de parâmetros;
5. validar em dados que não participaram do ajuste, incluindo desbalanceamento DC e sinais musicais;
6. somente então habilitar o modelo não linear durante a otimização.
