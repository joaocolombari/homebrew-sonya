# Corpus musical local

Esta pasta separa metadados versionáveis dos arquivos de áudio, que permanecem
locais por tamanho e direitos de uso.

- `source/`: originais preservados sem alteração;
- `audition/`: trechos canônicos PCM16/48 kHz para seleção por escuta;
- `final/`: as oito referências comuns à validação objetiva e ao WebMUSHRA;
- `webmushra/`: futura exportação dos estímulos processados para teste subjetivo.

As quatro subpastas são ignoradas pelo Git. A reprodutibilidade vem do manifesto
`configs/programme.yaml`, dos SHA-256 dos originais e do índice gerado durante a
preparação. O manifesto fixa quatro trechos online e oito trechos idênticos para
validação objetiva final e WebMUSHRA. Cada referência é apresentada em
`nominal = 0,447213595 Vpk` e `limit = 1 Vpk`; as tensões ficam no manifesto,
não na linha de comando. Não edite manualmente os WAVs canônicos: regenere-os pela CLI para
que o processamento e os hashes permaneçam auditáveis.

O conjunto candidato inicial usa o EBU SQAM (Tech 3253). A EBU permite o uso do
material como ferramenta de P&D não comercial; isso não autoriza publicar os
arquivos de áudio no repositório nem redistribuí-los como um pacote comercial.
