# Mapa mínimo para a migração

| Responsabilidade | Legado consultado | Camada Python inicial |
|---|---|---|
| GUI/inicialização | `CirOp.m`, `Opt.m` | CLI em `sonya.cli`; catálogos prontos para a futura GUI |
| Variáveis e alvos | `Circuits/Audio/menu.m` | `configs/legacy.yaml`, `sonya.config`, `sonya.parameters` |
| Topologias | circuitos selecionados pelas GUIs MATLAB | `sonya.topology`; manifests portáveis independentes do código |
| Geração/execução | `paramAC.m`, `Start/runsSafe.m` | `sonya.ltspice`, `sonya.simulators`; seis modos nos backends LTspice/ngspice, incluindo Crowe adaptativo |
| Fitness legado | `fitnessLTspice.m`, `prototype/evaluation.m`, `scoreAv.m` | `sonya.legacy`; score agregado ainda não é promovido |
| REW | `readREWMeasurement.m`, `readREWScope.m`, `readREWSpectrum.m`, `readREWTHD.m` | `sonya.parsers.rew` |
| LTspice LOG/resultados | `file2table_LTspice*.m`, `readFourierTable.m` | `sonya.parsers.legacy` |
| Métricas | `gedlee_from_meas.m`, `evaluation.m` | `sonya.metrics.*`; pós-processamento canônico comum, legado e GM robusto separados |
| Restrições | inexistente como estágio duro | `sonya.feasibility` (interface, limites ainda abertos) |
| Objetivos | soma compensável em `fitnessLTspice.m` | `sonya.objectives`, `sonya.catalog`; GM restrito à triagem/engenharia e validação perceptual sobre programa musical completo |
| Programa musical | inexistente | `configs/programme.yaml`, `sonya.programme`; corpus por propriedades e frente de Pareto completa |
| Otimização | `MetaHeu.m`, SAM/PSO | `bounded_grid` executável; DE, NSGA-II e PSO cadastrados para implementação |
| Proveniência/figuras | scripts dispersos | `sonya.provenance`, `sonya.figures`; saídas fora de raw data |

Não foram migradas as GUIs CirOp, a coleção inteira de metaheurísticas, campanhas históricas ou geração indiscriminada de figuras.

## Divergências auditadas

- O diretório de trabalho original estava dentro de outro checkout (`Persephone.git`); o desenvolvimento versionado passou a usar a branch dedicada `python-migration` do repositório Sonya.
- `circuit.sp` agora usa tap/carga nominal de 6 ohms, enquanto `evaluation.m` preserva os 6,15 ohms medidos no fluxo histórico.
- O cutoff de `evaluation.m` divide uma magnitude em dB por `sqrt(2)`; isso permanece apenas na reprodução histórica. Simulações novas usam a definição canônica de -3,0103 dB.
- `compareCircuits_graphs.m` contém `Prms(2)=11.16`; esse valor não entra nos cálculos Python.
- O GM-Legacy reconstrói uma transferência estática a partir de extremos de janelas de 2 ms. O GM-Crowe reduz a dependência da amostragem direta e reporta convergência harmônica; as consequências perceptuais da dinâmica modelada são avaliadas depois com programa musical completo.
- A lógica Windows de `runsSafe.m` não é reutilizada; o runner usa o binário nativo detectado no Mac.
- A biblioteca EL84 criptografada foi retirada do fluxo; o circuito original e os dois backends usam o mesmo arquivo aberto em formulação Koren.
- Os BC847C foram substituídos por MJE340 com um modelo portável e instrumentação de ponto de operação.
- O PAT4002 deixou de ser uma estrutura embutida específica: o circuito usa um modelo linear ultralinear genérico e o perfil ativo representa o Schatz customizado `5,776 kΩ : 6 Ω` documentado no TCC, terminado em 6 Ω para preservar a impedância primária refletida. Parâmetros reativos ainda são substitutos declarados; o modelo não linear aguarda medições físicas.
