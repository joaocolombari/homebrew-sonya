# Status da migração Python

Atualizado em 1º de outubro de 2026. Este arquivo registra o estado verificável do desenvolvimento; instalação e exemplos de uso ficam no [README.md](README.md).

## Resumo executivo

A primeira camada da aplicação agnóstica está implementada. A CLI separa e enumera topologias, algoritmos, simuladores e métricas; a interface local consome diretamente esses mesmos catálogos. `sonya gui` abre uma aplicação offline em `localhost`, mostra o circuito e o corpus, permite editar os limites do espaço de projeto e a regularidade perceptual, inicia campanhas em processos separados e recupera progresso e resultados persistidos. A aba de resultados agora lê o arquivo incremental da campanha, exibindo candidatos, frente e cobertura dominada antes do encerramento. LTspice e ngspice atendem a um contrato comum de diagnóstico e smoke test. Uma fórmula Homebrew comum a macOS/Linux e o comando `sonya install doctor` fornecem instalação versionada e um inventário verificável do pacote, simulador, ferramentas perceptuais e corpus, sem incorporar dados licenciados ao pacote.

O fluxo de referência da topologia `gagabiro_el84` continua validado com LTspice no macOS. LTspice e ngspice executam ponto de operação, transiente, AC, slew e GedLee com os mesmos modelos abertos de válvulas Koren, MJE340 e transformador linear portável. Ambos agora exportam formas de onda para a mesma camada canônica de pós-processamento. As grandes diferenças anteriores eram principalmente diferenças de definição e extração, não do circuito: no baseline, todas as métricas dinâmicas comparadas ficaram dentro de aproximadamente 1%.

O protocolo elétrico principal fixa a entrada em `−10 dBV`, como na interface de linha de consumo usada no trabalho. A comparação com potência igual na saída também foi implementada como opção: cada candidato é simulado iterativamente até atingir a potência real declarada, sem ocultar no modo padrão as diferenças de ganho e potência. O `GM-Crowe` agora possui um transiente independente de 1 V de pico, igualando o intervalo do `GM-Legacy`, e aumenta a ordem harmônica até demonstrar convergência.

A primeira campanha multi-fidelidade também está operacional. NSGA-II faz a busca multiobjetivo principal e GDE3 fornece uma segunda construção de Pareto; DE é o baseline escalar moderno, enquanto PSO e SAM preservam referências escalares do MATLAB. Todos recebem o mesmo orçamento em candidatos únicos. Um arquivo comum evita repetir avaliações, e todo candidato recebe GM-Crowe como quarto objetivo elétrico. A antiga promoção virou apenas um conjunto de destaques representativos por Pareto/crowding; as seleções perceptuais online/final são independentes. A saída distingue frente elétrica, validação perceptual e validação científica; as duas últimas permanecem vazias até a execução da campanha musical, e a científica exige também SOA dinâmica.

A camada perceptual está operacional de ponta a ponta nos dois backends: prepara pares mono PCM16 em 48 kHz, preserva a resposta em frequência ao corrigir somente atraso e nível escalar, integra a CLI oficial do ViSQOL e o GstPEAQ básico/avançado e constrói uma amostra online estocástica por meia-vida. O LTspice consome PCM16 diretamente com `wavefile`; o ngspice usa `filesource` externo. Ambos evitam inserir centenas de milhares de pontos no netlist. Cada caso atualiza um relatório parcial e falhas isoladas não descartam o restante da validação. A GUI permite selecionar trechos individuais para diagnóstico, mas uma seleção parcial da partição final é marcada como evidência parcial e não entra silenciosamente na frente validada. A validação final comprime a frente e inclui vizinhos próximos. ViSQOL 3.3.3 e GstPEAQ 0.6.1 estão instalados. O corpus EBU SQAM foi fixado em quatro sentinelas online e oito trechos finais; os mesmos oito IDs são usados na validação objetiva e no futuro WebMUSHRA. Os níveis musicais também estão fixados: `nominal = 0,447213595 Vpk` e `limit = 1 Vpk`. Ainda não há uma campanha completa que sustente uma reivindicação científica; SOA dinâmica e o transformador físico não linear permanecem pendentes.

Topologias deixaram de existir no código. Cada uma é descrita por um manifest relativo e portável; um usuário pode criar, validar, traduzir e executar seu próprio netlist sem carregar a configuração ou os arquivos do Sonya.

## Matriz de implementação

| Componente | Estado | Evidência/limite atual |
|---|---|---|
| Configuração de parâmetros | implementado | quantidade e identificadores genéricos; limites por campanha na GUI/CLI; o exemplo Sonya declara 25 |
| Manifests de topologia | implementado | circuitos, modelos, includes, transformações e suporte por backend fora do código |
| Backend LTspice | validado no macOS | versão 17.2.3, batch, seis modos e baseline completo |
| Backend ngspice | experimental completo | versões 46 no macOS e 45.2 no Ubuntu 26.04; seis modos da topologia EL84, incluindo otimização |
| Ferramenta de tradução | implementada | `init`, `validate`, `translate` e `run` independentes do projeto |
| Otimização genérica por manifest | implementada | parâmetros, limites e objetivo OP; LTspice e ngspice, até oito candidatos |
| Comparação de backends | implementada | resumo e deltas por métrica, sem presumir equivalência |
| Estímulo fixo −10 dBV | implementado, padrão | 0,316227766 V RMS; mesma entrada para todos os candidatos |
| Potência de saída comum | implementada, opcional | busca iterativa por candidato/backend usando potência média real na carga |
| Pós-processamento canônico | implementado | potência média, -3,0103 dB, THD harmônico e slew 20–80% comuns aos backends |
| MJE340 | implementado, validação dinâmica pendente | dois BC847C substituídos; `VCE`, `IC` e dissipação DC instrumentados nos dois backends |
| Transformador linear | implementado provisório | Schatz customizado `5,776 kΩ : 6 Ω` ativo e carga de `6 Ω`; impedância refletida preservada, parasitas ainda substitutos do PAT4002 |
| Transformador não linear | identificação pendente | modelo terminal comportamental escolhido; requer formas de onda dos exemplares |
| Transformador físico | identificado documentalmente | Schatz `5,776 kΩ`, taps `4/6 Ω` explícitos e `8 Ω` inferido até conferir os e-mails; ensaios pendentes |
| Candidato alternativo | documentado | EDCOR CXPP25-6.6K/8 Ω; perfil incompleto até medir um exemplar |
| Perfis de transformador na CLI | implementado | `show`, `init` e `render`; estados linear, perdas e não linear separados |
| `bounded_grid` | implementado | lote determinístico de 1–8 candidatos |
| Differential Evolution | implementado | DE/rand/1/bin escalar; baseline moderno com `F`, `CR`, seed e orçamento explícitos |
| GDE3 | implementado | segunda heurística Pareto; mutação diferencial e seleção por dominância/crowding |
| NSGA-II | implementado | busca Pareto 4D em potência, slew rate, uniformidade e GM-Crowe; THD diagnóstica; orçamento por candidatos únicos |
| PSO legado | implementado | referência comportamental com score histórico escalar |
| SAM legado | implementado | annealing com resfriamento e crossover de elite; referência escalar |
| Destaques representativos | implementado | Pareto/crowding no NSGA-II/GDE3, ranking escalar no DE/PSO/SAM; somente inspeção, sem definir a seleção perceptual |
| Arquivo de candidatos | implementado | JSONL somente-acréscimo, chaveado por parâmetros, protocolo e hashes das entradas |
| Tolerância a falhas de candidato | implementada | não convergência, timeout e dados não finitos são penalizados e arquivados; a campanha continua e exclui esses pontos das frentes, hipervolume e seleção perceptual |
| GM-Legacy | implementado | reprodução MATLAB pela escada de 101 amplitudes; explicitamente não mede memória |
| GM-Crowe | implementado | 1 V de pico, FFT única, Chebyshev e ordem adaptativa H10…H400; exige duas mudanças consecutivas ≤0,5% |
| Diagnósticos do GM-Legacy | implementados | derivada analítica, PCHIP ou suavização; estabilidade avaliada com 100%, 50% e 25% dos pontos |
| ViSQOLAudio | adaptador implementado, ViSQOL 3.3.3 validado no Mac e Ubuntu | MOS-LQO primário e único eixo perceptual; requer campanha completa |
| GstPEAQ básico/avançado | adaptador implementado, GstPEAQ 0.6.1 validado no Mac e Ubuntu | confirmação ODG; explicitamente não tratado como implementação normativa conforme tolerâncias BS.1387 |
| Preparação de áudio | implementada e validada nos dois backends | LTspice `wavefile` PCM16; ngspice `filesource`; mono 48 kHz, alinhamento, ajuste escalar comum e resposta em frequência preservada |
| Amostragem perceptual | implementada | meia-vida/seed, ranks Pareto, novidade, baseline/extremos obrigatórios, limites de tempo/candidatos e shortlist final epsilon |
| Benchmark de custo | implementado para LTspice/ngspice | sinal determinístico, circuito completo, WAVs e projeção por candidatos × trechos × níveis × duração |
| Executor perceptual pós-seleção | implementado e testado nos dois backends | exige originais e WAVs canônicos por hash; executa nominal/limit, agrega por média aritmética de casos com mínimo/máximo/desvio/n, grava checkpoint após cada caso e continua após falha isolada |
| Frente de Pareto | implementada em quatro classes | busca, engenharia, perceptual e científica; auditoria registra métricas/evidências ausentes |
| Corpus musical | pronto para validação musical | 4 online; 8 finais idênticos aos 8 do WebMUSHRA; dois níveis fixos; SQAM mono PCM16/48 kHz e hashes fixados |
| Interface gráfica local/privada | implementada para campanhas locais e remotas | `sonya gui`; diagrama, selecionar todos, limites editáveis, jobs persistentes, pausa/cancelamento seguro, eventos, resultados preliminares, Pareto 4D, cobertura dominada e hipervolume técnico, comparação, escalas perceptuais e executor pós-seleção; jobs validados recebem estado visual próprio; restrita a localhost e acessível remotamente por túnel SSH |
| Distribuição Homebrew | validada no macOS; validação do tap no Linux automatizada na release | mesma fórmula para macOS/Linux; LTspice externo no Mac, ngspice automático no Linux; estado e corpus fora do prefixo versionado |
| Diagnóstico da instalação | implementado | `package`, `core`, `perceptual` e `all`; lista versões/caminhos e falha seletivamente com `--strict` |

## Validação executada nesta etapa

- 109 testes automatizados aprovados;
- a fórmula Homebrew foi instalada e testada de ponta a ponta com Homebrew 7.0.7 no macOS: criou um Python 3.14 isolado com 14 pacotes, executou o diagnóstico pós-instalação, passou em `brew test` e em `brew audit`; o diagnóstico confirmou `package` e `core` prontos, detectou LTspice 17.2.3, ngspice 46, ffmpeg, ViSQOL 3.3.3 e GstPEAQ 0.6.1 e marcou corretamente somente o corpus externo como pendência perceptual;
- o workflow de release repete a instalação pelo tap privado em macOS 15 e Ubuntu 24.04 a cada tag `v*`; no Linux ele exige também o escopo elétrico `core`, incluindo o ngspice instalado pela própria fórmula;
- a campanha LTspice determinística que antes encerrava no candidato 7 foi repetida: o transiente inválido gerou `analysis_failed`/`candidate_failed`, o candidato 8 executou normalmente e a campanha terminou com 7 sucessos, 1 falha e 37 chamadas ao simulador; o candidato inválido ficou fora das frentes e da seleção perceptual, enquanto o hipervolume preservou um platô na avaliação 7;
- uma campanha GDE3 real foi iniciada pela GUI com `F = 0,8`, confirmando a correção da grade HTML que antes tornava o próprio valor padrão inválido; o cancelamento solicitado durante o segundo candidato deixou a análise Crowe terminar e encerrou com código 130 exatamente na fronteira anterior ao terceiro candidato;
- o monitor exibiu incrementalmente `op`, `tran`, `ac`, `slew` e `crowe`, candidato atual, tempos de cada análise e o evento final `cancelled_at_boundary`;
- a falha perceptual relatada foi reproduzida: o PWL embutido criava um arquivo de parâmetros de aproximadamente 17 MB e o ngspice excedia 300/600 s antes de terminar o primeiro caso; o novo `filesource` externo processou os mesmos 12,1 s/580.800 amostras em `28,43 s`;
- o novo adaptador LTspice reproduz o fluxo do exemplo didático `5_wav.asc`: lê PCM16/48 kHz diretamente com `wavefile`, preserva somente `V(in)`/`V(out)` no RAW e reduziu um ensaio de 1,1 s de aproximadamente `98 MB` para `4,3 MB`;
- um caso real completo com o candidato baseline, contrabaixo, nível nominal, ViSQOL e PEAQ básico terminou sem falhas nos dois backends: ngspice em `42,13 s` totais (`28,73 s` de simulação), com MOS-LQO `4,69131` e ODG `−1,223`; LTspice em `76,29 s` (`54,79 s` de simulação), com MOS-LQO `4,67163` e ODG `−0,852`;
- o ngspice entregou pico `0,0122%` abaixo do alvo e o LTspice `0,0020%`; a antiga tolerância de `0,001%` rejeitava resultados válidos, enquanto o limite explícito de `0,05%` ainda detecta erros reais de calibração e registra a diferença em cada caso;
- a GUI e a CLI agora selecionam trechos individuais para diagnóstico; executar menos que os oito itens de `validation` produz `partial_validation_only` e não satisfaz a evidência da frente perceptual validada;
- a validação musical agora grava `validation.partial.json` depois de cada sucesso/falha, publica o estágio do erro e exclui da frente perceptual qualquer candidato incompleto sem encerrar os casos restantes;
- `sonya gui` foi aberto em `localhost`, confirmou LTspice/ngspice, carregou a figura do circuito, os catálogos, o corpus e as métricas reais sem serviços externos;
- uma campanha NSGA-II real iniciada pela GUI avaliou oito candidatos no ngspice em 34 simulações e alimentou as telas de acompanhamento/resultados com potência, THD, resposta em frequência, ganho, slew, GM-Crowe e grandezas DC dos dois MJE340;
- uma campanha GDE3 posterior à mudança de protocolo avaliou quatro candidatos em exatamente 20 simulações (`op`, `tran`, `ac`, `slew` e `crowe` para cada um); os quatro registros continham `gm_crowe` e vetores de quatro objetivos, enquanto `--promote 2` apenas destacou dois representantes;
- a GUI passou a executar a validação perceptual depois da campanha com seleção online/final, corpus de 4/8 trechos, níveis nominal/limit e escolha ViSQOL/GstPEAQ; antes de iniciar, ela mostra o produto candidatos × trechos × níveis e persiste log/relatório separados;
- uma campanha de verificação restringiu `X1` a `60–80 Ω`, avaliou quatro candidatos em 17 simulações e confirmou que todos os valores produzidos ficaram dentro do intervalo gravado no protocolo;
- a figura F8 foi incorporada à topologia e os designadores do netlist foram alinhados a `R1–R18`, `C1–C5` e `Q1/Q2`, sem alterar conectividade ou valores elétricos;
- o wheel foi inspecionado e contém o servidor local, HTML/CSS/JavaScript, ícone e figura do circuito;
- o bootstrap Ubuntu agora cria o usuário de serviço `sonya` sem login/sudo, instala e testa uma cópia isolada em `/srv/sonya` e registra a GUI como serviço local acessível apenas por túnel SSH;
- a suíte limpa diferencia protocolo musical válido de arquivos SQAM locais: a ausência deliberada do áudio fora do Git desabilita somente a etapa perceptual, sem invalidar a instalação elétrica;
- a release `ff7be4e` foi instalada no servidor `easn-cloud` com Ubuntu 26.04, Python 3.14.4, ngspice 45.2 e ffmpeg 8.0.1; o smoke mediu `V(out) = 0,5 V` e os 100 testes passaram em `2,11 s`;
- o instalador perceptual reproduzível foi validado no mesmo Ubuntu 26.04: compilou ViSQOL 3.3.3 com Bazel 5.1.0/GCC 12, compilou GstPEAQ 0.6.1, registrou o plugin GStreamer e o diagnóstico real do Sonya retornou `ready: true` para as duas métricas;
- o serviço `sonya-gui` foi habilitado no `systemd`, executa como o usuário isolado `sonya`, escuta somente em `127.0.0.1:8765` no servidor e foi acessado no Mac pelo túnel local `8876 → 8765`;
- os nove originais EBU SQAM e seus WAVs canônicos foram transferidos de forma privada para `/srv/sonya/app/python/corpus`; todos os hashes passaram e a API remota confirmou `programme_ready`, `assets_ready` e `protocol_ready`;
- a primeira campanha real no servidor executou NSGA-II com todos os parâmetros livres: 8 candidatos, 40 simulações, 8 sucessos, nenhuma falha e frente elétrica com 6 soluções em aproximadamente 4 min 53 s;
- DE escalar e GDE3 multiobjetivo foram exercitados em funções sintéticas com o mesmo orçamento de candidatos; GDE3 preservou compromissos não dominados;
- a auditoria de Pareto recusou um resultado perceptual de desenvolvimento sem evidência do conjunto de validação;
- `sonya simulator doctor` identificou LTspice 17.2.3 e ngspice 46 como prontos;
- os dois backends executaram em batch um divisor resistivo e mediram `V(out) = 0,5 V`;
- `sonya evaluation corpus` confirmou `programme_ready: true`: contrato 4/8/8, categorias, originais, WAVs canônicos e os dois níveis passaram;
- uma otimização LTspice de três candidatos executou 15 simulações; `X1 −5%` venceu o teste provisório com score `1,7549`, o baseline obteve `2,0133` e nenhum resultado foi marcado como projeto aprovado;
- uma campanha NSGA-II piloto no ngspice, ainda com o PAT4002 histórico, avaliou quatro candidatos variando `X1`, executou 20 simulações de triagem e apenas um GM-Crowe adicional; ela validou a infraestrutura, mas seus valores não são comparáveis à próxima campanha com o Schatz;
- uma campanha GDE3 com o Schatz ativo avaliou cinco candidatos variando `X1`, executou 26 simulações, produziu três soluções não dominadas na triagem e promoveu uma para GM-Crowe; as frentes perceptual e científica permaneceram vazias por falta das evidências declaradas;
- após retirar o GM-Legacy da triagem multiobjetivo, uma campanha GDE3 de quatro candidatos executou exatamente 17 simulações: quatro análises elétricas por candidato e um GM-Crowe para o promovido, em vez de 21 com a escada legada;
- a mesma campanha registrou seed, rank, probabilidade e sorteio da amostragem perceptual, selecionando obrigatoriamente baseline e extremo sem deixar resultados perceptuais influenciarem a heurística;
- um benchmark real de 0,55 s de áudio no circuito completo/ngspice levou `12,199 s` (`22,18×` tempo real), gerou `186.103` amostras e mediu atraso de `1,5 ms`; projetado linearmente, 8 candidatos × 3 trechos × 2 níveis × 5 s custam cerca de `1,49 h` em série, antes do custo das métricas;
- ViSQOL 3.3.3 e GstPEAQ 0.6.1 foram compilados e instalados localmente; a preparação passou a emitir PCM16 para compatibilidade com o ViSQOL oficial;
- uma execução técnica de 5 s atravessou a CLI completa e retornou MOS-LQO `3,02712`, ODG básico `−3,911` e ODG avançado `−3,956`; o trecho repetido artificialmente serve somente como smoke test, não como resultado científico;
- um teste real de dois níveis processou 5 s do contrabaixo pelo circuito completo/ngspice e pelas três métricas em `475,05 s`: o pico entregue foi `0,447213595 V` no nominal e `1,000000000 V` no limit; ViSQOL foi `4,72023/4,55092`, GstPEAQ básico `−0,713/−1,875` e avançado `−0,358/−1,089`; é evidência de integração, não resultado científico;
- nesse teste, cada simulação de 5 s levou aproximadamente `230 s` (`46×` tempo real); por projeção linear conservadora, 8 trechos × 2 níveis × 12 s custam cerca de `2,45 h` por candidato em série, antes de variações por conteúdo e máquina;
- nove candidatos EBU SQAM foram verificados pelo hash do original e renderizados como referências canônicas; cada WAV tem 12 s, mono PCM16/48 kHz, ID estável e hash fixado em `programme-audition.lock.json` para futuro reaproveitamento no WebMUSHRA;
- castanholas, contrabaixo, Strauss e Schubert formam o conjunto online mínimo; cravo, soprano, Baird e ABBA completam os oito finais, e o manifesto testa que validação e WebMUSHRA usem exatamente os mesmos IDs;
- Eddie Rabbitt foi mantido como reserva por redundância com o pop denso do ABBA; seu WAV canônico continua acessível para audição e sensibilidade, sem incluí-lo nas oito avaliações finais;
- a repetição da mesma campanha com o arquivo JSONL reutilizado executou zero novas simulações e reproduziu os mesmos identificadores de candidato e shortlist;
- um candidato de integração também executou os seis modos no ngspice, sem medidas ausentes e com backend marcado `experimental`;
- um projeto novo criado por `topology init` foi validado, traduzido e executado no ngspice sem acessar configuração, circuitos ou caminhos do Sonya;
- esse mesmo projeto foi otimizado a partir de parâmetros, limites e objetivo declarados no próprio manifest, tanto no ngspice quanto no LTspice;
- a investigação mostrou que os netlists e todos os modelos tinham hashes idênticos; a aparente diferença de potência comparava RMS da potência instantânea com potência média, os cutoffs usavam níveis diferentes e o slew selecionava bordas/derivadas diferentes;
- com o Schatz linear no tap/carga de `6 Ω`, o baseline mediu diferenças LTspice/ngspice de `+0,049%` em potência, menos de `0,000004%` nos cutoffs, `+0,251%` em THD, `+4,76%` em slew e `−0,057%` no GM legado;
- em 1 V de pico, o GM-Crowe adaptativo convergiu em H200 para `5,016489` no LTspice e `5,019072` no ngspice (`+0,051%`); o GM-Legacy mediu `6,053491/6,050040` (`−0,057%`);
- a convergência do GM-Crowe foi aceita após mudanças de `0,204%` e `0,0165%` no LTspice e `0,208%` e `0,0170%` no ngspice, ambas abaixo do limite de 0,5%;
- no modo opcional de 10 W comuns com o Schatz linear, a calibração encontrou `0,311880 V RMS` no LTspice e `0,311819 V RMS` no ngspice; as potências finais foram `10,00012/10,00104 W`, diferença de `0,0093%`;
- no modo de potência comum, o GM-Crowe continua usando seu ensaio separado em 1 V de pico; a calibração de 10 W afeta somente as métricas elétricas nominais;
- após a troca para MJE340, o baseline LTspice mediu Q1 em `7,069 V`, `9,357 mA`, `66,1 mW` e Q2 em `1,368 V`, `1,859 mA`, `2,54 mW`; isso valida apenas o ponto DC, não a SOA dinâmica;
- o TCC documenta o transformador físico Schatz com primário de `5,776 kΩ` e taps secundários explícitos de `4/6 Ω`; o circuito agora seleciona o tap de `6 Ω` e uma carga de `6 Ω`, preservando matematicamente a impedância refletida de `5,776 kΩ`;
- indutância, fuga, capacitância e tap UL ainda são substitutos declarados do PAT4002, enquanto DCR, perdas, saturação e histerese continuam aguardando ensaio;
- `sonya transformer show` expõe separadamente a especificação do Schatz, a origem de cada parâmetro, perdas não identificadas e modelo não linear pendente;
- o pacote `sonya_jaes-0.1.0` foi gerado com sucesso nos formatos wheel e source distribution;
- os artefatos de cada execução foram escritos somente em `outputs/processed`, com proveniência.

## Seletores disponíveis na CLI

```bash
sonya topology list
sonya topology show gagabiro_el84
sonya topology init meu_circuito --directory ./meu_circuito
sonya topology validate ./meu_circuito/topology.yaml
sonya topology translate ./meu_circuito/topology.yaml --backend ngspice --output ./traduzido
sonya topology run ./meu_circuito/topology.yaml --backend ngspice --output ./execucao
sonya transformer show configs/transformers/pat4002.yaml
sonya transformer show configs/transformers/schatz_custom_5776_4_6_8.yaml
sonya transformer show configs/transformers/edcor_cxpp25_6k6_8.yaml
sonya transformer init meu_trafo --output ./meu_trafo.yaml
sonya transformer render ./meu_trafo.yaml --output ./meu_trafo.inc
sonya algorithm list
sonya algorithm show bounded_grid
sonya algorithm show nsga2
sonya algorithm show gde3
sonya algorithm show differential_evolution
sonya objective list
sonya simulator list
sonya simulator doctor
sonya simulator smoke --backend ltspice
sonya simulator smoke --backend ngspice
sonya simulator compare ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt
sonya simulator compare ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt --drive-mode matched-output-power --target-output-power 10
sonya evaluation plan
sonya evaluation corpus
sonya perceptual doctor
sonya perceptual benchmark ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt --duration 0.5 --projection-duration 5
sonya perceptual sample ./outputs/minha-campanha/campaign.json --perceptual-half-life 50 --perceptual-online-max 10
sonya perceptual validate ./outputs/minha-campanha/campaign.json
```

A otimização reduzida recebe explicitamente os três seletores:

```bash
sonya optimize test ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --topology gagabiro_el84 \
  --algorithm bounded_grid \
  --backend ltspice \
  --vary X1 --count 3 --step 0.05
```

O comando acima usa `fixed-input` em −10 dBV. A alternativa solicitada pelo revisor é ativada com `--drive-mode matched-output-power --target-output-power 10`; a tensão encontrada e todo o histórico da calibração ficam no relatório.

Hoje `gagabiro_el84 + bounded_grid` é executável com LTspice (`validated`) e ngspice (`experimental`). Opções planejadas permanecem visíveis para estabilizar o contrato da GUI, mas geram erro claro ao serem solicitadas.

A campanha contínua usa os mesmos seletores e adiciona orçamento e promoção:

```bash
sonya optimize campaign ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --topology gagabiro_el84 --algorithm nsga2 --backend ngspice \
  --vary X1 --budget 8 --population-size 4 --promote 2
```

`gde3` pode substituir `nsga2` sem escalarizar os objetivos. `differential_evolution`, `legacy_pso` e `legacy_sam` usam o score histórico e servem como referências escalares. DE/GDE3 expõem `--mutation-factor` e `--crossover-probability`. O núcleo dos algoritmos e do espaço de parâmetros é genérico; o adaptador completo desta campanha ainda usa as análises da topologia EL84. Topologias externas continuam executáveis e otimizáveis pelo manifest reduzido.

Os perfis de transformador distinguem três estados que não devem ser confundidos: `linear_ready`, `losses_identified` e `nonlinear_ready`. O Schatz está linearmente executável porque a relação é conhecida e os parasitas provisórios estão explícitos; isso não significa que suas perdas ou não linearidades foram identificadas. O PAT4002 fica como reprodução histórica e o EDCOR como alternativa de hardware.

## Avaliação multi-fidelidade

O catálogo de métricas separa quatro camadas:

1. **triagem elétrica:** restrições, potência, slew rate, uniformidade e GM-Crowe em todo candidato; THD diagnóstica e sem a escada GM-Legacy nos algoritmos multiobjetivo;
2. **destaques:** representantes da frente por Pareto/crowding para inspeção, sem nova simulação elétrica e sem definir as listas perceptuais;
3. **programa musical:** ViSQOLAudio como objetivo primário e GstPEAQ básico/avançado como confirmação;
4. **subjetiva:** WebMUSHRA somente nos finalistas, com as mesmas oito referências da validação objetiva.

O manifesto [`configs/programme.yaml`](configs/programme.yaml) exige cobertura de ataques percussivos, grave sustentado, instrumento harmônico, voz, mix denso, alto fator de crista e transição forte-fraco. Arquivos comerciais não entram no Git: serão referenciados com trecho, papel e SHA-256. Os detalhes estão em [EVALUATION_PROTOCOL.md](EVALUATION_PROTOCOL.md).

GM continua útil como proxy leve e psicoacusticamente motivado. O GM-Legacy preserva a comparação histórica nos algoritmos escalares. O GM-Crowe reduz a dependência da amostragem direta de `T(x)`, mantém a fase harmônica e registra como `memory_ratio` o resíduo em quadratura que não cabe numa transferência estática única; esse campo é diagnóstico, não objetivo. ViSQOLAudio e GstPEAQ avaliam depois a forma de onda musical completa, incluindo as consequências perceptuais da dinâmica que o modelo efetivamente simula.

Há agora duas heurísticas de Pareto implementadas: NSGA-II como principal e GDE3 como verificação independente de cobertura. O relatório separa as frentes de busca, engenharia, validação perceptual e validação científica. A auditoria da última exige SOA dinâmica, corpus de validação separado, versões dos adaptadores e proveniência; por isso ela permanece corretamente vazia no estado atual.

## Baseline reproduzido

Na simulação canônica com entrada exata de −10 dBV e o Schatz linear, LTspice/ngspice produziram respectivamente `10,2869/10,2920 W`, `4,7068/4,9311 V/µs`, `0,8567/0,8589%` de THD e cutoffs de `8,93628 Hz` e `67,9581 kHz` em ambos. Em uma execução separada de 1 V de pico, o GM-Crowe foi `5,0151/5,0192`, convergindo em H200; o GM-Legacy foi `6,0532/6,0502`. Assim, os dois GMs percorrem o mesmo intervalo sem alterar o ponto nominal usado para potência, ganho e THD.

O circuito legado nunca é executado na árvore de origem. O runner copia o netlist e os modelos para uma pasta derivada, normaliza somente a cópia e registra as mudanças e hashes. Isso também protege os dados históricos durante futuras traduções para ngspice.

## Bloqueios científicos

- limites e margens de SOA/dissipação por dispositivo;
- medição das DCRs, perdas, corrente a vazio, dependência de `V/f`, polarização DC e distorção dos transformadores físicos;
- caracterização da carga experimental de `6,15 Ω` em torno do tap nominal de `6 Ω`;
- confirmação auditiva final dos oito trechos selecionados;
- calibração do orçamento, população e quantidade promovida numa campanha piloto maior;
- validação numérica do GM-Crowe aberto contra o VIRTINS usando os mesmos sinais sintéticos e tabelas harmônicas;
- protocolo subjetivo cego.

Esses bloqueios impedem declarar um circuito ótimo, não impedem continuar a infraestrutura e os ensaios piloto.

## Próximos passos de desenvolvimento

1. medir os exemplares do transformador, completar o equivalente linear e identificar o modelo não linear terminal comum aos backends;
2. executar uma campanha piloto maior e comparar NSGA-II e GDE3 pelo mesmo orçamento de candidatos, usando o hipervolume agora disponível e mantendo DE, PSO e SAM como referências escalares;
3. executar a primeira validação perceptual completa da seleção final nos oito trechos e dois níveis fixados;
4. fechar o contrato de distribuição autocontida, publicar uma versão imutável e então criar o tap Homebrew; Homebrew ficará como um dos canais, não como dependência arquitetural.
