# Protocolo de avaliação multi-fidelidade

Este documento transforma a discussão metodológica em um contrato implementável. Ele evita duas conclusões indevidas: que o GM sozinho representa todo o comportamento dinâmico e que uma única métrica perceptual decide qual circuito é melhor.

## Objetivo

A otimização deve encontrar compromissos entre segurança elétrica, desempenho convencional e qualidade percebida em programa musical. Métricas caras não precisam ser executadas para toda a população, mas um candidato só pode entrar na frente de Pareto **validada** quando estiver eletricamente viável e tiver todas as métricas exigidas.

## Camadas de avaliação

| Camada | Candidatos | Avaliação | Estado |
|---|---|---|---|
| Preflight | todos | limites dos parâmetros, simetria, VAA e futuras restrições SOA | parcial; SOA ainda pendente |
| Triagem elétrica | todos os viáveis | potência, slew rate, uniformidade em frequência e GM-Crowe; THD diagnóstica | implementada em LTspice e ngspice |
| Shortlist | representantes da frente | Pareto/crowding para inspeção e próxima etapa, sem nova simulação elétrica | implementado |
| Programa musical | amostra online e shortlist final | ViSQOLAudio primário e GstPEAQ de confirmação em dois níveis fixos | implementado e testado no ngspice |
| Subjetiva | finalistas | WebMUSHRA com as mesmas oito referências da validação objetiva | planejada |

O GM continua útil por ser leve, historicamente comparável e psicoacusticamente motivado. GM-Crowe entra em todo candidato da campanha multiobjetivo como quarto eixo; GM-Legacy permanece nas referências escalares DE/PSO/SAM e em ablações históricas. Como ambos operam sobre uma resposta sem comparar explicitamente estados anteriores do circuito, o programa os declara com `captures_memory: no`.

## Níveis e convergência do GM

As métricas elétricas de operação normal continuam usando `−10 dBV` (`0,316227766 V RMS`). O GM-Crowe não reutiliza esse transiente: ele possui uma análise separada de `1 V` de pico (`0,707106781 V RMS`, `−3,0103 dBV`), exatamente o limite superior da escada de amplitudes do GM-Legacy. Isso iguala o intervalo de entrada sem substituir o nível nominal de potência, ganho e THD.

A reconstrução espectral não fixa mais H20. Ela calcula uma única FFT e avalia ordens crescentes declaradas na configuração. A execução converge somente depois de duas mudanças relativas consecutivas de no máximo `0,5%`; se atingir H400 sem cumprir a regra, preserva o resultado para diagnóstico com `converged: false`. O passo temporal é derivado do número de amostras por ciclo para que a maior ordem configurada seja resolvível.

Esse ensaio continua sendo estático em regime permanente. O nível mais alto percorre uma região mais curva de `T(x)`, mas não transforma GM em medida completa da dinâmica. Essa limitação é coberta na validação posterior: o programa musical inteiro atravessa a simulação transiente do circuito antes do cálculo de ViSQOL e GstPEAQ.

## Programa musical

As músicas não são escolhidas por gênero ou preferência, mas pelas propriedades que exercitam o circuito. O corpus deve cobrir:

- ataques percussivos;
- grave sustentado;
- instrumento harmônico sustentado;
- voz;
- mix denso;
- alto fator de crista;
- transição de trecho forte para fraco.

Os papéis são cumulativos. Quatro itens `development` formam o conjunto sentinela online; oito itens `validation` formam o conjunto objetivo final; os mesmos oito IDs recebem `subjective` e serão usados no WebMUSHRA. Um contrato versionado exige as cardinalidades `4/8/8`, igualdade exata entre validação e subjetivo e inclusão dos quatro online no conjunto final. Início, duração, canal, categorias, fonte, condições de uso e SHA-256 são explícitos. Arquivos licenciados ficam fora do Git; manifesto e lock de hashes são versionados.

O conjunto inicial usa nove trechos de 12 segundos do EBU SQAM Tech 3253. Os quatro sentinelas online são: castanholas para ataques esparsos/baixa mascaragem, contrabaixo para grave sustentado, Strauss para textura densa/banda larga e Schubert para a transição forte–fraco. Cravo, soprano, Baird e ABBA completam os oito finais. Eddie Rabbitt fica como reserva por ser o caso mais redundante com o pop denso do ABBA. O material foi criado para avaliação subjetiva e seu uso é restrito a P&D não comercial.

O reuso dos quatro sentinelas dentro dos oito finais é aceitável nesta primeira campanha porque os resultados online só estimam custo e correlação e não alteram mutação, sobrevivência ou escolha de parâmetros. Se no futuro a métrica perceptual passar a orientar a busca, treinar um surrogate ou ajustar o protocolo de forma adaptativa, será obrigatório criar um conjunto final realmente não visto.

`sonya corpus prepare` gera referências mono PCM16/48 kHz para audição. Para as gravações estéreo do SQAM é escolhido o canal esquerdo declarado, sem soma L+R, conforme a observação técnica da própria coleção. O processamento aplica remoção de DC, fades de 10 ms e somente ganho escalar por RMS ativo com proteção de pico; não aplica equalização nem compressão. O lock versionável fixa SHA-256 do original, intervalo, canal, parâmetros de processamento e SHA-256 do WAV canônico.

Os mesmos oito WAVs canônicos da validação final serão preservados como referências do WebMUSHRA. O exportador subjetivo deverá criar IDs cegos somente para as condições processadas, manter referência oculta e âncoras separadas, e registrar o mapeamento em arquivo não servido aos participantes. O pacote de áudio continuará fora do Git e sua distribuição deverá respeitar as condições do SQAM.

Cada trecho é processado uma vez em cada nível fixo:

- `nominal`: `0,447213595 Vpk`, pico equivalente a um seno de `−10 dBV`;
- `limit`: `1 Vpk`, limite superior histórico dos ensaios GM, sem alegar que seja o limiar de clipping de todo candidato.

O ajuste é puramente escalar e preserva o fator de crista. Como o estímulo ngspice é PWL com interpolação linear, seus segmentos não ultrapassam os extremos amostrados; o executor ainda verifica o pico da entrada exportada e falha se ele divergir do manifesto. As métricas são agregadas separadamente por nível e o relatório calcula `limit_minus_nominal`.

ViSQOLAudio é o objetivo perceptual primário por atender áudio genérico e ser operacionalmente acessível. GstPEAQ básico e avançado entram como confirmações, não como novos eixos da frente: isso evita inflar artificialmente a dimensionalidade com estimadores correlacionados. A implementação GstPEAQ declara que não satisfaz as tolerâncias de conformidade da recomendação, portanto seus ODGs não são chamados de PEAQ normativo. As métricas não isolam nem nomeiam mecanismos de memória; elas avaliam a degradação perceptual da forma de onda completa, incluindo as consequências de todo comportamento dependente do tempo que o modelo do circuito represente. Efeitos ausentes do modelo — como histerese, sag de fonte ou deriva térmica não modelados — exigem melhorar o modelo ou validar hardware, não um objetivo abstrato separado. PESQ e STOI foram excluídos do protocolo principal porque seu domínio é fala.

Os adaptadores trabalham com pares mono a 48 kHz. A referência é o próprio sinal de entrada declarado; a saída simulada é alinhada no tempo e recebe somente um ajuste escalar de nível ativo. Não há equalização inversa, portanto alterações de resposta em frequência, distorção e dinâmica permanecem na comparação. Depois do ajuste, uma escala comum evita clipping nos dois WAVs. Versões, comandos, atraso, ganho aplicado, hashes e proveniência devem acompanhar cada resultado.

### Amostragem ativa e validação final

Avaliar um candidato a cada dez iterações não respeita o custo real quando há vários trechos e níveis. A política implementada usa um processo estocástico reprodutível apenas entre candidatos das primeiras frentes de dominância. Sua taxa básica é `ln(2) / H`, em que `H` é a meia-vida em candidatos; primeira frente e novidade no espaço normalizado de objetivos aumentam a probabilidade. Seed, probabilidade, sorteio e justificativa ficam no relatório.

Baseline e extremos de cada objetivo são obrigatórios. O processo reserva suas vagas e seu tempo antes de aceitar amostras opcionais. Há dois limites rígidos: número máximo de candidatos e orçamento de tempo calculado a partir de um custo empírico por candidato. Nesta primeira etapa, os resultados online medem custo e correlação, mas não influenciam seleção, mutação ou sobrevivência do otimizador.

Terminada a busca, a validação não é aleatória. A primeira frente é comprimida em células epsilon no espaço normalizado, preservando extremos e diversidade, e recebe um número declarado de candidatos próximos à frente. Todos os finalistas resultantes são avaliados no corpus de validação. Somente depois de haver dados suficientes será aceitável treinar um surrogate perceptual, sempre com incerteza e auditoria separadas.

## Algoritmos, orçamento e shortlist

NSGA-II é o algoritmo principal. GDE3 é a segunda heurística multiobjetivo e serve para verificar a cobertura da frente com um mecanismo evolutivo diferente. Na triagem, ambos mantêm potência, slew rate, variação da resposta e GM-Crowe como objetivos separados, sem pesos arbitrários. THD continua calculada como diagnóstico. A análise GedLee legada continua fora desse laço.

A Differential Evolution `DE/rand/1/bin` também está implementada, mas permanece escalar: usa o score histórico como baseline moderno para ablação e para futura identificação dos parâmetros do transformador. PSO e SAM continuam como referências históricas. DE, PSO e SAM não recebem métricas musicais dentro do laço e não são usados para definir sozinhos a frente perceptual.

Comparações usam orçamento de **candidatos de circuito únicos**, não gerações. O relatório registra também o número real de execuções do simulador, porque a calibração de potência comum e as fidelidades adicionais podem exigir mais de uma execução por candidato.

O shortlist já é explícito. Para NSGA-II e GDE3, seleciona primeiro candidatos não dominados e usa distância de crowding para preservar diversidade; se o número solicitado exceder a primeira frente, percorre as frentes seguintes. Para DE/PSO/SAM, destaca os menores scores históricos. O número é dado por `--promote` por compatibilidade da CLI, mas essa opção não dispara mais GM-Crowe nem outra simulação: todos os candidatos já possuem os quatro objetivos elétricos — potência, slew rate, uniformidade e GM-Crowe.

Todos os estágios compartilham um arquivo JSONL somente-acréscimo. A chave inclui parâmetros, backend, topologia, protocolo e hashes de configuração, circuito e modelos. Assim, uma continuação com `--archive` reutiliza resultados idênticos, mas uma mudança relevante invalida o cache.

O backend é fixado durante uma campanha; resultados LTspice e ngspice não são misturados numa mesma frente antes de uma validação de equivalência.

Para um conjunto de objetivos, um candidato entra no cálculo da frente apenas se:

- passou todas as restrições duras disponíveis;
- tem valor finito para cada objetivo declarado;
- foi avaliado no mesmo simulador, versões de modelo e corpus da campanha;
- possui proveniência suficiente para repetir o resultado.

Um candidato é removido da frente se outro for pelo menos tão bom em todos os objetivos e estritamente melhor em um deles. A função `sonya.programme.pareto_front` já implementa essa regra e ignora registros inviáveis ou incompletos.

A execução atual produz uma **frente elétrica 4D** durante a própria busca, com potência, slew rate, uniformidade em frequência e GM-Crowe. THD permanece no relatório como diagnóstico, sem alterar a dominância. O relatório reserva ainda uma **frente perceptual de validação** e uma **frente cientificamente validada**. Elas não são preenchidas por aproximação: exigem uma campanha completa no corpus de validação; a frente científica exige adicionalmente SOA dinâmica comprovada.

O cálculo registra uma auditoria por candidato. A frente perceptual exige `programme_validation_split`, `perceptual_adapter_versions` e `reproducible_provenance`. Para avançar à frente cientificamente validada, o registro deve comprovar também `dynamic_soa_validated` e possuir todos os objetivos elétricos e perceptuais. Isso impede que o ajuste no conjunto de desenvolvimento seja reapresentado como validação perceptual e que uma boa pontuação musical esconda uma lacuna de segurança.

## Contrato já disponível na CLI

```bash
sonya objective list
sonya evaluation plan
sonya evaluation corpus
sonya perceptual doctor
sonya perceptual benchmark ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --duration 0.5 --projection-duration 5
sonya perceptual validate ./outputs/minha-campanha/campaign.json \
  --selection final --role validation
sonya optimize campaign ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --algorithm nsga2 --backend ngspice --vary X1 \
  --budget 8 --population-size 4 --promote 2

sonya optimize campaign ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --algorithm gde3 --backend ngspice --vary X1 \
  --budget 8 --population-size 4 --promote 2 \
  --mutation-factor 0.8 --crossover-probability 0.9
```

O plano vem de `configs/programme.yaml`. Seleção, referências canônicas e níveis estão prontos e `evaluation corpus` os valida antes da execução. `perceptual doctor` verifica as ferramentas externas sem torná-las dependências obrigatórias da simulação, e `perceptual sample` permite recalcular a política de seleção a partir de um relatório de campanha.

## Decisões ainda necessárias

- confirmar por audição que os oito trechos fixados não contêm artefatos inadequados ao teste;
- empacotar de forma reproduzível as versões fixadas do ViSQOL e GstPEAQ nos ambientes de execução;
- validar no Linux o alinhamento, o ajuste escalar de nível e o tratamento de clipping já implementados;
- calibrar orçamento, tamanho da população e quantidade promovida numa campanha piloto maior;
- desenhar o ensaio subjetivo e o número de ouvintes.
