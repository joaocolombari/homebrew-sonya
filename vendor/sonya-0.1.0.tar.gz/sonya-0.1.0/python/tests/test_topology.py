from pathlib import Path
import shutil

import pytest

from sonya.manifest_optimization import optimize_manifest
from sonya.topology import create_topology_scaffold, execute_staged_topology, load_topology_manifest, stage_topology


ROOT = Path(__file__).resolve().parents[2]


def test_real_topology_stages_without_personal_paths(tmp_path) -> None:
    manifest = load_topology_manifest(ROOT / "python/configs/topologies/gagabiro_el84.yaml")
    assert manifest.diagram is not None and manifest.diagram.name == "gagabiro-el84-circuit.png"
    staged = stage_topology(
        manifest,
        "ngspice",
        tmp_path / "staged",
        ROOT / "Circuits/Audio/gagabiro_el84/param_unoptimized.txt",
    )
    text = staged.circuit.read_text(encoding="utf-8")
    assert "C:\\Users" not in text
    assert ".include mje340.lib" in text
    assert ".include output_transformer.lib" in text
    assert ".include transformer_schatz_5776.inc" in text
    assert ".include koren_tubes.lib" in text
    assert ".backanno" not in text.lower()
    assert "{int(X1)" not in text
    assert staged.manifest.is_file()


def test_real_topology_uses_portable_mje340_and_transformer_models() -> None:
    manifest = load_topology_manifest(ROOT / "python/configs/topologies/gagabiro_el84.yaml")
    for backend in manifest.backends.values():
        names = {item.source.name for item in backend.dependencies}
        assert "mje340.lib" in names
        assert "output_transformer.lib" in names
        assert "transformer_schatz_5776.inc" in names
        assert "bc847c.lib" not in names
        assert "trafos.lib" not in names
    transistor = (ROOT / "python/models/mje340.lib").read_text(encoding="utf-8")
    transformer = (ROOT / "ModelsLTspice/output_transformer.lib").read_text(encoding="utf-8")
    assert ".model MJE340 NPN" in transistor
    assert ".SUBCKT OUTPUT_TRANSFORMER_UL" in transformer
    assert "LLEAK" in transformer
    assert "RPRI" in transformer


def test_real_topology_uses_the_same_open_tube_models_for_both_backends() -> None:
    manifest = load_topology_manifest(ROOT / "python/configs/topologies/gagabiro_el84.yaml")
    tube_sources = {
        backend_id: [item.source.name for item in backend.dependencies if "tube" in item.source.name]
        for backend_id, backend in manifest.backends.items()
    }
    assert tube_sources == {
        "ltspice": ["koren_tubes.lib"],
        "ngspice": ["koren_tubes.lib"],
    }
    shared_model = (ROOT / "ModelsLTspice/koren_tubes.lib").read_text(encoding="utf-8")
    legacy_entry = (ROOT / "ModelsLTspice/tubes.lib").read_text(encoding="utf-8")
    assert ".SUBCKT 12AU7" in shared_model
    assert ".SUBCKT EL84" in shared_model
    assert "encrypted file" not in legacy_entry.lower()
    assert ".SUBCKT EL84" in legacy_entry


def test_new_user_can_create_and_stage_an_independent_topology(tmp_path) -> None:
    manifest_path, circuit_path = create_topology_scaffold("my_amplifier", tmp_path / "my-amplifier")
    assert circuit_path.is_file()
    assert (manifest_path.parent / "parameters.inc").is_file()
    manifest = load_topology_manifest(manifest_path)
    staged = stage_topology(manifest, "ngspice", tmp_path / "translated")
    assert staged.circuit.is_file()
    assert (staged.working_directory / "parameters.inc").is_file()
    assert manifest.parameter_ids == ("R_TOP", "R_BOTTOM")
    assert manifest.objective is not None
    assert manifest.objective.goal == "target"


@pytest.mark.skipif(shutil.which("ngspice") is None, reason="ngspice is not installed")
def test_new_user_scaffold_runs_without_explicit_parameter_path(tmp_path) -> None:
    manifest_path, _ = create_topology_scaffold("runnable_divider", tmp_path / "topology")
    manifest = load_topology_manifest(manifest_path)
    staged = stage_topology(manifest, "ngspice", tmp_path / "run")
    execution = execute_staged_topology(staged)
    assert execution.passed


@pytest.mark.skipif(shutil.which("ngspice") is None, reason="ngspice is not installed")
def test_new_user_manifest_can_drive_a_generic_optimization(tmp_path) -> None:
    manifest_path, _ = create_topology_scaffold("optimizable_divider", tmp_path / "topology")
    manifest = load_topology_manifest(manifest_path)
    report_path = optimize_manifest(manifest, "ngspice", tmp_path / "results", vary=["R_TOP"], count=3, step=0.1)
    report = report_path.read_text(encoding="utf-8")
    assert '"winner": "baseline"' in report
    assert '"objective_value": 0.5' in report
