from pathlib import Path

from sonya.catalog import algorithm_spec, algorithm_specs, metric_specs, topology_specs
from sonya.config import load_config


ROOT = Path(__file__).resolve().parents[2]
CONFIG = load_config(ROOT / "python/configs/legacy.yaml")


def test_catalog_exposes_implemented_and_planned_algorithms() -> None:
    assert algorithm_spec("bounded_grid").status == "implemented"
    assert algorithm_spec("nsga2").multiobjective
    assert algorithm_spec("nsga2").status == "implemented"
    assert algorithm_spec("legacy_pso").status == "implemented"
    assert algorithm_spec("legacy_sam").status == "implemented"
    assert algorithm_spec("differential_evolution").status == "implemented"
    assert algorithm_spec("gde3").multiobjective
    assert algorithm_spec("gde3").status == "implemented"
    assert {item.id for item in algorithm_specs()} >= {"bounded_grid", "differential_evolution", "gde3", "nsga2", "legacy_pso", "legacy_sam"}


def test_topology_declares_backend_validation_status() -> None:
    topology = topology_specs(CONFIG)[0]
    assert topology.id == "gagabiro_el84"
    assert topology.simulator_support["ltspice"] == "validated"
    assert topology.simulator_support["ngspice"] == "experimental"


def test_metric_catalog_keeps_gm_out_of_memory_claims() -> None:
    metrics = {item.id: item for item in metric_specs()}
    assert metrics["gm_legacy"].captures_memory == "no"
    assert metrics["gm_crowe"].captures_memory == "no"
    assert metrics["gm_crowe"].status == "implemented"
    assert metrics["visqol_audio"].captures_memory == "indirect"
