from pathlib import Path

import pytest

from sonya.config import load_config
from sonya.legacy import evaluate_measurement_directory
from sonya.metrics.frequency import corrected_frequency_metrics, legacy_frequency_metrics


ROOT = Path(__file__).resolve().parents[2]
CONFIG = load_config(ROOT / "python/configs/legacy.yaml")
CASE = ROOT / "Circuits/Audio/gagabiro_el84/prototype/test_unnoptimized"


def test_real_measurement_reproduces_rounded_matlab_baseline() -> None:
    result = evaluate_measurement_directory(CASE, 300.0, CONFIG)
    assert result["gain_db"] == pytest.approx(24.65, abs=0.01)
    assert result["output_power_w"] == pytest.approx(4.74, abs=0.01)
    assert result["frequency_legacy"]["sampled_std_db"] == pytest.approx(0.76, abs=0.01)
    assert result["frequency_legacy"]["low_cutoff_hz"] == pytest.approx(11.00, abs=0.02)
    assert result["frequency_legacy"]["high_cutoff_hz"] == pytest.approx(23278.65, abs=0.1)
    assert result["slew_rate_v_per_us"] == pytest.approx(0.50, abs=0.01)
    assert result["legacy_gm"] == pytest.approx(5.69, abs=0.02)
    assert result["legacy_gm_status"] == "baseline_only"


def test_corrected_cutoff_is_kept_separate_from_legacy() -> None:
    from sonya.parsers.rew import read_rew_measurement

    response = read_rew_measurement(CASE / "AC.txt")
    targets = CONFIG.raw["legacy_evaluation"]["frequency_points_hz"]
    legacy = legacy_frequency_metrics(response.frequency_hz, response.magnitude_db, targets)
    corrected = corrected_frequency_metrics(response.frequency_hz, response.magnitude_db, targets)
    assert legacy.method.startswith("legacy_")
    assert corrected.method.startswith("corrected_")
    assert legacy.cutoff_level_db != corrected.cutoff_level_db
