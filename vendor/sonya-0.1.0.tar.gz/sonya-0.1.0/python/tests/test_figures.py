from pathlib import Path

import pytest

from sonya.figures import assert_derived_output_path


def test_figure_output_cannot_overwrite_raw_data(tmp_path: Path) -> None:
    raw = tmp_path / "raw"
    raw.mkdir()
    with pytest.raises(ValueError, match="raw-data"):
        assert_derived_output_path(raw / "figure.png", [raw])
    assert assert_derived_output_path(tmp_path / "processed/figure.png", [raw]) == (tmp_path / "processed/figure.png").resolve()
