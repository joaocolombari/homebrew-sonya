import hashlib
from pathlib import Path

import pytest

from sonya.transformer import create_transformer_profile, load_transformer_profile, render_linear_include


ROOT = Path(__file__).resolve().parents[2]


def test_pat4002_profile_separates_linear_baseline_from_identification() -> None:
    profile = load_transformer_profile(ROOT / "python/configs/transformers/pat4002.yaml")
    assert profile.linear_ready is True
    assert profile.losses_identified is False
    assert profile.nonlinear_ready is False
    rendered = render_linear_include(profile)
    assert ".param TX_LPRIM=535" in rendered
    assert ".param TX_LLEAK=0.003699606" in rendered
    assert ".param TX_RPRI=0" in rendered
    assert "losses_identified=false" in rendered


def test_new_transformer_profile_is_measurement_first_and_not_renderable(tmp_path) -> None:
    output = create_transformer_profile("my_output_transformer", tmp_path / "transformer.yaml")
    profile = load_transformer_profile(output)
    assert profile.linear_ready is False
    assert profile.nonlinear_ready is False
    with pytest.raises(ValueError, match="incomplete"):
        render_linear_include(profile)


def test_hardware_candidate_does_not_pretend_catalog_values_are_a_model() -> None:
    profile = load_transformer_profile(ROOT / "python/configs/transformers/edcor_cxpp25_6k6_8.yaml")
    assert profile.values["primary_impedance_ohm"] == 6600
    assert profile.values["secondary_impedance_ohm"] == 8
    assert profile.linear_ready is False
    assert profile.nonlinear_ready is False


def test_active_schatz_profile_separates_specification_from_surrogates() -> None:
    profile = load_transformer_profile(ROOT / "python/configs/transformers/schatz_custom_5776_4_6_8.yaml")
    assert profile.linear_ready is True
    assert profile.losses_identified is False
    assert profile.nonlinear_ready is False
    assert profile.values["primary_impedance_ohm"] == 5776
    assert profile.values["secondary_impedance_ohm"] == 6
    assert profile.statuses["primary_impedance_ohm"] == "design_specification_tcc_pdf_page_89"
    assert profile.statuses["primary_inductance_h"].startswith("surrogate_")
    assert profile.design_specification["secondary_taps_ohm"] == [4.0, 6.0, 8.0]
    assert profile.design_specification["manufacturer"] == "Schatz Transformadores"
    source_document = ROOT / str(profile.design_specification["source_document"])
    expected_hash = str(profile.design_specification["source_document_sha256"])
    assert len(expected_hash) == 64
    assert all(character in "0123456789abcdef" for character in expected_hash)
    if source_document.is_file():
        assert hashlib.sha256(source_document.read_bytes()).hexdigest() == expected_hash
    rendered = render_linear_include(profile)
    assert "primary_inductance_h.status=surrogate_from_pat4002_not_measured_on_schatz" in rendered
    assert ".param TX_ZPRI=5776" in rendered
    assert ".param TX_ZSEC=6" in rendered
    active_include = (ROOT / "Circuits/Audio/gagabiro_el84/transformer_schatz_5776.inc").read_text(
        encoding="utf-8"
    )
    for declaration in (
        "TX_LPRIM=535",
        "TX_LLEAK=3.699606m",
        "TX_ZPRI=5776",
        "TX_ZSEC=6",
        "TX_ULTAP=.4",
        "TX_CPRI=613p",
    ):
        assert declaration in active_include
    circuit = (ROOT / "Circuits/Audio/gagabiro_el84/circuit.sp").read_text(encoding="utf-8")
    assert "Rload \t0 \t\tout \t6" in circuit
    # The portable model uses LRATIO=ZSEC/ZPRI.  Loading the selected tap with
    # its nominal impedance therefore reflects exactly ZPRI at the primary.
    turns_ratio_squared = profile.values["primary_impedance_ohm"] / profile.values["secondary_impedance_ohm"]
    assert profile.values["secondary_impedance_ohm"] * turns_ratio_squared == pytest.approx(5776.0)
