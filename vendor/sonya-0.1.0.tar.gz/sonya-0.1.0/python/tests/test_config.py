from pathlib import Path
import math

import yaml

from sonya.config import load_config


ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "python/configs/legacy.yaml"


def test_real_config_is_valid_and_explicit_about_units() -> None:
    config = load_config(CONFIG)
    assert len(config.parameters) == 25
    assert all(parameter.unit for parameter in config.parameters)
    assert config.raw["legacy_evaluation"]["gm"]["status"] == "baseline_only"
    assert config.raw["legacy_evaluation"]["input_level_dbv"] == -10.0
    assert config.raw["legacy_evaluation"]["input_rms_v"] == math.pow(10.0, -10.0 / 20.0)
    assert config.raw["legacy_evaluation"]["drive"]["default_mode"] == "fixed_input"
    assert config.raw["legacy_evaluation"]["gm"]["crowe"]["input_peak_v"] == 1.0
    assert config.raw["legacy_evaluation"]["gm"]["crowe"]["harmonic_orders"][-1] == 400
    assert config.raw["future_methodology"]["gm_is_primary_objective"] is False


def test_local_ltspice_path_is_configured() -> None:
    config = load_config(CONFIG)
    assert config.simulator_executable == Path("/Applications/LTspice.app/Contents/MacOS/LTspice")
    assert config.raw["future_methodology"]["fixed_parameters"][0]["id"] == "X24"


def test_parameter_count_and_names_are_not_framework_constants(tmp_path) -> None:
    raw = yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    raw["parameters"] = [
        {"id": "R_FEEDBACK", "name": "Feedback resistor", "unit": "ohm", "minimum": 100, "maximum": 10000, "baseline": 1000}
    ]
    raw["future_methodology"]["fixed_parameters"] = []
    raw["future_methodology"]["symmetry_groups"] = []
    raw["data"]["processed_root"] = str(tmp_path / "outputs")
    raw["data"]["raw_roots"] = [str(ROOT / "Circuits")]
    raw["topologies"]["manifests"] = [str(ROOT / "python/configs/topologies/gagabiro_el84.yaml")]
    path = tmp_path / "config.yaml"
    path.write_text(yaml.safe_dump(raw), encoding="utf-8")
    config = load_config(path)
    assert [item.id for item in config.parameters] == ["R_FEEDBACK"]
