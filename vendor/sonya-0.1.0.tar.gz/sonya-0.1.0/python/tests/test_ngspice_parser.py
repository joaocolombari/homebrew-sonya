from sonya.parsers.ngspice import read_ngspice_fourier_thd, read_wrdata


def test_wrdata_parser_reads_named_finite_columns(tmp_path) -> None:
    path = tmp_path / "data.dat"
    path.write_text(" time v(out)\n 0 1\n 1e-3 2\n", encoding="utf-8")
    names, values = read_wrdata(path)
    assert names == ("time", "v(out)")
    assert values.shape == (2, 2)
    assert values[-1, -1] == 2.0


def test_ngspice_fourier_parser() -> None:
    log = "Fourier analysis for v(out): No. Harmonics: 10, THD: 1.35124 %, Gridsize: 200"
    assert read_ngspice_fourier_thd(log) == 1.35124
