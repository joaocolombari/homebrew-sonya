from pathlib import Path

import numpy as np

from sonya.parsers.legacy import parse_spice_number, read_legacy_parameters, read_legacy_results
from sonya.parsers.ltspice import read_raw, read_raw_header
from sonya.parsers.rew import read_rew_measurement, read_rew_scope, read_rew_thd


ROOT = Path(__file__).resolve().parents[2]
PROTOTYPE = ROOT / "Circuits/Audio/gagabiro_el84/prototype"
FIXTURES = Path(__file__).resolve().parent / "fixtures"


def test_frequency_parser_reads_real_rew_export() -> None:
    measurement = read_rew_measurement(PROTOTYPE / "test_unnoptimized/AC.txt")
    assert measurement.frequency_hz.size > 10_000
    assert np.isclose(measurement.frequency_hz[0], 0.366211)
    assert np.isclose(measurement.magnitude_db[0], -13.230)
    assert np.isclose(measurement.phase_deg[0], -84.5027)


def test_scope_parser_applies_rew_voltage_scale() -> None:
    trace = read_rew_scope(PROTOTYPE / "test_unnoptimized/tran.txt")
    assert np.isclose(trace.sample_rate_hz, 48_000.0, rtol=1e-9)
    assert np.isclose(trace.voltage_v[0], -0.4453125 / 0.06568572050037597)


def test_thd_parser_reads_harmonics_from_real_export() -> None:
    path = FIXTURES / "stepped-thd-focusrite.txt"
    table = read_rew_thd(path)
    assert table.data.shape == (13, 15)
    assert np.isclose(table.column("thd_percent")[0], 1.47)
    assert np.isclose(table.column("h2_percent")[-1], 0.0014)


def test_legacy_parameter_and_result_readers() -> None:
    parameters = read_legacy_parameters(FIXTURES / "legacy-param.txt")
    results = read_legacy_results(FIXTURES / "measurement-results.txt")
    assert len(parameters) == 25
    assert np.isclose(parameters["X24"], 298.82)
    assert results["legacy_gm"] == 5.69
    assert results["thd_percent"] == 0.85


def test_spice_suffixes_are_not_silently_dropped() -> None:
    parameters = read_legacy_parameters(ROOT / "Circuits/Audio/gagabiro_el84/param_unoptimized.txt")
    assert parameters["X2"] == 150_000
    assert parameters["X11"] == 1_000_000
    assert parse_spice_number("10m") == 0.01


def test_historical_simulation_summary_reader_handles_portuguese_thd_label() -> None:
    result = read_legacy_results(FIXTURES / "paramop-initial.txt")
    assert result["thd_percent"] == 0.636159
    assert result["legacy_gm"] == 5.54


def test_real_ltspice_raw_header_is_read_without_loading_waveforms() -> None:
    header = read_raw_header(FIXTURES / "circuit-baseline.raw")
    assert header.plot_name == "Transient Analysis"
    assert header.variable_count == 2
    assert header.point_count == 9737
    assert header.variables == (("time", "time"), ("V(out)", "voltage"))
    assert header.payload_format == "binary"


def test_real_ltspice_raw_binary_waveform_is_decoded() -> None:
    raw = read_raw(FIXTURES / "circuit-baseline.raw")
    assert raw.values["time"].shape == (9737,)
    assert np.isclose(raw.values["time"][0], 0.0)
    assert np.all(np.diff(raw.values["time"]) >= 0)
    assert np.all(np.isfinite(raw.values["V(out)"]))
