import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.io import wavfile

from sonya.config import load_config
from sonya.perceptual import (
    PerceptualDoctor,
    PerceptualMetricResult,
    active_rms,
    perceptual_doctors,
    prepare_excerpt,
    prepare_peak_excerpt,
    prepare_metric_pair,
    read_wav_mono,
    run_gstpeaq,
    run_visqol,
)
from sonya.perceptual_sampling import SamplingCandidate, build_sampling_plan, pareto_ranks
from sonya.perceptual_validation import (
    _input_delivery_diagnostics,
    campaign_candidates,
    run_programme_validation,
    select_programme_items,
    select_programme_levels,
)
from sonya.parsers.legacy import read_legacy_parameters
from sonya.programme import load_programme_manifest
from sonya.programme_simulation import (
    _write_ltspice_programme_wav,
    benchmark_signal,
    render_ltspice_programme_parameter_file,
    render_ngspice_programme_parameter_file,
)
from sonya.topology import load_topology_manifest


ROOT = Path(__file__).resolve().parents[2]


def _parameters() -> dict[str, float]:
    return read_legacy_parameters(ROOT / "Circuits/Audio/gagabiro_el84/param_unoptimized.txt")


def test_excerpt_uses_active_rms_and_declared_channel(tmp_path: Path) -> None:
    sample_rate = 48000
    stereo = np.column_stack((np.sin(2 * np.pi * 1000 * np.arange(sample_rate) / sample_rate), np.zeros(sample_rate)))
    source = tmp_path / "stereo.wav"
    wavfile.write(source, sample_rate, stereo.astype(np.float32))
    loaded_rate, mono = read_wav_mono(source, channel=0)
    excerpt = prepare_excerpt(mono, loaded_rate, 0.0, 0.5, target_rms_v=0.2, preroll_seconds=0.1)
    assert excerpt.size == round(0.6 * sample_rate)
    assert np.all(excerpt[: round(0.1 * sample_rate)] == 0)
    assert abs(active_rms(excerpt[round(0.1 * sample_rate):]) - 0.2) < 1e-6


def test_peak_excerpt_preserves_crest_factor_and_hits_declared_voltage() -> None:
    sample_rate = 48000
    source = np.array([0.0, -0.25, 0.5, -1.0, 0.25] * 9600, dtype=float)
    prepared = prepare_peak_excerpt(source, sample_rate, 1.0, 0.447213595499958, preroll_seconds=0.1)
    body = prepared[round(0.1 * sample_rate):]
    assert np.all(prepared[: round(0.1 * sample_rate)] == 0)
    assert np.isclose(np.max(np.abs(body)), 0.447213595499958)
    source_centered = source - np.mean(source)
    assert np.isclose(np.max(np.abs(body)) / active_rms(body), np.max(np.abs(source_centered)) / active_rms(source_centered))


def test_metric_pair_aligns_and_uses_only_scalar_level_match(tmp_path: Path) -> None:
    sample_rate = 192000
    duration = 0.2
    time_axis = np.arange(round(sample_rate * duration)) / sample_rate
    reference = np.sin(2 * np.pi * 997 * time_axis) + 0.2 * np.sin(2 * np.pi * 5000 * time_axis)
    delayed = np.concatenate((np.zeros(200), 3.0 * reference[:-200]))
    pair = prepare_metric_pair(time_axis, reference, delayed, tmp_path)
    assert pair.sample_rate_hz == 48000
    assert abs(pair.delay_samples - 50) <= 1
    assert abs(pair.level_match_db + 20.0 * np.log10(3.0)) < 0.05
    assert pair.reference.is_file() and pair.degraded.is_file()
    reference_rate, reference_pcm = wavfile.read(pair.reference)
    degraded_rate, degraded_pcm = wavfile.read(pair.degraded)
    assert reference_rate == degraded_rate == 48000
    assert reference_pcm.dtype == degraded_pcm.dtype == np.int16


def test_input_delivery_uses_adaptive_grid_without_requiring_sampled_peak() -> None:
    source_rate = 48000
    source = np.array([0.0, 1.0, 0.0, -0.5, 0.0], dtype=float)
    # No simulator timestamp lands on the narrow 1 V source peak.
    simulation_time = np.array([0.0, 0.75, 1.25, 2.5, 4.0]) / source_rate
    delivered = np.interp(simulation_time, np.arange(source.size) / source_rate, source)
    diagnostics = _input_delivery_diagnostics(
        source,
        source_rate,
        simulation_time,
        delivered,
        target_peak_v=1.0,
    )
    assert diagnostics["delivered_peak_v"] == 0.75
    assert diagnostics["delivered_peak_error_relative"] == 0.25
    assert diagnostics["gain_error_relative"] < 1e-12
    assert diagnostics["waveform_error_rms_relative"] < 1e-12


def test_input_delivery_rejects_real_gain_error_on_adaptive_grid() -> None:
    source_rate = 48000
    source = np.array([0.0, 1.0, 0.0, -0.5, 0.0], dtype=float)
    simulation_time = np.array([0.0, 0.75, 1.25, 2.5, 4.0]) / source_rate
    expected = np.interp(simulation_time, np.arange(source.size) / source_rate, source)
    with np.testing.assert_raises_regex(RuntimeError, "gain error"):
        _input_delivery_diagnostics(source, source_rate, simulation_time, 0.99 * expected, 1.0)


def test_sampling_plan_is_seeded_budgeted_and_preserves_final_front() -> None:
    candidates = [
        SamplingCandidate("baseline", (0.5, 0.5)),
        SamplingCandidate("power", (0.0, 1.0)),
        SamplingCandidate("quality", (1.0, 0.0)),
        SamplingCandidate("middle", (0.4, 0.4)),
        SamplingCandidate("dominated", (0.9, 0.9)),
    ]
    assert pareto_ranks(candidates)["dominated"] > 1
    first = build_sampling_plan(
        candidates,
        half_life_candidates=5,
        seed=9,
        online_max_candidates=4,
        estimated_cost_per_candidate_seconds=10,
        wall_time_budget_seconds=40,
        final_max_candidates=4,
    )
    second = build_sampling_plan(
        candidates,
        half_life_candidates=5,
        seed=9,
        online_max_candidates=4,
        estimated_cost_per_candidate_seconds=10,
        wall_time_budget_seconds=40,
        final_max_candidates=4,
    )
    assert first.online_candidate_ids == second.online_candidate_ids
    assert {"baseline", "power", "quality"} <= set(first.online_candidate_ids)
    assert first.estimated_online_cost_seconds <= 40
    assert "dominated" not in first.final_candidate_ids


def test_sampling_plan_reserves_late_mandatory_extreme() -> None:
    candidates = [
        SamplingCandidate("baseline", (0.5, 0.5)),
        SamplingCandidate("optional", (0.4, 0.4)),
        SamplingCandidate("late-power", (0.0, 1.0)),
        SamplingCandidate("late-quality", (1.0, 0.0)),
    ]
    plan = build_sampling_plan(
        candidates,
        half_life_candidates=0.01,
        online_max_candidates=3,
        estimated_cost_per_candidate_seconds=10,
        wall_time_budget_seconds=30,
    )
    assert plan.online_candidate_ids == ("baseline", "late-power", "late-quality")


def test_optional_metric_adapters_parse_values_and_record_implementation(tmp_path: Path, monkeypatch) -> None:
    visqol = tmp_path / "visqol"
    peaq = tmp_path / "peaq"
    visqol.write_text("#!/bin/sh\necho 'ViSQOL version 3.3.3 MOS-LQO: 4.25'\n", encoding="utf-8")
    peaq.write_text("#!/bin/sh\necho 'GstPEAQ version 0.6.1 Objective Difference Grade: -0.75'\n", encoding="utf-8")
    visqol.chmod(0o755)
    peaq.chmod(0o755)
    monkeypatch.setenv("SONYA_VISQOL", str(visqol))
    monkeypatch.setenv("SONYA_GSTPEAQ", str(peaq))
    reference = tmp_path / "reference.wav"
    degraded = tmp_path / "degraded.wav"
    reference.touch()
    degraded.touch()

    doctors = {item.id: item for item in perceptual_doctors()}
    assert doctors["visqol_audio"].ready
    assert doctors["gstpeaq_odg"].conformance == "open_implementation_not_bs1387_tolerance_conformant"
    assert run_visqol(reference, degraded).value == 4.25
    advanced = run_gstpeaq(reference, degraded, "advanced")
    assert advanced.value == -0.75
    assert "--advanced" in advanced.command


def test_programme_netlists_reference_external_audio_and_high_rate_transient() -> None:
    waveform = benchmark_signal(48000, 0.01)
    rendered = render_ngspice_programme_parameter_file(_parameters(), waveform, 48000, 192000)
    assert "Aprogramme %vd([V_in 0]) programme_source" in rendered
    assert 'filesource(file="programme-input.txt"' in rendered
    assert "wrdata sonya-programme.dat V(out) V(V_in)" in rendered
    assert "tran 5.20833333333333e-06" in rendered
    assert rendered.count("\n+") == 0
    rendered_lt = render_ltspice_programme_parameter_file(_parameters(), waveform, 48000, 192000)
    assert 'V5 V_in 0 wavefile="programme-input.wav" chan=0' in rendered_lt
    assert ".save V(out) V(V_in)" in rendered_lt
    assert ".options reltol=0.001 plotwinsize=0" in rendered_lt
    assert ".tran 0 0.00997916666666667 0 5.20833333333333e-06" in rendered_lt


def test_ltspice_programme_wav_preserves_declared_voltage_scale(tmp_path: Path) -> None:
    source = np.array([-1.0, -0.447213595499958, 0.0, 0.447213595499958, 1.0])
    path = _write_ltspice_programme_wav(tmp_path / "programme-input.wav", source, 48000)
    sample_rate, pcm = wavfile.read(path)
    restored = pcm.astype(float) / np.iinfo(np.int16).max
    assert sample_rate == 48000
    assert pcm.dtype == np.int16
    assert np.allclose(restored, source, atol=1.0 / np.iinfo(np.int16).max)


def test_validation_levels_and_campaign_selection_are_explicit(tmp_path: Path) -> None:
    manifest_path = tmp_path / "levels.yaml"
    manifest_path.write_text("""schema_version: 1
status: draft
selection: {required_categories: []}
evaluation:
  levels:
    - {id: nominal, description: nominal, calibration_status: ready, amplitude_kind: peak_v, target_peak_v: 0.447213595499958}
    - {id: limit, description: limit, calibration_status: ready, amplitude_kind: peak_v, target_peak_v: 1.0}
  metrics: {primary: visqol_audio, secondary: []}
items: []
""", encoding="utf-8")
    manifest = load_programme_manifest(manifest_path)
    assert [item.id for item in select_programme_levels(manifest)] == ["nominal", "limit"]
    assert [item.target_peak_v for item in select_programme_levels(manifest, ["limit"])] == [1.0]
    campaign = {
        "perceptual_sampling": {"final_candidate_ids": ["b", "a"]},
        "screening": {"records": [
            {"candidate_id": "a", "values": {"X1": 1.0}},
            {"candidate_id": "b", "values": {"X1": 2.0}},
        ]},
    }
    assert [item["candidate_id"] for item in campaign_candidates(campaign, "final")] == ["b", "a"]


def test_programme_items_can_select_a_reproducible_subset() -> None:
    programme = load_programme_manifest(ROOT / "python/configs/programme.yaml")
    selected = select_programme_items(programme, "development", ["sqam-castanets"])
    assert [item.id for item in selected] == ["sqam-castanets"]
    with np.testing.assert_raises_regex(ValueError, "not declared for role"):
        select_programme_items(programme, "development", ["sqam-soprano"])


def test_programme_validation_executes_declared_shortlist(tmp_path: Path, monkeypatch) -> None:
    sample_rate = 48000
    audio = np.sin(2 * np.pi * 997 * np.arange(sample_rate) / sample_rate).astype(np.float32)
    audio_path = tmp_path / "voice.wav"
    wavfile.write(audio_path, sample_rate, audio)
    digest = hashlib.sha256(audio_path.read_bytes()).hexdigest()
    programme_path = tmp_path / "programme.yaml"
    programme_path.write_text(
        f"""schema_version: 1
status: ready
selection:
  required_categories: [voice]
evaluation:
  levels:
    - {{id: nominal, description: nominal, calibration_status: ready, amplitude_kind: peak_v, target_peak_v: 0.447213595499958}}
  metrics:
    primary: visqol_audio
    secondary: [gstpeaq_basic_odg, gstpeaq_advanced_odg]
items:
  - id: voice
    path: voice.wav
    role: validation
    categories: [voice]
    start_seconds: 0
    duration_seconds: 0.1
    sha256: {digest}
    canonical_path: voice.wav
    canonical_sha256: {digest}
""",
        encoding="utf-8",
    )
    campaign_path = tmp_path / "campaign.json"
    failed_parameters = _parameters()
    failed_parameters["X1"] = 69.0
    campaign_path.write_text(json.dumps({
        "topology": "gagabiro_el84",
        "simulator_backend": "ngspice",
        "perceptual_sampling": {"final_candidate_ids": ["failed", "candidate"]},
        "screening": {"records": [
            {"candidate_id": "failed", "values": failed_parameters},
            {"candidate_id": "candidate", "values": _parameters()},
        ]},
    }), encoding="utf-8")
    config = load_config(ROOT / "python/configs/legacy.yaml")
    topology = load_topology_manifest(ROOT / "python/configs/topologies/gagabiro_el84.yaml")

    def fake_simulation(_config, _topology, _parameters, waveform, input_rate, _simulation_rate, output_root, **_kwargs):
        if _parameters["X1"] == 69.0:
            raise RuntimeError("intentional simulator failure")
        time_axis = np.arange(waveform.size) / input_rate
        return {
            "time": time_axis,
            "input": 0.9999 * waveform,
            "output": 2.0 * waveform,
            "elapsed_seconds": 0.01,
            "working_directory": str(output_root),
        }

    doctors = (
        PerceptualDoctor("visqol_audio", "/fake/visqol", True, True, "1", "fake", "test", {}),
        PerceptualDoctor("gstpeaq_odg", "/fake/peaq", True, True, "1", "fake", "test", {}),
    )
    monkeypatch.setattr(
        "sonya.perceptual_validation.run_programme",
        lambda _backend, *args, **kwargs: fake_simulation(*args, **kwargs),
    )
    monkeypatch.setattr("sonya.perceptual_validation.perceptual_doctors", lambda: doctors)
    monkeypatch.setattr(
        "sonya.perceptual_validation.run_visqol",
        lambda *_args: PerceptualMetricResult("visqol_audio", 4.2, "MOS-LQO", (), "fake", "1", "", ""),
    )
    monkeypatch.setattr(
        "sonya.perceptual_validation.run_gstpeaq",
        lambda *_args: PerceptualMetricResult(f"gstpeaq_{_args[-1]}_odg", -0.5, "ODG", (), "fake", "1", "", ""),
    )
    report_path = run_programme_validation(
        config,
        topology,
        campaign_path,
        load_programme_manifest(programme_path),
        tmp_path / "output",
        level_ids=["nominal"],
    )
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert report["status"] == "perceptual_validation_complete_with_failures"
    assert report["case_count"] == 1
    assert report["failed_case_count"] == 1
    assert report["failures"][0]["candidate_id"] == "failed"
    assert report["candidate_records"][0]["feasible"] is False
    assert np.isclose(report["cases"][0]["input_target_peak_v"], 0.447213595499958)
    assert np.isclose(report["cases"][0]["input_delivered_peak_v"], 0.9999 * 0.447213595499958)
    assert np.isclose(report["cases"][0]["input_peak_error_relative"], 1e-4)
    assert report["candidate_records"][1]["metrics"] == {
        "gstpeaq_advanced_odg": -0.5,
        "gstpeaq_basic_odg": -0.5,
        "visqol_audio": 4.2,
    }
    assert report["candidate_records"][1]["metric_statistics"]["visqol_audio"] == {
        "mean": 4.2,
        "minimum": 4.2,
        "maximum": 4.2,
        "standard_deviation": 0.0,
        "sample_count": 1,
    }
    assert report["scientific_scope"] == "validation"
    assert report["perceptual_pareto_audit"]["front_candidate_ids"] == ["candidate"]
