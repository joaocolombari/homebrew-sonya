from pathlib import Path

import pytest

from sonya.config import load_config
from sonya.feasibility import evaluate_parameter_constraints
from sonya.parsers.legacy import read_legacy_parameters
from sonya.scoring import legacy_score, legacy_score_breakdown


ROOT = Path(__file__).resolve().parents[2]
CONFIG = load_config(ROOT / "python/configs/legacy.yaml")


def test_legacy_score_reproduces_matlab_summary_components() -> None:
    values = {
        "vaa_v": 300.0,
        "gain_db": 29.47,
        "output_power_w": 13.51,
        "frequency_std_db": 0.21,
        "low_cutoff_hz": 9.04,
        "high_cutoff_hz": 48388.1,
        "slew_rate_v_per_us": 4.39,
        "gm_legacy": 5.54,
    }
    parts = legacy_score_breakdown(values, CONFIG.raw["legacy_evaluation"]["score_specs"])
    assert parts["vaa_v"] == pytest.approx(0.9231, abs=0.001)
    assert parts["output_power_w"] == pytest.approx(0.4967, abs=0.001)
    assert parts["gm_legacy"] == pytest.approx(6.08, abs=0.01)
    assert sum(parts.values()) == pytest.approx(8.058, abs=0.02)
    assert legacy_score(15, "> 15 5") == 0


def test_symmetry_is_a_hard_parameter_check() -> None:
    baseline = read_legacy_parameters(ROOT / "Circuits/Audio/gagabiro_el84/param_unoptimized.txt")
    feasible, results = evaluate_parameter_constraints(
        baseline,
        CONFIG.parameters,
        CONFIG.raw["future_methodology"]["symmetry_groups"],
        CONFIG.raw["future_methodology"]["fixed_parameters"],
    )
    assert feasible
    broken = dict(baseline)
    broken["X5"] *= 1.1
    feasible, results = evaluate_parameter_constraints(
        broken,
        CONFIG.parameters,
        CONFIG.raw["future_methodology"]["symmetry_groups"],
        CONFIG.raw["future_methodology"]["fixed_parameters"],
    )
    assert not feasible
    assert any(result.name == "symmetry_X4_X5" and not result.feasible for result in results)


def test_main_comparison_fixes_vaa_to_300_v() -> None:
    parameters = read_legacy_parameters(ROOT / "Circuits/Audio/gagabiro_el84/param_unoptimized.txt")
    parameters["X24"] = 335.399
    feasible, results = evaluate_parameter_constraints(
        parameters,
        CONFIG.parameters,
        CONFIG.raw["future_methodology"]["symmetry_groups"],
        CONFIG.raw["future_methodology"]["fixed_parameters"],
    )
    assert not feasible
    assert any(result.name == "fixed_X24" and not result.feasible for result in results)
