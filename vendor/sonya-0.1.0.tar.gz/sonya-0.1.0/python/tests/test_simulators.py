from pathlib import Path
import shutil

import pytest

from sonya.config import load_config
from sonya.parsers.legacy import read_legacy_parameters
from sonya.simulators import NgspiceBackend, _read_ngspice_operating_point, simulator_backends


ROOT = Path(__file__).resolve().parents[2]
CONFIG = load_config(ROOT / "python/configs/legacy.yaml")


def test_simulator_registry_has_portable_and_reference_backends() -> None:
    backends = simulator_backends(CONFIG)
    assert set(backends) == {"ltspice", "ngspice"}
    assert backends["ltspice"].doctor().capabilities.legacy_topology == "validated"
    assert backends["ngspice"].doctor().capabilities.legacy_topology == "experimental"


def test_missing_ngspice_is_reported_without_crashing(monkeypatch) -> None:
    monkeypatch.setenv("SONYA_NGSPICE", "/definitely/missing/ngspice")
    report = NgspiceBackend(CONFIG).doctor()
    assert report.available is False
    assert report.ready is False


def test_ngspice_operating_point_parser_accepts_node_table() -> None:
    log = """
        Node                                  Voltage
        ----                                  -------
        out                              5.000000e-01
        in                               1.000000e+00
    """
    assert _read_ngspice_operating_point(log, "out") == 0.5


def test_ngspice_operating_point_parser_accepts_print_table() -> None:
    log = """
        Index   v(out)
        ----------------
        0       5.000000e-01
    """
    assert _read_ngspice_operating_point(log, "out") == 0.5


@pytest.mark.skipif(shutil.which("ngspice") is None, reason="ngspice is not installed")
def test_portable_topology_runs_real_ngspice_operating_point(tmp_path) -> None:
    values = read_legacy_parameters(ROOT / "Circuits/Audio/gagabiro_el84/param_unoptimized.txt")
    report = NgspiceBackend(CONFIG).run_legacy_mode(values, "op", output_root=tmp_path)
    measurements = report["measurements"]
    assert isinstance(measurements, dict)
    assert 0.060 < measurements["bplus_supply_current_a"] < 0.070
    assert 0.020 < measurements["el84a_plate_current_a"] < 0.025
    assert 0 < measurements["mje340_q1_vce_v"] < 300
    assert 0 < measurements["mje340_q2_vce_v"] < 300
    assert 0 < measurements["mje340_q1_collector_current_a"] < 0.5
    assert 0 < measurements["mje340_q2_collector_current_a"] < 0.5
