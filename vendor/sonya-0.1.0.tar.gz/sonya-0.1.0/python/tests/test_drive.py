import pytest

from sonya.drive import calibrate_input_for_output_power, dbv_to_rms, rms_to_dbv


def test_minus_10_dbv_is_consumer_line_reference() -> None:
    assert dbv_to_rms(-10.0) == pytest.approx(0.31622776601683794)
    assert rms_to_dbv(dbv_to_rms(-10.0)) == pytest.approx(-10.0)


def test_output_power_calibration_uses_actual_nonlinear_response() -> None:
    # Deliberately nonlinear: a fixed gain estimate cannot solve this exactly.
    result = calibrate_input_for_output_power(
        lambda input_rms: 80.0 * input_rms**2 + 5.0 * input_rms**4,
        target_output_power_w=10.0,
        minimum_input_rms_v=0.01,
        maximum_input_rms_v=1.0,
        relative_tolerance=1e-5,
        max_iterations=24,
    )
    assert result.converged is True
    assert result.achieved_output_power_w == pytest.approx(10.0, rel=1e-5)
    assert result.evaluations


def test_output_power_calibration_rejects_unreachable_target() -> None:
    with pytest.raises(ValueError, match="outside"):
        calibrate_input_for_output_power(lambda value: value**2, 10.0, 0.01, 1.0)
