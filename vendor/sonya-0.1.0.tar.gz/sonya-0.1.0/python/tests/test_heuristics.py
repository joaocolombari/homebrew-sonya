from __future__ import annotations

from pathlib import Path

import pytest

from sonya.campaign import CandidateArchive, candidate_cache_key
from sonya.config import ParameterSpec
from sonya.heuristics import ParameterSpace, SearchEvaluation, run_search, select_for_promotion


def _space() -> ParameterSpace:
    specs = (
        ParameterSpec("A", "A", "ohm", 0.0, 10.0, 2.0),
        ParameterSpec("B", "B", "ohm", 0.0, 10.0, 2.0),
        ParameterSpec("FIXED", "fixed", "V", 1.0, 5.0, 3.0),
    )
    return ParameterSpace(
        {"A": 2.0, "B": 2.0, "FIXED": 3.0},
        specs,
        [["A", "B"]],
        [{"id": "FIXED", "value": 3.0}],
        ["A"],
    )


def test_parameter_space_preserves_symmetry_and_fixed_values() -> None:
    space = _space()
    assert space.size == 1
    decoded = space.decode([0.75])
    assert decoded["A"] == decoded["B"] == 7.5
    assert decoded["FIXED"] == 3.0
    with pytest.raises(ValueError, match="fixed"):
        ParameterSpace(
            space.baseline,
            (
                ParameterSpec("A", "A", "ohm", 0.0, 10.0, 2.0),
                ParameterSpec("B", "B", "ohm", 0.0, 10.0, 2.0),
                ParameterSpec("FIXED", "fixed", "V", 1.0, 5.0, 3.0),
            ),
            [["A", "B"]],
            [{"id": "FIXED", "value": 3.0}],
            ["FIXED"],
        )


def test_nsga2_uses_candidate_budget_and_preserves_tradeoff() -> None:
    space = _space()

    def evaluator(values: dict[str, float]) -> SearchEvaluation:
        x = values["A"] / 10.0
        return SearchEvaluation((x * x, (1.0 - x) ** 2), None)

    result = run_search("nsga2", space, evaluator, budget=12, population_size=4, seed=7)
    assert result.candidate_evaluations == 12
    assert len(result.pareto_front) >= 2
    promoted = select_for_promotion(result, 2)
    assert len(promoted) == 2
    assert promoted[0].id != promoted[1].id


def test_gde3_uses_candidate_budget_and_preserves_tradeoff() -> None:
    space = _space()

    def evaluator(values: dict[str, float]) -> SearchEvaluation:
        x = values["A"] / 10.0
        return SearchEvaluation((x * x, (1.0 - x) ** 2), None)

    result = run_search("gde3", space, evaluator, budget=16, population_size=4, seed=7)
    assert result.candidate_evaluations == 16
    assert len(result.pareto_front) >= 2
    assert len(select_for_promotion(result, 2)) == 2


@pytest.mark.parametrize("algorithm", ["differential_evolution", "legacy_pso", "legacy_sam"])
def test_historical_scalar_algorithms_run_against_same_budget(algorithm: str) -> None:
    space = _space()

    def evaluator(values: dict[str, float]) -> SearchEvaluation:
        score = (values["A"] - 7.0) ** 2
        return SearchEvaluation((score,), score)

    result = run_search(algorithm, space, evaluator, budget=10, population_size=4, seed=3)
    assert result.candidate_evaluations == 10
    assert len(select_for_promotion(result, 1)) == 1


def test_candidate_archive_is_append_only_and_reusable(tmp_path: Path) -> None:
    path = tmp_path / "archive.jsonl"
    key = candidate_cache_key("screening", {"X1": 1.0}, {"backend": "test"})
    archive = CandidateArchive(path)
    archive.put(key, {"stage": "screening", "objectives": [1.0]})
    archive.put(key, {"stage": "replacement", "objectives": [2.0]})
    assert archive.writes == 1
    reloaded = CandidateArchive(path)
    assert reloaded.get(key) == {
        "cache_key": key,
        "objectives": [1.0],
        "stage": "screening",
    }
    assert reloaded.cache_hits == 1
