from pathlib import Path

from sonya.data import audit_data


def test_data_audit_finds_duplicates_and_manual_override(tmp_path: Path) -> None:
    raw = tmp_path / "raw"
    source = tmp_path / "source"
    raw.mkdir()
    source.mkdir()
    (raw / "a.txt").write_text("same", encoding="utf-8")
    (raw / "b.txt").write_text("same", encoding="utf-8")
    (source / "plot.m").write_text("Prms(2)=11.16;\n", encoding="utf-8")
    report = audit_data([raw], [source])
    assert report["file_count"] == 2
    assert report["duplicate_group_count"] == 1
    assert report["manual_numeric_overrides"][0]["line"] == 1

