import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pytest
from scipy.io import wavfile

from sonya.corpus import canonicalize_audio, prepare_corpus_audition, render_audition_html
from sonya.programme import load_programme_manifest


def test_canonical_audio_uses_scalar_gain_fades_and_pcm16() -> None:
    sample_rate = 48000
    time = np.arange(sample_rate) / sample_rate
    source = 0.05 + 0.1 * np.sin(2 * np.pi * 997 * time)
    result = canonicalize_audio(source, sample_rate, target_active_rms_dbfs=-20, peak_dbfs=-1, fade_seconds=0.01)
    assert result.samples.dtype == np.int16
    assert abs(result.active_rms_dbfs - (-20.0)) < 0.01
    assert result.peak_limited is False
    assert result.samples[0] == 0
    assert result.samples[-1] == 0


def test_audition_preparation_pins_source_and_canonical_hashes(tmp_path: Path) -> None:
    source = tmp_path / "source.wav"
    source.write_bytes(b"auditable source fixture")
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    manifest_path = tmp_path / "programme.yaml"
    manifest_path.write_text(
        f"""schema_version: 1
status: audition_pending_selection
selection:
  required_categories: [voice]
evaluation:
  levels:
    - {{id: nominal, description: nominal, calibration_status: pending, amplitude_kind: peak_v, target_peak_v: 0.447213595499958}}
  metrics: {{primary: visqol_audio, secondary: []}}
items:
  - id: candidate
    title: Candidate voice
    path: source.wav
    role: candidate
    categories: [voice]
    start_seconds: 0
    duration_seconds: 1
    sha256: {digest}
    source_collection: fixture
    channel: 0
""",
        encoding="utf-8",
    )

    def decode(_item, sample_rate, _ffmpeg):
        time = np.arange(sample_rate) / sample_rate
        return 0.1 * np.sin(2 * np.pi * 440 * time)

    index_path = prepare_corpus_audition(
        load_programme_manifest(manifest_path),
        tmp_path / "audition",
        ffmpeg_executable=sys.executable,
        lock_path=tmp_path / "audition.lock.json",
        decoder=decode,
    )
    index = json.loads(index_path.read_text(encoding="utf-8"))
    item = index["items"][0]
    canonical = Path(item["canonical_path"])
    assert item["source_sha256"] == digest
    assert hashlib.sha256(canonical.read_bytes()).hexdigest() == item["canonical_sha256"]
    rate, audio = wavfile.read(canonical)
    assert rate == 48000
    assert audio.dtype == np.int16
    assert (index_path.parent / "index.html").is_file()
    assert (index_path.parent / "audition.m3u").is_file()
    lock = json.loads((tmp_path / "audition.lock.json").read_text(encoding="utf-8"))
    assert lock["items"][0]["canonical_sha256"] == item["canonical_sha256"]
    assert "canonical_path" not in lock["items"][0]

    def changed_decode(_item, sample_rate, _ffmpeg):
        time = np.arange(sample_rate) / sample_rate
        return 0.1 * np.sin(2 * np.pi * 880 * time)

    with pytest.raises(ValueError, match="lock differs"):
        prepare_corpus_audition(
            load_programme_manifest(manifest_path),
            tmp_path / "audition",
            ffmpeg_executable=sys.executable,
            lock_path=tmp_path / "audition.lock.json",
            decoder=changed_decode,
        )
    assert hashlib.sha256(canonical.read_bytes()).hexdigest() == item["canonical_sha256"]


def test_audition_html_uses_stable_asset_ids() -> None:
    page = render_audition_html([{
        "id": "clip-a",
        "title": "A & B",
        "categories": ["voice"],
        "notes": "Listen <carefully>",
        "crest_factor_db": 12.5,
    }])
    assert 'src="assets/clip-a.wav"' in page
    assert "A &amp; B" in page
    assert "Listen &lt;carefully&gt;" in page
