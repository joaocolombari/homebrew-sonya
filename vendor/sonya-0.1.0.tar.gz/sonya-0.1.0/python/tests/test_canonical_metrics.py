import numpy as np
import pytest

from sonya.metrics.canonical import slew_metrics, transient_metrics
from sonya.metrics.gedlee_crowe import crowe_gedlee_adaptive, crowe_gedlee_metric, crowe_gedlee_stability
from sonya.metrics.gedlee_legacy import legacy_gedlee_metric, robust_gedlee_metric, robust_gedlee_stability


def test_transient_power_is_mean_v_squared_over_load() -> None:
    time = np.linspace(0.0, 0.02, 20001)
    output = 4.0 * np.sin(2.0 * np.pi * 1000.0 * time)
    source = np.sin(2.0 * np.pi * 1000.0 * time)
    result = transient_metrics(time, output, source, 8.0, 1000.0)
    assert result.output_rms == pytest.approx(4.0 / np.sqrt(2.0), rel=1e-5)
    assert result.output_power_w == pytest.approx(1.0, rel=1e-5)
    assert result.gain_rms == pytest.approx(4.0, rel=1e-5)
    assert result.thd_percent < 1e-6


def test_slew_uses_central_edge_fits_instead_of_one_derivative_sample() -> None:
    time = np.linspace(0.0, 0.01, 10001)
    phase = np.mod(time, 0.002)
    output = np.where(phase < 0.001, -1.0 + 2000.0 * phase, 1.0 - 2000.0 * (phase - 0.001))
    result = slew_metrics(time, output, resample_interval_s=1e-6)
    assert result.rising_v_per_s == pytest.approx(2000.0, rel=1e-3)
    assert result.falling_v_per_s == pytest.approx(-2000.0, rel=1e-3)
    assert result.slew_v_per_s == pytest.approx(2000.0, rel=1e-3)


def test_analytic_gm_does_not_use_the_legacy_integration_point_count() -> None:
    amplitudes = np.linspace(0.0, 1.0, 101)
    transfer = lambda value: value + 0.08 * value**3
    minima = transfer(-amplitudes)
    maxima = transfer(amplitudes)
    robust = robust_gedlee_metric(minima, maxima, method="cubic_analytic")
    assert robust > 0
    assert legacy_gedlee_metric(minima, maxima, interpolation_points=100) != pytest.approx(
        legacy_gedlee_metric(minima, maxima, interpolation_points=1000), rel=1e-6
    )
    assert robust_gedlee_metric(minima, maxima, method="cubic_analytic") == pytest.approx(robust, rel=1e-12)


def test_smoothed_gm_reports_stability_across_amplitude_point_counts() -> None:
    amplitudes = np.linspace(0.0, 1.0, 101)
    clean = amplitudes + 0.08 * amplitudes**3
    noise = 3e-4 * np.sin(np.arange(amplitudes.size) * 1.7)
    minima = -(clean + noise)
    maxima = clean - noise
    report = robust_gedlee_stability(
        minima,
        maxima,
        method="smoothing_spline",
        smoothing_strength=5e-4,
        strides=(1, 2, 4),
    )
    assert report["stable"] is True
    assert report["relative_span"] < 0.05


def test_crowe_gm_recovers_a_memoryless_cubic_as_chebyshev_terms() -> None:
    time = np.linspace(0.0, 0.1, 100001)
    source = np.cos(2.0 * np.pi * 1000.0 * time + 0.37)
    output = 3.2 + 7.0 * (source + 0.08 * source**3)
    result = crowe_gedlee_metric(time, output, 1000.0, harmonics=8, cycles=20)
    # x + 0.08*x^3 = 1.06*T1(x) + 0.02*T3(x); H1 is normalized to one.
    assert result.chebyshev_coefficients[1] == pytest.approx(1.0, abs=1e-12)
    assert result.chebyshev_coefficients[2] == pytest.approx(0.0, abs=1e-10)
    assert result.chebyshev_coefficients[3] == pytest.approx(0.02 / 1.06, rel=1e-8)
    assert result.value > 0
    assert result.memory_ratio < 1e-8
    assert result.fit_residual_rms_relative < 1e-10


def test_crowe_gm_uses_harmonic_phase_and_reports_quadrature() -> None:
    time = np.linspace(0.0, 0.05, 50001)
    angle = 2.0 * np.pi * 1000.0 * time
    in_phase = np.cos(angle) + 0.02 * np.cos(3.0 * angle)
    quadrature = np.cos(angle) + 0.02 * np.sin(3.0 * angle)
    static_result = crowe_gedlee_metric(time, in_phase, 1000.0, harmonics=6, cycles=20)
    dynamic_result = crowe_gedlee_metric(time, quadrature, 1000.0, harmonics=6, cycles=20)
    assert static_result.value > dynamic_result.value
    assert static_result.memory_ratio < 1e-8
    assert dynamic_result.memory_ratio > 0.99


def test_crowe_gm_reports_harmonic_order_convergence() -> None:
    time = np.linspace(0.0, 0.05, 50001)
    source = np.cos(2.0 * np.pi * 1000.0 * time)
    output = source + 0.03 * source**3
    report = crowe_gedlee_stability(time, output, 1000.0, harmonic_limits=(3, 5, 8), cycles=20)
    assert report["stable"] is True
    assert report["relative_span"] < 1e-8


def test_crowe_gm_adapts_until_two_successive_orders_converge() -> None:
    time = np.linspace(0.0, 0.05, 200001)
    source = np.cos(2.0 * np.pi * 1000.0 * time)
    output = np.tanh(1.5 * source)
    result, report = crowe_gedlee_adaptive(
        time,
        output,
        1000.0,
        harmonic_orders=(4, 8, 16, 32, 64),
        cycles=20,
        samples_per_cycle=1000,
        convergence_tolerance=0.02,
        consecutive_converged_steps=2,
    )
    assert report["converged"] is True
    assert report["selected_harmonics"] <= 64
    assert result.harmonic_orders[-1] == report["selected_harmonics"]


def test_crowe_gm_adaptive_reports_nonconvergence_at_configured_ceiling() -> None:
    time = np.linspace(0.0, 0.05, 50001)
    output = np.sign(np.cos(2.0 * np.pi * 1000.0 * time))
    result, report = crowe_gedlee_adaptive(
        time,
        output,
        1000.0,
        harmonic_orders=(3, 5, 7),
        cycles=20,
        samples_per_cycle=100,
        convergence_tolerance=1e-12,
        consecutive_converged_steps=2,
    )
    assert report["converged"] is False
    assert report["selected_harmonics"] == 7
    assert result.harmonic_orders[-1] == 7
