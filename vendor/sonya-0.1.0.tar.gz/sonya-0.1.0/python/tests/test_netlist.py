from pathlib import Path
import math

from sonya.netlist import normalise_legacy_netlist, render_legacy_parameter_file, render_ngspice_legacy_parameter_file
from sonya.parsers.legacy import read_legacy_parameters


ROOT = Path(__file__).resolve().parents[2]
PARAMETERS = read_legacy_parameters(ROOT / "Circuits/Audio/gagabiro_el84/param_unoptimized.txt")


def test_all_legacy_modes_render_with_25_parameters() -> None:
    for mode in ("op", "tran", "ac", "slew", "gedlee", "crowe"):
        rendered = render_legacy_parameter_file(PARAMETERS, mode)
        assert sum(1 for line in rendered.splitlines() if line.startswith(".param X")) == 25
        assert ".option reltol=0.001" in rendered
    operating_point = render_legacy_parameter_file(PARAMETERS, "op")
    assert "Ix(U2:P)" in operating_point
    assert "Ix(XU2:1)" not in operating_point
    assert "mje340_q1_vce_v" in operating_point
    assert "abs(Ic(Q1))" in operating_point


def test_default_transient_drive_is_exactly_minus_10_dbv() -> None:
    rendered = render_legacy_parameter_file(PARAMETERS, "tran")
    expected_peak = 10.0 ** (-10.0 / 20.0) * math.sqrt(2.0)
    assert f"SINE(0 {expected_peak:.15g} 1k)" in rendered


def test_transient_drive_can_be_overridden_for_output_power_matching() -> None:
    rendered_lt = render_legacy_parameter_file(PARAMETERS, "tran", input_rms_v=0.2)
    rendered_ng = render_ngspice_legacy_parameter_file(PARAMETERS, "tran", input_rms_v=0.2)
    expected_peak = 0.2 * math.sqrt(2.0)
    assert f"SINE(0 {expected_peak:.15g} 1k)" in rendered_lt
    assert f"SINE(0 {expected_peak:.15g} 1k)" in rendered_ng


def test_crowe_mode_uses_declared_peak_and_high_resolution_timestep() -> None:
    input_rms = 1.0 / math.sqrt(2.0)
    rendered_lt = render_legacy_parameter_file(PARAMETERS, "crowe", input_rms_v=input_rms, crowe_timestep_s=2.5e-7)
    rendered_ng = render_ngspice_legacy_parameter_file(PARAMETERS, "crowe", input_rms_v=input_rms, crowe_timestep_s=2.5e-7)
    assert "SINE(0 1 1k)" in rendered_lt
    assert ".tran 0 100m 0 2.5e-07" in rendered_lt
    assert "SINE(0 1 1k)" in rendered_ng
    assert "tran 2.5e-07 100m 0 2.5e-07" in rendered_ng


def test_gedlee_uses_runtime_time_expression_on_macos() -> None:
    rendered = render_legacy_parameter_file(PARAMETERS, "gedlee")
    assert "B2 amp 0 V=10m*ceil(time*500)-10m" in rendered
    assert "V={10m*ceil" not in rendered
    assert rendered.count(".MEAS TRAN MIN") == 101
    assert rendered.count(".MEAS TRAN MAX") == 101


def test_original_circuit_uses_portable_relative_model_paths() -> None:
    source_path = ROOT / "Circuits/Audio/gagabiro_el84/circuit.sp"
    source = source_path.read_text(encoding="utf-8")
    derived, changes = normalise_legacy_netlist(source)
    assert ":\\Users\\" not in source
    assert "../../../python/models/mje340.lib" in source
    assert "../../../ModelsLTspice/output_transformer.lib" in source
    assert "./transformer_schatz_5776.inc" in source
    assert "Q1 N013 N021 N023 \t0 MJE340" in source
    assert "../../../ModelsLTspice/koren_tubes.lib" in source
    assert ".include ../../../ModelsLTspice/koren_tubes.lib" in derived
    assert "replaced absolute Windows standard.bjt path with staged local file" not in changes
    assert source_path.read_text(encoding="utf-8") == source


def test_integer_component_wrappers_are_removed_only_in_derived_text() -> None:
    source_path = ROOT / "Circuits/Audio/gagabiro_el84/circuit.sp"
    source = source_path.read_text(encoding="utf-8")
    derived, changes = normalise_legacy_netlist(source)
    assert "{int(X1)*1R}" in source
    assert "{X1*1R}" in derived
    assert "removed legacy int() wrappers from derived component parameters" in changes
    assert source_path.read_text(encoding="utf-8") == source


def test_ngspice_adapter_exports_each_legacy_analysis() -> None:
    expected_outputs = {
        "op": "sonya-op.dat",
        "tran": "sonya-tran.dat",
        "ac": "sonya-ac.dat",
        "slew": "sonya-slew.dat",
        "gedlee": "sonya-gedlee.dat",
        "crowe": "sonya-crowe.dat",
    }
    for mode, output in expected_outputs.items():
        rendered = render_ngspice_legacy_parameter_file(PARAMETERS, mode)
        assert output in rendered
        assert ".control" in rendered
        assert rendered.count(".param X") == 25
    operating_point = render_ngspice_legacy_parameter_file(PARAMETERS, "op")
    assert "@q1[ic]" in operating_point
