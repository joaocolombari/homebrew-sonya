import pytest

from sonya.objectives import ObjectiveTerm, weighted_objective
from sonya.optimization import (
    evaluate_feasible_batch,
    evaluate_small_batch,
    generate_test_candidates,
    pipeline_test_score,
)
from sonya.config import ParameterSpec


def test_legacy_gm_cannot_become_new_objective_accidentally() -> None:
    with pytest.raises(ValueError, match="screening/baseline"):
        weighted_objective({"legacy_gm": 1.0}, [ObjectiveTerm("legacy_gm", 1.0)])
    with pytest.raises(ValueError, match="screening/baseline"):
        weighted_objective({"robust_gm": 1.0}, [ObjectiveTerm("robust_gm", 1.0)])
    with pytest.raises(ValueError, match="screening/baseline"):
        weighted_objective({"gm_legacy": 1.0}, [ObjectiveTerm("gm_legacy", 1.0)])
    with pytest.raises(ValueError, match="screening/baseline"):
        weighted_objective({"gm_crowe": 1.0}, [ObjectiveTerm("gm_crowe", 1.0)])


def test_reduced_evaluation_refuses_full_campaign() -> None:
    with pytest.raises(ValueError, match="limited"):
        evaluate_small_batch(range(9), float)


def test_infeasible_candidates_never_reach_expensive_evaluator() -> None:
    evaluated: list[int] = []

    def evaluator(candidate: int) -> float:
        evaluated.append(candidate)
        return float(candidate)

    results = evaluate_feasible_batch(
        [1, -1],
        lambda candidate: (candidate > 0, "must be positive"),
        evaluator,
    )
    assert evaluated == [1]
    assert results[0].score == 1.0
    assert results[1].score is None


def test_test_candidates_preserve_symmetry_and_fixed_parameters() -> None:
    specs = tuple(
        ParameterSpec(f"X{index}", f"P{index}", "unit", 1.0, 1000.0, 100.0)
        for index in range(1, 4)
    )
    baseline = {"X1": 100.0, "X2": 100.0, "X3": 100.0}
    candidates = generate_test_candidates(
        baseline,
        specs,
        [["X1", "X2"]],
        [{"id": "X3"}],
        ["X1"],
        count=3,
        fractional_step=0.05,
    )
    assert [item.id for item in candidates] == ["baseline", "X1_X2_minus_5pct", "X1_X2_plus_5pct"]
    assert candidates[1].values["X1"] == candidates[1].values["X2"] == 95.0
    assert all(item.values["X3"] == 100.0 for item in candidates)


def test_pipeline_score_excludes_legacy_gm() -> None:
    summary = {"legacy_score_parts": {"gain_db": 1.0, "gm_legacy": 999.0, "output_power_w": 2.0}}
    assert pipeline_test_score(summary) == 3.0
