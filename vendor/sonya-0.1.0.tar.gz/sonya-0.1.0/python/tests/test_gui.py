from importlib.resources import files
import errno
import json
from pathlib import Path
import threading
import time

import pytest

from sonya.cli import SCREENING_OBJECTIVES, build_parser
from sonya.config import load_config
from sonya.gui import JobStore, _archive_report_summary, _event_progress, _report_summary, build_campaign_command, build_perceptual_command, gui_bootstrap, serve_gui
from sonya.indicators import hypervolume, normalized_hypervolume_trace
from sonya.run_control import RunCancelled, RunControl


ROOT = Path(__file__).resolve().parents[2]
CONFIG = load_config(ROOT / "python/configs/legacy.yaml")
PROGRAMME = ROOT / "python/configs/programme.yaml"
PARAMETERS = ROOT / "Circuits/Audio/gagabiro_el84/param_unoptimized.txt"


def test_gui_bootstrap_uses_existing_catalogs_and_complete_programme() -> None:
    report = gui_bootstrap(CONFIG, PROGRAMME, inspect_tools=False)
    assert report["project"]["default_topology"] == "gagabiro_el84"
    assert report["project"]["default_parameter_file"] == str(PARAMETERS)
    assert report["campaign_algorithm_ids"] == [
        "differential_evolution",
        "gde3",
        "legacy_pso",
        "legacy_sam",
        "nsga2",
    ]
    assert report["programme"]["protocol_ready"] is True
    assert report["programme"]["item_count"] == 9
    assert report["topologies"][0]["diagram"].endswith("gagabiro-el84-circuit.png")
    assert report["result_metrics"]["slew_rate_v_per_us"]["unit"] == "V/µs"
    assert [item["id"] for item in report["metrics_by_tier"]["programme"]] == [
        "visqol_audio",
        "gstpeaq_basic_odg",
        "gstpeaq_advanced_odg",
    ]
    assert SCREENING_OBJECTIVES == (
        "maximize_output_power_w",
        "maximize_slew_rate_v_per_us",
        "minimize_frequency_std_db",
        "minimize_gm_crowe",
    )


def test_gui_builds_a_shell_free_campaign_command(tmp_path: Path) -> None:
    command, normalized = build_campaign_command(
        {
            "topology": "gagabiro_el84",
            "backend": "ngspice",
            "algorithm": "gde3",
            "parameters_path": str(PARAMETERS),
            "vary": ["X1"],
            "budget": 8,
            "population_size": 4,
            "promote": 2,
            "seed": 7,
            "mutation_factor": 0.7,
            "crossover_probability": 0.85,
            "drive_mode": "fixed_input",
            "parameter_bounds": {"X1": {"minimum": 50, "maximum": 120}},
        },
        CONFIG,
        PROGRAMME,
        tmp_path / "output",
        python_executable="/usr/bin/python3",
    )
    assert command[:3] == ["/usr/bin/python3", "-m", "sonya.cli"]
    assert command[command.index("--algorithm") + 1] == "gde3"
    assert command[-2:] == ["--vary", "X1"]
    assert normalized["multiobjective"] is True
    assert normalized["gm_crowe_every_candidate"] is True
    assert normalized["estimated_simulator_runs_lower_bound"] == 40
    assert normalized["perceptual_sampling"]["half_life_candidates"] == 50.0
    assert command[command.index("--perceptual-online-max") + 1] == "10"
    assert normalized["parameter_bounds"]["X1"] == {"minimum": 50.0, "maximum": 120.0}
    assert command[command.index("--parameter-bound") + 1] == "X1:50.0:120.0"


def test_gui_accepts_localized_gde3_factor_and_control_files(tmp_path: Path) -> None:
    command, normalized = build_campaign_command(
        {
            "backend": "ngspice",
            "algorithm": "gde3",
            "parameters_path": str(PARAMETERS),
            "budget": 4,
            "population_size": 4,
            "promote": 1,
            "mutation_factor": "0,8",
        },
        CONFIG,
        PROGRAMME,
        tmp_path / "output",
        control_path=tmp_path / "control.json",
        event_path=tmp_path / "events.jsonl",
    )
    assert normalized["mutation_factor"] == 0.8
    assert command[command.index("--control-file") + 1].endswith("control.json")
    assert command[command.index("--event-log") + 1].endswith("events.jsonl")


def test_gui_reports_an_existing_listener_without_traceback(tmp_path: Path, monkeypatch, capsys) -> None:
    def occupied(*_args, **_kwargs):
        raise OSError(errno.EADDRINUSE, "Address already in use")

    monkeypatch.setattr("sonya.gui.SonyaGuiServer", occupied)
    status = serve_gui(CONFIG, PROGRAMME, port=8765, open_browser=False, state_root=tmp_path)
    assert status == 2
    message = capsys.readouterr().err
    assert "porta 8765 já está em uso" in message
    assert "sonya gui --port 8766" in message


def test_gui_builds_explicit_post_selection_perceptual_command(tmp_path: Path) -> None:
    campaign = tmp_path / "campaign.json"
    campaign.write_text(json.dumps({
        "simulator_backend": "ngspice",
        "perceptual_sampling": {
            "online_candidate_ids": ["online-a"],
            "final_candidate_ids": ["final-a", "final-b"],
        },
    }), encoding="utf-8")
    command, normalized = build_perceptual_command(
        {
            "selection": "final",
            "role": "validation",
            "programme_items": ["sqam-double-bass", "sqam-castanets"],
            "levels": ["nominal", "limit"],
            "metric": "all",
            "peaq_model": "both",
        },
        CONFIG,
        PROGRAMME,
        campaign,
        tmp_path / "perceptual",
        python_executable="/usr/bin/python3",
    )
    assert command[:3] == ["/usr/bin/python3", "-m", "sonya.cli"]
    assert command[3:5] == ["--config", str(CONFIG.source)]
    assert command.count("--level") == 2
    assert normalized["candidate_ids"] == ["final-a", "final-b"]
    assert normalized["programme_item_ids"] == ["sqam-double-bass", "sqam-castanets"]
    assert normalized["programme_item_count"] == 2
    assert normalized["estimated_cases"] == 8
    assert command.count("--item") == 2
    assert normalized["simulation_sample_rate_hz"] == 48000
    assert normalized["timeout_seconds"] == 1200.0

    document = json.loads(campaign.read_text(encoding="utf-8"))
    document["simulator_backend"] = "ltspice"
    campaign.write_text(json.dumps(document), encoding="utf-8")
    _, ltspice_normalized = build_perceptual_command(
        {"selection": "online", "role": "development", "levels": ["nominal"]},
        CONFIG,
        PROGRAMME,
        campaign,
        tmp_path / "perceptual-ltspice",
    )
    assert ltspice_normalized["simulator_backend"] == "ltspice"


def test_gui_campaign_summary_exposes_points_and_gm_protocol(tmp_path: Path) -> None:
    report_path = tmp_path / "campaign.json"
    report_path.write_text(json.dumps({
        "status": "electrical_pareto_complete",
        "algorithm": "gde3",
        "simulator_backend": "ngspice",
        "screening": {
            "objectives": ["maximize_output_power_w", "minimize_gm_crowe"],
            "search_front_candidate_ids": ["candidate-a"],
            "records": [{
                "candidate_id": "candidate-a",
                "values": {"X1": 82.0},
                "metrics": {"output_power_w": 10.0, "gm_crowe": 5.0},
            }],
        },
        "engineering": {
            "records": [{"candidate_id": "candidate-a", "feasible": True, "metrics": {"gm_crowe": 5.0}}],
            "front_candidate_ids": ["candidate-a"],
        },
        "promotion": {"candidate_ids": ["candidate-a"]},
    }), encoding="utf-8")
    summary = _report_summary(report_path)
    assert summary["gm_crowe_in_search"] is True
    assert summary["points"][0]["id"] == "candidate-a"
    assert summary["points"][0]["metrics"]["gm_crowe"] == 5.0


def test_gui_summary_exposes_baseline_and_normalized_hypervolume(tmp_path: Path) -> None:
    report_path = tmp_path / "campaign.json"
    report_path.write_text(json.dumps({
        "search_space": {"baseline": {"X1": 70.0}},
        "screening": {
            "objectives": ["minimize_a", "minimize_b"],
            "records": [
                {"candidate_id": "a", "values": {"X1": 70.0}, "metrics": {"gm_crowe": 2.0}, "objectives_minimization": [2.0, 2.0]},
                {"candidate_id": "b", "values": {"X1": 90.0}, "metrics": {"gm_crowe": 1.0}, "objectives_minimization": [1.0, 1.0]},
            ],
        },
        "engineering": {"records": [], "front_candidate_ids": ["b"]},
    }), encoding="utf-8")
    summary = _report_summary(report_path)
    assert summary["baseline_values"] == {"X1": 70.0}
    assert summary["hypervolume"]["values"][-1]["hypervolume"] > summary["hypervolume"]["values"][0]["hypervolume"]
    assert summary["hypervolume"]["dimensions"] == 2
    assert summary["hypervolume"]["maximum_hypervolume"] == pytest.approx(1.21)
    assert 0.0 <= summary["hypervolume"]["values"][-1]["coverage_fraction"] <= 1.0


def test_gui_builds_preliminary_result_from_candidate_archive() -> None:
    summary = _archive_report_summary(
        [
            {
                "stage": "screening",
                "candidate_id": "a",
                "values": {"X1": 70.0},
                "metrics": {"output_power_w": 8.0, "thd_percent": 1.5, "frequency_std_db": 0.7, "gm_crowe": 2.0},
                "objectives": [-8.0, 1.5, 0.7, 2.0],
                "feasible": True,
            },
            {
                "stage": "screening",
                "candidate_id": "b",
                "values": {"X1": 80.0},
                "metrics": {"output_power_w": 9.0, "thd_percent": 1.2, "frequency_std_db": 0.6, "gm_crowe": 1.8},
                "objectives": [-9.0, 1.2, 0.6, 1.8],
                "feasible": True,
            },
        ],
        {"algorithm": "nsga2", "backend": "ngspice", "budget": 100, "multiobjective": True},
        simulator_runs=10,
    )
    assert summary is not None
    assert summary["partial"] is True
    assert summary["pareto_fronts"]["search"] == ["b"]
    assert summary["accounting"]["successful_candidates"] == 2
    assert summary["hypervolume"]["dimensions"] == 4
    assert summary["hypervolume"]["values"][-1]["coverage_percent"] == pytest.approx(100.0)


def test_gui_excludes_failed_candidates_and_keeps_hypervolume_plateau(tmp_path: Path) -> None:
    report_path = tmp_path / "campaign.json"
    report_path.write_text(json.dumps({
        "screening": {
            "objectives": ["minimize_a", "minimize_b"],
            "records": [
                {"candidate_id": "a", "metrics": {"a": 2.0}, "objectives_minimization": [2.0, 2.0], "feasible": True},
                {
                    "candidate_id": "bad",
                    "metrics": {},
                    "objectives_minimization": [1e30, 1e30],
                    "feasible": False,
                    "failure": {"message": "waveform contains non-finite values"},
                },
                {"candidate_id": "c", "metrics": {"a": 1.0}, "objectives_minimization": [1.0, 1.0], "feasible": True},
            ],
        },
        "engineering": {"records": [], "front_candidate_ids": ["c"]},
    }), encoding="utf-8")
    summary = _report_summary(report_path)
    assert [item["id"] for item in summary["points"]] == ["a", "c"]
    assert summary["failed_candidates"][0]["id"] == "bad"
    trace = summary["hypervolume"]["values"]
    assert [item["evaluation"] for item in trace] == [1, 2, 3]
    assert trace[1]["hypervolume"] == trace[0]["hypervolume"]
    assert trace[2]["hypervolume"] > trace[1]["hypervolume"]


def test_failed_candidate_counts_as_completed_progress() -> None:
    progress = _event_progress([
        {"event": "candidate_completed", "candidate_index": 1, "budget": 3},
        {"event": "candidate_failed", "candidate_index": 2, "budget": 3},
    ])
    assert progress["completed"] == 2
    assert progress["fraction"] == pytest.approx(2 / 3)


def test_hypervolume_and_safe_cancel_boundary(tmp_path: Path) -> None:
    assert hypervolume([(0.2, 0.3)], (1.0, 1.0)) == pytest.approx(0.56)
    trace = normalized_hypervolume_trace([(2.0, 2.0), (1.0, 1.0)])
    assert trace["values"][1]["hypervolume"] >= trace["values"][0]["hypervolume"]
    assert trace["values"][1]["coverage_percent"] == pytest.approx(100.0)
    control_path = tmp_path / "control.json"
    event_path = tmp_path / "events.jsonl"
    control_path.write_text('{"action":"cancel"}', encoding="utf-8")
    control = RunControl(control_path, event_path, run_kind="test")
    with pytest.raises(RunCancelled):
        control.checkpoint("between_candidates", candidate_index=2)
    assert json.loads(event_path.read_text(encoding="utf-8").splitlines()[-1])["event"] == "cancelled_at_boundary"


def test_large_nondominated_front_uses_bounded_deterministic_hypervolume() -> None:
    count = 300
    points = [
        (index / (count - 1), 1.0 - index / (count - 1), 0.5, 0.5)
        for index in range(count)
    ]
    first = normalized_hypervolume_trace(points, max_trace_points=12)
    second = normalized_hypervolume_trace(points, max_trace_points=12)
    assert first["approximate"] is True
    assert first["method"] == "deterministic_halton_estimate"
    assert first["sample_count"] == 32768
    assert first["values"] == second["values"]
    assert all(
        right["coverage_fraction"] >= left["coverage_fraction"]
        for left, right in zip(first["values"], first["values"][1:])
    )


def test_cooperative_pause_resumes_at_same_boundary(tmp_path: Path) -> None:
    control_path = tmp_path / "control.json"
    event_path = tmp_path / "events.jsonl"
    control_path.write_text('{"action":"pause"}', encoding="utf-8")
    control = RunControl(control_path, event_path, run_kind="test", poll_seconds=0.01)
    worker = threading.Thread(target=control.checkpoint, args=("before_candidate",), daemon=True)
    worker.start()
    deadline = time.monotonic() + 1.0
    while time.monotonic() < deadline:
        if event_path.is_file() and "paused_at_boundary" in event_path.read_text(encoding="utf-8"):
            break
        time.sleep(0.01)
    assert worker.is_alive()
    control_path.write_text('{"action":"run"}', encoding="utf-8")
    worker.join(timeout=1.0)
    assert not worker.is_alive()
    events = [json.loads(line)["event"] for line in event_path.read_text(encoding="utf-8").splitlines()]
    assert events == ["paused_at_boundary", "resumed"]


def test_gui_rejects_fixed_or_invalid_campaign_parameters(tmp_path: Path) -> None:
    base = {
        "backend": "ngspice",
        "algorithm": "nsga2",
        "parameters_path": str(PARAMETERS),
        "budget": 8,
        "population_size": 4,
        "promote": 2,
    }
    with pytest.raises(ValueError, match="fixos"):
        build_campaign_command({**base, "vary": ["X24"]}, CONFIG, PROGRAMME, tmp_path / "fixed")
    with pytest.raises(ValueError, match="população"):
        build_campaign_command({**base, "population_size": 9}, CONFIG, PROGRAMME, tmp_path / "population")
    with pytest.raises(ValueError, match="valor inicial de X1"):
        build_campaign_command(
            {**base, "parameter_bounds": {"X1": {"minimum": 80, "maximum": 120}}},
            CONFIG,
            PROGRAMME,
            tmp_path / "bounds",
        )


def test_campaign_cli_accepts_repeatable_parameter_bounds() -> None:
    args = build_parser().parse_args([
        "optimize", "campaign", str(PARAMETERS),
        "--parameter-bound", "X1:50:120",
        "--parameter-bound", "X2:100000:200000",
    ])
    assert args.parameter_bound == [("X1", 50.0, 120.0), ("X2", 100000.0, 200000.0)]


def test_gui_assets_and_cli_entrypoint_are_packaged(tmp_path: Path) -> None:
    index = files("sonya.gui_assets").joinpath("index.html").read_text(encoding="utf-8")
    app = files("sonya.gui_assets").joinpath("app.js").read_text(encoding="utf-8")
    assert "Configure o experimento" in index
    assert 'id="perceptual-half-life" type="number" min="0.1" step="0.1" value="50"' in index
    assert 'id="select-all-parameters"' in index
    assert 'id="mutation-factor" name="mutation_factor" type="number" min="0.01"' in index
    assert 'href="/sonya-favicon-v4.png"' in index
    assert 'filterSelect.id = "result-candidate-filter"' in app
    assert 'resultCandidateFilter: "pareto"' in app
    assert '"Pareto com destaque"' in app
    assert files("sonya.gui_assets").joinpath("sonya-favicon-v4.svg").read_text(encoding="utf-8").startswith("<svg")
    assert files("sonya.gui_assets").joinpath("sonya-icon.png").read_bytes().startswith(b"\x89PNG")
    assert files("sonya.gui_assets").joinpath("gagabiro-el84-circuit.png").read_bytes().startswith(b"\x89PNG")
    args = build_parser().parse_args(["gui", "--no-open", "--port", "0", "--state-root", str(tmp_path)])
    assert args.command == "gui"
    assert args.no_open is True
    assert args.port == 0


def test_empty_job_store_is_a_valid_first_run(tmp_path: Path) -> None:
    store = JobStore(tmp_path / "jobs", CONFIG, PROGRAMME)
    assert store.list() == []
