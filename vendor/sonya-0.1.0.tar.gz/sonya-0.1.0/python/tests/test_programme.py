from pathlib import Path

from sonya.programme import ProgrammeConfigError, load_programme_manifest, pareto_audit, pareto_front, programme_report


ROOT = Path(__file__).resolve().parents[2]


def test_selected_programme_manifest_enforces_shared_final_and_subjective_set() -> None:
    manifest = load_programme_manifest(ROOT / "python/configs/programme.yaml")
    report = programme_report(manifest)
    assert report["status"] == "ready"
    # SQAM audio is deliberately distributed outside Git.  A clean package
    # validates the protocol while reporting that the local assets are absent;
    # a research workstation with the corpus installed reports full readiness.
    expected_assets_ready = all(
        bool(item["exists"] and item["hash_matches"])
        and (
            "reserve" in item["roles"]
            or bool(item["canonical_exists"] and item["canonical_hash_matches"])
        )
        for item in report["items"]
    )
    assert report["assets_ready"] is expected_assets_ready
    assert report["ready"] is expected_assets_ready
    assert report["programme_ready"] is expected_assets_ready
    assert report["item_count"] == 9
    assert report["role_counts"] == {
        "candidate": 0,
        "development": 4,
        "validation": 8,
        "subjective": 8,
        "reserve": 1,
    }
    assert report["role_contract"] == {"passed": True, "violations": []}
    assert all(count > 0 for count in report["validation_category_coverage"].values())
    assert report["role_ids"]["validation"] == report["role_ids"]["subjective"]
    assert set(report["role_ids"]["development"]) <= set(report["role_ids"]["validation"])
    assert report["role_ids"]["development"] == [
        "sqam-castanets",
        "sqam-double-bass",
        "sqam-orchestra-strauss",
        "sqam-piano-schubert",
    ]
    assert report["levels_ready"] is True
    assert report["protocol_ready"] is True
    assert report["metrics"]["primary"] == "visqol_audio"
    reserve = next(item for item in report["items"] if item["id"] == "sqam-pop-eddie-rabbitt")
    assert reserve["roles"] == ("reserve",)
    assert str(reserve["canonical_path"]).endswith("corpus/audition/assets/sqam-pop-eddie-rabbitt.wav")
    if reserve["canonical_exists"]:
        assert reserve["canonical_hash_matches"] is True


def test_programme_manifest_can_use_an_external_corpus_root(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("SONYA_CORPUS_ROOT", str(tmp_path))
    manifest = load_programme_manifest(ROOT / "python/configs/programme.yaml")

    assert all(item.path is not None and item.path.is_relative_to(tmp_path) for item in manifest.items)
    assert all(
        item.canonical_path is not None and item.canonical_path.is_relative_to(tmp_path)
        for item in manifest.items
    )


def test_pareto_front_requires_feasible_complete_records() -> None:
    records = [
        {"id": "a", "feasible": True, "metrics": {"cost": 1.0, "quality": 3.0}},
        {"id": "b", "feasible": True, "metrics": {"cost": 2.0, "quality": 4.0}},
        {"id": "dominated", "feasible": True, "metrics": {"cost": 3.0, "quality": 2.0}},
        {"id": "missing", "feasible": True, "metrics": {"cost": 0.0}},
        {"id": "not-finite", "feasible": True, "metrics": {"cost": float("nan"), "quality": 9.0}},
        {"id": "unsafe", "feasible": False, "metrics": {"cost": 0.0, "quality": 5.0}},
    ]
    front = pareto_front(records, {"cost": "minimize", "quality": "maximize"})
    assert {item["id"] for item in front} == {"a", "b"}


def test_perceptual_pareto_audit_requires_validation_evidence() -> None:
    records = [
        {
            "id": "development-only",
            "metrics": {"visqol": 4.8, "recovery": 0.1},
            "evidence": {"validation_split": False, "adapter_versions": True},
        },
        {
            "id": "validated",
            "metrics": {"visqol": 4.6, "recovery": 0.2},
            "evidence": {"validation_split": True, "adapter_versions": True},
        },
    ]
    audit = pareto_audit(
        records,
        {"visqol": "maximize", "recovery": "minimize"},
        ("validation_split", "adapter_versions"),
    )
    assert audit["front_candidate_ids"] == ["validated"]
    assert audit["excluded"] == {"development-only": ["missing_evidence:validation_split"]}


def test_programme_manifest_rejects_invalid_hash(tmp_path) -> None:
    path = tmp_path / "programme.yaml"
    path.write_text(
        """schema_version: 1
status: draft
selection:
  required_categories: [voice]
evaluation:
  levels:
    - {id: nominal, description: clean, calibration_status: pending, amplitude_kind: peak_v, target_peak_v: 0.447213595499958}
  metrics: {primary: visqol_audio, secondary: []}
items:
  - id: voice
    path: voice.wav
    role: development
    categories: [voice]
    duration_seconds: 10
    sha256: not-a-hash
""",
        encoding="utf-8",
    )
    try:
        load_programme_manifest(path)
    except ProgrammeConfigError as exc:
        assert "invalid SHA-256" in str(exc)
    else:
        raise AssertionError("invalid SHA-256 was accepted")
