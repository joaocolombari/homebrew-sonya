from pathlib import Path

from sonya.config import load_config
from sonya.installation import installation_report


ROOT = Path(__file__).resolve().parents[2]


def test_installation_report_separates_package_core_and_perceptual_readiness() -> None:
    report = installation_report(
        load_config(ROOT / "python" / "configs" / "legacy.yaml"),
        ROOT / "python" / "configs" / "programme.yaml",
    )

    assert report["scopes"]["package"] is True
    assert set(report["scopes"]) == {"package", "core", "perceptual", "all"}
    components = {item["id"]: item for item in report["components"]}
    assert set(components) == {
        "python_package",
        "project_files",
        "simulator",
        "ffmpeg",
        "perceptual_metrics",
        "programme_corpus",
    }
    assert components["simulator"]["details"]["required_backend"] in {"ltspice", "ngspice"}
