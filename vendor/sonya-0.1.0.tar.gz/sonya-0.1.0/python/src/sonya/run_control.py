from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import time
from typing import Any


class RunCancelled(RuntimeError):
    """Raised only at a declared safe boundary."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class RunControl:
    """Cooperative pause/cancel control plus an append-only JSONL event stream.

    A simulator invocation is never killed halfway through.  Callers choose safe
    boundaries (a candidate or programme case) and call :meth:`checkpoint` there.
    """

    def __init__(
        self,
        control_path: str | Path | None = None,
        event_path: str | Path | None = None,
        *,
        run_kind: str,
        poll_seconds: float = 0.25,
    ) -> None:
        self.control_path = Path(control_path).expanduser().resolve() if control_path else None
        self.event_path = Path(event_path).expanduser().resolve() if event_path else None
        self.run_kind = run_kind
        self.poll_seconds = poll_seconds
        self.sequence = self._last_sequence()
        self._paused = False

    def _last_sequence(self) -> int:
        if self.event_path is None or not self.event_path.is_file():
            return 0
        try:
            last = self.event_path.read_text(encoding="utf-8").splitlines()[-1]
            return int(json.loads(last).get("sequence", 0))
        except (OSError, IndexError, ValueError, json.JSONDecodeError):
            return 0

    def action(self) -> str:
        if self.control_path is None or not self.control_path.is_file():
            return "run"
        try:
            value = json.loads(self.control_path.read_text(encoding="utf-8")).get("action", "run")
        except (OSError, json.JSONDecodeError):
            return "run"
        return value if value in {"run", "pause", "cancel"} else "run"

    def emit(self, event: str, **payload: Any) -> dict[str, Any]:
        self.sequence += 1
        record = {
            "sequence": self.sequence,
            "timestamp": _utc_now(),
            "run_kind": self.run_kind,
            "event": event,
            **payload,
        }
        if self.event_path is not None:
            self.event_path.parent.mkdir(parents=True, exist_ok=True)
            with self.event_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(record, sort_keys=True, default=str) + "\n")
                stream.flush()
        return record

    def checkpoint(self, boundary: str, **context: Any) -> None:
        action = self.action()
        if action == "cancel":
            self.emit("cancelled_at_boundary", boundary=boundary, **context)
            raise RunCancelled(f"cancelled safely at {boundary}")
        while action == "pause":
            if not self._paused:
                self.emit("paused_at_boundary", boundary=boundary, **context)
                self._paused = True
            time.sleep(self.poll_seconds)
            action = self.action()
            if action == "cancel":
                self.emit("cancelled_at_boundary", boundary=boundary, **context)
                raise RunCancelled(f"cancelled safely at {boundary}")
        if self._paused:
            self.emit("resumed", boundary=boundary, **context)
            self._paused = False

