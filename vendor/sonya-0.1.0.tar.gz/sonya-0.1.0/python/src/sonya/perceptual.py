from __future__ import annotations

from dataclasses import asdict, dataclass
from fractions import Fraction
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
from typing import Literal, Sequence

import numpy as np
from scipy import signal
from scipy.io import wavfile


_NUMBER = r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?"


@dataclass(frozen=True)
class PerceptualDoctor:
    id: str
    executable: str | None
    available: bool
    ready: bool
    version: str | None
    implementation: str
    conformance: str
    details: dict[str, object]


@dataclass(frozen=True)
class PerceptualMetricResult:
    id: str
    value: float
    unit: str
    command: tuple[str, ...]
    implementation: str
    version: str | None
    stdout: str
    stderr: str

    def record(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class PreparedMetricPair:
    reference: Path
    degraded: Path
    sample_rate_hz: int
    samples: int
    delay_samples: int
    level_match_db: float
    shared_peak_scale: float
    reference_rms: float
    degraded_rms_before_match: float

    def record(self) -> dict[str, object]:
        data = asdict(self)
        data["reference"] = str(self.reference)
        data["degraded"] = str(self.degraded)
        return data


def _discover(environment: str, names: Sequence[str]) -> Path | None:
    override = os.environ.get(environment)
    candidate = override or next((value for name in names if (value := shutil.which(name))), None)
    return Path(candidate).expanduser().resolve() if candidate else None


def _version(executable: Path, arguments: tuple[str, ...]) -> tuple[str | None, dict[str, object]]:
    try:
        completed = subprocess.run(
            (str(executable), *arguments),
            capture_output=True,
            text=True,
            timeout=10.0,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return None, {"error": str(exc)}
    output = f"{completed.stdout}\n{completed.stderr}".strip()
    match = re.search(r"(?i)(?:version|visqol|gstpeaq|peaq)[^0-9]{0,12}([0-9]+(?:\.[0-9A-Za-z_-]+)+)", output)
    return (match.group(1) if match else None), {
        "return_code": completed.returncode,
        "version_output": output[:4000],
    }


def perceptual_doctors() -> tuple[PerceptualDoctor, ...]:
    visqol = _discover("SONYA_VISQOL", ("visqol",))
    peaq = _discover("SONYA_GSTPEAQ", ("peaq",))
    records: list[PerceptualDoctor] = []
    if visqol is None or not visqol.is_file() or not os.access(visqol, os.X_OK):
        available = visqol is not None and visqol.is_file()
        records.append(PerceptualDoctor(
            "visqol_audio",
            str(visqol) if visqol else None,
            available,
            False,
            None,
            "Google ViSQOL command-line tool",
            "official_open_source_implementation",
            {"environment_override": "SONYA_VISQOL", "required_sample_rate_hz": 48000, "executable": False if available else None},
        ))
    else:
        version, details = _version(visqol, ("--version",))
        records.append(PerceptualDoctor(
            "visqol_audio", str(visqol), True, True, version,
            "Google ViSQOL command-line tool", "official_open_source_implementation",
            {**details, "environment_override": "SONYA_VISQOL", "required_sample_rate_hz": 48000},
        ))
    if peaq is None or not peaq.is_file() or not os.access(peaq, os.X_OK):
        available = peaq is not None and peaq.is_file()
        records.append(PerceptualDoctor(
            "gstpeaq_odg", str(peaq) if peaq else None, available, False, None,
            "GstPEAQ command-line tool", "open_implementation_not_bs1387_tolerance_conformant",
            {"environment_override": "SONYA_GSTPEAQ", "executable": False if available else None},
        ))
    else:
        version, details = _version(peaq, ("--version",))
        records.append(PerceptualDoctor(
            "gstpeaq_odg", str(peaq), True, True, version,
            "GstPEAQ command-line tool", "open_implementation_not_bs1387_tolerance_conformant",
            {**details, "environment_override": "SONYA_GSTPEAQ"},
        ))
    return tuple(records)


def _doctor(metric_id: str) -> PerceptualDoctor:
    return next(item for item in perceptual_doctors() if item.id == metric_id)


def run_visqol(reference: str | Path, degraded: str | Path, timeout_seconds: float = 120.0) -> PerceptualMetricResult:
    doctor = _doctor("visqol_audio")
    if not doctor.ready or doctor.executable is None:
        raise RuntimeError("ViSQOL is not ready; install the official tool or set SONYA_VISQOL")
    command = (
        doctor.executable,
        "--reference_file", str(Path(reference).resolve()),
        "--degraded_file", str(Path(degraded).resolve()),
        "--verbose",
    )
    completed = subprocess.run(command, capture_output=True, text=True, timeout=timeout_seconds, check=False)
    output = f"{completed.stdout}\n{completed.stderr}"
    match = re.search(rf"(?i)(?:MOS[- _]?LQO|moslqo)\s*[:=]\s*({_NUMBER})", output)
    if completed.returncode != 0 or match is None:
        raise RuntimeError(f"ViSQOL failed or returned no MOS-LQO (exit {completed.returncode})")
    return PerceptualMetricResult(
        "visqol_audio", float(match.group(1)), "MOS-LQO", command,
        doctor.implementation, doctor.version, completed.stdout, completed.stderr,
    )


def run_gstpeaq(
    reference: str | Path,
    degraded: str | Path,
    model: Literal["basic", "advanced"] = "basic",
    timeout_seconds: float = 120.0,
) -> PerceptualMetricResult:
    doctor = _doctor("gstpeaq_odg")
    if not doctor.ready or doctor.executable is None:
        raise RuntimeError("GstPEAQ is not ready; install it or set SONYA_GSTPEAQ")
    arguments = [doctor.executable]
    if model == "advanced":
        arguments.append("--advanced")
    arguments.extend((str(Path(reference).resolve()), str(Path(degraded).resolve())))
    command = tuple(arguments)
    completed = subprocess.run(command, capture_output=True, text=True, timeout=timeout_seconds, check=False)
    output = f"{completed.stdout}\n{completed.stderr}"
    match = re.search(rf"(?i)(?:\bODG\b|Objective\s+Difference\s+Grade)\s*[:=]\s*({_NUMBER})", output)
    if completed.returncode != 0 or match is None:
        raise RuntimeError(f"GstPEAQ failed or returned no ODG (exit {completed.returncode})")
    return PerceptualMetricResult(
        f"gstpeaq_{model}_odg", float(match.group(1)), "ODG", command,
        doctor.implementation, doctor.version, completed.stdout, completed.stderr,
    )


def read_wav_mono(path: str | Path, channel: int = 0) -> tuple[int, np.ndarray]:
    sample_rate, raw = wavfile.read(Path(path).expanduser().resolve())
    array = np.asarray(raw)
    if array.ndim == 2:
        if channel < 0 or channel >= array.shape[1]:
            raise ValueError(f"audio channel {channel} is outside 0..{array.shape[1] - 1}")
        array = array[:, channel]
    if array.ndim != 1 or array.size < 2:
        raise ValueError("audio must contain at least two mono samples")
    if np.issubdtype(array.dtype, np.integer):
        info = np.iinfo(array.dtype)
        scale = float(max(abs(info.min), info.max))
        values = array.astype(np.float64) / scale
    else:
        values = array.astype(np.float64)
    if not np.all(np.isfinite(values)):
        raise ValueError("audio contains non-finite samples")
    return int(sample_rate), values


def active_rms(values: np.ndarray, threshold_db: float = -60.0) -> float:
    array = np.asarray(values, dtype=float)
    peak = float(np.max(np.abs(array))) if array.size else 0.0
    if peak <= 0.0:
        raise ValueError("audio is silent")
    active = array[np.abs(array) >= peak * 10.0 ** (threshold_db / 20.0)]
    if active.size == 0:
        raise ValueError("audio has no active samples")
    return float(np.sqrt(np.mean(np.square(active))))


def prepare_excerpt(
    values: np.ndarray,
    sample_rate_hz: int,
    start_seconds: float,
    duration_seconds: float,
    target_rms_v: float = 10.0 ** (-10.0 / 20.0),
    preroll_seconds: float = 0.1,
) -> np.ndarray:
    if sample_rate_hz <= 0 or start_seconds < 0 or duration_seconds <= 0 or target_rms_v <= 0 or preroll_seconds < 0:
        raise ValueError("invalid excerpt settings")
    start = round(start_seconds * sample_rate_hz)
    stop = start + round(duration_seconds * sample_rate_hz)
    excerpt = np.asarray(values, dtype=float)[start:stop]
    if excerpt.size != stop - start:
        raise ValueError("audio file is shorter than the requested excerpt")
    excerpt = excerpt - float(np.mean(excerpt))
    scaled = excerpt * (target_rms_v / active_rms(excerpt))
    preroll = np.zeros(round(preroll_seconds * sample_rate_hz), dtype=float)
    return np.concatenate((preroll, scaled))


def prepare_peak_excerpt(
    values: np.ndarray,
    sample_rate_hz: int,
    duration_seconds: float,
    target_peak_v: float,
    preroll_seconds: float = 0.1,
) -> np.ndarray:
    """Prepare an already-cropped canonical excerpt at an exact peak voltage.

    The ngspice adapter uses linear PWL interpolation, so interpolation cannot
    exceed the endpoint extrema. Scaling the canonical samples therefore fixes
    the continuous simulator input peak without changing crest factor.
    """

    if sample_rate_hz <= 0 or duration_seconds <= 0 or target_peak_v <= 0 or preroll_seconds < 0:
        raise ValueError("invalid peak-calibrated excerpt settings")
    expected = round(duration_seconds * sample_rate_hz)
    excerpt = np.asarray(values, dtype=float)[:expected]
    if excerpt.size != expected or not np.all(np.isfinite(excerpt)):
        raise ValueError("canonical audio is shorter than the declared excerpt or contains non-finite samples")
    excerpt = excerpt - float(np.mean(excerpt))
    peak = float(np.max(np.abs(excerpt)))
    if peak <= 0:
        raise ValueError("canonical audio is silent")
    scaled = excerpt * (target_peak_v / peak)
    preroll = np.zeros(round(preroll_seconds * sample_rate_hz), dtype=float)
    return np.concatenate((preroll, scaled))


def _resample(time: np.ndarray, values: np.ndarray, target_sample_rate_hz: int) -> np.ndarray:
    source_time = np.asarray(time, dtype=float)
    source_values = np.asarray(values, dtype=float)
    if source_time.ndim != 1 or source_values.shape != source_time.shape or source_time.size < 4:
        raise ValueError("time and waveform must be matching one-dimensional arrays")
    source_rate = 1.0 / float(np.median(np.diff(source_time)))
    uniform_time = np.arange(source_time[0], source_time[-1], 1.0 / source_rate)
    uniform = np.interp(uniform_time, source_time, source_values)
    ratio = Fraction(target_sample_rate_hz / source_rate).limit_denominator(4096)
    return signal.resample_poly(uniform, ratio.numerator, ratio.denominator)


def _align(reference: np.ndarray, degraded: np.ndarray, max_delay_samples: int) -> tuple[np.ndarray, np.ndarray, int]:
    length = min(reference.size, degraded.size)
    ref = reference[:length] - float(np.mean(reference[:length]))
    test = degraded[:length] - float(np.mean(degraded[:length]))
    correlation = signal.correlate(test, ref, mode="full", method="fft")
    lags = signal.correlation_lags(test.size, ref.size, mode="full")
    allowed = np.abs(lags) <= max_delay_samples
    lag = int(lags[allowed][int(np.argmax(correlation[allowed]))])
    if lag > 0:
        test, ref = test[lag:], ref[: test.size - lag]
    elif lag < 0:
        ref, test = ref[-lag:], test[: ref.size + lag]
    length = min(ref.size, test.size)
    return ref[:length], test[:length], lag


def prepare_metric_pair(
    time: np.ndarray,
    input_voltage: np.ndarray,
    output_voltage: np.ndarray,
    output_directory: str | Path,
    target_sample_rate_hz: int = 48000,
    max_delay_seconds: float = 0.1,
    *,
    reference_time: np.ndarray | None = None,
) -> PreparedMetricPair:
    output = Path(output_directory).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    reference = _resample(
        time if reference_time is None else reference_time,
        input_voltage,
        target_sample_rate_hz,
    )
    degraded = _resample(time, output_voltage, target_sample_rate_hz)
    reference, degraded, delay = _align(reference, degraded, round(max_delay_seconds * target_sample_rate_hz))
    reference_rms = active_rms(reference)
    degraded_rms = active_rms(degraded)
    level_scale = reference_rms / degraded_rms
    degraded = degraded * level_scale
    peak = max(float(np.max(np.abs(reference))), float(np.max(np.abs(degraded))))
    shared_scale = min(1.0, 0.95 / peak) if peak > 0 else 1.0
    reference = reference * shared_scale
    degraded = degraded * shared_scale
    reference_path = output / "reference.wav"
    degraded_path = output / "degraded.wav"
    # ViSQOL 3.3.x rejects IEEE-float WAV files.  Keep a shared analogue scale
    # above, then quantize both signals identically to conventional 16-bit PCM.
    pcm_scale = float(np.iinfo(np.int16).max)
    reference_pcm = np.rint(reference * pcm_scale).astype(np.int16)
    degraded_pcm = np.rint(degraded * pcm_scale).astype(np.int16)
    wavfile.write(reference_path, target_sample_rate_hz, reference_pcm)
    wavfile.write(degraded_path, target_sample_rate_hz, degraded_pcm)
    return PreparedMetricPair(
        reference_path,
        degraded_path,
        target_sample_rate_hz,
        int(reference.size),
        delay,
        20.0 * math.log10(level_scale),
        shared_scale,
        reference_rms,
        degraded_rms,
    )
