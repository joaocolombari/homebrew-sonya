from __future__ import annotations

from pathlib import Path
import json
import os
import tempfile

_MATPLOTLIB_CACHE = Path(tempfile.gettempdir()) / "sonya-matplotlib"
_MATPLOTLIB_CACHE.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(_MATPLOTLIB_CACHE))
os.environ.setdefault("XDG_CACHE_HOME", str(_MATPLOTLIB_CACHE))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .parsers.ltspice import read_raw
from .provenance import write_provenance


def assert_derived_output_path(output: str | Path, raw_roots: list[Path]) -> Path:
    target = Path(output).resolve()
    for raw_root in raw_roots:
        root = raw_root.resolve()
        if target == root or root in target.parents:
            raise ValueError("figures and processed artifacts cannot be written into raw-data roots")
    return target


def plot_legacy_evaluation(evaluation_path: str | Path, output: str | Path, raw_roots: list[Path]) -> Path:
    source = Path(evaluation_path).resolve()
    target = assert_derived_output_path(output, raw_roots)
    document = json.loads(source.read_text(encoding="utf-8"))
    by_mode = {run["mode"]: run for run in document["runs"]}
    missing = {"tran", "ac", "slew", "gedlee"} - by_mode.keys()
    if missing:
        raise ValueError(f"evaluation is missing figure inputs: {', '.join(sorted(missing))}")
    transient = read_raw(by_mode["tran"]["raw_path"])
    ac = read_raw(by_mode["ac"]["raw_path"])
    slew = read_raw(by_mode["slew"]["raw_path"])
    gm_measurements = by_mode["gedlee"]["measurements"]

    fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    fig.suptitle("Sonya — reprodução local do baseline legado", fontsize=15)

    time = np.asarray(transient.values["time"], dtype=float)
    voltage = np.asarray(transient.values["V(out)"], dtype=float)
    mask = time >= max(0.0, time[-1] - 0.005)
    axes[0, 0].plot(time[mask] * 1e3, voltage[mask], color="#236192", linewidth=1.5)
    axes[0, 0].set(title="Transiente a 1 kHz", xlabel="Tempo (ms)", ylabel="V(out) (V)")

    frequency = np.real(ac.values["frequency"])
    response_db = 20.0 * np.log10(np.abs(ac.values["V(out)"]))
    axes[0, 1].semilogx(frequency, response_db, color="#c45100", linewidth=1.5)
    axes[0, 1].set(title="Resposta em frequência", xlabel="Frequência (Hz)", ylabel="Magnitude (dB)", xlim=(1, 100_000))

    slew_time = np.asarray(slew.values["time"], dtype=float)
    slew_voltage = np.asarray(slew.values["V(out)"], dtype=float)
    axes[1, 0].plot((slew_time - slew_time[0]) * 1e6, slew_voltage, color="#3b7d23", linewidth=1.5)
    axes[1, 0].set(title="Resposta ao degrau", xlabel="Tempo relativo (µs)", ylabel="V(out) (V)")

    minima = np.asarray([gm_measurements[f"min{index}"] for index in range(101)], dtype=float)[::-1]
    maxima = np.asarray([gm_measurements[f"max{index}"] for index in range(101)], dtype=float)
    centre = 0.5 * (maxima[0] + minima[-1])
    transfer = np.concatenate((minima[:-1], [centre], maxima[1:]))
    input_v = np.linspace(-1.0, 1.0, transfer.size)
    gain = 10 ** (float(document["summary"]["measurements"]["gain_db"]) / 20.0)
    axes[1, 1].plot(input_v, transfer / gain, color="#6f4c9b", linewidth=1.5)
    axes[1, 1].set(title=f"T(x) legado — GM={document['summary']['measurements']['gm_legacy']:.3f}", xlabel="Entrada normalizada", ylabel="Saída normalizada")

    for axis in axes.flat:
        axis.grid(True, alpha=0.25)
    target.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(target, dpi=160)
    plt.close(fig)
    write_provenance(target.with_suffix(target.suffix + ".provenance.json"), [source, *[run["raw_path"] for run in by_mode.values() if run.get("raw_path")]], "legacy_evaluation_figure")
    return target
