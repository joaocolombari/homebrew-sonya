from __future__ import annotations

import math
import re


def legacy_score(value: float, specification: str) -> float:
    """Faithful scalar port of MATLAB ``scoreAv.m``."""
    match = re.search(r"[=>vV</wW]", specification)
    if match is None:
        raise ValueError(f"invalid legacy score specification: {specification!r}")
    model = match.group(0)
    data = [float(item) for item in specification[match.end() :].split()]
    x = float(value)
    if model == "<":
        if len(data) < 3:
            data = [data[0], 0.0, data[1]]
        return max(0.0, x * data[1] / data[0], data[2] * (x - data[0]) / abs(data[0]) + data[1])
    if model == ">":
        return max(0.0, (data[0] - x) / abs(data[0])) * data[1]
    if model == "=":
        return abs(data[0] - x) / abs(data[0]) * data[1]
    if model == "/":
        return x / data[0] * data[1]
    if model in {"v", "V"}:
        if len(data) < 4:
            data.append(data[2])
        if model == "V" and len(data) < 5:
            data.append(data[3])
        lower, upper = sorted(data[:2])
        score = max(0.0, data[2] * (lower - x) / abs(lower), data[3] * (x - upper) / abs(upper))
        if model == "V" and x < data[4]:
            return math.inf
        return score
    point_values = data[:-1]
    weight = data[-1]
    point_count = len(point_values) // 2
    segment = 0
    while segment < point_count - 1 and x > point_values[2 * segment]:
        segment += 1
    if segment == 0:
        x1, y1, x2, y2 = point_values[:4]
    else:
        x1, y1, x2, y2 = point_values[2 * segment - 2 : 2 * segment + 2]
    score = y1 + (x - x1) * (y2 - y1) / (x2 - x1)
    return max(0.0, score) * weight


def legacy_score_breakdown(measurements: dict[str, float], specifications: dict[str, str]) -> dict[str, float]:
    missing = specifications.keys() - measurements.keys()
    if missing:
        raise ValueError(f"missing measurements for legacy score: {', '.join(sorted(missing))}")
    return {name: legacy_score(measurements[name], spec) for name, spec in specifications.items()}
