from __future__ import annotations

import math
from typing import Sequence

import numpy as np


_EXACT_FRONT_LIMIT = 128
_APPROXIMATE_SAMPLE_COUNT = 32768
_HALTON_BASES = (2, 3, 5, 7, 11, 13, 17, 19)


def _dominates(left: Sequence[float], right: Sequence[float]) -> bool:
    return left != right and all(a <= b for a, b in zip(left, right))


def nondominated(points: Sequence[Sequence[float]]) -> list[tuple[float, ...]]:
    clean = [tuple(float(value) for value in point) for point in points]
    if not clean:
        return []
    width = len(clean[0])
    if width == 0 or any(len(point) != width for point in clean):
        raise ValueError("hypervolume points must have one common positive dimension")
    if any(not all(math.isfinite(value) for value in point) for point in clean):
        raise ValueError("hypervolume points must be finite")
    front: list[tuple[float, ...]] = []
    for point in clean:
        if any(_dominates(other, point) for other in front):
            continue
        front = [other for other in front if not _dominates(point, other)]
        if point not in front:
            front.append(point)
    return front


def _halton_samples(count: int, dimensions: int, reference: Sequence[float]) -> np.ndarray:
    if dimensions > len(_HALTON_BASES):
        raise ValueError(f"deterministic hypervolume supports at most {len(_HALTON_BASES)} dimensions")
    indices = np.arange(1, count + 1, dtype=np.int64)
    samples = np.empty((count, dimensions), dtype=float)
    for dimension, base in enumerate(_HALTON_BASES[:dimensions]):
        values = np.zeros(count, dtype=float)
        factor = 1.0 / base
        remaining = indices.copy()
        while np.any(remaining):
            values += factor * (remaining % base)
            remaining //= base
            factor /= base
        samples[:, dimension] = values * float(reference[dimension])
    return samples


def _approximate_hypervolume_trace(
    normalized: Sequence[tuple[float, ...]],
    reference: tuple[float, ...],
    checkpoints: Sequence[tuple[int, int]],
    maximum_hypervolume: float,
    sample_count: int,
) -> list[dict[str, object]]:
    samples = _halton_samples(sample_count, len(reference), reference)
    dominated = np.zeros(sample_count, dtype=bool)
    values: list[dict[str, object]] = []
    previous_count = 0
    sample_chunk = 4096
    for count, front_size in checkpoints:
        block = np.asarray(normalized[previous_count:count], dtype=float)
        if block.size:
            for start in range(0, sample_count, sample_chunk):
                stop = min(sample_count, start + sample_chunk)
                newly_dominated = np.any(
                    np.all(block[:, np.newaxis, :] <= samples[np.newaxis, start:stop, :], axis=2),
                    axis=0,
                )
                dominated[start:stop] |= newly_dominated
        previous_count = count
        coverage = float(np.mean(dominated))
        values.append({
            "evaluation": count,
            "hypervolume": coverage * maximum_hypervolume,
            "coverage_fraction": coverage,
            "coverage_percent": 100.0 * coverage,
            "front_size": front_size,
        })
    return values


def hypervolume(points: Sequence[Sequence[float]], reference: Sequence[float]) -> float:
    """Exact dominated hypervolume for minimization objectives.

    The recursive axis slicing is intentionally small and dependency-free.  It
    is ample for the 3--4 objectives and O(100) candidates used by the GUI.
    """

    ref = tuple(float(value) for value in reference)
    usable = [
        tuple(float(value) for value in point)
        for point in points
        if len(point) == len(ref) and all(float(value) < limit for value, limit in zip(point, ref))
    ]
    if not usable:
        return 0.0
    front = nondominated(usable)
    if len(ref) == 1:
        return max(0.0, ref[0] - min(point[0] for point in front))
    cuts = sorted({point[0] for point in front} | {ref[0]})
    total = 0.0
    for low, high in zip(cuts, cuts[1:]):
        active = [point[1:] for point in front if point[0] <= low]
        if active:
            total += (high - low) * hypervolume(active, ref[1:])
    return total


def normalized_hypervolume_trace(
    points: Sequence[Sequence[float]],
    *,
    reference_margin: float = 0.1,
    max_trace_points: int = 32,
) -> dict[str, object]:
    """Normalize once, then calculate exact hypervolume at bounded checkpoints."""

    if not points:
        return {
            "dimensions": 0,
            "reference_point": [],
            "reference_margin": reference_margin,
            "maximum_hypervolume": 0.0,
            "method": "exact_axis_slicing",
            "approximate": False,
            "sample_count": None,
            "exact_front_limit": _EXACT_FRONT_LIMIT,
            "normalization": [],
            "values": [],
        }
    raw = [tuple(float(value) for value in point) for point in points]
    width = len(raw[0])
    if width == 0 or any(len(point) != width for point in raw):
        raise ValueError("objective vectors must have one common positive dimension")
    lows = [min(point[index] for point in raw) for index in range(width)]
    highs = [max(point[index] for point in raw) for index in range(width)]
    normalized = [
        tuple(
            0.0 if highs[index] == lows[index] else (point[index] - lows[index]) / (highs[index] - lows[index])
            for index in range(width)
        )
        for point in raw
    ]
    reference = tuple(1.0 + reference_margin for _ in range(width))
    maximum_hypervolume = math.prod(reference)
    step = max(1, math.ceil(len(normalized) / max(1, max_trace_points)))
    checkpoints = set(range(1, len(normalized) + 1, step)) | {len(normalized)}
    front_checkpoints: list[tuple[int, tuple[tuple[float, ...], ...]]] = []
    front: list[tuple[float, ...]] = []
    for count, point in enumerate(normalized, start=1):
        if not any(_dominates(other, point) for other in front):
            front = [
                other
                for other in front
                if not _dominates(point, other)
            ]
            if point not in front:
                front.append(point)
        if count not in checkpoints:
            continue
        front_checkpoints.append((count, tuple(front)))

    use_approximation = max((len(item) for _, item in front_checkpoints), default=0) > _EXACT_FRONT_LIMIT
    if use_approximation:
        values = _approximate_hypervolume_trace(
            normalized,
            reference,
            [(count, len(item)) for count, item in front_checkpoints],
            maximum_hypervolume,
            _APPROXIMATE_SAMPLE_COUNT,
        )
    else:
        values = []
        for count, checkpoint_front in front_checkpoints:
            dominated = hypervolume(checkpoint_front, reference)
            values.append({
                "evaluation": count,
                "hypervolume": dominated,
                "coverage_fraction": dominated / maximum_hypervolume,
                "coverage_percent": 100.0 * dominated / maximum_hypervolume,
                "front_size": len(checkpoint_front),
            })
    return {
        "dimensions": width,
        "reference_point": list(reference),
        "reference_margin": reference_margin,
        "maximum_hypervolume": maximum_hypervolume,
        "method": "deterministic_halton_estimate" if use_approximation else "exact_axis_slicing",
        "approximate": use_approximation,
        "sample_count": _APPROXIMATE_SAMPLE_COUNT if use_approximation else None,
        "exact_front_limit": _EXACT_FRONT_LIMIT,
        "trace_sample_step": step,
        "normalization": [
            {"minimum": lows[index], "maximum": highs[index]}
            for index in range(width)
        ],
        "values": values,
    }
