from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from typing import TypeVar
from dataclasses import dataclass

from .config import ParameterSpec

T = TypeVar("T")


@dataclass(frozen=True)
class CandidateResult:
    candidate: object
    feasible: bool
    score: float | None
    reason: str = ""


@dataclass(frozen=True)
class TestCandidate:
    """A deterministic, bounded perturbation used to exercise the optimizer pipeline."""

    id: str
    values: dict[str, float]
    changes: dict[str, float]


def generate_test_candidates(
    baseline: dict[str, float],
    specs: Sequence[ParameterSpec],
    symmetry_groups: Sequence[Sequence[str]],
    fixed_parameters: Sequence[dict[str, object]],
    vary: Sequence[str],
    count: int = 3,
    fractional_step: float = 0.05,
) -> list[TestCandidate]:
    """Create a tiny reproducible search around a known baseline.

    This is intentionally not a general optimizer.  It exists to validate the
    complete candidate -> preflight -> LTspice -> metric -> ranking path.
    """
    if not 1 <= count <= 8:
        raise ValueError("test optimization is limited to 1..8 candidates")
    if not 0 < fractional_step <= 0.25:
        raise ValueError("fractional step must be greater than 0 and at most 0.25")
    spec_by_id = {spec.id: spec for spec in specs}
    fixed_ids = {str(item["id"]) for item in fixed_parameters}
    requested = list(dict.fromkeys(vary))
    if not requested:
        raise ValueError("at least one parameter must be selected with --vary")
    unknown = [parameter_id for parameter_id in requested if parameter_id not in spec_by_id]
    if unknown:
        raise ValueError(f"unknown parameter(s): {', '.join(unknown)}")
    forbidden = [parameter_id for parameter_id in requested if parameter_id in fixed_ids]
    if forbidden:
        raise ValueError(f"fixed parameter(s) cannot be varied: {', '.join(forbidden)}")

    groups: dict[str, tuple[str, ...]] = {}
    for group in symmetry_groups:
        members = tuple(str(item) for item in group)
        for member in members:
            groups[member] = members

    candidates = [TestCandidate("baseline", dict(baseline), {})]
    scale = 1
    while len(candidates) < count:
        before = len(candidates)
        for parameter_id in requested:
            members = groups.get(parameter_id, (parameter_id,))
            for direction, name in ((-1.0, "minus"), (1.0, "plus")):
                if len(candidates) >= count:
                    break
                delta = direction * scale * fractional_step
                values = dict(baseline)
                changes: dict[str, float] = {}
                valid = True
                for member in members:
                    spec = spec_by_id[member]
                    proposed = float(baseline[member]) * (1.0 + delta)
                    if not spec.minimum <= proposed <= spec.maximum:
                        valid = False
                        break
                    values[member] = proposed
                    changes[member] = proposed
                if not valid or values == baseline:
                    continue
                percent = round(abs(delta) * 100.0, 6)
                label = "_".join(members)
                candidates.append(TestCandidate(f"{label}_{name}_{percent:g}pct", values, changes))
        if len(candidates) == before:
            raise ValueError("could not generate enough distinct in-bound test candidates")
        scale += 1
    return candidates


def pipeline_test_score(summary: dict[str, object]) -> float:
    """Rank a test batch without promoting the legacy GM to a new objective."""
    parts = summary.get("legacy_score_parts")
    if not isinstance(parts, dict):
        raise ValueError("simulation summary has no score breakdown")
    return sum(float(value) for name, value in parts.items() if name not in {"legacy_gm", "gm_legacy"})


def evaluate_small_batch(candidates: Iterable[T], evaluator: Callable[[T], float], maximum: int = 8) -> list[tuple[T, float]]:
    """Test seam for future optimizers; deliberately refuses large campaigns."""
    selected = list(candidates)
    if len(selected) > maximum:
        raise ValueError(f"reduced evaluation is limited to {maximum} candidates")
    return [(candidate, evaluator(candidate)) for candidate in selected]


def evaluate_feasible_batch(
    candidates: Iterable[T],
    feasibility: Callable[[T], tuple[bool, str]],
    evaluator: Callable[[T], float],
    maximum: int = 8,
) -> list[CandidateResult]:
    """Enforce hard feasibility before invoking an expensive evaluator."""
    selected = list(candidates)
    if len(selected) > maximum:
        raise ValueError(f"reduced evaluation is limited to {maximum} candidates")
    results: list[CandidateResult] = []
    for candidate in selected:
        feasible, reason = feasibility(candidate)
        results.append(CandidateResult(candidate, feasible, evaluator(candidate) if feasible else None, reason))
    return results
