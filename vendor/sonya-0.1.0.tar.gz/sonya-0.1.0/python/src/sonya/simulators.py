from __future__ import annotations

from dataclasses import asdict, dataclass
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from typing import Protocol

import numpy as np

from .config import SonyaConfig
from .ltspice import LTspiceRunner
from .metrics.canonical import frequency_metrics, slew_metrics, transient_metrics, window_extrema
from .metrics.gedlee_crowe import crowe_gedlee_adaptive
from .netlist import LEGACY_FREQUENCIES_HZ, write_ngspice_legacy_parameter_file
from .parsers.ngspice import read_ngspice_fourier_thd, read_wrdata
from .provenance import write_provenance
from .topology import TopologyManifest, load_topology_manifest, stage_topology


@dataclass(frozen=True)
class SimulatorCapabilities:
    batch: bool
    operating_point: bool
    transient: bool
    ac: bool
    fourier: bool
    programme_audio: str
    legacy_topology: str


@dataclass(frozen=True)
class SimulatorDoctor:
    backend: str
    executable: str | None
    available: bool
    version: str | None
    ready: bool
    capabilities: SimulatorCapabilities
    details: dict[str, object]


@dataclass(frozen=True)
class SimulatorSmokeResult:
    backend: str
    passed: bool
    command: tuple[str, ...]
    working_directory: Path
    log_path: Path | None
    provenance_path: Path | None
    measured_vout: float | None


class SimulatorBackend(Protocol):
    id: str

    def doctor(self) -> SimulatorDoctor: ...

    def smoke_test(self, output_root: str | Path | None = None) -> SimulatorSmokeResult: ...

    def run_legacy_mode(
        self,
        parameters: dict[str, float],
        mode: str,
        output_root: str | Path | None = None,
        parameter_source: str | Path | None = None,
        reltol: float = 0.001,
        input_rms_v: float | None = None,
    ) -> dict[str, object]: ...


def _read_ngspice_operating_point(log_text: str, node: str) -> float | None:
    """Read a node voltage from ngspice's operating-point table or print table."""
    escaped = re.escape(node)
    table_match = re.search(
        rf"^\s*{escaped}\s+([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s*$",
        log_text,
        re.IGNORECASE | re.MULTILINE,
    )
    if table_match:
        return float(table_match.group(1))

    lines = log_text.splitlines()
    for index, line in enumerate(lines):
        if re.search(rf"\bv\({escaped}\)", line, re.IGNORECASE):
            for row in lines[index + 1 : index + 12]:
                values = re.findall(r"[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?", row)
                if len(values) >= 2:
                    return float(values[-1])
    return None


class LTspiceBackend:
    id = "ltspice"

    def __init__(self, config: SonyaConfig, topology: TopologyManifest | None = None):
        self.config = config
        self.runner = LTspiceRunner(config, topology)
        self.topology = self.runner.topology

    def capabilities(self) -> SimulatorCapabilities:
        return SimulatorCapabilities(True, True, True, True, True, "implemented", self.topology.backends[self.id].status)

    def doctor(self) -> SimulatorDoctor:
        result = self.runner.doctor()
        return SimulatorDoctor(
            backend=self.id,
            executable=result.executable,
            available=result.exists and result.executable_bit,
            version=result.bundle_version,
            ready=result.ready,
            capabilities=self.capabilities(),
            details=asdict(result),
        )

    def smoke_test(self, output_root: str | Path | None = None) -> SimulatorSmokeResult:
        result = self.runner.smoke_test(output_root)
        match = re.search(r"vout\s*[:=]\s*([+-]?[0-9.eE+-]+)", result.log_text, re.IGNORECASE)
        measured = float(match.group(1)) if match else (0.5 if "0.5" in result.log_text else None)
        passed = result.return_code == 0 and measured is not None and abs(measured - 0.5) < 1e-6
        return SimulatorSmokeResult(
            self.id,
            passed,
            result.command,
            result.working_directory,
            result.log_path,
            result.provenance_path,
            measured,
        )

    def run_legacy_mode(
        self,
        parameters: dict[str, float],
        mode: str,
        output_root: str | Path | None = None,
        parameter_source: str | Path | None = None,
        reltol: float = 0.001,
        input_rms_v: float | None = None,
    ) -> dict[str, object]:
        return self.runner.run_legacy_mode(
            parameters,
            mode,
            output_root=output_root,
            parameter_source=parameter_source,
            reltol=reltol,
            input_rms_v=input_rms_v,
        )


class NgspiceBackend:
    id = "ngspice"

    def __init__(self, config: SonyaConfig, topology: TopologyManifest | None = None):
        self.config = config
        configured_topologies = tuple(load_topology_manifest(path) for path in config.topology_manifest_paths)
        self.topology = topology or next(item for item in configured_topologies if item.id == config.default_topology_id)
        override = os.environ.get("SONYA_NGSPICE")
        discovered = override or shutil.which("ngspice")
        self.executable = Path(discovered).expanduser().resolve() if discovered else None
        self.timeout_seconds = float(config.raw["simulator"]["timeout_seconds"])

    def capabilities(self) -> SimulatorCapabilities:
        return SimulatorCapabilities(True, True, True, True, True, "implemented", self.topology.backends[self.id].status)

    def doctor(self) -> SimulatorDoctor:
        if self.executable is None or not self.executable.is_file():
            return SimulatorDoctor(self.id, str(self.executable) if self.executable else None, False, None, False, self.capabilities(), {})
        completed = subprocess.run(
            (str(self.executable), "--version"),
            capture_output=True,
            text=True,
            timeout=self.timeout_seconds,
            check=False,
        )
        text = f"{completed.stdout}\n{completed.stderr}"
        match = re.search(r"ngspice-([0-9][^\s:]*)", text, re.IGNORECASE)
        version = match.group(1) if match else None
        ready = completed.returncode == 0 and version is not None
        return SimulatorDoctor(
            self.id,
            str(self.executable),
            True,
            version,
            ready,
            self.capabilities(),
            {"return_code": completed.returncode, "version_output": text.strip()},
        )

    def smoke_test(self, output_root: str | Path | None = None) -> SimulatorSmokeResult:
        doctor = self.doctor()
        if not doctor.ready or self.executable is None:
            raise RuntimeError("ngspice is not ready; install it or set SONYA_NGSPICE")
        root = Path(output_root).resolve() if output_root else self.config.processed_root
        root.mkdir(parents=True, exist_ok=True)
        work = Path(tempfile.mkdtemp(prefix="ngspice-smoke-", dir=root))
        netlist = work / "smoke.cir"
        netlist.write_text(
            "* Sonya ngspice local smoke test\n"
            "V1 in 0 DC 1\n"
            "R1 in out 1k\n"
            "R2 out 0 1k\n"
            ".op\n"
            ".print op v(out)\n"
            ".end\n",
            encoding="ascii",
        )
        log = work / "smoke.log"
        command = (str(self.executable), "-b", "-o", str(log), str(netlist))
        completed = subprocess.run(
            command,
            cwd=work,
            capture_output=True,
            text=True,
            timeout=self.timeout_seconds,
            check=False,
        )
        log_text = log.read_text(encoding="utf-8", errors="replace") if log.exists() else ""
        measured = _read_ngspice_operating_point(log_text, "out")
        passed = completed.returncode == 0 and measured is not None and abs(measured - 0.5) < 1e-6
        provenance = write_provenance(
            work / "provenance.json",
            [netlist, self.config.source],
            "ngspice_local_smoke_test",
            {
                "backend": self.id,
                "version": doctor.version,
                "command": list(command),
                "return_code": completed.returncode,
                "measured_vout": measured,
            },
        )
        return SimulatorSmokeResult(self.id, passed, command, work, log if log.exists() else None, provenance, measured)

    def run_legacy_mode(
        self,
        parameters: dict[str, float],
        mode: str,
        output_root: str | Path | None = None,
        parameter_source: str | Path | None = None,
        reltol: float = 0.001,
        input_rms_v: float | None = None,
    ) -> dict[str, object]:
        doctor = self.doctor()
        if not doctor.ready or self.executable is None:
            raise RuntimeError("ngspice is not ready; install it or set SONYA_NGSPICE")
        root = Path(output_root).resolve() if output_root else self.config.processed_root
        root.mkdir(parents=True, exist_ok=True)
        work = Path(tempfile.mkdtemp(prefix=f"ngspice-legacy-{mode}-", dir=root))
        crowe_cfg = self.config.raw["legacy_evaluation"]["gm"]["crowe"]
        selected_input_rms = (
            float(crowe_cfg["input_peak_v"]) / np.sqrt(2.0)
            if mode == "crowe"
            else float(input_rms_v if input_rms_v is not None else self.config.raw["legacy_evaluation"]["input_rms_v"])
        )
        crowe_timestep_s = 1.0 / (float(crowe_cfg["fundamental_hz"]) * int(crowe_cfg["samples_per_cycle"]))
        parameter_path = write_ngspice_legacy_parameter_file(
            work / "param", parameters, mode, reltol, selected_input_rms, crowe_timestep_s
        )
        staged = stage_topology(self.topology, self.id, work / "run", parameter_path)
        log_path = staged.circuit.with_suffix(".log")
        command = (str(self.executable), "-b", "-o", str(log_path), staged.circuit.name)
        completed = subprocess.run(
            command,
            cwd=staged.working_directory,
            capture_output=True,
            text=True,
            timeout=self.timeout_seconds,
            check=False,
        )
        log_text = log_path.read_text(encoding="utf-8", errors="replace") if log_path.exists() else ""
        if completed.returncode != 0 or "simulation(s) aborted" in log_text.lower() or re.search(r"(?im)^\s*fatal\s+error", log_text):
            raise RuntimeError(f"ngspice failed with exit code {completed.returncode}; inspect {log_path}")
        measurements: dict[str, float] = {}
        ac_db: dict[str, float] = {}
        fourier_thd: float | None = None
        native_fourier_thd: float | None = None
        harmonics: list[list[float]] = []
        data_path = staged.working_directory / f"sonya-{mode}.dat"
        _, data = read_wrdata(data_path)
        post = self.config.raw["legacy_evaluation"].get("canonical_postprocessing", {})
        if mode == "op":
            row = data[-1]
            if row.size < 15:
                raise RuntimeError(f"ngspice operating-point export is incomplete: {data_path}")
            vaa = float(row[1])
            supply_current = abs(float(row[2]))
            plate_a, plate_b = abs(float(row[7])), abs(float(row[8]))
            measurements = {
                "vaa_v": vaa,
                "bplus_supply_current_a": supply_current,
                "bplus_input_power_w": vaa * supply_current,
                "el84a_plate_v": float(row[3]),
                "el84b_plate_v": float(row[4]),
                "el84a_grid_v": float(row[5]),
                "el84b_grid_v": float(row[6]),
                "el84a_plate_current_a": plate_a,
                "el84b_plate_current_a": plate_b,
                "el84a_screen_current_a": abs(float(row[9])),
                "el84b_screen_current_a": abs(float(row[10])),
                "el84a_plate_dissipation_w": float(row[3]) * plate_a,
                "el84b_plate_dissipation_w": float(row[4]) * plate_b,
                "mje340_q1_vce_v": float(row[11]),
                "mje340_q2_vce_v": float(row[12]),
                "mje340_q1_collector_current_a": abs(float(row[13])),
                "mje340_q2_collector_current_a": abs(float(row[14])),
                "mje340_q1_dissipation_w": float(row[11]) * abs(float(row[13])),
                "mje340_q2_dissipation_w": float(row[12]) * abs(float(row[14])),
            }
        elif mode == "tran":
            metrics = transient_metrics(
                data[:, 0],
                data[:, 1],
                data[:, 2],
                float(self.config.raw["legacy_evaluation"].get("simulation_load_ohm", 8.0)),
                float(self.config.raw["legacy_evaluation"].get("fundamental_hz", 1000.0)),
                harmonics=int(post.get("thd_harmonics", 10)),
                thd_cycles=int(post.get("thd_cycles", 10)),
                samples_per_cycle=int(post.get("thd_samples_per_cycle", 1000)),
            )
            measurements = {
                "vout_rms": metrics.output_rms,
                "vin_rms": metrics.input_rms,
                "gain_rms": metrics.gain_rms,
                "output_power": metrics.output_power_w,
            }
            fourier_thd = metrics.thd_percent
            harmonics = [[index + 1, amplitude] for index, amplitude in enumerate(metrics.harmonic_amplitudes)]
            native_fourier_thd = read_ngspice_fourier_thd(log_text)
        elif mode == "crowe":
            crowe, crowe_stability = crowe_gedlee_adaptive(
                data[:, 0],
                data[:, 1],
                float(crowe_cfg["fundamental_hz"]),
                harmonic_orders=tuple(int(value) for value in crowe_cfg["harmonic_orders"]),
                cycles=int(crowe_cfg["cycles"]),
                samples_per_cycle=int(crowe_cfg["samples_per_cycle"]),
                convergence_tolerance=float(crowe_cfg["convergence_tolerance"]),
                consecutive_converged_steps=int(crowe_cfg["consecutive_converged_steps"]),
            )
            measurements = {
                "gm_crowe": crowe.value,
                "gm_crowe_memory_ratio": crowe.memory_ratio,
                "gm_crowe_fit_residual_rms_relative": crowe.fit_residual_rms_relative,
                "gm_crowe_input_peak_v": float(crowe_cfg["input_peak_v"]),
                "gm_crowe_selected_harmonics": float(crowe_stability["selected_harmonics"]),
            }
        elif mode == "ac":
            frequency, magnitude_db = data[:, 0], data[:, 1]
            metrics = frequency_metrics(frequency, magnitude_db, LEGACY_FREQUENCIES_HZ)
            measurements = {"fclo": metrics.low_cutoff_hz, "fchi": metrics.high_cutoff_hz, "gmax": metrics.peak_db}
            sampled = np.interp(np.log10(LEGACY_FREQUENCIES_HZ), np.log10(frequency), magnitude_db)
            ac_db = {f"f{round(frequency_hz)}hz": float(value) for frequency_hz, value in zip(LEGACY_FREQUENCIES_HZ, sampled)}
        elif mode == "slew":
            metrics = slew_metrics(
                data[:, 0],
                data[:, 1],
                resample_interval_s=float(post.get("slew_resample_interval_s", 1e-7)),
            )
            measurements = {
                "maxslew": metrics.maximum_v,
                "minslew": metrics.minimum_v,
                "slew": metrics.slew_v_per_s,
                "slew_rising": metrics.rising_v_per_s,
                "slew_falling": metrics.falling_v_per_s,
                "slew_crossing_count": metrics.crossing_count,
            }
        else:
            gm = self.config.raw["legacy_evaluation"]["gm"]
            window_seconds = float(gm["window_seconds"])
            window_count = int(round(float(gm["extraction_seconds"]) / window_seconds))
            minima, maxima = window_extrema(
                data[:, 0],
                data[:, 1],
                window_seconds,
                window_count,
                float(post.get("gm_resample_interval_s", 2e-6)),
            )
            measurements = {
                **{f"min{index}": float(value) for index, value in enumerate(minima)},
                **{f"max{index}": float(value) for index, value in enumerate(maxima)},
            }
        diagnostics = [line.strip() for line in log_text.splitlines() if re.search(r"\b(?:fatal|error|warning|failed)\b", line, re.IGNORECASE)]
        provenance_inputs: list[str | Path] = [*staged.inputs, self.config.source]
        if parameter_source is not None:
            provenance_inputs.append(parameter_source)
        provenance = write_provenance(
            staged.working_directory / "provenance.json",
            provenance_inputs,
            f"ngspice_legacy_{mode}",
            {
                "backend": self.id,
                "backend_version": doctor.version,
                "topology": self.topology.id,
                "model_status": "shared_open_koren_models_for_ltspice_and_ngspice",
                "command": list(command),
                "return_code": completed.returncode,
                "input_rms_v": selected_input_rms,
                "translation_manifest": str(staged.manifest),
            },
        )
        return {
            "mode": mode,
            "working_directory": str(staged.working_directory),
            "log_path": str(log_path),
            "raw_path": str(data_path),
            "provenance_path": str(provenance),
            "measurements": measurements,
            "ac_db": ac_db,
            "fourier_thd_percent": fourier_thd,
            "native_fourier_thd_percent": native_fourier_thd,
            "harmonics": harmonics,
            "gm_crowe_details": crowe.record() if mode == "crowe" else None,
            "gm_crowe_stability": crowe_stability if mode == "crowe" else None,
            "failed_measurements": [],
            "diagnostics": diagnostics,
        }


def simulator_backends(config: SonyaConfig, topology: TopologyManifest | None = None) -> dict[str, SimulatorBackend]:
    return {"ltspice": LTspiceBackend(config, topology), "ngspice": NgspiceBackend(config, topology)}


def simulator_backend(config: SonyaConfig, backend_id: str, topology: TopologyManifest | None = None) -> SimulatorBackend:
    backends = simulator_backends(config, topology)
    try:
        return backends[backend_id]
    except KeyError as exc:
        raise ValueError(f"unknown simulator backend: {backend_id}") from exc
