from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import math
import os
from pathlib import Path
import re
from typing import Literal

import yaml


class ProgrammeConfigError(ValueError):
    pass


ProgrammeRole = Literal["candidate", "development", "validation", "subjective", "reserve"]
PROGRAMME_ROLES: tuple[ProgrammeRole, ...] = ("candidate", "development", "validation", "subjective", "reserve")


@dataclass(frozen=True)
class ProgrammeItem:
    id: str
    path: Path | None
    roles: tuple[ProgrammeRole, ...]
    categories: tuple[str, ...]
    start_seconds: float
    duration_seconds: float
    sha256: str | None
    title: str
    source_collection: str | None
    source_track: str | None
    source_url: str | None
    usage_terms: str | None
    notes: str | None
    channel: int
    canonical_path: Path | None
    canonical_sha256: str | None


@dataclass(frozen=True)
class ProgrammeLevel:
    id: str
    description: str
    calibration_status: str
    amplitude_kind: Literal["peak_v"]
    target_peak_v: float


@dataclass(frozen=True)
class ProgrammeManifest:
    source: Path
    status: str
    required_categories: tuple[str, ...]
    levels: tuple[ProgrammeLevel, ...]
    primary_metric: str
    secondary_metrics: tuple[str, ...]
    items: tuple[ProgrammeItem, ...]
    required_role_counts: tuple[tuple[ProgrammeRole, int], ...]
    identical_role_sets: tuple[tuple[ProgrammeRole, ...], ...]
    subset_role_sets: tuple[tuple[ProgrammeRole, ProgrammeRole], ...]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_programme_manifest(path: str | Path) -> ProgrammeManifest:
    source = Path(path).expanduser().resolve()
    try:
        raw = yaml.safe_load(source.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise ProgrammeConfigError(f"cannot read programme manifest {source}: {exc}") from exc
    if not isinstance(raw, dict) or raw.get("schema_version") != 1:
        raise ProgrammeConfigError("programme manifest must use schema_version 1")
    selection = raw.get("selection")
    evaluation = raw.get("evaluation")
    if not isinstance(selection, dict) or not isinstance(evaluation, dict):
        raise ProgrammeConfigError("programme manifest requires selection and evaluation mappings")
    levels_raw = evaluation.get("levels")
    items_raw = raw.get("items")
    if not isinstance(levels_raw, list) or not levels_raw:
        raise ProgrammeConfigError("evaluation.levels must be a non-empty list")
    if not isinstance(items_raw, list):
        raise ProgrammeConfigError("items must be a list")

    corpus_override = Path(os.environ["SONYA_CORPUS_ROOT"]).expanduser().resolve() if "SONYA_CORPUS_ROOT" in os.environ else None

    def resolved_item_path(raw_value: object) -> Path | None:
        if raw_value in {None, ""}:
            return None
        relative = Path(str(raw_value))
        if corpus_override is not None and "corpus" in relative.parts:
            corpus_index = relative.parts.index("corpus")
            return corpus_override.joinpath(*relative.parts[corpus_index + 1 :]).resolve()
        return (source.parent / relative).resolve()

    role_contract = selection.get("role_contract", {})
    if not isinstance(role_contract, dict):
        raise ProgrammeConfigError("selection.role_contract must be a mapping")
    counts_raw = role_contract.get("exact_counts", {})
    identical_raw = role_contract.get("identical_sets", [])
    subsets_raw = role_contract.get("subset_sets", [])
    if not isinstance(counts_raw, dict) or not isinstance(identical_raw, list) or not isinstance(subsets_raw, list):
        raise ProgrammeConfigError("invalid selection.role_contract")

    def checked_role(value: object) -> ProgrammeRole:
        role = str(value)
        if role not in PROGRAMME_ROLES:
            raise ProgrammeConfigError(f"invalid programme role: {role}")
        return role  # type: ignore[return-value]

    required_role_counts: list[tuple[ProgrammeRole, int]] = []
    for role_value, count_value in counts_raw.items():
        role = checked_role(role_value)
        count = int(count_value)
        if count < 0:
            raise ProgrammeConfigError(f"invalid exact count for programme role {role}")
        required_role_counts.append((role, count))

    identical_role_sets: list[tuple[ProgrammeRole, ...]] = []
    for group in identical_raw:
        if not isinstance(group, list) or len(group) < 2:
            raise ProgrammeConfigError("each identical role set must contain at least two roles")
        identical_role_sets.append(tuple(checked_role(value) for value in group))

    subset_role_sets: list[tuple[ProgrammeRole, ProgrammeRole]] = []
    for pair in subsets_raw:
        if not isinstance(pair, list) or len(pair) != 2:
            raise ProgrammeConfigError("each subset role set must contain [subset, superset]")
        subset_role_sets.append((checked_role(pair[0]), checked_role(pair[1])))

    levels_list: list[ProgrammeLevel] = []
    for item in levels_raw:
        amplitude_kind = str(item.get("amplitude_kind", "peak_v"))
        target_peak_v = float(item.get("target_peak_v", 0.0))
        if amplitude_kind != "peak_v" or not math.isfinite(target_peak_v) or target_peak_v <= 0:
            raise ProgrammeConfigError(f"invalid peak-voltage calibration for programme level {item.get('id')}")
        levels_list.append(ProgrammeLevel(
            str(item["id"]),
            str(item["description"]),
            str(item["calibration_status"]),
            "peak_v",
            target_peak_v,
        ))
    levels = tuple(levels_list)
    items: list[ProgrammeItem] = []
    seen: set[str] = set()
    for item in items_raw:
        if not isinstance(item, dict):
            raise ProgrammeConfigError("each programme item must be a mapping")
        item_id = str(item["id"])
        if item_id in seen:
            raise ProgrammeConfigError(f"duplicate programme item: {item_id}")
        seen.add(item_id)
        has_role = "role" in item
        has_roles = "roles" in item
        if has_role == has_roles:
            raise ProgrammeConfigError(f"programme item {item_id} must declare exactly one of role or roles")
        roles_raw = [item["role"]] if has_role else item["roles"]
        if not isinstance(roles_raw, list) or not roles_raw:
            raise ProgrammeConfigError(f"programme item {item_id} roles must be a non-empty list")
        roles = tuple(checked_role(value) for value in roles_raw)
        if len(set(roles)) != len(roles):
            raise ProgrammeConfigError(f"duplicate programme role for item {item_id}")
        raw_path = item.get("path")
        item_path = resolved_item_path(raw_path)
        start = float(item.get("start_seconds", 0.0))
        duration = float(item["duration_seconds"])
        if start < 0 or duration <= 0:
            raise ProgrammeConfigError(f"invalid time range for programme item {item_id}")
        categories = tuple(str(value) for value in item.get("categories", []))
        expected_hash = item.get("sha256")
        if expected_hash is not None and not re.fullmatch(r"[0-9a-fA-F]{64}", str(expected_hash)):
            raise ProgrammeConfigError(f"invalid SHA-256 for programme item {item_id}")
        raw_canonical_path = item.get("canonical_path")
        canonical_path = resolved_item_path(raw_canonical_path)
        canonical_hash = item.get("canonical_sha256")
        if canonical_hash is not None and not re.fullmatch(r"[0-9a-fA-F]{64}", str(canonical_hash)):
            raise ProgrammeConfigError(f"invalid canonical SHA-256 for programme item {item_id}")
        if (canonical_path is None) != (canonical_hash is None):
            raise ProgrammeConfigError(f"programme item {item_id} must declare canonical_path and canonical_sha256 together")
        channel = int(item.get("channel", 0))
        if channel < 0:
            raise ProgrammeConfigError(f"invalid channel for programme item {item_id}")
        items.append(ProgrammeItem(
            item_id,
            item_path,
            roles,
            categories,
            start,
            duration,
            str(expected_hash).lower() if expected_hash else None,
            str(item.get("title", item_id)),
            str(item["source_collection"]) if item.get("source_collection") else None,
            str(item["source_track"]) if item.get("source_track") else None,
            str(item["source_url"]) if item.get("source_url") else None,
            str(item["usage_terms"]) if item.get("usage_terms") else None,
            str(item["notes"]) if item.get("notes") else None,
            channel,
            canonical_path,
            str(canonical_hash).lower() if canonical_hash else None,
        ))

    metrics = evaluation.get("metrics")
    if not isinstance(metrics, dict) or not metrics.get("primary"):
        raise ProgrammeConfigError("evaluation.metrics.primary is required")
    return ProgrammeManifest(
        source=source,
        status=str(raw.get("status", "unknown")),
        required_categories=tuple(str(item) for item in selection.get("required_categories", [])),
        levels=levels,
        primary_metric=str(metrics["primary"]),
        secondary_metrics=tuple(str(item) for item in metrics.get("secondary", [])),
        items=tuple(items),
        required_role_counts=tuple(required_role_counts),
        identical_role_sets=tuple(identical_role_sets),
        subset_role_sets=tuple(subset_role_sets),
    )


def programme_report(manifest: ProgrammeManifest) -> dict[str, object]:
    category_coverage = {category: 0 for category in manifest.required_categories}
    validation_category_coverage = {category: 0 for category in manifest.required_categories}
    role_counts = {role: 0 for role in PROGRAMME_ROLES}
    role_ids: dict[str, set[str]] = {role: set() for role in PROGRAMME_ROLES}
    item_records: list[dict[str, object]] = []
    all_files_ready = True
    hashes_match = True
    canonical_files_ready = True
    canonical_hashes_match = True
    for item in manifest.items:
        for role in item.roles:
            role_counts[role] += 1
            role_ids[role].add(item.id)
        for category in item.categories:
            if category in category_coverage:
                category_coverage[category] += 1
                if "validation" in item.roles:
                    validation_category_coverage[category] += 1
        exists = item.path is not None and item.path.is_file()
        all_files_ready = all_files_ready and exists
        actual_hash = _sha256(item.path) if exists and item.path is not None else None
        hash_matches = item.sha256 is not None and actual_hash == item.sha256
        hashes_match = hashes_match and hash_matches
        canonical_required = "validation" in item.roles or "development" in item.roles or "subjective" in item.roles
        canonical_exists = item.canonical_path is not None and item.canonical_path.is_file()
        actual_canonical_hash = _sha256(item.canonical_path) if canonical_exists and item.canonical_path is not None else None
        canonical_hash_matches = item.canonical_sha256 is not None and actual_canonical_hash == item.canonical_sha256
        if canonical_required:
            canonical_files_ready = canonical_files_ready and canonical_exists
            canonical_hashes_match = canonical_hashes_match and canonical_hash_matches
        record = asdict(item)
        record.update({
            "path": str(item.path) if item.path else None,
            "exists": exists,
            "actual_sha256": actual_hash,
            "hash_matches": hash_matches,
            "canonical_path": str(item.canonical_path) if item.canonical_path else None,
            "canonical_exists": canonical_exists,
            "actual_canonical_sha256": actual_canonical_hash,
            "canonical_hash_matches": canonical_hash_matches,
        })
        item_records.append(record)
    categories_ready = all(count > 0 for count in validation_category_coverage.values())
    role_contract_violations: list[str] = []
    for role, expected in manifest.required_role_counts:
        actual = role_counts[role]
        if actual != expected:
            role_contract_violations.append(f"role_count:{role}:expected={expected}:actual={actual}")
    for roles in manifest.identical_role_sets:
        reference = role_ids[roles[0]]
        if any(role_ids[role] != reference for role in roles[1:]):
            role_contract_violations.append(f"role_sets_not_identical:{'='.join(roles)}")
    for subset, superset in manifest.subset_role_sets:
        missing = sorted(role_ids[subset] - role_ids[superset])
        if missing:
            role_contract_violations.append(f"role_set_not_subset:{subset}<={superset}:missing={','.join(missing)}")
    roles_ready = role_counts["candidate"] == 0 and role_counts["validation"] > 0 and not role_contract_violations
    levels_ready = all(item.calibration_status == "ready" for item in manifest.levels)
    protocol_ready = (
        manifest.status == "ready"
        and bool(manifest.items)
        and categories_ready
        and roles_ready
        and levels_ready
    )
    assets_ready = all_files_ready and hashes_match and canonical_files_ready and canonical_hashes_match
    programme_ready = protocol_ready and assets_ready
    ready = programme_ready
    return {
        "source": str(manifest.source),
        "status": manifest.status,
        "ready": ready,
        "item_count": len(manifest.items),
        "category_coverage": category_coverage,
        "validation_category_coverage": validation_category_coverage,
        "role_counts": role_counts,
        "role_ids": {role: sorted(ids) for role, ids in role_ids.items()},
        "role_contract": {
            "passed": not role_contract_violations,
            "violations": role_contract_violations,
        },
        "levels_ready": levels_ready,
        "assets_ready": assets_ready,
        "programme_ready": programme_ready,
        "protocol_ready": protocol_ready,
        "levels": [asdict(item) for item in manifest.levels],
        "metrics": {"primary": manifest.primary_metric, "secondary": list(manifest.secondary_metrics)},
        "items": item_records,
    }


def pareto_front(
    records: list[dict[str, object]],
    objectives: dict[str, Literal["minimize", "maximize"]],
) -> list[dict[str, object]]:
    """Return the nondominated, feasible and fully evaluated records."""
    return pareto_audit(records, objectives)["front"]  # type: ignore[return-value]


def pareto_audit(
    records: list[dict[str, object]],
    objectives: dict[str, Literal["minimize", "maximize"]],
    required_evidence: tuple[str, ...] = (),
) -> dict[str, object]:
    """Build a Pareto front while preserving every validity exclusion.

    Objective values and evidence are deliberately separate.  A candidate can
    have perceptual scores without being eligible for a validated front when,
    for example, those scores came only from the development corpus.
    """

    complete: list[dict[str, object]] = []
    excluded: dict[str, list[str]] = {}
    for index, record in enumerate(records):
        candidate_id = str(record.get("candidate_id", record.get("id", f"record-{index}")))
        reasons: list[str] = []
        metrics = record.get("metrics")
        if not record.get("feasible", True):
            reasons.append("infeasible")
        if not isinstance(metrics, dict):
            reasons.append("missing_metrics")
        else:
            missing = [name for name in objectives if name not in metrics]
            if missing:
                reasons.extend(f"missing_metric:{name}" for name in missing)
        evidence = record.get("evidence")
        for requirement in required_evidence:
            if not isinstance(evidence, dict) or evidence.get(requirement) is not True:
                reasons.append(f"missing_evidence:{requirement}")
        if reasons:
            excluded[candidate_id] = reasons
            continue
        try:
            assert isinstance(metrics, dict)
            values = [float(metrics[name]) for name in objectives]
        except (TypeError, ValueError):
            excluded[candidate_id] = ["invalid_metric_value"]
            continue
        if not all(math.isfinite(value) for value in values):
            excluded[candidate_id] = ["non_finite_metric"]
            continue
        complete.append(record)

    def dominates(left: dict[str, object], right: dict[str, object]) -> bool:
        left_metrics = left["metrics"]
        right_metrics = right["metrics"]
        assert isinstance(left_metrics, dict) and isinstance(right_metrics, dict)
        no_worse = True
        strictly_better = False
        for name, direction in objectives.items():
            left_value = float(left_metrics[name])
            right_value = float(right_metrics[name])
            if direction == "maximize":
                left_value, right_value = -left_value, -right_value
            no_worse = no_worse and left_value <= right_value
            strictly_better = strictly_better or left_value < right_value
        return no_worse and strictly_better

    front = [candidate for candidate in complete if not any(dominates(other, candidate) for other in complete if other is not candidate)]
    return {
        "objectives": dict(objectives),
        "required_evidence": list(required_evidence),
        "eligible_candidate_ids": [str(item.get("candidate_id", item.get("id"))) for item in complete],
        "excluded": excluded,
        "front_candidate_ids": [str(item.get("candidate_id", item.get("id"))) for item in front],
        "front": front,
    }
