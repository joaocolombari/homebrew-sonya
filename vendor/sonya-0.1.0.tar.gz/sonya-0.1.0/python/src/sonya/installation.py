from __future__ import annotations

from importlib import metadata
import platform
from pathlib import Path
import shutil
import sys

from .config import SonyaConfig
from .perceptual import perceptual_doctors
from .programme import load_programme_manifest, programme_report
from .simulators import simulator_backends
from .topology import load_topology_manifest


def _component(component_id: str, ready: bool, required_for: tuple[str, ...], **details: object) -> dict[str, object]:
    return {
        "id": component_id,
        "ready": ready,
        "status": "ready" if ready else "missing",
        "required_for": list(required_for),
        "details": details,
    }


def installation_report(config: SonyaConfig, programme_path: Path) -> dict[str, object]:
    components: list[dict[str, object]] = []
    dependencies: dict[str, str | None] = {}
    for distribution in ("sonya-jaes", "numpy", "scipy", "matplotlib", "PyYAML"):
        try:
            dependencies[distribution] = metadata.version(distribution)
        except metadata.PackageNotFoundError:
            dependencies[distribution] = None
    components.append(
        _component(
            "python_package",
            all(dependencies.values()),
            ("package", "core", "perceptual"),
            python=sys.version.split()[0],
            executable=sys.executable,
            distributions=dependencies,
        )
    )

    manifests_ready = True
    manifest_errors: list[str] = []
    for manifest_path in config.topology_manifest_paths:
        try:
            load_topology_manifest(manifest_path)
        except Exception as exc:
            manifests_ready = False
            manifest_errors.append(f"{manifest_path}: {exc}")
    components.append(
        _component(
            "project_files",
            manifests_ready,
            ("package", "core", "perceptual"),
            config=str(config.source),
            topology_manifests=[str(path) for path in config.topology_manifest_paths],
            errors=manifest_errors,
        )
    )

    system = platform.system().lower()
    required_backend = "ltspice" if system == "darwin" else "ngspice" if system == "linux" else None
    backend_records = {name: backend.doctor() for name, backend in simulator_backends(config).items()}
    backend_ready = required_backend is not None and backend_records[required_backend].ready
    components.append(
        _component(
            "simulator",
            backend_ready,
            ("core",),
            platform=platform.platform(),
            required_backend=required_backend,
            backends={
                name: {"ready": record.ready, "version": record.version, "executable": record.executable}
                for name, record in backend_records.items()
            },
        )
    )

    ffmpeg = shutil.which("ffmpeg")
    components.append(_component("ffmpeg", ffmpeg is not None, ("perceptual",), executable=ffmpeg))

    metric_records = perceptual_doctors()
    components.append(
        _component(
            "perceptual_metrics",
            all(record.ready for record in metric_records),
            ("perceptual",),
            metrics=[
                {"id": record.id, "ready": record.ready, "version": record.version, "executable": record.executable}
                for record in metric_records
            ],
        )
    )

    try:
        programme = programme_report(load_programme_manifest(programme_path))
        corpus_ready = bool(programme["programme_ready"])
        corpus_details: dict[str, object] = {
            "programme": str(programme_path),
            "protocol_ready": programme["protocol_ready"],
            "assets_ready": programme["assets_ready"],
            "item_count": programme["item_count"],
        }
    except Exception as exc:
        corpus_ready = False
        corpus_details = {"programme": str(programme_path), "error": str(exc)}
    components.append(_component("programme_corpus", corpus_ready, ("perceptual",), **corpus_details))

    scopes = {
        scope: all(bool(item["ready"]) for item in components if scope in item["required_for"])
        for scope in ("package", "core", "perceptual")
    }
    scopes["all"] = scopes["core"] and scopes["perceptual"]
    return {
        "status": "ready" if scopes["all"] else "partial",
        "platform": system,
        "scopes": scopes,
        "components": components,
    }
