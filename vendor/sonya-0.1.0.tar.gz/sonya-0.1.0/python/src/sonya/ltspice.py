from __future__ import annotations

from dataclasses import dataclass
import math
import plistlib
from pathlib import Path
import re
import subprocess
import tempfile

import numpy as np

from .config import SonyaConfig
from .metrics.canonical import frequency_metrics, slew_metrics, transient_metrics, window_extrema
from .metrics.gedlee_crowe import crowe_gedlee_adaptive
from .netlist import LEGACY_FREQUENCIES_HZ, write_parameter_file
from .parsers.legacy import read_ltspice_measurements
from .parsers.ltspice import read_ac_measurements, read_fourier_result, read_raw
from .provenance import write_provenance
from .topology import TopologyManifest, load_topology_manifest, stage_topology


@dataclass(frozen=True)
class LTspiceDoctor:
    executable: str
    exists: bool
    executable_bit: bool
    bundle_version: str | None
    expected_bundle_version: str | None
    version_matches: bool | None
    model_files: dict[str, bool]
    ready: bool


@dataclass(frozen=True)
class SimulationResult:
    command: tuple[str, ...]
    working_directory: Path
    return_code: int
    log_path: Path | None
    log_text: str
    provenance_path: Path | None = None


class LTspiceRunner:
    def __init__(self, config: SonyaConfig, topology: TopologyManifest | None = None):
        self.config = config
        configured_topologies = tuple(load_topology_manifest(path) for path in config.topology_manifest_paths)
        self.topology = topology or next(item for item in configured_topologies if item.id == config.default_topology_id)
        self.executable = config.simulator_executable
        simulator = config.raw["simulator"]
        self.batch_arguments = tuple(str(item) for item in simulator["batch_arguments"])
        self.timeout_seconds = float(simulator["timeout_seconds"])

    def doctor(self) -> LTspiceDoctor:
        plist_path = self.executable.parents[1] / "Info.plist" if len(self.executable.parents) >= 2 else Path()
        version: str | None = None
        if plist_path.is_file():
            with plist_path.open("rb") as stream:
                version = plistlib.load(stream).get("CFBundleShortVersionString")
        expected = self.config.raw["simulator"].get("expected_bundle_version")
        model_paths = [item.source for item in self.topology.backends["ltspice"].dependencies]
        models = {str(path): path.is_file() for path in model_paths}
        exists = self.executable.is_file()
        executable_bit = exists and bool(self.executable.stat().st_mode & 0o111)
        version_matches = (version == str(expected)) if expected is not None and version is not None else None
        return LTspiceDoctor(
            executable=str(self.executable),
            exists=exists,
            executable_bit=executable_bit,
            bundle_version=version,
            expected_bundle_version=str(expected) if expected is not None else None,
            version_matches=version_matches,
            model_files=models,
            ready=exists and executable_bit and all(models.values()) and version_matches is not False,
        )

    def run(self, netlist: str | Path, timeout_seconds: float | None = None) -> SimulationResult:
        source = Path(netlist).resolve()
        if not source.is_file():
            raise FileNotFoundError(source)
        command = (str(self.executable), *self.batch_arguments, source.name)
        completed = subprocess.run(
            command,
            cwd=source.parent,
            capture_output=True,
            text=True,
            timeout=timeout_seconds or self.timeout_seconds,
            check=False,
        )
        log_path = source.with_suffix(".log")
        log_text = ""
        if log_path.exists():
            payload = log_path.read_bytes()
            encodings = ("utf-16",) if payload.startswith((b"\xff\xfe", b"\xfe\xff")) or (payload and payload.count(b"\x00") / len(payload) > 0.1) else ("utf-8-sig", "latin-1")
            for encoding in encodings:
                try:
                    log_text = payload.decode(encoding)
                    break
                except UnicodeError:
                    continue
        if completed.returncode != 0:
            raise RuntimeError(f"LTspice failed with exit code {completed.returncode}: {completed.stderr.strip()}")
        if "fatal error" in log_text.lower():
            raise RuntimeError("LTspice log contains a fatal error")
        return SimulationResult(command, source.parent, completed.returncode, log_path if log_path.exists() else None, log_text)

    def smoke_test(self, output_root: str | Path | None = None) -> SimulationResult:
        root = Path(output_root).resolve() if output_root else self.config.processed_root
        root.mkdir(parents=True, exist_ok=True)
        work = Path(tempfile.mkdtemp(prefix="ltspice-smoke-", dir=root))
        netlist = work / "smoke.sp"
        netlist.write_text(
            "* Sonya LTspice local smoke test\nV1 in 0 1\nR1 in out 1k\nR2 out 0 1k\n.op\n.meas op vout PARAM V(out)\n.end\n",
            encoding="ascii",
        )
        result = self.run(netlist)
        provenance = write_provenance(
            work / "provenance.json",
            [netlist, self.config.source],
            "ltspice_local_smoke_test",
            {
                "executable": str(self.executable),
                "command": list(result.command),
                "return_code": result.return_code,
                "log_path": str(result.log_path) if result.log_path else None,
            },
        )
        return SimulationResult(
            result.command,
            result.working_directory,
            result.return_code,
            result.log_path,
            result.log_text,
            provenance,
        )

    def stage_legacy_circuit(
        self,
        circuit: str | Path,
        destination: str | Path,
        parameter_file: str | Path | None = None,
    ) -> Path:
        """Stage the selected topology through the backend-independent translator."""
        source = Path(circuit).resolve()
        if source != self.topology.circuit:
            raise ValueError("circuit overrides require their own topology manifest")
        parameters = parameter_file
        if parameters is None and (source.parent / "param").is_file():
            parameters = source.parent / "param"
        return stage_topology(self.topology, "ltspice", destination, parameters).circuit

    def run_legacy_mode(
        self,
        parameters: dict[str, float],
        mode: str,
        output_root: str | Path | None = None,
        circuit: str | Path | None = None,
        parameter_source: str | Path | None = None,
        reltol: float = 0.001,
        input_rms_v: float | None = None,
    ) -> dict[str, object]:
        root = Path(output_root).resolve() if output_root else self.config.processed_root
        root.mkdir(parents=True, exist_ok=True)
        work = Path(tempfile.mkdtemp(prefix=f"ltspice-legacy-{mode}-", dir=root))
        circuit_source = Path(circuit).resolve() if circuit else self.topology.circuit
        crowe_cfg = self.config.raw["legacy_evaluation"]["gm"]["crowe"]
        selected_input_rms = (
            float(crowe_cfg["input_peak_v"]) / math.sqrt(2.0)
            if mode == "crowe"
            else float(input_rms_v if input_rms_v is not None else self.config.raw["legacy_evaluation"]["input_rms_v"])
        )
        crowe_timestep_s = 1.0 / (float(crowe_cfg["fundamental_hz"]) * int(crowe_cfg["samples_per_cycle"]))
        rendered_parameters = write_parameter_file(work / "param", parameters, mode, reltol, selected_input_rms, crowe_timestep_s)
        staged = self.stage_legacy_circuit(circuit_source, work / "run", rendered_parameters)
        result = self.run(staged)
        log_path = result.log_path
        native_measurements = read_ltspice_measurements(log_path) if log_path else {}
        native_ac_db = read_ac_measurements(log_path) if log_path and mode == "ac" else {}
        native_fourier = read_fourier_result(log_path) if log_path and mode == "tran" else None
        measurements = dict(native_measurements)
        ac_db = dict(native_ac_db)
        fourier_thd = native_fourier.thd_percent if native_fourier else None
        harmonics = [list(row) for row in native_fourier.harmonics] if native_fourier else []
        raw_path = staged.with_suffix(".raw")
        post = self.config.raw["legacy_evaluation"].get("canonical_postprocessing", {})
        if mode != "op" and raw_path.is_file():
            raw = read_raw(raw_path)
            if mode == "tran":
                metrics = transient_metrics(
                    raw.values["time"],
                    raw.values["V(out)"],
                    raw.values["V(v_in)"],
                    float(self.config.raw["legacy_evaluation"].get("simulation_load_ohm", 8.0)),
                    float(self.config.raw["legacy_evaluation"].get("fundamental_hz", 1000.0)),
                    harmonics=int(post.get("thd_harmonics", 10)),
                    thd_cycles=int(post.get("thd_cycles", 10)),
                    samples_per_cycle=int(post.get("thd_samples_per_cycle", 1000)),
                )
                measurements = {
                    "vout_rms": metrics.output_rms,
                    "vin_rms": metrics.input_rms,
                    "gain_rms": metrics.gain_rms,
                    "output_power": metrics.output_power_w,
                }
                fourier_thd = metrics.thd_percent
                harmonics = [[index + 1, amplitude] for index, amplitude in enumerate(metrics.harmonic_amplitudes)]
            elif mode == "crowe":
                crowe, crowe_stability = crowe_gedlee_adaptive(
                    raw.values["time"],
                    raw.values["V(out)"],
                    float(crowe_cfg["fundamental_hz"]),
                    harmonic_orders=tuple(int(value) for value in crowe_cfg["harmonic_orders"]),
                    cycles=int(crowe_cfg["cycles"]),
                    samples_per_cycle=int(crowe_cfg["samples_per_cycle"]),
                    convergence_tolerance=float(crowe_cfg["convergence_tolerance"]),
                    consecutive_converged_steps=int(crowe_cfg["consecutive_converged_steps"]),
                )
                measurements = {
                    "gm_crowe": crowe.value,
                    "gm_crowe_memory_ratio": crowe.memory_ratio,
                    "gm_crowe_fit_residual_rms_relative": crowe.fit_residual_rms_relative,
                    "gm_crowe_input_peak_v": float(crowe_cfg["input_peak_v"]),
                    "gm_crowe_selected_harmonics": float(crowe_stability["selected_harmonics"]),
                }
            elif mode == "ac":
                frequency = np.real(np.asarray(raw.values["frequency"]))
                magnitude_db = 20.0 * np.log10(np.abs(np.asarray(raw.values["V(out)"])))
                metrics = frequency_metrics(frequency, magnitude_db, LEGACY_FREQUENCIES_HZ)
                measurements = {"fclo": metrics.low_cutoff_hz, "fchi": metrics.high_cutoff_hz, "gmax": metrics.peak_db}
                sampled = np.interp(np.log10(LEGACY_FREQUENCIES_HZ), np.log10(frequency), magnitude_db)
                ac_db = {f"f{round(frequency_hz)}hz": float(value) for frequency_hz, value in zip(LEGACY_FREQUENCIES_HZ, sampled)}
            elif mode == "slew":
                metrics = slew_metrics(
                    raw.values["time"],
                    raw.values["V(out)"],
                    resample_interval_s=float(post.get("slew_resample_interval_s", 1e-7)),
                )
                measurements = {
                    "maxslew": metrics.maximum_v,
                    "minslew": metrics.minimum_v,
                    "slew": metrics.slew_v_per_s,
                    "slew_rising": metrics.rising_v_per_s,
                    "slew_falling": metrics.falling_v_per_s,
                    "slew_crossing_count": metrics.crossing_count,
                }
            elif mode == "gedlee":
                gm = self.config.raw["legacy_evaluation"]["gm"]
                window_seconds = float(gm["window_seconds"])
                window_count = int(round(float(gm["extraction_seconds"]) / window_seconds))
                minima, maxima = window_extrema(
                    raw.values["time"],
                    raw.values["V(out)"],
                    window_seconds,
                    window_count,
                    float(post.get("gm_resample_interval_s", 2e-6)),
                )
                measurements = {
                    **{f"min{index}": float(value) for index, value in enumerate(minima)},
                    **{f"max{index}": float(value) for index, value in enumerate(maxima)},
                }
        failed_measurements = re.findall(r'Measurement "([^"]+)" FAIL', result.log_text, re.IGNORECASE)
        diagnostic_lines = [
            line.strip()
            for line in result.log_text.splitlines()
            if re.search(r"\b(?:fatal error|error:|warning:|fail(?:ed)?\b)", line, re.IGNORECASE)
        ]
        inputs: list[str | Path] = [self.topology.source, circuit_source, self.config.source]
        inputs.extend(item.source for item in self.topology.backends["ltspice"].dependencies)
        if parameter_source is not None:
            inputs.append(parameter_source)
        provenance = write_provenance(
            staged.parent / "provenance.json",
            inputs,
            f"ltspice_legacy_{mode}",
            {
                "mode": mode,
                "reltol": reltol,
                "input_rms_v": selected_input_rms,
                "command": list(result.command),
                "return_code": result.return_code,
                "staging_manifest": str(staged.parent / "translation.json"),
            },
        )
        return {
            "mode": mode,
            "working_directory": str(staged.parent),
            "log_path": str(log_path) if log_path else None,
            "raw_path": str(raw_path) if raw_path.exists() else None,
            "provenance_path": str(provenance),
            "measurements": measurements,
            "native_measurements": native_measurements,
            "ac_db": ac_db,
            "native_ac_db": native_ac_db,
            "fourier_thd_percent": fourier_thd,
            "native_fourier_thd_percent": native_fourier.thd_percent if native_fourier else None,
            "harmonics": harmonics,
            "gm_crowe_details": crowe.record() if mode == "crowe" and raw_path.is_file() else None,
            "gm_crowe_stability": crowe_stability if mode == "crowe" and raw_path.is_file() else None,
            "failed_measurements": failed_measurements,
            "diagnostics": diagnostic_lines,
        }
