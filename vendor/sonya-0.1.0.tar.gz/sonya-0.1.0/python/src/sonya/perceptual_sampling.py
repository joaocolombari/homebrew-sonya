from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class SamplingCandidate:
    id: str
    objectives: tuple[float, ...]


@dataclass(frozen=True)
class SamplingDecision:
    candidate_id: str
    pareto_rank: int
    eligible: bool
    mandatory_reason: str | None
    probability: float
    random_draw: float | None
    selected_online: bool
    estimated_cost_seconds: float


@dataclass(frozen=True)
class PerceptualSamplingPlan:
    seed: int
    half_life_candidates: float
    online_max_candidates: int
    wall_time_budget_seconds: float
    estimated_cost_per_candidate_seconds: float
    decisions: tuple[SamplingDecision, ...]
    online_candidate_ids: tuple[str, ...]
    final_candidate_ids: tuple[str, ...]
    estimated_online_cost_seconds: float

    def record(self) -> dict[str, object]:
        return {
            **{key: value for key, value in asdict(self).items() if key != "decisions"},
            "decisions": [asdict(item) for item in self.decisions],
        }


def _dominates(left: np.ndarray, right: np.ndarray) -> bool:
    return bool(np.all(left <= right) and np.any(left < right))


def pareto_ranks(candidates: Sequence[SamplingCandidate]) -> dict[str, int]:
    remaining = list(range(len(candidates)))
    matrix = np.asarray([item.objectives for item in candidates], dtype=float)
    ranks: dict[str, int] = {}
    rank = 1
    while remaining:
        front = [
            index for index in remaining
            if not any(_dominates(matrix[other], matrix[index]) for other in remaining if other != index)
        ]
        if not front:
            front = [remaining[0]]
        for index in front:
            ranks[candidates[index].id] = rank
        selected = set(front)
        remaining = [index for index in remaining if index not in selected]
        rank += 1
    return ranks


def _normalized_matrix(candidates: Sequence[SamplingCandidate]) -> np.ndarray:
    matrix = np.asarray([item.objectives for item in candidates], dtype=float)
    if matrix.ndim != 2 or matrix.shape[1] == 0 or not np.all(np.isfinite(matrix)):
        raise ValueError("sampling candidates require finite objective vectors of equal nonzero length")
    low, high = np.min(matrix, axis=0), np.max(matrix, axis=0)
    span = np.where(high > low, high - low, 1.0)
    return (matrix - low) / span


def _compressed_front(
    candidates: Sequence[SamplingCandidate],
    ranks: dict[str, int],
    normalized: np.ndarray,
    epsilon: float,
    maximum: int,
) -> list[str]:
    front_indices = [index for index, item in enumerate(candidates) if ranks[item.id] == 1]
    mandatory = {front_indices[int(np.argmin(normalized[front_indices, objective]))] for objective in range(normalized.shape[1])}
    if len(mandatory) > maximum:
        raise ValueError("final candidate cap is smaller than the objective-extreme set")
    cells: dict[tuple[int, ...], int] = {}
    for index in front_indices:
        cell = tuple(int(math.floor(value / epsilon)) for value in normalized[index]) if epsilon > 0 else (index,)
        cells.setdefault(cell, index)
    selected = list(dict.fromkeys([*sorted(mandatory), *cells.values()]))
    if len(selected) > maximum:
        retained = list(sorted(mandatory))[:maximum]
        while len(retained) < maximum:
            remaining = [index for index in selected if index not in retained]
            next_index = max(
                remaining,
                key=lambda index: min(float(np.linalg.norm(normalized[index] - normalized[other])) for other in retained),
            )
            retained.append(next_index)
        selected = retained
    return [candidates[index].id for index in selected]


def build_sampling_plan(
    candidates: Sequence[SamplingCandidate],
    *,
    half_life_candidates: float = 50.0,
    seed: int = 0,
    eligible_ranks: int = 2,
    online_max_candidates: int = 10,
    wall_time_budget_seconds: float = math.inf,
    estimated_cost_per_candidate_seconds: float = 0.0,
    final_max_candidates: int = 20,
    epsilon: float = 0.02,
    near_front_finalists: int = 2,
) -> PerceptualSamplingPlan:
    if not candidates:
        raise ValueError("at least one sampling candidate is required")
    if len({item.id for item in candidates}) != len(candidates):
        raise ValueError("sampling candidate ids must be unique")
    if half_life_candidates <= 0 or eligible_ranks < 1 or online_max_candidates < 1 or final_max_candidates < 1:
        raise ValueError("invalid perceptual sampling settings")
    if not 0 <= epsilon < 1 or estimated_cost_per_candidate_seconds < 0 or wall_time_budget_seconds < 0:
        raise ValueError("invalid perceptual sampling budget")
    normalized = _normalized_matrix(candidates)
    ranks = pareto_ranks(candidates)
    baseline_id = candidates[0].id
    extreme_ids = {
        candidates[int(np.argmin(normalized[:, objective]))].id
        for objective in range(normalized.shape[1])
    }
    mandatory = {baseline_id: "baseline", **{candidate_id: "objective_extreme" for candidate_id in extreme_ids if candidate_id != baseline_id}}
    if len(mandatory) > online_max_candidates:
        raise ValueError("online candidate cap is smaller than the mandatory baseline/extreme set")
    mandatory_cost = len(mandatory) * estimated_cost_per_candidate_seconds
    if mandatory_cost > wall_time_budget_seconds:
        raise ValueError("wall-time budget is smaller than the mandatory baseline/extreme set")

    rng = np.random.default_rng(seed)
    decisions: list[SamplingDecision] = []
    selected: list[str] = []
    selected_indices: list[int] = []
    cost = 0.0
    base_hazard = math.log(2.0) / half_life_candidates
    for index, candidate in enumerate(candidates):
        rank = ranks[candidate.id]
        eligible = rank <= eligible_ranks
        mandatory_reason = mandatory.get(candidate.id)
        draw: float | None = None
        probability = 0.0
        choose = False
        remaining_mandatory = sum(item.id in mandatory for item in candidates[index + 1:])
        capacity = (
            len(selected) < online_max_candidates - remaining_mandatory
            and cost + (remaining_mandatory + 1) * estimated_cost_per_candidate_seconds <= wall_time_budget_seconds
        )
        if mandatory_reason is not None and capacity:
            choose = True
            probability = 1.0
        elif eligible and capacity:
            rank_weight = 2.0 if rank == 1 else 1.0
            if selected_indices:
                novelty = min(float(np.linalg.norm(normalized[index] - normalized[other])) for other in selected_indices)
            else:
                novelty = 1.0
            weight = rank_weight * (1.0 + novelty)
            probability = 1.0 - math.exp(-base_hazard * weight)
            draw = float(rng.random())
            choose = draw < probability
        if choose:
            selected.append(candidate.id)
            selected_indices.append(index)
            cost += estimated_cost_per_candidate_seconds
        decisions.append(SamplingDecision(
            candidate.id, rank, eligible, mandatory_reason, probability, draw, choose,
            estimated_cost_per_candidate_seconds if choose else 0.0,
        ))

    final_ids = _compressed_front(candidates, ranks, normalized, epsilon, final_max_candidates)
    if len(final_ids) < final_max_candidates and near_front_finalists > 0:
        near = [
            (index, item) for index, item in enumerate(candidates)
            if ranks[item.id] > 1 and item.id not in final_ids
        ]
        front_indices = [index for index, item in enumerate(candidates) if ranks[item.id] == 1]
        near.sort(key=lambda pair: min(float(np.linalg.norm(normalized[pair[0]] - normalized[front])) for front in front_indices))
        for _, item in near[: min(near_front_finalists, final_max_candidates - len(final_ids))]:
            final_ids.append(item.id)

    return PerceptualSamplingPlan(
        seed,
        half_life_candidates,
        online_max_candidates,
        wall_time_budget_seconds,
        estimated_cost_per_candidate_seconds,
        tuple(decisions),
        tuple(selected),
        tuple(final_ids),
        cost,
    )
