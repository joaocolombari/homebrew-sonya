"""Static assets bundled with the local Sonya interface."""
