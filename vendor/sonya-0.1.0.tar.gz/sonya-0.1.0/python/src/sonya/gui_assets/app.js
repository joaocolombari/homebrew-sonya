const state = {
  bootstrap: null,
  jobs: [],
  selectedJobId: null,
  selectedJob: null,
  selectedCandidateId: null,
  comparedCandidateIds: [],
  resultCandidateFilter: "pareto",
  corpusRole: "all",
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const element = (tag, className, text) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
};
const finite = (value) => Number.isFinite(Number(value));
const number = (value, digits = 2) => finite(value)
  ? Number(value).toLocaleString("pt-BR", { minimumFractionDigits: digits, maximumFractionDigits: digits })
  : "—";

async function request(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || `Falha HTTP ${response.status}`);
  return body;
}

function showView(name) {
  $$(".view").forEach((view) => view.classList.toggle("hidden", view.id !== name));
  $$(".nav-item[data-view]").forEach((tab) => tab.classList.toggle("active", tab.dataset.view === name));
}

function statusPill(label, ready) {
  return element("span", `status-pill ${ready ? "ready" : "warning"}`, label);
}

function renderReadiness() {
  const container = $("#readiness");
  container.replaceChildren();
  state.bootstrap.simulators.forEach((item) => {
    container.append(statusPill(`${item.backend}: ${item.ready ? "pronto" : "indisponível"}`, item.ready));
  });
  container.append(statusPill(`corpus: ${state.bootstrap.programme.ready ? "pronto" : "incompleto"}`, state.bootstrap.programme.ready));
  const perceptualReady = state.bootstrap.perceptual_tools.length > 0
    && state.bootstrap.perceptual_tools.every((item) => item.ready);
  container.append(statusPill(`perceptual: ${perceptualReady ? "pronto" : "verificar"}`, perceptualReady));
}

function selectedTopology() {
  return state.bootstrap.topologies.find((item) => item.id === $("#topology").value);
}

function renderTopologies() {
  const select = $("#topology");
  select.replaceChildren();
  state.bootstrap.topologies.forEach((item) => {
    const option = element("option", "", item.name);
    option.value = item.id;
    option.selected = item.id === state.bootstrap.project.default_topology;
    select.append(option);
  });
  $("#parameters-path").value = state.bootstrap.project.default_parameter_file;
  renderBackends();
}

function renderCircuit(topology) {
  const figure = $("#circuit-figure");
  if (!topology.diagram) {
    figure.classList.add("hidden");
    return;
  }
  const url = `/api/topologies/${encodeURIComponent(topology.id)}/diagram`;
  $("#circuit-image").src = url;
  $("#dialog-circuit-image").src = url;
  $("#dialog-circuit-name").textContent = topology.name;
  $("#circuit-caption").textContent = topology.diagram_caption
    || "A nomenclatura da figura deve ser declarada junto à topologia para manter o framework independente do circuito.";
  figure.classList.remove("hidden");
}

function renderBackends() {
  const topology = selectedTopology();
  const select = $("#backend");
  const previous = select.value;
  select.replaceChildren();
  Object.entries(topology.simulator_support).forEach(([id, status]) => {
    const doctor = state.bootstrap.simulators.find((item) => item.backend === id);
    const label = `${id} — ${status}${doctor && !doctor.ready ? " (indisponível)" : ""}`;
    const option = element("option", "", label);
    option.value = id;
    option.disabled = status === "planned" || (doctor && !doctor.ready);
    if (id === previous || (!previous && id === "ngspice")) option.selected = true;
    select.append(option);
  });
  if (!select.value) {
    const firstEnabled = [...select.options].find((option) => !option.disabled);
    if (firstEnabled) firstEnabled.selected = true;
  }
  $("#topology-note").textContent = `${topology.description} ${topology.parameter_count} parâmetros · análises: ${topology.analyses.join(", ")}.`;
  renderCircuit(topology);
  updateReview();
}

function renderAlgorithms() {
  const select = $("#algorithm");
  select.replaceChildren();
  state.bootstrap.algorithms
    .filter((item) => state.bootstrap.campaign_algorithm_ids.includes(item.id))
    .forEach((item) => {
      const option = element("option", "", `${item.name}${item.multiobjective ? " · Pareto" : " · escalar"}`);
      option.value = item.id;
      option.selected = item.id === "nsga2";
      select.append(option);
    });
  updateAlgorithm();
}

function updateAlgorithm() {
  const algorithm = state.bootstrap.algorithms.find((item) => item.id === $("#algorithm").value);
  $("#algorithm-note").textContent = algorithm.description;
  const names = {
    population_size: "População",
    evaluation_budget: "Candidatos únicos",
    mutation_factor: "F",
    crossover_probability: "CR",
    seed: "Seed",
    initial_temperature: "Temperatura inicial",
    cooling: "Resfriamento",
  };
  const active = new Set(["population_size", "evaluation_budget", "seed"]);
  if (["gde3", "differential_evolution"].includes(algorithm.id)) active.add("mutation_factor").add("crossover_probability");
  const explanations = algorithm.parameters
    .filter((parameter) => active.has(parameter.id) || algorithm.id === "legacy_sam")
    .map((parameter) => `${names[parameter.id] || parameter.id}: ${parameter.description || "parâmetro do algoritmo"}`);
  if (algorithm.id === "legacy_sam") explanations.push("Na interface atual, temperatura inicial e resfriamento usam os valores históricos 50 e 0,9.");
  $("#algorithm-parameters-note").textContent = explanations.join(" ");
  const differential = ["gde3", "differential_evolution"].includes(algorithm.id);
  $("#mutation-factor").disabled = !differential;
  $("#crossover-probability").disabled = !differential;
  updateReview();
}

function renderParameters() {
  const container = $("#parameters");
  container.replaceChildren();
  state.bootstrap.parameters.forEach((item) => {
    const card = element("div", `parameter${item.fixed ? " disabled" : ""}`);
    card.dataset.parameterId = item.id;
    card.dataset.baseline = String(item.baseline);
    const top = element("div", "parameter-top");
    const toggle = element("label", "parameter-toggle");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.value = item.id;
    checkbox.checked = item.id === "X1";
    checkbox.disabled = item.fixed;
    checkbox.addEventListener("change", updateParameterSummary);
    const copy = element("span");
    copy.append(element("strong", "", `${item.id} · ${item.name}`));
    const group = item.symmetry_group ? ` · simetria ${item.symmetry_group.join("/")}` : "";
    copy.append(element("small", "", `inicial ${item.baseline} ${item.unit}${group}${item.fixed ? " · fixo" : ""}`));
    toggle.append(checkbox, copy);
    top.append(toggle);
    const bounds = element("div", "bound-row");
    [["Mín.", "minimum", item.minimum], ["Máx.", "maximum", item.maximum]].forEach(([labelText, kind, value]) => {
      const boundLabel = element("label", "bound-field", labelText);
      const input = document.createElement("input");
      input.type = "number";
      input.step = "any";
      input.value = String(value);
      input.dataset.bound = kind;
      input.disabled = item.fixed;
      input.addEventListener("input", () => {
        validateParameterCard(card);
        updateParameterSummary();
      });
      boundLabel.append(input);
      bounds.append(boundLabel);
    });
    bounds.append(element("span", "bound-unit", item.unit));
    card.append(top, bounds);
    container.append(card);
    validateParameterCard(card);
  });
  updateParameterSummary();
}

function validateParameterCard(card) {
  const minimum = card.querySelector('[data-bound="minimum"]');
  const maximum = card.querySelector('[data-bound="maximum"]');
  if (!minimum || !maximum || minimum.disabled) return true;
  const lower = Number(minimum.value), upper = Number(maximum.value);
  const valid = finite(lower) && finite(upper) && lower < upper;
  const message = valid ? "" : "Use valores finitos com mínimo menor que o máximo.";
  minimum.setCustomValidity(message);
  maximum.setCustomValidity(message);
  card.classList.toggle("invalid", !valid);
  return valid;
}

function selectedParameters() {
  return $$("#parameters input:checked").map((item) => item.value);
}

function parameterBounds() {
  const result = {};
  $$("#parameters .parameter").forEach((card) => {
    const minimum = card.querySelector('[data-bound="minimum"]');
    const maximum = card.querySelector('[data-bound="maximum"]');
    if (!minimum || !maximum || minimum.disabled) return;
    result[card.dataset.parameterId] = { minimum: Number(minimum.value), maximum: Number(maximum.value) };
  });
  return result;
}

function updateParameterSummary() {
  const container = $("#parameter-summary");
  container.replaceChildren();
  const selected = selectedParameters();
  if (!selected.length) {
    container.append(element("span", "", "Todos os parâmetros não fixos"));
  } else {
    selected.forEach((id) => {
      const parameter = state.bootstrap.parameters.find((item) => item.id === id);
      container.append(element("span", "", `${id} · ${parameter ? parameter.name : id}`));
    });
  }
  updateReview();
}

function renderObjectives() {
  const container = $("#objective-cards");
  container.replaceChildren();
  const cards = [
    ["Potência", "maximizar · W · triagem"],
    ["Slew rate", "maximizar · V/µs · triagem"],
    ["Desvio da resposta", "minimizar · dB · triagem"],
    ["GM-Crowe", "minimizar · todos os candidatos"],
    ["ViSQOL", "maximizar · MOS-LQO"],
    ["GstPEAQ", "confirmar · ODG"],
  ];
  cards.forEach(([name, description]) => {
    const card = element("div", "objective");
    card.append(element("strong", "", name), element("span", "", description));
    container.append(card);
  });
}

function driveMode() {
  return $("input[name=drive_mode]:checked").value;
}

function updateDrive() {
  $("#target-power-wrap").classList.toggle("hidden", driveMode() !== "matched_output_power");
  updateReview();
}

function updateSamplingExplanation() {
  const halfLife = Number($("#perceptual-half-life").value);
  if (!finite(halfLife) || halfLife <= 0) {
    $("#sampling-probability").textContent = "valor inválido";
    $("#sampling-explanation").textContent = "A meia-vida precisa ser positiva.";
    return;
  }
  const probability = 1 - Math.exp(-Math.log(2) / halfLife);
  const interval = 1 / probability;
  $("#sampling-probability").textContent = `${number(100 * probability, 2)}% por elegível`;
  $("#sampling-explanation").textContent = `Base sem peso: uma seleção a cada ~${number(interval, 1)} candidatos elegíveis; em ${number(halfLife, 0)}, a chance acumulada chega a 50%. Rank 1 e novidade aumentam essa probabilidade.`;
  updateReview();
}

function updateReview() {
  if (!state.bootstrap) return;
  const algorithm = state.bootstrap.algorithms.find((item) => item.id === $("#algorithm").value);
  const budget = Number($("#budget").value || 0);
  const runs = budget * (algorithm && algorithm.multiobjective ? 5 : 6);
  const parameterCopy = selectedParameters().length ? `${selectedParameters().length} dimensão(ões) escolhida(s)` : "todos os parâmetros livres";
  const halfLife = Number($("#perceptual-half-life").value || 0);
  $("#review-copy").textContent = `${algorithm ? algorithm.name : "Algoritmo"}, ${budget} candidatos, ${parameterCopy} e pelo menos ${runs} simulações, incluindo GM-Crowe para cada candidato. ${driveMode() === "matched_output_power" ? "A calibração por potência acrescentará execuções." : "Entrada fixa em −10 dBV."} Plano perceptual com meia-vida de ${halfLife} candidatos.`;
}

function formPayload() {
  const numeric = (selector, fallback) => {
    const input = $(selector);
    const parsed = input.valueAsNumber;
    return Number.isFinite(parsed) ? parsed : fallback;
  };
  return {
    name: $("#job-name").value,
    topology: $("#topology").value,
    backend: $("#backend").value,
    parameters_path: $("#parameters-path").value,
    algorithm: $("#algorithm").value,
    budget: Number($("#budget").value),
    population_size: Number($("#population-size").value),
    promote: Number($("#promote").value),
    seed: Number($("#seed").value),
    mutation_factor: numeric("#mutation-factor", 0.8),
    crossover_probability: numeric("#crossover-probability", 0.9),
    drive_mode: driveMode(),
    target_output_power_w: Number($("#target-output-power").value),
    vary: selectedParameters(),
    parameter_bounds: parameterBounds(),
    perceptual_seed: $("#perceptual-seed").value === "" ? null : Number($("#perceptual-seed").value),
    perceptual_half_life: Number($("#perceptual-half-life").value),
    perceptual_eligible_ranks: Number($("#perceptual-eligible-ranks").value),
    perceptual_online_max: Number($("#perceptual-online-max").value),
    perceptual_final_max: Number($("#perceptual-final-max").value),
    perceptual_near_front: Number($("#perceptual-near-front").value),
    perceptual_epsilon: Number($("#perceptual-epsilon").value),
    perceptual_estimated_cost_seconds: Number($("#perceptual-cost").value),
    perceptual_wall_time_hours: Number($("#perceptual-wall-time").value),
  };
}

async function submitCampaign(event) {
  event.preventDefault();
  const button = $("#start-button");
  const error = $("#form-error");
  error.classList.add("hidden");
  button.disabled = true;
  button.textContent = "Iniciando…";
  try {
    const job = await request("/api/jobs", { method: "POST", body: JSON.stringify(formPayload()) });
    state.selectedJobId = job.id;
    await refreshJobs();
    await selectJob(job.id);
    showView("monitor");
  } catch (exception) {
    error.textContent = exception.message;
    error.classList.remove("hidden");
  } finally {
    button.disabled = false;
    button.textContent = "Iniciar campanha";
  }
}

function statusLabel(status) {
  return ({ running: "em execução", starting: "iniciando", pause_requested: "pausa solicitada", paused: "pausada", cancel_requested: "cancelamento solicitado", cancelled: "cancelada", completed: "concluída", failed: "falhou", interrupted: "interrompida", failed_to_start: "não iniciou" })[status] || status;
}

function jobStatusPresentation(job) {
  const run = job?.perceptual_run;
  if (job?.status === "completed" && run?.status === "completed") {
    const failed = Number(run.failed_case_count || 0);
    if (failed > 0) {
      return { label: `elétrica concluída · perceptual com ${failed} falha(s)`, className: "failed" };
    }
    return { label: "elétrica + perceptual concluída", className: "perceptual-complete" };
  }
  if (job?.status === "completed") {
    return { label: "elétrica concluída", className: "completed" };
  }
  return { label: statusLabel(job?.status), className: job?.status || "" };
}

const activeStatuses = ["starting", "running", "pause_requested", "paused", "cancel_requested"];

function renderJobList() {
  const container = $("#job-list");
  container.replaceChildren();
  if (!state.jobs.length) {
    container.append(element("div", "empty-state", "Ainda não há campanhas iniciadas pela interface."));
    return;
  }
  state.jobs.forEach((job) => {
    const row = element("button", "job-row");
    row.type = "button";
    const copy = element("span");
    copy.append(element("strong", "", job.name));
    const perceptual = job.perceptual_run && activeStatuses.includes(job.perceptual_run.status) ? ` · perceptual ${statusLabel(job.perceptual_run.status)}` : "";
    const presentation = jobStatusPresentation(job);
    copy.append(element("small", "", `${job.request.algorithm} · ${job.request.backend} · ${job.progress.screening_completed}/${job.progress.budget} candidatos${perceptual}`));
    row.append(copy);
    row.append(element("span", `job-state ${presentation.className}`, presentation.label));
    row.append(element("span", "", new Date(job.created_at).toLocaleString("pt-BR")));
    row.addEventListener("click", () => selectJob(job.id));
    container.append(row);
  });
}

async function refreshJobs() {
  const response = await request("/api/jobs");
  state.jobs = response.jobs;
  $("#running-count").textContent = String(state.jobs.filter((job) => activeStatuses.includes(job.status) || activeStatuses.includes(job.perceptual_run?.status)).length);
  renderJobList();
  if (state.selectedJobId) await selectJob(state.selectedJobId, false);
}

async function selectJob(jobId, switchView = true) {
  const changedJob = state.selectedJobId !== jobId;
  state.selectedJobId = jobId;
  state.selectedJob = await request(`/api/jobs/${encodeURIComponent(jobId)}`);
  if (changedJob) {
    state.selectedCandidateId = null;
    state.comparedCandidateIds = [];
    state.resultCandidateFilter = "pareto";
  }
  renderActiveJob();
  renderResults();
  if (switchView) showView("monitor");
}

function metricBox(label, value) {
  const box = element("div", "metric-box");
  box.append(element("small", "", label), element("strong", "", String(value)));
  return box;
}

async function controlRun(target, action) {
  state.selectedJob = await request(`/api/jobs/${encodeURIComponent(state.selectedJobId)}/control`, {
    method: "POST",
    body: JSON.stringify({ target, action }),
  });
  await refreshJobs();
}

function runControls(target, status) {
  const controls = element("div", "run-controls");
  if (!activeStatuses.includes(status)) return controls;
  const paused = ["pause_requested", "paused"].includes(status);
  const pause = element("button", "button secondary", paused ? "Retomar" : "Pausar");
  pause.type = "button";
  pause.disabled = status === "cancel_requested";
  pause.addEventListener("click", () => controlRun(target, paused ? "resume" : "pause").catch((error) => window.alert(error.message)));
  const cancel = element("button", "button danger", status === "cancel_requested" ? "Cancelando…" : "Cancelar");
  cancel.type = "button";
  cancel.disabled = status === "cancel_requested";
  cancel.addEventListener("click", () => controlRun(target, "cancel").catch((error) => window.alert(error.message)));
  controls.append(pause, cancel);
  return controls;
}

function eventDescription(item) {
  if (!item) return "Aguardando o primeiro evento.";
  const names = {
    campaign_started: "Campanha iniciada",
    candidate_started: "Candidato iniciado",
    analysis_started: "Análise iniciada",
    analysis_completed: "Análise concluída",
    candidate_completed: "Candidato concluído",
    candidate_failed: "Candidato inválido; busca continuará",
    analysis_failed: "Análise inválida",
    search_completed: "Busca concluída",
    campaign_completed: "Campanha concluída",
    validation_started: "Validação iniciada",
    case_started: "Caso musical iniciado",
    simulation_started: "Simulação musical iniciada",
    simulation_completed: "Simulação musical concluída",
    metrics_started: "Métricas perceptuais iniciadas",
    case_completed: "Caso musical concluído",
    case_failed: "Caso musical falhou",
    validation_completed: "Validação concluída",
    paused_at_boundary: "Pausada em fronteira segura",
    resumed: "Execução retomada",
    cancelled_at_boundary: "Cancelada em fronteira segura",
  };
  const context = [
    item.candidate_id,
    item.programme_item_id,
    item.level_id,
    item.analysis,
    item.case_index && item.total_cases ? `${item.case_index}/${item.total_cases}` : null,
    item.candidate_index && item.budget ? `${item.candidate_index}/${item.budget}` : null,
  ].filter(Boolean).join(" · ");
  return `${names[item.event] || item.event}${context ? ` · ${context}` : ""}`;
}

function renderEventTimeline(container, events, title) {
  const section = element("section", "event-panel");
  section.append(element("h3", "", title));
  const timeline = element("div", "event-timeline");
  (events || []).slice(-8).reverse().forEach((item) => {
    const row = element("div", `event-row ${item.event === "case_failed" ? "failed" : ""}`);
    row.append(
      element("span", "event-dot"),
      element("span", "", eventDescription(item)),
      element("time", "", item.timestamp ? new Date(item.timestamp).toLocaleTimeString("pt-BR") : ""),
    );
    timeline.append(row);
  });
  if (!timeline.children.length) timeline.append(element("p", "note", "Os eventos detalhados aparecerão aqui."));
  section.append(timeline);
  container.append(section);
}

function renderActiveJob() {
  const job = state.selectedJob;
  const container = $("#active-job");
  if (!job) return;
  container.className = "monitor-card";
  container.replaceChildren();
  const header = element("div", "monitor-header");
  const copy = element("div");
  const presentation = jobStatusPresentation(job);
  copy.append(element("p", "eyebrow", presentation.label));
  copy.append(element("h2", "", job.name));
  copy.append(element("p", "", `${job.request.topology} · ${job.request.algorithm} · ${job.request.backend}`));
  const headerActions = element("div", "monitor-actions");
  headerActions.append(element("span", `job-state ${presentation.className}`, presentation.label), runControls("campaign", job.status));
  header.append(copy, headerActions);
  container.append(header);
  const metrics = element("div", "metrics-strip");
  const sampling = job.request.perceptual_sampling || {};
  const gmEveryCandidate = job.request.gm_crowe_every_candidate === true || job.result?.gm_crowe_in_search;
  const gmCompleted = gmEveryCandidate ? job.progress.screening_completed : job.progress.engineering_completed;
  metrics.append(
    metricBox("Candidatos", `${job.progress.screening_completed}/${job.progress.budget}`),
    metricBox("GM-Crowe", `${gmCompleted}/${job.progress.budget}`),
    metricBox("Simulações mínimas", job.request.estimated_simulator_runs_lower_bound),
    metricBox("Meia-vida perceptual", sampling.half_life_candidates ? `${sampling.half_life_candidates} cand.` : "—"),
  );
  container.append(metrics);
  const track = element("div", "progress-track");
  const bar = element("div", "progress-bar");
  bar.style.width = `${100 * job.progress.fraction}%`;
  track.append(bar);
  container.append(track);
  renderEventTimeline(container, job.events, "Eventos da otimização");
  const perceptual = job.perceptual_run;
  if (perceptual) {
    const section = element("section", "perceptual-monitor");
    const pHeader = element("div", "monitor-header");
    const pCopy = element("div");
    pCopy.append(element("p", "eyebrow", "Validação perceptual"), element("h2", "", statusLabel(perceptual.status)));
    const progress = job.perceptual_progress || {};
    pCopy.append(element("p", "", `${progress.completed || 0}/${progress.total || perceptual.request?.estimated_cases || 0} casos concluídos`));
    pHeader.append(pCopy, runControls("perceptual", perceptual.status));
    section.append(pHeader);
    const pTrack = element("div", "progress-track");
    const pBar = element("div", "progress-bar perceptual");
    pBar.style.width = `${100 * Number(progress.fraction || 0)}%`;
    pTrack.append(pBar);
    section.append(pTrack);
    renderEventTimeline(section, job.perceptual_events, "Eventos da validação");
    if (["failed", "interrupted"].includes(perceptual.status) && job.perceptual_log_tail) section.append(element("pre", "", job.perceptual_log_tail));
    container.append(section);
  }
  if (["failed", "interrupted"].includes(job.status) && job.log_tail) container.append(element("pre", "", job.log_tail));
}

function metricMeta(id) {
  return state.bootstrap.result_metrics[id] || { label: id, unit: "", direction: "diagnostic", group: "outros", digits: 3, scale: 1 };
}

function metricValue(point, id) {
  const value = point && point.metrics ? point.metrics[id] : null;
  const scale = Number(metricMeta(id).scale || 1);
  return finite(value) ? Number(value) * scale : null;
}

function formatMetric(point, id) {
  const meta = metricMeta(id);
  const value = metricValue(point, id);
  return value === null ? "—" : `${number(value, Number(meta.digits ?? 3))}${meta.unit ? ` ${meta.unit}` : ""}`;
}

function directionCopy(direction) {
  return direction === "maximize" ? "maior é melhor" : direction === "minimize" ? "menor é melhor" : "diagnóstico";
}

function availableMetrics(points) {
  const ids = new Set();
  points.forEach((point) => Object.entries(point.metrics || {}).forEach(([id, value]) => {
    if (finite(value) && state.bootstrap.result_metrics[id]) ids.add(id);
  }));
  return [...ids].sort((left, right) => {
    const preferred = ["output_power_w", "thd_percent", "frequency_std_db", "slew_rate_v_per_us", "gain_db", "gm_crowe", "gm_legacy"];
    const li = preferred.indexOf(left), ri = preferred.indexOf(right);
    if (li >= 0 || ri >= 0) return (li < 0 ? 99 : li) - (ri < 0 ? 99 : ri);
    return metricMeta(left).label.localeCompare(metricMeta(right).label, "pt-BR");
  });
}

function svgNode(name, attributes = {}) {
  const node = document.createElementNS("http://www.w3.org/2000/svg", name);
  Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, String(value)));
  return node;
}

function paddedExtent(values, clampAtZero = false) {
  let low = Math.min(...values), high = Math.max(...values);
  if (low === high) {
    const pad = Math.abs(low) > 0 ? Math.abs(low) * .08 : 1;
    return [clampAtZero ? Math.max(0, low - pad) : low - pad, high + pad];
  }
  const pad = (high - low) * .08;
  return [clampAtZero ? Math.max(0, low - pad) : low - pad, high + pad];
}

function axisScale(values, metricId) {
  const positive = values.every((value) => value > 0);
  const useLog = positive && Math.max(...values) / Math.min(...values) >= 100;
  const transform = useLog ? (value) => Math.log10(value) : (value) => value;
  const inverse = useLog ? (value) => 10 ** value : (value) => value;
  const nonnegative = new Set(["output_power_w", "thd_percent", "frequency_std_db", "slew_rate_v_per_us", "low_cutoff_hz", "high_cutoff_hz"]);
  const extent = paddedExtent(values.map(transform), !useLog && nonnegative.has(metricId));
  return { transform, inverse, extent, useLog };
}

function createParetoChart(points, xMetric, yMetric, colorMetric) {
  const svg = svgNode("svg", { viewBox: "0 0 880 460", role: "img", "aria-label": "Projeção da frente de Pareto" });
  svg.classList.add("chart");
  const valid = points.filter((item) => metricValue(item, xMetric) !== null && metricValue(item, yMetric) !== null);
  if (!valid.length) {
    const message = svgNode("text", { x: 440, y: 230, "text-anchor": "middle" });
    message.textContent = "Não há valores completos para estes eixos.";
    svg.append(message);
    return svg;
  }
  const width = 880, height = 460;
  const margin = { left: 86, right: 34, top: 25, bottom: 66 };
  const xScale = axisScale(valid.map((item) => metricValue(item, xMetric)), xMetric);
  const yScale = axisScale(valid.map((item) => metricValue(item, yMetric)), yMetric);
  const [xMin, xMax] = xScale.extent;
  const [yMin, yMax] = yScale.extent;
  const x = (value) => margin.left + (xScale.transform(value) - xMin) / (xMax - xMin) * (width - margin.left - margin.right);
  const y = (value) => height - margin.bottom - (yScale.transform(value) - yMin) / (yMax - yMin) * (height - margin.top - margin.bottom);
  const colorValues = valid.map((item) => metricValue(item, colorMetric)).filter((item) => item !== null);
  const colorLow = colorValues.length ? Math.min(...colorValues) : 0;
  const colorHigh = colorValues.length ? Math.max(...colorValues) : 1;
  const color = (point) => {
    const value = metricValue(point, colorMetric);
    if (value === null || colorHigh === colorLow) return point.search_front ? "#2878c8" : "#a9adb2";
    const ratio = (value - colorLow) / (colorHigh - colorLow);
    return `hsl(${210 - 175 * ratio} 58% ${58 - 8 * ratio}%)`;
  };

  for (let index = 0; index <= 5; index += 1) {
    const gx = margin.left + index / 5 * (width - margin.left - margin.right);
    const gy = margin.top + index / 5 * (height - margin.top - margin.bottom);
    svg.append(svgNode("line", { x1: gx, x2: gx, y1: margin.top, y2: height - margin.bottom, class: "grid" }));
    svg.append(svgNode("line", { x1: margin.left, x2: width - margin.right, y1: gy, y2: gy, class: "grid" }));
    const xTick = svgNode("text", { x: gx, y: height - margin.bottom + 20, "text-anchor": "middle", class: "tick" });
    xTick.textContent = number(xScale.inverse(xMin + index / 5 * (xMax - xMin)), 3);
    const yTick = svgNode("text", { x: margin.left - 12, y: gy + 4, "text-anchor": "end", class: "tick" });
    yTick.textContent = number(yScale.inverse(yMax - index / 5 * (yMax - yMin)), 3);
    svg.append(xTick, yTick);
  }
  svg.append(svgNode("line", { x1: margin.left, x2: width - margin.right, y1: height - margin.bottom, y2: height - margin.bottom, class: "axis-line" }));
  svg.append(svgNode("line", { x1: margin.left, x2: margin.left, y1: margin.top, y2: height - margin.bottom, class: "axis-line" }));

  valid.forEach((item) => {
    const point = svgNode("circle", {
      cx: x(metricValue(item, xMetric)),
      cy: y(metricValue(item, yMetric)),
      r: item.search_front ? 7 : 5,
      class: `point${item.search_front ? " front" : ""}${item.highlight ? " engineering" : ""}${state.selectedCandidateId === item.id ? " selected" : ""}`,
      fill: color(item),
      tabindex: 0,
    });
    point.style.fill = color(item);
    const title = svgNode("title");
    title.textContent = `${item.id}: ${formatMetric(item, xMetric)} · ${formatMetric(item, yMetric)} · cor ${formatMetric(item, colorMetric)}`;
    point.append(title);
    const choose = () => {
      state.selectedCandidateId = item.id;
      renderResults();
    };
    point.addEventListener("click", choose);
    point.addEventListener("keydown", (event) => { if (["Enter", " "].includes(event.key)) choose(); });
    svg.append(point);
  });

  const xMeta = metricMeta(xMetric), yMeta = metricMeta(yMetric);
  const xLabel = svgNode("text", { x: width / 2, y: 447, "text-anchor": "middle" });
  xLabel.textContent = `${xMeta.label} (${xMeta.unit || "sem unidade"}) · ${directionCopy(xMeta.direction)}${xScale.useLog ? " · escala log" : ""}`;
  const yLabel = svgNode("text", { x: 18, y: height / 2, transform: `rotate(-90 18 ${height / 2})`, "text-anchor": "middle" });
  yLabel.textContent = `${yMeta.label} (${yMeta.unit || "sem unidade"}) · ${directionCopy(yMeta.direction)}${yScale.useLog ? " · escala log" : ""}`;
  svg.append(xLabel, yLabel);
  return svg;
}

function createLineChart(values, xKey, yKey, yLabel) {
  const svg = svgNode("svg", { viewBox: "0 0 880 300", role: "img", "aria-label": yLabel });
  svg.classList.add("chart", "compact-chart");
  const valid = values.filter((item) => finite(item[xKey]) && finite(item[yKey]));
  if (!valid.length) return svg;
  const margin = { left: 78, right: 30, top: 25, bottom: 54 }, width = 880, height = 300;
  const xs = valid.map((item) => Number(item[xKey])), ys = valid.map((item) => Number(item[yKey]));
  const [xMin, xMax] = paddedExtent(xs), [yMin, yMax] = paddedExtent(ys, true);
  const x = (value) => margin.left + (value - xMin) / (xMax - xMin) * (width - margin.left - margin.right);
  const y = (value) => height - margin.bottom - (value - yMin) / (yMax - yMin) * (height - margin.top - margin.bottom);
  for (let index = 0; index <= 5; index += 1) {
    const gx = margin.left + index / 5 * (width - margin.left - margin.right);
    const gy = margin.top + index / 5 * (height - margin.top - margin.bottom);
    svg.append(svgNode("line", { x1: gx, x2: gx, y1: margin.top, y2: height - margin.bottom, class: "grid" }));
    svg.append(svgNode("line", { x1: margin.left, x2: width - margin.right, y1: gy, y2: gy, class: "grid" }));
    const xt = svgNode("text", { x: gx, y: height - 24, "text-anchor": "middle", class: "tick" });
    xt.textContent = number(xMin + index / 5 * (xMax - xMin), 0);
    const yt = svgNode("text", { x: margin.left - 10, y: gy + 4, "text-anchor": "end", class: "tick" });
    yt.textContent = number(yMax - index / 5 * (yMax - yMin), 4);
    svg.append(xt, yt);
  }
  const path = svgNode("path", {
    d: valid.map((item, index) => `${index ? "L" : "M"} ${x(Number(item[xKey]))} ${y(Number(item[yKey]))}`).join(" "),
    class: "series-line",
  });
  svg.append(path);
  valid.forEach((item) => svg.append(svgNode("circle", { cx: x(Number(item[xKey])), cy: y(Number(item[yKey])), r: 3.5, class: "series-point" })));
  const xl = svgNode("text", { x: width / 2, y: height - 5, "text-anchor": "middle" });
  xl.textContent = "Candidatos avaliados";
  const yl = svgNode("text", { x: 18, y: height / 2, transform: `rotate(-90 18 ${height / 2})`, "text-anchor": "middle" });
  yl.textContent = yLabel;
  svg.append(xl, yl);
  return svg;
}

function createBarChart(points, metricId) {
  const valid = points.filter((point) => metricValue(point, metricId) !== null);
  const svg = svgNode("svg", { viewBox: "0 0 520 250", role: "img", "aria-label": metricMeta(metricId).label });
  svg.classList.add("bar-chart");
  if (!valid.length) return svg;
  const values = valid.map((point) => metricValue(point, metricId));
  const low = Math.min(0, ...values), high = Math.max(0, ...values);
  const span = high - low || 1, left = 76, right = 12, top = 30, bottom = 55;
  const innerWidth = 520 - left - right, innerHeight = 250 - top - bottom;
  const y = (value) => top + (high - value) / span * innerHeight;
  const zero = y(0), slot = innerWidth / valid.length;
  for (let index = 0; index <= 4; index += 1) {
    const value = high - index / 4 * span;
    const gy = y(value);
    svg.append(svgNode("line", { x1: left, x2: 520 - right, y1: gy, y2: gy, class: "grid" }));
    const tick = svgNode("text", { x: left - 9, y: gy + 4, "text-anchor": "end", class: "tick" });
    tick.textContent = number(value, 3);
    svg.append(tick);
  }
  valid.forEach((point, index) => {
    const value = metricValue(point, metricId), barY = Math.min(zero, y(value)), barHeight = Math.max(1, Math.abs(zero - y(value)));
    const rect = svgNode("rect", { x: left + index * slot + slot * .16, y: barY, width: slot * .68, height: barHeight, class: "bar" });
    const title = svgNode("title"); title.textContent = `${point.id}: ${formatMetric(point, metricId)}`; rect.append(title); svg.append(rect);
    const label = svgNode("text", { x: left + (index + .5) * slot, y: 224, "text-anchor": "middle", class: "tick" });
    label.textContent = point.id.slice(0, 6); svg.append(label);
  });
  const title = svgNode("text", { x: left, y: 16 });
  const meta = metricMeta(metricId);
  title.textContent = `${meta.label} (${meta.unit || "s/un."}) · ${directionCopy(meta.direction)}`;
  const yLabel = svgNode("text", { x: 15, y: top + innerHeight / 2, transform: `rotate(-90 15 ${top + innerHeight / 2})`, "text-anchor": "middle" });
  yLabel.textContent = meta.unit || "sem unidade";
  svg.append(
    title,
    yLabel,
    svgNode("line", { x1: left, x2: 520 - right, y1: zero, y2: zero, class: "axis-line" }),
    svgNode("line", { x1: left, x2: left, y1: top, y2: 250 - bottom, class: "axis-line" }),
  );
  return svg;
}

function makeMetricSelect(id, metrics, selected) {
  const select = document.createElement("select");
  select.id = id;
  metrics.forEach((metric) => {
    const meta = metricMeta(metric);
    const option = element("option", "", `${meta.label} (${meta.unit || "s/un."})`);
    option.value = metric;
    option.selected = metric === selected;
    select.append(option);
  });
  return select;
}

function renderCandidateDetails(container, point) {
  container.replaceChildren();
  if (!point) {
    container.append(element("p", "", "Selecione um ponto ou uma linha para inspecionar todas as métricas."));
    return;
  }
  container.append(element("p", "eyebrow", "Candidato selecionado"), element("h2", "", point.id));
  const stateCopy = [point.search_front ? `frente elétrica ${point.gmInSearch ? "4D" : "3D"}` : "fora da frente", point.highlight ? (point.gmInSearch ? "destaque representativo" : "frente com GM") : null].filter(Boolean).join(" · ");
  container.append(element("p", "", stateCopy));
  const compare = element("button", "button secondary", state.comparedCandidateIds.includes(point.id) ? "Remover da comparação" : "Adicionar à comparação");
  compare.type = "button";
  compare.addEventListener("click", () => {
    state.comparedCandidateIds = state.comparedCandidateIds.includes(point.id)
      ? state.comparedCandidateIds.filter((id) => id !== point.id)
      : [...state.comparedCandidateIds, point.id];
    renderResults();
  });
  container.append(compare);
  const groups = {};
  Object.keys(point.metrics || {}).forEach((id) => {
    if (!finite(point.metrics[id]) || !state.bootstrap.result_metrics[id]) return;
    const group = metricMeta(id).group || "outros";
    groups[group] = groups[group] || [];
    groups[group].push(id);
  });
  const groupContainer = element("div", "metric-groups");
  Object.entries(groups).forEach(([group, ids]) => {
    const section = element("section", "metric-group");
    section.append(element("h3", "", group));
    const list = element("div", "metric-list");
    ids.forEach((id) => {
      const row = element("div", "metric-row");
      row.append(element("span", "", metricMeta(id).label), element("strong", "", formatMetric(point, id)));
      list.append(row);
    });
    section.append(list);
    groupContainer.append(section);
  });
  container.append(groupContainer);
  const parameters = element("div", "parameter-values");
  Object.entries(point.values || {}).forEach(([id, value]) => {
    const spec = state.bootstrap.parameters.find((item) => item.id === id);
    const baseline = state.selectedJob?.result?.baseline_values?.[id];
    const changed = finite(baseline) && Math.abs(Number(value) - Number(baseline)) > Math.max(1e-12, Math.abs(Number(baseline)) * 1e-10);
    const copy = `${id}${spec ? ` · ${spec.name}` : ""} = ${number(value, 4)}${spec?.unit ? ` ${spec.unit}` : ""}${changed ? ` (base ${number(baseline, 4)})` : ""}`;
    parameters.append(element("span", changed ? "changed" : "", copy));
  });
  container.append(element("h3", "", "Parâmetros do circuito"), parameters);
}

function renderCandidateTable(container, points) {
  const columns = ["output_power_w", "thd_percent", "frequency_std_db", "slew_rate_v_per_us", "gain_db", "gm_crowe"];
  const wrap = element("div", "table-wrap");
  const table = document.createElement("table");
  const head = document.createElement("thead");
  const header = document.createElement("tr");
  ["Candidato", ...columns.map((id) => `${metricMeta(id).label} (${metricMeta(id).unit})`)].forEach((label) => header.append(element("th", "", label)));
  head.append(header);
  const body = document.createElement("tbody");
  if (!points.length) {
    const row = document.createElement("tr");
    const cell = element("td", "empty-table-cell", "Nenhum candidato pertence a esta seleção.");
    cell.colSpan = columns.length + 1;
    row.append(cell);
    body.append(row);
  }
  points.forEach((point) => {
    const row = document.createElement("tr");
    row.classList.toggle("selected", point.id === state.selectedCandidateId);
    const idCell = document.createElement("td");
    const compare = document.createElement("input");
    compare.type = "checkbox";
    compare.className = "comparison-check";
    compare.checked = state.comparedCandidateIds.includes(point.id);
    compare.title = "Incluir na comparação";
    compare.addEventListener("click", (event) => event.stopPropagation());
    compare.addEventListener("change", () => {
      state.comparedCandidateIds = compare.checked
        ? [...new Set([...state.comparedCandidateIds, point.id])]
        : state.comparedCandidateIds.filter((id) => id !== point.id);
      renderResults();
    });
    idCell.append(compare);
    idCell.append(document.createTextNode(point.id));
    const badges = element("span", "table-badges");
    if (point.search_front) badges.append(element("span", "mini-badge", "Pareto"));
    if (point.highlight) badges.append(element("span", "mini-badge engineering", point.gmInSearch ? "destaque" : "GM"));
    idCell.append(badges);
    row.append(idCell);
    columns.forEach((id) => row.append(element("td", "", formatMetric(point, id))));
    row.addEventListener("click", () => {
      state.selectedCandidateId = point.id;
      renderResults();
    });
    body.append(row);
  });
  table.append(head, body);
  wrap.append(table);
  container.append(wrap);
}

function renderCandidateComparison(container, points) {
  const selected = points.filter((point) => state.comparedCandidateIds.includes(point.id));
  container.append(element("p", "eyebrow", "Comparação"), element("h2", "", "Candidatos lado a lado"));
  if (!selected.length) {
    container.append(element("p", "note", "Marque candidatos na tabela ou use o botão do candidato selecionado."));
    return;
  }
  const metrics = ["output_power_w", "thd_percent", "frequency_std_db", "gm_crowe", "slew_rate_v_per_us", "gain_db"];
  const wrap = element("div", "table-wrap");
  const table = document.createElement("table");
  const head = document.createElement("thead"), header = document.createElement("tr");
  ["Métrica", ...selected.map((point) => point.id)].forEach((copy) => header.append(element("th", "", copy)));
  head.append(header);
  const body = document.createElement("tbody");
  metrics.forEach((metric) => {
    const row = document.createElement("tr");
    row.append(element("td", "", `${metricMeta(metric).label} (${metricMeta(metric).unit})`));
    selected.forEach((point) => row.append(element("td", "", formatMetric(point, metric))));
    body.append(row);
  });
  table.append(head, body); wrap.append(table); container.append(wrap);
  const charts = element("div", "comparison-charts");
  ["output_power_w", "slew_rate_v_per_us", "frequency_std_db", "gm_crowe"].forEach((metric) => charts.append(createBarChart(selected, metric)));
  container.append(charts);
}

function makeLabeledSelect(labelText, options, selected) {
  const label = element("label", "", labelText);
  const select = document.createElement("select");
  options.forEach(([value, copy]) => {
    const option = element("option", "", copy);
    option.value = value;
    option.selected = value === selected;
    select.append(option);
  });
  label.append(select);
  return { label, select };
}

function renderPerceptualResults(container, result) {
  if (!result || !Array.isArray(result.candidate_records)) return;
  const summary = element("div", "perceptual-summary");
  summary.append(
    metricBox("Casos executados", result.case_count ?? "—"),
    metricBox("Tempo total", finite(result.elapsed_seconds) ? `${number(result.elapsed_seconds, 1)} s` : "—"),
    metricBox("Escopo", result.scientific_scope === "validation" ? "validação final" : "desenvolvimento"),
  );
  container.append(summary);
  container.append(element("p", "chart-note", "Cada valor é a média aritmética, com o mesmo peso, de todos os casos bem-sucedidos daquele candidato (trecho musical × nível de entrada). Não há ponderação por gênero, trecho ou nível; o intervalo mínimo–máximo e o desvio-padrão ficam explícitos abaixo."));
  const tableWrap = element("div", "table-wrap");
  const table = document.createElement("table");
  const head = document.createElement("thead");
  const header = document.createElement("tr");
  ["Candidato", "ViSQOL médio (MOS-LQO)", "PEAQ básico médio (ODG)", "PEAQ avançado médio (ODG)"].forEach((copy) => header.append(element("th", "", copy)));
  head.append(header);
  const body = document.createElement("tbody");
  result.candidate_records.forEach((record) => {
    const row = document.createElement("tr");
    const metrics = record.metrics || {};
    const summaryFor = (id) => {
      const statistics = record.metric_statistics?.[id];
      if (!statistics) return number(metrics[id], 4);
      return `${number(statistics.mean, 4)} · mín ${number(statistics.minimum, 3)} · máx ${number(statistics.maximum, 3)} · σ ${number(statistics.standard_deviation, 3)} · n=${statistics.sample_count}`;
    };
    row.append(
      element("td", "", record.candidate_id),
      element("td", "", summaryFor("visqol_audio")),
      element("td", "", summaryFor("gstpeaq_basic_odg")),
      element("td", "", summaryFor("gstpeaq_advanced_odg")),
    );
    body.append(row);
  });
  table.append(head, body);
  tableWrap.append(table);
  container.append(tableWrap);
  const points = result.candidate_records.map((record) => ({ id: record.candidate_id, metrics: record.metrics || {} }));
  const charts = element("div", "comparison-charts perceptual-charts");
  ["visqol_audio", "gstpeaq_basic_odg", "gstpeaq_advanced_odg"].forEach((metricId) => {
    if (points.some((point) => finite(point.metrics[metricId]))) charts.append(createBarChart(points, metricId));
  });
  if (charts.children.length) container.append(element("h3", "final-chart-title", "Resumo perceptual final"), charts);
}

async function startPerceptualValidation(button, error, payload) {
  button.disabled = true;
  button.textContent = "Iniciando…";
  error.classList.add("hidden");
  try {
    state.selectedJob = await request(`/api/jobs/${encodeURIComponent(state.selectedJobId)}/perceptual`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
    await refreshJobs();
    renderActiveJob();
    renderResults();
  } catch (exception) {
    error.textContent = exception.message;
    error.classList.remove("hidden");
    button.disabled = false;
    button.textContent = "Executar validação perceptual";
  }
}

function renderPerceptualPanel(container, campaignResult) {
  const card = element("article", "perceptual-card");
  card.append(element("p", "eyebrow", "Pós-seleção"), element("h2", "", "Validação perceptual com programa musical"));
  card.append(element("p", "perceptual-intro", "Esta etapa simula os candidatos selecionados com os trechos canônicos e só então executa ViSQOL e GstPEAQ. Ela fica separada da busca porque cada caso envolve áudio completo e é muito mais caro que o GM-Crowe."));

  const sampling = campaignResult.perceptual_sampling || {};
  const online = sampling.online_candidate_ids || [];
  const finalIds = sampling.final_candidate_ids || [];
  const selection = makeLabeledSelect("Seleção", [["final", `Final · ${finalIds.length} candidato(s)`], ["online", `Online · ${online.length} candidato(s)`]], "final");
  const role = makeLabeledSelect("Corpus", [["validation", `Final · ${state.bootstrap.programme.role_counts.validation || 0} trechos`], ["development", `Online · ${state.bootstrap.programme.role_counts.development || 0} trechos`]], "validation");
  const metric = makeLabeledSelect("Métricas", [["all", "ViSQOL + GstPEAQ"], ["visqol", "Somente ViSQOL"], ["gstpeaq", "Somente GstPEAQ"]], "all");
  const peaq = makeLabeledSelect("Modelo PEAQ", [["both", "Básico + avançado"], ["basic", "Básico"], ["advanced", "Avançado"]], "both");
  const rate = makeLabeledSelect("Taxa da simulação", [["48000", "48 kHz · recomendado"], ["96000", "96 kHz"], ["192000", "192 kHz · muito lento"]], "48000");
  const timeout = makeLabeledSelect("Limite por caso", [["600", "10 min"], ["1200", "20 min · recomendado"], ["3600", "60 min"]], "1200");
  const controls = element("div", "validation-controls");
  controls.append(selection.label, role.label, metric.label, peaq.label, rate.label, timeout.label);
  const programmeItems = element("fieldset", "level-controls programme-item-controls");
  programmeItems.append(element("legend", "", "Trechos do corpus"));
  const itemInputs = (state.bootstrap.programme.items || []).map((item) => {
    const label = element("label", "check-label");
    const input = document.createElement("input");
    input.type = "checkbox";
    input.value = item.id;
    input.checked = true;
    input.dataset.roles = (item.roles || []).join(",");
    label.dataset.roles = input.dataset.roles;
    label.append(input, document.createTextNode(item.title || item.id));
    programmeItems.append(label);
    return { input, label, roles: item.roles || [] };
  });
  const levels = element("fieldset", "level-controls");
  levels.append(element("legend", "", "Níveis de entrada"));
  const levelInputs = [["nominal", "nominal · −10 dBV"], ["limit", "limit · 1 Vpk"]].map(([value, copy]) => {
    const label = element("label", "check-label");
    const input = document.createElement("input");
    input.type = "checkbox";
    input.value = value;
    input.checked = true;
    label.append(input, document.createTextNode(copy));
    levels.append(label);
    return input;
  });
  const estimate = element("p", "validation-estimate");
  const updateEstimate = () => {
    const candidates = selection.select.value === "final" ? finalIds.length : online.length;
    const eligibleItems = itemInputs.filter((item) => item.roles.includes(role.select.value));
    itemInputs.forEach((item) => item.label.classList.toggle("hidden", !item.roles.includes(role.select.value)));
    const clips = eligibleItems.filter((item) => item.input.checked).length;
    const levelCount = levelInputs.filter((item) => item.checked).length;
    estimate.textContent = `${candidates} candidato(s) × ${clips} trecho(s) × ${levelCount} nível(is) = ${candidates * clips * levelCount} casos de áudio.`;
    peaq.label.classList.toggle("hidden", metric.select.value === "visqol");
  };
  [selection.select, role.select, metric.select, ...levelInputs, ...itemInputs.map((item) => item.input)].forEach((input) => input.addEventListener("change", updateEstimate));
  updateEstimate();

  const action = element("div", "validation-action");
  const button = element("button", "button primary", "Executar validação perceptual");
  button.type = "button";
  const error = element("p", "error hidden");
  const run = state.selectedJob.perceptual_run;
  const running = run && activeStatuses.includes(run.status);
  button.disabled = running || !["ngspice", "ltspice"].includes(campaignResult.backend);
  if (running) button.textContent = "Validação em execução…";
  button.addEventListener("click", () => {
    const selectedLevels = levelInputs.filter((item) => item.checked).map((item) => item.value);
    if (!selectedLevels.length) {
      error.textContent = "Selecione ao menos um nível.";
      error.classList.remove("hidden");
      return;
    }
    const selectedItems = itemInputs
      .filter((item) => item.roles.includes(role.select.value) && item.input.checked)
      .map((item) => item.input.value);
    if (!selectedItems.length) {
      error.textContent = "Selecione ao menos um trecho do corpus.";
      error.classList.remove("hidden");
      return;
    }
    startPerceptualValidation(button, error, {
      selection: selection.select.value,
      role: role.select.value,
      metric: metric.select.value,
      peaq_model: peaq.select.value,
      levels: selectedLevels,
      programme_items: selectedItems,
      simulation_sample_rate_hz: Number(rate.select.value),
      timeout_seconds: Number(timeout.select.value),
    });
  });
  action.append(button, estimate);
  card.append(controls, programmeItems, levels, action, error);
  card.append(element("p", "note", `A validação usará o mesmo backend da campanha: ${campaignResult.backend}. Cada caso grava um checkpoint; falhas isoladas ficam registradas sem apagar os casos já concluídos.`));
  if (run) card.append(element("p", "validation-state", `Última execução: ${statusLabel(run.status)}${run.request ? ` · ${run.request.estimated_cases} casos planejados` : ""}.`));
  if (running) card.append(runControls("perceptual", run.status));
  if (run && ["failed", "interrupted"].includes(run.status)) card.append(element("p", "error", "A validação terminou com erro. O caso e a causa aparecem no monitor; os casos já concluídos permanecem no relatório parcial."));
  renderPerceptualResults(card, state.selectedJob.perceptual_result);
  container.append(card);
}

function renderResults() {
  const container = $("#results-content");
  const previousX = $("#result-x-axis")?.value;
  const previousY = $("#result-y-axis")?.value;
  const previousColor = $("#result-color-axis")?.value;
  const result = state.selectedJob && state.selectedJob.result;
  if (!result) {
    container.className = "empty-state";
    container.textContent = state.selectedJob ? "A campanha ainda não produziu um relatório final." : "Selecione uma campanha concluída em “Acompanhar”.";
    return;
  }
  const points = result.points || [];
  points.forEach((point) => {
    point.gmInSearch = Boolean(result.gm_crowe_in_search);
    point.highlight = result.gm_crowe_in_search ? point.promoted : point.engineering_front;
  });
  const candidateFilters = [
    { value: "all", label: "Todos", predicate: () => true },
    { value: "pareto", label: "Frente de Pareto", predicate: (point) => point.search_front },
    { value: "highlight", label: result.gm_crowe_in_search ? "Pareto com destaque" : "Pareto com GM", predicate: (point) => point.search_front && point.highlight },
  ].map((filter) => ({ ...filter, count: points.filter(filter.predicate).length }));
  if (!candidateFilters.some((filter) => filter.value === state.resultCandidateFilter)) {
    state.resultCandidateFilter = "pareto";
  }
  if (state.resultCandidateFilter === "pareto" && !candidateFilters.find((filter) => filter.value === "pareto").count) {
    state.resultCandidateFilter = "all";
  }
  const activeCandidateFilter = candidateFilters.find((filter) => filter.value === state.resultCandidateFilter);
  const visiblePoints = points.filter(activeCandidateFilter.predicate);
  if (!visiblePoints.some((point) => point.id === state.selectedCandidateId)) {
    state.selectedCandidateId = (visiblePoints.find((item) => item.highlight) || visiblePoints[0] || null)?.id || null;
  }
  container.className = "result-shell";
  container.replaceChildren();

  if (result.partial) {
    const live = element("article", "live-result-banner");
    live.append(
      element("strong", "", "Resultado preliminar — campanha em execução"),
      element("span", "", "A frente, os extremos de normalização e todo o histórico de cobertura são recalculados conforme chegam candidatos. Use a tendência para decidir se vale continuar; os valores só ficam definitivos no encerramento."),
    );
    container.append(live);
  }

  const overview = element("div", "result-overview");
  const accounting = result.accounting || {};
  const failedCandidates = result.failed_candidates || [];
  const searchFront = result.pareto_fronts && result.pareto_fronts.search || [];
  const engineeringFront = result.pareto_fronts && result.pareto_fronts.engineering || [];
  const hypervolumeValues = result.hypervolume?.values || [];
  const finalHypervolume = hypervolumeValues.length ? hypervolumeValues[hypervolumeValues.length - 1].hypervolume : null;
  const finalCoverage = hypervolumeValues.length ? hypervolumeValues[hypervolumeValues.length - 1].coverage_percent : null;
  [
    ["Algoritmo", result.algorithm],
    ["Simulador", result.backend],
    ["Candidatos avaliados", points.length + failedCandidates.length],
    ["Inválidos", failedCandidates.length],
    [result.gm_crowe_in_search ? "Frente Pareto 4D" : "Frente elétrica 3D", `${searchFront.length} candidatos`],
    [result.gm_crowe_in_search ? "Destaques representativos" : "Frente com GM", `${result.gm_crowe_in_search ? (result.promotion && result.promotion.candidate_ids || []).length : engineeringFront.length} candidatos`],
    ["Cobertura dominada", finite(finalCoverage) ? `${number(finalCoverage, 2)}%` : "—"],
    [`Hipervolume ${result.hypervolume?.dimensions || "—"}D`, finite(finalHypervolume) ? number(finalHypervolume, 4) : "—"],
  ].forEach(([label, value]) => {
    const card = element("div", "result-card");
    card.append(element("small", "", label), element("strong", "", String(value ?? "—")));
    overview.append(card);
  });
  container.append(overview);

  if (failedCandidates.length) {
    const failureCard = element("article", "table-card");
    failureCard.append(
      element("p", "eyebrow", "Robustez da campanha"),
      element("h2", "", "Candidatos descartados sem interromper a busca"),
      element("p", "chart-note", "Falhas numéricas, timeout ou formas de onda inválidas recebem penalidade e não entram na frente, no hipervolume ou na seleção perceptual."),
    );
    const list = element("div", "metric-list");
    failedCandidates.forEach((item) => {
      const failure = item.failure || {};
      const row = element("div", "metric-row");
      const stage = failure.analysis ? ` · análise ${failure.analysis}` : "";
      row.append(
        element("span", "", `Avaliação ${item.evaluation} · ${item.id}${stage}`),
        element("strong", "", failure.message || "falha numérica"),
      );
      list.append(row);
    });
    failureCard.append(list);
    container.append(failureCard);
  }

  const metrics = availableMetrics(points);
  const xDefault = metrics.includes("output_power_w") ? "output_power_w" : metrics[0];
  const yDefault = metrics.includes("slew_rate_v_per_us") ? "slew_rate_v_per_us" : metrics[1] || metrics[0];
  const xSelected = previousX || xDefault;
  const ySelected = previousY || yDefault;
  const colorDefault = metrics.includes("frequency_std_db") ? "frequency_std_db" : metrics[0];
  const colorSelected = previousColor || colorDefault;
  const chartCard = element("article", "chart-card");
  const chartHeader = element("div", "chart-card-header");
  const copy = element("div");
  const slewIsObjective = (result.screening_objectives || []).includes("maximize_slew_rate_v_per_us");
  copy.append(element("p", "eyebrow", "Projeção multiobjetivo"), element("h2", "", "Frente de Pareto elétrica"));
  copy.append(element("p", "", result.gm_crowe_in_search
    ? (slewIsObjective
      ? "Azul identifica a frente não dominada calculada simultaneamente em potência, slew rate, desvio da resposta e GM-Crowe. THD continua registrada para diagnóstico, mas não altera a dominância. O contorno vinho marca apenas destaques representativos para inspeção; a cor interna varia com o desvio da resposta. A seleção perceptual online/final é calculada separadamente."
      : "Esta campanha usa o protocolo anterior: potência, THD, desvio da resposta e GM-Crowe. Slew rate está disponível como métrica, mas não participou da dominância. O contorno vinho marca os destaques representativos para inspeção.")
    : "Este relatório antigo calculou a busca em potência, THD e desvio da resposta; GM-Crowe existe somente nos promovidos. O contorno vinho marca a frente de engenharia desse protocolo anterior."));
  const controls = element("div", "chart-controls");
  const xLabel = element("label", "", "Eixo horizontal");
  const xSelect = makeMetricSelect("result-x-axis", metrics, metrics.includes(xSelected) ? xSelected : xDefault);
  xLabel.append(xSelect);
  const yLabel = element("label", "", "Eixo vertical");
  const ySelect = makeMetricSelect("result-y-axis", metrics, metrics.includes(ySelected) ? ySelected : yDefault);
  yLabel.append(ySelect);
  const colorLabel = element("label", "", "Cor");
  const colorSelect = makeMetricSelect("result-color-axis", metrics, metrics.includes(colorSelected) ? colorSelected : colorDefault);
  colorLabel.append(colorSelect);
  controls.append(xLabel, yLabel, colorLabel);
  chartHeader.append(copy, controls);
  chartCard.append(chartHeader, createParetoChart(points, xSelect.value, ySelect.value, colorSelect.value));
  const legend = element("div", "legend");
  const dominatedLegend = element("span"); dominatedLegend.append(element("i"), document.createTextNode("demais candidatos"));
  const frontLegend = element("span", "front"); frontLegend.append(element("i"), document.createTextNode(result.gm_crowe_in_search ? "frente elétrica 4D" : "frente elétrica 3D"));
  const engineeringLegend = element("span", "engineering"); engineeringLegend.append(element("i"), document.createTextNode(result.gm_crowe_in_search ? "destaque representativo" : "frente com GM"));
  legend.append(dominatedLegend, frontLegend, engineeringLegend, element("span", "", `cor: ${metricMeta(colorSelect.value).label}`));
  chartCard.append(legend);
  xSelect.addEventListener("change", renderResults);
  ySelect.addEventListener("change", renderResults);
  colorSelect.addEventListener("change", renderResults);
  container.append(chartCard);

  if (hypervolumeValues.length) {
    const hvCard = element("article", "chart-card");
    hvCard.append(
      element("p", "eyebrow", "Convergência multiobjetivo"),
      element("h2", "", "Cobertura dominada do espaço de referência"),
      element("p", "chart-note", `Cada objetivo é reescalado entre 0 (melhor valor observado) e 1 (pior). O ponto 1,1 é 10% pior que o pior observado em cada eixo, portanto fica estritamente atrás da frente e evita contribuição nula na borda. Em ${result.hypervolume?.dimensions || "—"} dimensões, a caixa de referência mede ${number(result.hypervolume?.maximum_hypervolume, 4)}; a curva mostra o hipervolume dividido por essa caixa. Quanto maior, maior a região de compromisso dominada.${result.hypervolume?.approximate ? ` Como a frente é grande, o hipervolume usa uma estimativa determinística de ${result.hypervolume.sample_count} amostras para manter a interface responsiva.` : " O hipervolume é calculado exatamente."}${Number(result.hypervolume?.trace_sample_step || 1) > 1 ? ` A curva exibe um checkpoint a cada ${result.hypervolume.trace_sample_step} candidatos.` : ""}${result.partial ? " Durante a execução, novos extremos podem reescalar também os pontos anteriores." : " Compare principalmente a evolução dentro desta campanha, pois os extremos mudam entre campanhas."}`),
      createLineChart(hypervolumeValues, "evaluation", "coverage_percent", "Cobertura dominada (%)"),
    );
    container.append(hvCard);
  }

  const lower = element("div", "result-lower");
  const tableCard = element("article", "table-card");
  const tableHeader = element("div", "candidate-table-header");
  const tableCopy = element("div");
  tableCopy.append(
    element("p", "eyebrow", "Métricas com unidades"),
    element("h2", "", `${activeCandidateFilter.label} · ${visiblePoints.length}`),
  );
  const filterControl = element("label", "candidate-filter-control", "Exibir na lista");
  const filterSelect = document.createElement("select");
  filterSelect.id = "result-candidate-filter";
  filterSelect.setAttribute("aria-label", "Exibir candidatos na lista");
  candidateFilters.forEach((filter) => {
    const option = element("option", "", `${filter.label} · ${filter.count}`);
    option.value = filter.value;
    option.selected = filter.value === state.resultCandidateFilter;
    filterSelect.append(option);
  });
  filterSelect.addEventListener("change", () => {
    state.resultCandidateFilter = filterSelect.value;
    renderResults();
  });
  filterControl.append(filterSelect);
  tableHeader.append(tableCopy, filterControl);
  tableCard.append(tableHeader);
  renderCandidateTable(tableCard, visiblePoints);
  const detail = element("aside", "candidate-card");
  renderCandidateDetails(detail, visiblePoints.find((item) => item.id === state.selectedCandidateId));
  lower.append(tableCard, detail);
  container.append(lower);

  const comparison = element("article", "comparison-card");
  renderCandidateComparison(comparison, points);
  container.append(comparison);

  const sampling = result.perceptual_sampling || {};
  const method = element("article", "method-card");
  const online = sampling.online_candidate_ids || [];
  const finalIds = sampling.final_candidate_ids || [];
  method.append(element("h2", "", "Como ler este resultado"));
  const objectiveCount = (result.screening_objectives || []).length || (result.gm_crowe_in_search ? 4 : 3);
  method.append(element("p", "", `Uma projeção 2D não redefine a dominância calculada em ${objectiveCount} objetivos: um ponto azul pode parecer pior nos dois eixos escolhidos e ainda preservar vantagem em um eixo oculto. Não existe uma “função de custo global” única sem impor pesos; isso transformaria a escolha multiobjetivo em uma preferência escalar. Foram registradas ${accounting.simulator_runs ?? "—"} simulações. O plano selecionou ${online.length} candidato(s) online e ${finalIds.length} finalista(s).`));
  container.append(method);
  if (!result.partial) renderPerceptualPanel(container, result);
}

function roleLabel(role) {
  return ({ development: "online", validation: "final", subjective: "WebMUSHRA", reserve: "reserva", candidate: "candidato" })[role] || role;
}

function renderCorpus() {
  const programme = state.bootstrap.programme;
  const summary = $("#corpus-summary");
  summary.replaceChildren();
  const nominal = (programme.levels || []).find((item) => item.id === "nominal");
  const limit = (programme.levels || []).find((item) => item.id === "limit");
  [
    ["Trechos canônicos", programme.item_count],
    ["Online", `${programme.role_counts.development || 0} trechos`],
    ["Final / WebMUSHRA", `${programme.role_counts.validation || 0} / ${programme.role_counts.subjective || 0}`],
    ["Níveis", `${nominal ? `${nominal.target_peak_v} Vpk nominal` : "nominal"} · ${limit ? `${limit.target_peak_v} Vpk limit` : "limit"}`],
  ].forEach(([label, value]) => summary.append(metricBox(label, value)));

  const container = $("#corpus-list");
  container.replaceChildren();
  const items = (programme.items || []).filter((item) => state.corpusRole === "all" || item.roles.includes(state.corpusRole));
  items.forEach((item) => {
    const card = element("article", "corpus-card");
    const header = element("div", "corpus-card-header");
    const copy = element("div");
    copy.append(element("h2", "", item.title));
    copy.append(element("p", "", item.notes || `${item.source_collection || "Corpus"} · ${item.duration_seconds}s`));
    const roles = element("div", "role-badges");
    item.roles.forEach((role) => roles.append(element("span", "role-badge", roleLabel(role))));
    header.append(copy, roles);
    card.append(header);
    if (item.canonical_exists) {
      const audio = document.createElement("audio");
      audio.controls = true;
      audio.preload = "metadata";
      audio.src = `/api/corpus/${encodeURIComponent(item.id)}/audio`;
      card.append(audio);
    } else {
      card.append(element("p", "error", "Arquivo canônico indisponível."));
    }
    const categories = element("div", "category-badges");
    item.categories.forEach((category) => categories.append(element("span", "category-badge", category.replaceAll("_", " "))));
    card.append(categories);
    const meta = element("div", "corpus-meta");
    meta.append(element("span", "", `${number(item.duration_seconds, 1)} s · canal ${item.channel}`));
    meta.append(element("span", item.canonical_hash_matches ? "ready-dot" : "", item.canonical_hash_matches ? "✓ hash verificado" : "hash pendente"));
    card.append(meta);
    container.append(card);
  });
}

async function initialize() {
  try {
    state.bootstrap = await request("/api/bootstrap");
    state.jobs = state.bootstrap.jobs;
    $("#project-name").textContent = state.bootstrap.project.name;
    $("#loading").classList.add("hidden");
    $("#configure").classList.remove("hidden");
    renderReadiness();
    renderTopologies();
    renderAlgorithms();
    renderParameters();
    renderObjectives();
    renderJobList();
    renderCorpus();
    $("#running-count").textContent = String(state.jobs.filter((job) => activeStatuses.includes(job.status) || activeStatuses.includes(job.perceptual_run?.status)).length);
    updateSamplingExplanation();
    updateReview();
  } catch (exception) {
    $("#loading").textContent = `Não foi possível iniciar a interface: ${exception.message}`;
  }
}

$$(".nav-item[data-view]").forEach((tab) => tab.addEventListener("click", () => showView(tab.dataset.view)));
$("#topology").addEventListener("change", renderBackends);
$("#algorithm").addEventListener("change", updateAlgorithm);
$("#toggle-parameters").addEventListener("click", () => {
  const hidden = $("#parameters").classList.toggle("hidden");
  $("#toggle-parameters").textContent = hidden ? "Mostrar parâmetros" : "Ocultar parâmetros";
});
$("#select-all-parameters").addEventListener("click", () => {
  $$("#parameters .parameter-toggle input:not(:disabled)").forEach((input) => { input.checked = true; });
  updateParameterSummary();
  $("#parameters").classList.remove("hidden");
  $("#toggle-parameters").textContent = "Ocultar parâmetros";
});
$$("input[name=drive_mode]").forEach((input) => input.addEventListener("change", updateDrive));
[$("#budget"), $("#population-size"), $("#promote")].forEach((input) => input.addEventListener("input", updateReview));
$("#perceptual-half-life").addEventListener("input", updateSamplingExplanation);
$("#campaign-form").addEventListener("submit", submitCampaign);
$("#refresh-jobs").addEventListener("click", refreshJobs);
$("#expand-circuit").addEventListener("click", () => $("#circuit-dialog").showModal());
$("#close-circuit").addEventListener("click", () => $("#circuit-dialog").close());
$$(".filter[data-corpus-role]").forEach((button) => button.addEventListener("click", () => {
  state.corpusRole = button.dataset.corpusRole;
  $$(".filter[data-corpus-role]").forEach((item) => item.classList.toggle("active", item === button));
  renderCorpus();
}));

initialize();
setInterval(() => {
  if (state.jobs.some((job) => activeStatuses.includes(job.status) || activeStatuses.includes(job.perceptual_run?.status))) refreshJobs().catch(() => {});
}, 2000);
