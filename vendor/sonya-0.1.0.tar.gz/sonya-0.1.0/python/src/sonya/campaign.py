from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Mapping


def candidate_cache_key(
    stage: str,
    values: Mapping[str, float],
    protocol: Mapping[str, object],
) -> str:
    document = {
        "stage": stage,
        "values": {name: float(values[name]) for name in sorted(values)},
        "protocol": dict(protocol),
    }
    encoded = json.dumps(document, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


class CandidateArchive:
    """Append-only JSONL cache shared by all fidelities in one campaign."""

    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._records: dict[str, dict[str, object]] = {}
        self.cache_hits = 0
        self.writes = 0
        if self.path.is_file():
            for line_number, line in enumerate(self.path.read_text(encoding="utf-8").splitlines(), start=1):
                if not line.strip():
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"invalid candidate archive line {line_number}: {exc}") from exc
                if not isinstance(record, dict) or not isinstance(record.get("cache_key"), str):
                    raise ValueError(f"invalid candidate archive line {line_number}")
                self._records[str(record["cache_key"])] = record

    def get(self, key: str) -> dict[str, object] | None:
        record = self._records.get(key)
        if record is not None:
            self.cache_hits += 1
        return record

    def put(self, key: str, record: Mapping[str, object]) -> dict[str, object]:
        if key in self._records:
            return self._records[key]
        stored = {"cache_key": key, **dict(record)}
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(stored, sort_keys=True, allow_nan=True, default=str) + "\n")
        self._records[key] = stored
        self.writes += 1
        return stored

    def __len__(self) -> int:
        return len(self._records)
