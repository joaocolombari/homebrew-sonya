from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
import math

import numpy as np

from .config import SonyaConfig
from .metrics.electrical import gain_and_power, harmonic_distortion_percent
from .metrics.frequency import corrected_frequency_metrics, legacy_frequency_metrics
from .metrics.gedlee_legacy import extract_window_extrema, legacy_gedlee_metric
from .parsers.legacy import read_legacy_results
from .parsers.rew import ScopeTrace, read_rew_measurement, read_rew_scope


def trim_scope(trace: ScopeTrace, window_seconds: float, mode: str) -> ScopeTrace:
    voltage = trace.voltage_v
    time = trace.time_s
    samples = round(trace.sample_rate_hz * window_seconds)
    if samples <= 0:
        raise ValueError("trim window is less than one sample")
    if mode == "zero":
        crossings = np.flatnonzero(voltage[:-1] * voltage[1:] <= 0)
        start = int(crossings[0]) if crossings.size else 0
    elif mode == "peak":
        start = int(np.argmax(voltage))
    elif mode == "gedlee":
        peak = int(np.argmax(voltage))
        crossings = np.flatnonzero(voltage[peak:-1] * voltage[peak + 1 :] <= 0)
        crossing = int(crossings[min(3, crossings.size - 1)]) if crossings.size else -1
        start = peak + crossing + 1 - samples
        if start < 0:
            raise ValueError("legacy GM extraction requests samples before the recording starts")
    elif mode == "none":
        start = 0
    else:
        raise ValueError(f"unknown trim mode: {mode}")
    stop = min(start + samples, voltage.size)
    return ScopeTrace(trace.path, time[start:stop] - time[start], voltage[start:stop], trace.sample_rate_hz, trace.volts_scale_factor)


def _slew_rate(trace: ScopeTrace) -> float:
    midpoint = 0.5 * (float(np.max(trace.voltage_v)) + float(np.min(trace.voltage_v)))
    derivative = np.diff(trace.voltage_v) / np.diff(trace.time_s)
    index = min(int(np.argmin(np.abs(trace.voltage_v - midpoint))), derivative.size - 1)
    return float(abs(derivative[index]) * 1e-6)


def evaluate_measurement_directory(directory: str | Path, vaa_v: float, config: SonyaConfig) -> dict[str, object]:
    """Reproduce the measurable part of ``evaluation.m`` without writing files."""
    root = Path(directory).resolve()
    legacy_cfg = config.raw["legacy_evaluation"]
    transient = trim_scope(read_rew_scope(root / "tran.txt"), 0.100, "zero")
    electrical = gain_and_power(transient.voltage_v, float(legacy_cfg["input_rms_v"]), float(legacy_cfg["load_ohm"]))
    response = read_rew_measurement(root / "AC.txt") if (root / "AC.txt").exists() else read_rew_measurement(root / "ac.txt")
    frequency = legacy_frequency_metrics(response.frequency_hz, response.magnitude_db, legacy_cfg["frequency_points_hz"])
    corrected_frequency = corrected_frequency_metrics(response.frequency_hz, response.magnitude_db, legacy_cfg["frequency_points_hz"])
    slew = trim_scope(read_rew_scope(root / "rise_and_fall.txt"), 0.010, "zero")
    gm_cfg = legacy_cfg["gm"]
    gm_trace = trim_scope(read_rew_scope(root / "gedlee.txt"), float(gm_cfg["extraction_seconds"]), "gedlee")
    minima, maxima = extract_window_extrema(gm_trace.voltage_v, gm_trace.sample_rate_hz, float(gm_cfg["window_seconds"]))
    gm = legacy_gedlee_metric(
        minima,
        maxima,
        gain_reference=float(electrical["gain_ratio"]),
        input_step_v=float(gm_cfg["input_step_v"]),
        interpolation_points=int(gm_cfg["interpolation_points"]),
    )
    values: dict[str, object] = {
        "vaa_v": float(vaa_v),
        **electrical,
        "frequency_legacy": asdict(frequency),
        "frequency_corrected": asdict(corrected_frequency),
        "slew_rate_v_per_us": _slew_rate(slew),
        "legacy_gm": gm,
        "legacy_gm_status": "baseline_only",
        "thd_percent_diagnostic": harmonic_distortion_percent(
            transient.voltage_v,
            transient.sample_rate_hz,
            float(legacy_cfg.get("fundamental_hz", 1000.0)),
        ),
    }
    reference_path = root / "results.txt"
    if reference_path.exists():
        reference = read_legacy_results(reference_path)
        comparable = {
            "gain_db": electrical["gain_db"],
            "output_power_w": electrical["output_power_w"],
            "frequency_std_db": frequency.sampled_std_db,
            "low_cutoff_hz": frequency.low_cutoff_hz,
            "high_cutoff_hz": frequency.high_cutoff_hz,
            "slew_rate_v_per_us": values["slew_rate_v_per_us"],
            "legacy_gm": gm,
        }
        values["matlab_reference"] = reference
        values["reference_delta"] = {
            key: float(value) - reference[key]
            for key, value in comparable.items()
            if key in reference and math.isfinite(float(value))
        }
    return values

