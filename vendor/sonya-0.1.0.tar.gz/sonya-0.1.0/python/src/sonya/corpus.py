from __future__ import annotations

from dataclasses import dataclass
import html
import json
import math
from pathlib import Path
import shutil
import subprocess
import tempfile
from typing import Callable

import numpy as np
from scipy.io import wavfile

from .perceptual import active_rms
from .programme import ProgrammeItem, ProgrammeManifest, programme_report
from .provenance import sha256


@dataclass(frozen=True)
class CanonicalAudio:
    samples: np.ndarray
    active_rms_dbfs: float
    peak_dbfs: float
    crest_factor_db: float
    gain_db: float
    peak_limited: bool


def canonicalize_audio(
    samples: np.ndarray,
    sample_rate_hz: int,
    target_active_rms_dbfs: float = -20.0,
    peak_dbfs: float = -1.0,
    fade_seconds: float = 0.01,
) -> CanonicalAudio:
    values = np.asarray(samples, dtype=float)
    if values.ndim != 1 or values.size < 2 or not np.all(np.isfinite(values)):
        raise ValueError("decoded corpus audio must be a finite mono signal")
    if sample_rate_hz <= 0 or fade_seconds < 0:
        raise ValueError("invalid corpus audio processing settings")
    values = values - float(np.mean(values))
    fade_samples = min(round(fade_seconds * sample_rate_hz), values.size // 2)
    if fade_samples:
        ramp = np.linspace(0.0, 1.0, fade_samples, endpoint=False)
        values[:fade_samples] *= ramp
        values[-fade_samples:] *= ramp[::-1]
    source_rms = active_rms(values)
    requested_gain = (10.0 ** (target_active_rms_dbfs / 20.0)) / source_rms
    source_peak = float(np.max(np.abs(values)))
    peak_limit = (10.0 ** (peak_dbfs / 20.0)) / source_peak
    gain = min(requested_gain, peak_limit)
    scaled = values * gain
    final_rms = active_rms(scaled)
    final_peak = float(np.max(np.abs(scaled)))
    pcm = np.rint(np.clip(scaled, -1.0, 1.0) * np.iinfo(np.int16).max).astype(np.int16)
    return CanonicalAudio(
        pcm,
        20.0 * math.log10(final_rms),
        20.0 * math.log10(final_peak),
        20.0 * math.log10(final_peak / final_rms),
        20.0 * math.log10(gain),
        peak_limit < requested_gain,
    )


def _decode_excerpt(item: ProgrammeItem, sample_rate_hz: int, ffmpeg: Path) -> np.ndarray:
    if item.path is None:
        raise ValueError(f"corpus item {item.id} has no source path")
    filter_graph = f"pan=mono|c0=c{item.channel}"
    command = (
        str(ffmpeg), "-v", "error", "-ss", f"{item.start_seconds:.9f}",
        "-t", f"{item.duration_seconds:.9f}", "-i", str(item.path),
        "-af", filter_graph, "-ar", str(sample_rate_hz), "-f", "f32le", "-",
    )
    completed = subprocess.run(command, capture_output=True, check=False)
    if completed.returncode != 0:
        details = completed.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"ffmpeg could not decode corpus item {item.id}: {details}")
    values = np.frombuffer(completed.stdout, dtype="<f4").astype(float)
    expected = round(item.duration_seconds * sample_rate_hz)
    if abs(values.size - expected) > 1:
        raise RuntimeError(f"decoded corpus item {item.id} has {values.size} samples, expected {expected}")
    return values[:expected]


def _ffmpeg_version(ffmpeg: Path) -> str:
    completed = subprocess.run((str(ffmpeg), "-version"), capture_output=True, text=True, check=False)
    return completed.stdout.splitlines()[0].strip() if completed.stdout else "unknown"


def render_audition_html(records: list[dict[str, object]], title: str = "Sonya — seleção do corpus") -> str:
    cards = []
    for index, record in enumerate(records, start=1):
        categories = ", ".join(str(value) for value in record["categories"])
        notes = html.escape(str(record.get("notes") or ""))
        cards.append(f"""
        <article>
          <h2>{index}. {html.escape(str(record['title']))}</h2>
          <p><strong>ID:</strong> <code>{html.escape(str(record['id']))}</code><br>
             <strong>Categorias:</strong> {html.escape(categories)}<br>
             <strong>Crest factor:</strong> {float(record['crest_factor_db']):.2f} dB</p>
          <audio controls preload="metadata" src="assets/{html.escape(str(record['id']))}.wav"></audio>
          <p>{notes}</p>
        </article>""")
    return f"""<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <style>
    body {{ max-width: 880px; margin: 2rem auto; padding: 0 1rem; font: 16px/1.5 system-ui, sans-serif; color: #202124; }}
    article {{ border-top: 1px solid #ddd; padding: 1rem 0 1.5rem; }}
    audio {{ width: 100%; }} code {{ background: #f2f2f2; padding: .15rem .3rem; }}
  </style>
</head>
<body>
  <h1>{html.escape(title)}</h1>
  <p>Use fones ou o mesmo sistema de reprodução para todas as amostras. Os níveis foram ajustados apenas por ganho escalar; nenhum compressor ou equalizador foi aplicado.</p>
  {''.join(cards)}
</body>
</html>
"""


def _portable_lock(index: dict[str, object]) -> dict[str, object]:
    items = index["items"]
    assert isinstance(items, list)
    return {
        "schema_version": 1,
        "purpose": "pin exact canonical references for objective validation and subjective export",
        "manifest_sha256": index["manifest_sha256"],
        "processing": index["processing"],
        "items": [
            {
                "id": item["id"],
                "source_sha256": item["source_sha256"],
                "source_channel": item["source_channel"],
                "source_start_seconds": item["source_start_seconds"],
                "duration_seconds": item["duration_seconds"],
                "canonical_sha256": item["canonical_sha256"],
                "webmushra_asset_id": item["webmushra_asset_id"],
                "usage_terms": item["usage_terms"],
            }
            for item in items
        ],
    }


def _verify_existing_lock(path: Path, lock: dict[str, object]) -> bool:
    if not path.exists():
        return False
    existing = json.loads(path.read_text(encoding="utf-8"))
    if existing != lock:
        raise ValueError(f"audition lock differs from regenerated assets: {path}")
    return True


def prepare_corpus_audition(
    manifest: ProgrammeManifest,
    output_directory: str | Path,
    *,
    role: str = "candidate",
    sample_rate_hz: int = 48000,
    target_active_rms_dbfs: float = -20.0,
    peak_dbfs: float = -1.0,
    fade_seconds: float = 0.01,
    ffmpeg_executable: str | Path | None = None,
    lock_path: str | Path | None = None,
    decoder: Callable[[ProgrammeItem, int, Path], np.ndarray] = _decode_excerpt,
) -> Path:
    output = Path(output_directory).expanduser().resolve()
    assets = output / "assets"
    assets.mkdir(parents=True, exist_ok=True)
    discovered = str(ffmpeg_executable) if ffmpeg_executable else shutil.which("ffmpeg")
    if discovered is None:
        raise RuntimeError("ffmpeg is required to prepare FLAC/WAV corpus excerpts")
    ffmpeg = Path(discovered).expanduser().resolve()
    selected = list(manifest.items) if role == "all" else [item for item in manifest.items if role in item.roles]
    if not selected:
        raise ValueError(f"programme manifest has no {role} items")

    report = programme_report(manifest)
    source_records = {str(item["id"]): item for item in report["items"]}  # type: ignore[index]
    records: list[dict[str, object]] = []
    with tempfile.TemporaryDirectory(prefix=".audition-", dir=output) as temporary:
        staging = Path(temporary)
        staged_targets: list[tuple[Path, Path]] = []
        for item in selected:
            source = source_records[item.id]
            if not source["exists"]:
                raise FileNotFoundError(f"corpus source is missing for {item.id}: {item.path}")
            if not source["hash_matches"]:
                raise ValueError(f"corpus source hash does not match for {item.id}")
            decoded = decoder(item, sample_rate_hz, ffmpeg)
            canonical = canonicalize_audio(decoded, sample_rate_hz, target_active_rms_dbfs, peak_dbfs, fade_seconds)
            staged = staging / f"{item.id}.wav"
            target = assets / f"{item.id}.wav"
            wavfile.write(staged, sample_rate_hz, canonical.samples)
            canonical_hash = sha256(staged)
            if item.canonical_sha256 is not None and canonical_hash != item.canonical_sha256:
                raise ValueError(f"generated canonical audio hash does not match the manifest for {item.id}")
            staged_targets.append((staged, target))
            records.append({
                "id": item.id,
                "title": item.title,
                "roles": list(item.roles),
                "categories": list(item.categories),
                "notes": item.notes,
                "source_collection": item.source_collection,
                "source_track": item.source_track,
                "source_url": item.source_url,
                "usage_terms": item.usage_terms,
                "source_path": str(item.path),
                "source_sha256": source["actual_sha256"],
                "source_channel": item.channel,
                "source_start_seconds": item.start_seconds,
                "duration_seconds": item.duration_seconds,
                "canonical_path": str(target),
                "canonical_sha256": canonical_hash,
                "sample_rate_hz": sample_rate_hz,
                "sample_count": int(canonical.samples.size),
                "sample_format": "pcm_s16le",
                "active_rms_dbfs": canonical.active_rms_dbfs,
                "peak_dbfs": canonical.peak_dbfs,
                "crest_factor_db": canonical.crest_factor_db,
                "gain_db": canonical.gain_db,
                "peak_limited": canonical.peak_limited,
                "fade_seconds": fade_seconds,
                "webmushra_asset_id": f"ref-{item.id}",
            })

        index = {
            "schema_version": 1,
            "status": "canonical_reference_assets_ready",
            "scientific_scope": "reference_preparation_only_not_quality_result",
            "manifest": str(manifest.source),
            "manifest_sha256": sha256(manifest.source),
            "decoder": {"implementation": "ffmpeg", "version": _ffmpeg_version(ffmpeg)},
            "processing": {
                "channel_policy": "declared_single_channel_no_stereo_sum",
                "sample_rate_hz": sample_rate_hz,
                "sample_format": "pcm_s16le",
                "target_active_rms_dbfs": target_active_rms_dbfs,
                "peak_dbfs": peak_dbfs,
                "fade_seconds": fade_seconds,
                "dynamics_processing": "none",
                "equalization": "none",
            },
            "webmushra_preservation": {
                "reference_assets_are_immutable_by_sha256": True,
                "blind_condition_ids_deferred_until_processed_finalists_exist": True,
                "redistribution_restriction": "R&D use; audio remains outside Git",
            },
            "items": records,
        }
        lock_target = Path(lock_path).expanduser().resolve() if lock_path is not None else None
        lock = _portable_lock(index)
        lock_exists = _verify_existing_lock(lock_target, lock) if lock_target is not None else False
        for staged, target in staged_targets:
            staged.replace(target)

        index_path = output / "audition-index.json"
        index_path.write_text(json.dumps(index, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        (output / "index.html").write_text(render_audition_html(records), encoding="utf-8")
        (output / "audition.m3u").write_text(
            "#EXTM3U\n" + "".join(f"#EXTINF:{item.duration_seconds:.3f},{item.title}\nassets/{item.id}.wav\n" for item in selected),
            encoding="utf-8",
        )
        if lock_target is not None and not lock_exists:
            lock_target.parent.mkdir(parents=True, exist_ok=True)
            lock_target.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return index_path
