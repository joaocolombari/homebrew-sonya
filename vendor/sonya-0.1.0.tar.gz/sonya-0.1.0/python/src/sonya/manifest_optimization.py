from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path
import re
import tempfile

from .config import ParameterSpec
from .optimization import generate_test_candidates
from .parsers.legacy import read_ltspice_measurements
from .parsers.ngspice import read_wrdata
from .provenance import write_provenance
from .topology import TopologyError, TopologyManifest, execute_staged_topology, stage_topology


def _render_parameters(values: dict[str, float]) -> str:
    return "".join(f".param {name}={value:.15g}\n" for name, value in values.items())


def _inject_before_end(text: str, payload: str) -> str:
    matches = list(re.finditer(r"(?im)^\s*\.end\s*$", text))
    if not matches:
        raise TopologyError("topology circuit requires a final .end directive")
    match = matches[-1]
    return text[: match.start()] + payload.rstrip() + "\n" + text[match.start() :]


def _instrument(staged_circuit: Path, backend_id: str, expression: str) -> Path | None:
    text = staged_circuit.read_text(encoding="utf-8", errors="replace")
    if backend_id == "ngspice":
        data_path = staged_circuit.parent / "sonya-objective.dat"
        payload = (
            ".control\n"
            "set wr_vecnames\n"
            "set wr_singlescale\n"
            "op\n"
            f"wrdata {data_path.name} {expression}\n"
            "quit\n"
            ".endc\n"
        )
    elif backend_id == "ltspice":
        data_path = None
        payload = f".op\n.meas op sonya_objective PARAM {expression}\n"
    else:
        raise TopologyError(f"generic optimization does not support backend {backend_id!r}")
    staged_circuit.write_text(_inject_before_end(text, payload), encoding="utf-8")
    return data_path


def _score(value: float, goal: str, target: float | None) -> float:
    if goal == "minimize":
        return value
    if goal == "maximize":
        return -value
    assert target is not None
    return abs(value - target)


def optimize_manifest(
    manifest: TopologyManifest,
    backend_id: str,
    output_root: str | Path,
    vary: list[str] | None = None,
    count: int = 3,
    step: float = 0.05,
    executable: str | Path | None = None,
    timeout_seconds: float = 30.0,
) -> Path:
    if manifest.objective is None or not manifest.parameters or manifest.parameter_file is None:
        raise TopologyError("manifest does not declare generic optimization parameters and objective")
    if backend_id not in manifest.backends:
        raise TopologyError(f"topology {manifest.id!r} has no backend {backend_id!r}")
    baseline = {item.id: item.baseline for item in manifest.parameters}
    specs = tuple(ParameterSpec(item.id, item.name, item.unit, item.minimum, item.maximum, item.baseline) for item in manifest.parameters)
    candidates = generate_test_candidates(baseline, specs, (), (), vary or [specs[0].id], count, step)
    root = Path(output_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    run_root = Path(tempfile.mkdtemp(prefix=f"{manifest.id}-optimization-", dir=root))
    records: list[dict[str, object]] = []
    for index, candidate in enumerate(candidates):
        candidate_root = run_root / f"candidate-{index:02d}-{candidate.id}"
        candidate_root.mkdir()
        parameter_path = candidate_root / manifest.parameter_file
        parameter_path.write_text(_render_parameters(candidate.values), encoding="ascii")
        staged = stage_topology(manifest, backend_id, candidate_root / "run", parameter_path)
        objective_data = _instrument(staged.circuit, backend_id, manifest.objective.expression)
        execution = execute_staged_topology(staged, executable, timeout_seconds)
        if not execution.passed:
            raise RuntimeError(f"candidate {candidate.id} failed; inspect {execution.log}")
        if backend_id == "ngspice":
            assert objective_data is not None
            _, data = read_wrdata(objective_data)
            value = float(data[-1, -1])
        else:
            measurements = read_ltspice_measurements(execution.log)
            if "sonya_objective" not in measurements:
                raise RuntimeError(f"LTspice objective measurement is missing in {execution.log}")
            value = float(measurements["sonya_objective"])
        records.append(
            {
                "id": candidate.id,
                "changes": candidate.changes,
                "values": candidate.values,
                "objective_value": value,
                "score": _score(value, manifest.objective.goal, manifest.objective.target),
                "execution": asdict(execution),
                "translation_manifest": str(staged.manifest),
            }
        )
    ranking = sorted(records, key=lambda item: float(item["score"]))
    for rank, record in enumerate(ranking, start=1):
        record["rank"] = rank
    report = {
        "status": "generic_manifest_optimization_test",
        "topology": manifest.id,
        "backend": backend_id,
        "backend_status": manifest.backends[backend_id].status,
        "objective": asdict(manifest.objective),
        "winner": ranking[0]["id"],
        "results": records,
    }
    report_path = run_root / "optimization.json"
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
    write_provenance(
        run_root / "provenance.json",
        [manifest.source, manifest.circuit, *(item.source for item in manifest.backends[backend_id].dependencies)],
        "generic_manifest_optimization_test",
        {"backend": backend_id, "candidate_count": len(candidates), "report_path": str(report_path)},
    )
    return report_path
