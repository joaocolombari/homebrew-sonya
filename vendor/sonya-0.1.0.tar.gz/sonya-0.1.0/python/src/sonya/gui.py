from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import errno
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files
import json
import math
import mimetypes
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import uuid
import webbrowser
from typing import Any
from urllib.parse import unquote, urlsplit

from .catalog import algorithm_specs, catalog_record, metric_specs, topology_specs
from .config import SonyaConfig
from .indicators import nondominated, normalized_hypervolume_trace
from .perceptual import perceptual_doctors
from .parsers.legacy import read_legacy_parameters
from .programme import load_programme_manifest, programme_report
from .simulators import simulator_backends


CAMPAIGN_ALGORITHMS = frozenset({"nsga2", "gde3", "differential_evolution", "legacy_pso", "legacy_sam"})
JOB_ID = re.compile(r"^[0-9]{8}T[0-9]{6}Z-[0-9a-f]{8}$")


RESULT_METRICS: dict[str, dict[str, object]] = {
    "output_power_w": {"label": "Potência de saída", "unit": "W", "direction": "maximize", "group": "desempenho", "digits": 3},
    "thd_percent": {"label": "THD", "unit": "%", "direction": "minimize", "group": "desempenho", "digits": 4},
    "frequency_std_db": {"label": "Desvio da resposta", "unit": "dB", "direction": "minimize", "group": "desempenho", "digits": 4},
    "gain_db": {"label": "Ganho", "unit": "dB", "direction": "diagnostic", "group": "legado", "digits": 3},
    "slew_rate_v_per_us": {"label": "Slew rate", "unit": "V/µs", "direction": "maximize", "group": "legado", "digits": 3},
    "low_cutoff_hz": {"label": "Corte inferior", "unit": "Hz", "direction": "diagnostic", "group": "legado", "digits": 2},
    "high_cutoff_hz": {"label": "Corte superior", "unit": "Hz", "direction": "diagnostic", "group": "legado", "digits": 0},
    "vaa_v": {"label": "Tensão VAA", "unit": "V", "direction": "diagnostic", "group": "operação", "digits": 2},
    "bplus_supply_current_a": {"label": "Corrente da fonte B+", "unit": "mA", "direction": "diagnostic", "group": "operação", "digits": 2, "scale": 1000.0},
    "bplus_input_power_w": {"label": "Potência de entrada B+", "unit": "W", "direction": "diagnostic", "group": "operação", "digits": 3},
    "el84a_plate_current_a": {"label": "Corrente de placa V5", "unit": "mA", "direction": "diagnostic", "group": "operação", "digits": 2, "scale": 1000.0},
    "el84b_plate_current_a": {"label": "Corrente de placa V6", "unit": "mA", "direction": "diagnostic", "group": "operação", "digits": 2, "scale": 1000.0},
    "el84a_plate_dissipation_w": {"label": "Dissipação de placa V5", "unit": "W", "direction": "minimize", "group": "operação", "digits": 3},
    "el84b_plate_dissipation_w": {"label": "Dissipação de placa V6", "unit": "W", "direction": "minimize", "group": "operação", "digits": 3},
    "mje340_q1_vce_v": {"label": "VCE de Q1", "unit": "V", "direction": "diagnostic", "group": "operação", "digits": 3},
    "mje340_q2_vce_v": {"label": "VCE de Q2", "unit": "V", "direction": "diagnostic", "group": "operação", "digits": 3},
    "mje340_q1_collector_current_a": {"label": "Corrente de coletor Q1", "unit": "mA", "direction": "diagnostic", "group": "operação", "digits": 3, "scale": 1000.0},
    "mje340_q2_collector_current_a": {"label": "Corrente de coletor Q2", "unit": "mA", "direction": "diagnostic", "group": "operação", "digits": 3, "scale": 1000.0},
    "mje340_q1_dissipation_w": {"label": "Dissipação de Q1", "unit": "mW", "direction": "minimize", "group": "operação", "digits": 2, "scale": 1000.0},
    "mje340_q2_dissipation_w": {"label": "Dissipação de Q2", "unit": "mW", "direction": "minimize", "group": "operação", "digits": 2, "scale": 1000.0},
    "gm_legacy": {"label": "GM-Legacy", "unit": "adim.", "direction": "minimize", "group": "engenharia", "digits": 5},
    "gm_crowe": {"label": "GM-Crowe", "unit": "adim.", "direction": "minimize", "group": "engenharia", "digits": 5},
    "gm_crowe_memory_ratio": {"label": "Resíduo em quadratura", "unit": "adim.", "direction": "diagnostic", "group": "engenharia", "digits": 5},
    "gm_crowe_fit_residual_rms_relative": {"label": "Resíduo relativo do ajuste", "unit": "%", "direction": "minimize", "group": "engenharia", "digits": 3, "scale": 100.0},
    "gm_crowe_input_peak_v": {"label": "Pico de entrada do GM", "unit": "Vpk", "direction": "diagnostic", "group": "engenharia", "digits": 3},
    "gm_crowe_selected_harmonics": {"label": "Harmônicos do GM", "unit": "ordens", "direction": "diagnostic", "group": "engenharia", "digits": 0},
    "visqol_audio": {"label": "ViSQOLAudio", "unit": "MOS-LQO", "direction": "maximize", "group": "perceptual", "digits": 3},
    "gstpeaq_basic_odg": {"label": "GstPEAQ básico", "unit": "ODG", "direction": "maximize", "group": "perceptual", "digits": 3},
    "gstpeaq_advanced_odg": {"label": "GstPEAQ avançado", "unit": "ODG", "direction": "maximize", "group": "perceptual", "digits": 3},
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _payload_float(payload: dict[str, object], key: str, default: float) -> float:
    raw = payload.get(key, default)
    if raw is None or raw == "":
        raw = default
    if isinstance(raw, str):
        raw = raw.strip().replace(",", ".")
    try:
        value = float(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{key} requer um número válido") from exc
    if not math.isfinite(value):
        raise ValueError(f"{key} requer um número finito")
    return value


def _default_parameter_file(config: SonyaConfig) -> Path | None:
    for topology in topology_specs(config):
        candidate = Path(topology.circuit).with_name("param_unoptimized.txt")
        if candidate.is_file():
            return candidate.resolve()
    return None


def _doctor_records(config: SonyaConfig) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for backend_id, backend in simulator_backends(config).items():
        try:
            records.append(asdict(backend.doctor()))
        except Exception as exc:  # A diagnostic failure must not prevent the GUI from opening.
            records.append({"backend": backend_id, "ready": False, "available": False, "error": str(exc)})
    return records


def _perceptual_doctor_records() -> list[dict[str, object]]:
    try:
        return [asdict(item) for item in perceptual_doctors()]
    except Exception as exc:  # Optional adapters remain visible even when their diagnostics fail.
        return [{"id": "perceptual_tools", "ready": False, "error": str(exc)}]


def gui_bootstrap(
    config: SonyaConfig,
    programme_path: str | Path,
    *,
    inspect_tools: bool = True,
) -> dict[str, object]:
    programme = programme_report(load_programme_manifest(programme_path))
    algorithms = [catalog_record(item) for item in algorithm_specs()]
    topologies = [catalog_record(item) for item in topology_specs(config)]
    metrics = [catalog_record(item) for item in metric_specs()]
    grouped_metrics = {
        tier: [item for item in metrics if item["tier"] == tier]
        for tier in ("screening", "engineering", "programme", "subjective")
    }
    drive = config.raw["legacy_evaluation"]["drive"]
    fixed = {str(item["id"]) for item in config.raw["future_methodology"]["fixed_parameters"]}
    symmetry = [list(map(str, item)) for item in config.raw["future_methodology"]["symmetry_groups"]]
    return {
        "project": {
            "name": str(config.raw["project"]["name"]),
            "config": str(config.source),
            "default_topology": config.default_topology_id,
            "default_parameter_file": str(_default_parameter_file(config) or ""),
        },
        "topologies": topologies,
        "algorithms": algorithms,
        "campaign_algorithm_ids": sorted(CAMPAIGN_ALGORITHMS),
        "metrics_by_tier": grouped_metrics,
        "result_metrics": RESULT_METRICS,
        "parameters": [
            {**asdict(item), "fixed": item.id in fixed, "symmetry_group": next((group for group in symmetry if item.id in group), None)}
            for item in config.parameters
        ],
        "drive": {
            "default_mode": str(drive["default_mode"]),
            "fixed_input_dbv": float(config.raw["legacy_evaluation"]["input_level_dbv"]),
            "matched_output_power_w": float(drive["matched_output_power_w"]),
        },
        "programme": programme,
        "simulators": _doctor_records(config) if inspect_tools else [],
        "perceptual_tools": _perceptual_doctor_records() if inspect_tools else [],
        "ui": {
            "schema_version": 2,
            "progress_unit": "unique_circuit_candidates",
            "refresh_interval_ms": 2000,
            "local_only": True,
            "perceptual_sampling_defaults": {
                "half_life_candidates": 50.0,
                "eligible_ranks": 2,
                "online_max_candidates": 10,
                "final_max_candidates": 20,
                "near_front_finalists": 2,
                "epsilon": 0.02,
                "estimated_cost_per_candidate_seconds": 0.0,
                "wall_time_budget_hours": 0.0,
            },
        },
    }


def build_campaign_command(
    payload: dict[str, object],
    config: SonyaConfig,
    programme_path: Path,
    output_root: Path,
    *,
    python_executable: str | Path | None = None,
    control_path: str | Path | None = None,
    event_path: str | Path | None = None,
) -> tuple[list[str], dict[str, object]]:
    topology_id = str(payload.get("topology", config.default_topology_id))
    topology_by_id = {item.id: item for item in topology_specs(config)}
    if topology_id not in topology_by_id:
        raise ValueError(f"topologia desconhecida: {topology_id}")
    topology = topology_by_id[topology_id]

    backend = str(payload.get("backend", "ngspice"))
    if backend not in topology.simulator_support:
        raise ValueError(f"a topologia {topology_id} não oferece o simulador {backend}")
    if topology.simulator_support[backend] == "planned":
        raise ValueError(f"o simulador {backend} ainda está planejado para {topology_id}")

    algorithm = str(payload.get("algorithm", "nsga2"))
    available_algorithms = {item.id: item for item in algorithm_specs()}
    if algorithm not in CAMPAIGN_ALGORITHMS or algorithm not in available_algorithms:
        raise ValueError(f"algoritmo indisponível para campanha: {algorithm}")
    if available_algorithms[algorithm].status != "implemented":
        raise ValueError(f"algoritmo ainda não implementado: {algorithm}")

    parameters_path = Path(str(payload.get("parameters_path", ""))).expanduser().resolve()
    if not parameters_path.is_file():
        raise ValueError(f"arquivo de parâmetros não encontrado: {parameters_path}")

    budget = int(payload.get("budget", 8))
    population_size = int(payload.get("population_size", 4))
    promote = int(payload.get("promote", 2))
    seed = int(payload.get("seed", 0))
    if budget < 4:
        raise ValueError("o orçamento deve ter pelo menos 4 candidatos")
    if population_size < 4 or population_size > budget:
        raise ValueError("a população deve ficar entre 4 e o orçamento")
    if promote < 1 or promote > budget:
        raise ValueError("a promoção deve ficar entre 1 e o orçamento")

    drive_mode = str(payload.get("drive_mode", "fixed_input")).replace("-", "_")
    if drive_mode not in {"fixed_input", "matched_output_power"}:
        raise ValueError(f"modo de excitação desconhecido: {drive_mode}")
    target_power = _payload_float(payload, "target_output_power_w", 10.0)
    if drive_mode == "matched_output_power" and target_power <= 0:
        raise ValueError("a potência de saída comum deve ser positiva")

    vary_raw = payload.get("vary", [])
    if not isinstance(vary_raw, list):
        raise ValueError("a lista de parâmetros variáveis é inválida")
    known_parameters = {item.id: item for item in config.parameters}
    fixed_parameters = {
        str(item["id"]) for item in config.raw["future_methodology"]["fixed_parameters"]
    }
    vary = list(dict.fromkeys(str(item) for item in vary_raw))
    unknown = [item for item in vary if item not in known_parameters]
    forbidden = [item for item in vary if item in fixed_parameters]
    if unknown:
        raise ValueError(f"parâmetros desconhecidos: {', '.join(unknown)}")
    if forbidden:
        raise ValueError(f"parâmetros fixos não podem variar: {', '.join(forbidden)}")

    bounds_raw = payload.get("parameter_bounds", {})
    if not isinstance(bounds_raw, dict):
        raise ValueError("os limites dos parâmetros devem formar um objeto")
    baseline_values = read_legacy_parameters(parameters_path)
    parameter_bounds: dict[str, dict[str, float]] = {}
    for parameter_id, raw_bound in bounds_raw.items():
        parameter_id = str(parameter_id)
        if parameter_id not in known_parameters:
            raise ValueError(f"limite de parâmetro desconhecido: {parameter_id}")
        if parameter_id in fixed_parameters:
            raise ValueError(f"o limite de {parameter_id} não pode mudar porque o parâmetro é fixo")
        if not isinstance(raw_bound, dict):
            raise ValueError(f"limite inválido para {parameter_id}")
        minimum = float(raw_bound.get("minimum"))
        maximum = float(raw_bound.get("maximum"))
        if not math.isfinite(minimum) or not math.isfinite(maximum) or minimum >= maximum:
            raise ValueError(f"{parameter_id} requer mínimo finito menor que o máximo")
        baseline = float(baseline_values[parameter_id])
        if not minimum <= baseline <= maximum:
            raise ValueError(f"o valor inicial de {parameter_id} ({baseline:g}) deve ficar entre mínimo e máximo")
        parameter_bounds[parameter_id] = {"minimum": minimum, "maximum": maximum}
    for group in config.raw["future_methodology"]["symmetry_groups"]:
        members = [str(item) for item in group]
        lower = max(parameter_bounds.get(item, {"minimum": known_parameters[item].minimum})["minimum"] for item in members)
        upper = min(parameter_bounds.get(item, {"maximum": known_parameters[item].maximum})["maximum"] for item in members)
        if lower >= upper:
            raise ValueError(f"o grupo simétrico {'/'.join(members)} não possui intervalo comum")

    mutation_factor = _payload_float(payload, "mutation_factor", 0.8)
    crossover_probability = _payload_float(payload, "crossover_probability", 0.9)
    if not 0 < mutation_factor <= 2:
        raise ValueError("F deve estar em (0, 2]")
    if not 0 <= crossover_probability <= 1:
        raise ValueError("CR deve estar em [0, 1]")

    perceptual_half_life = _payload_float(payload, "perceptual_half_life", 50.0)
    perceptual_eligible_ranks = int(payload.get("perceptual_eligible_ranks", 2))
    perceptual_online_max = int(payload.get("perceptual_online_max", 10))
    perceptual_final_max = int(payload.get("perceptual_final_max", 20))
    perceptual_near_front = int(payload.get("perceptual_near_front", 2))
    perceptual_epsilon = _payload_float(payload, "perceptual_epsilon", 0.02)
    perceptual_estimated_cost_seconds = _payload_float(payload, "perceptual_estimated_cost_seconds", 0.0)
    perceptual_wall_time_hours = _payload_float(payload, "perceptual_wall_time_hours", 0.0)
    seed_value = payload.get("perceptual_seed")
    perceptual_seed = seed if seed_value in {None, ""} else int(seed_value)
    if perceptual_half_life <= 0:
        raise ValueError("a meia-vida perceptual deve ser positiva")
    if perceptual_eligible_ranks < 1:
        raise ValueError("ao menos uma camada de Pareto deve ser elegível")
    if perceptual_online_max < 4:
        raise ValueError("o limite online deve permitir baseline e extremos (mínimo 4)")
    if perceptual_final_max < 1 or perceptual_near_front < 0:
        raise ValueError("os limites da seleção perceptual são inválidos")
    if not 0 <= perceptual_epsilon < 1:
        raise ValueError("o epsilon perceptual deve estar em [0, 1)")
    if perceptual_estimated_cost_seconds < 0 or perceptual_wall_time_hours < 0:
        raise ValueError("os orçamentos perceptuais não podem ser negativos")

    command = [
        str(python_executable or sys.executable),
        "-m",
        "sonya.cli",
        "--config",
        str(config.source),
        "optimize",
        "campaign",
        str(parameters_path),
        "--topology",
        topology_id,
        "--backend",
        backend,
        "--algorithm",
        algorithm,
        "--budget",
        str(budget),
        "--population-size",
        str(population_size),
        "--seed",
        str(seed),
        "--promote",
        str(promote),
        "--mutation-factor",
        str(mutation_factor),
        "--crossover-probability",
        str(crossover_probability),
        "--drive-mode",
        drive_mode.replace("_", "-"),
        "--programme",
        str(programme_path),
        "--perceptual-seed",
        str(perceptual_seed),
        "--perceptual-half-life",
        str(perceptual_half_life),
        "--perceptual-eligible-ranks",
        str(perceptual_eligible_ranks),
        "--perceptual-online-max",
        str(perceptual_online_max),
        "--perceptual-final-max",
        str(perceptual_final_max),
        "--perceptual-near-front",
        str(perceptual_near_front),
        "--perceptual-epsilon",
        str(perceptual_epsilon),
        "--perceptual-estimated-cost-seconds",
        str(perceptual_estimated_cost_seconds),
        "--perceptual-wall-time-hours",
        str(perceptual_wall_time_hours),
        "--output-root",
        str(output_root),
    ]
    if control_path is not None:
        command.extend(("--control-file", str(control_path)))
    if event_path is not None:
        command.extend(("--event-log", str(event_path)))
    if drive_mode == "matched_output_power":
        command.extend(("--target-output-power", str(target_power)))
    # Preserve the manifest order. This works for arbitrary parameter identifiers,
    # not only the X1..X25 convention used by the reference topology.
    for parameter_id in (item.id for item in config.parameters if item.id in parameter_bounds):
        bound = parameter_bounds[parameter_id]
        command.extend(("--parameter-bound", f"{parameter_id}:{bound['minimum']}:{bound['maximum']}"))
    for parameter_id in vary:
        command.extend(("--vary", parameter_id))

    multiobjective = bool(available_algorithms[algorithm].multiobjective)
    screening_runs_per_candidate = 5 if multiobjective else 6
    normalized = {
        "topology": topology_id,
        "backend": backend,
        "backend_status": topology.simulator_support[backend],
        "algorithm": algorithm,
        "multiobjective": multiobjective,
        "gm_crowe_every_candidate": True,
        "parameters_path": str(parameters_path),
        "parameter_bounds": parameter_bounds,
        "vary": vary,
        "budget": budget,
        "population_size": population_size,
        "seed": seed,
        "promote": promote,
        "mutation_factor": mutation_factor,
        "crossover_probability": crossover_probability,
        "drive_mode": drive_mode,
        "target_output_power_w": target_power if drive_mode == "matched_output_power" else None,
        "perceptual_sampling": {
            "seed": perceptual_seed,
            "half_life_candidates": perceptual_half_life,
            "eligible_ranks": perceptual_eligible_ranks,
            "online_max_candidates": perceptual_online_max,
            "final_max_candidates": perceptual_final_max,
            "near_front_finalists": perceptual_near_front,
            "epsilon": perceptual_epsilon,
            "estimated_cost_per_candidate_seconds": perceptual_estimated_cost_seconds,
            "wall_time_budget_hours": perceptual_wall_time_hours,
            "execution": "selection_plan_only_perceptual_execution_is_separate",
        },
        "estimated_simulator_runs_lower_bound": budget * screening_runs_per_candidate,
        "estimate_note": "a calibração por potência comum pode acrescentar várias simulações por candidato",
    }
    return command, normalized


def _atomic_json(path: Path, record: dict[str, object]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(record, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
    temporary.replace(path)


def _write_control(path: Path, action: str) -> None:
    if action not in {"run", "pause", "cancel"}:
        raise ValueError("ação de execução inválida")
    path.parent.mkdir(parents=True, exist_ok=True)
    _atomic_json(path, {"action": action, "requested_at": _utc_now()})


def _read_events(path: str | Path | None, limit: int = 120) -> list[dict[str, object]]:
    if not path:
        return []
    source = Path(path)
    if not source.is_file():
        return []
    records: list[dict[str, object]] = []
    for line in source.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]:
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(record, dict):
            records.append(record)
    return records


def _event_progress(events: list[dict[str, object]], *, total: int = 0) -> dict[str, object]:
    completed_candidates = max(
        (
            int(item.get("candidate_index", 0))
            for item in events
            if item.get("event") in {"candidate_completed", "candidate_failed"}
        ),
        default=0,
    )
    completed_cases = max(
        (
            int(item.get("case_index", 0))
            for item in events
            if item.get("event") in {"case_completed", "case_failed"}
        ),
        default=0,
    )
    latest = events[-1] if events else None
    declared_total = 0
    for item in reversed(events):
        raw = item.get("total_cases") or item.get("budget")
        if isinstance(raw, int):
            declared_total = raw
            break
    denominator = declared_total or total
    completed = completed_cases if completed_cases else completed_candidates
    return {
        "completed": completed,
        "total": denominator,
        "fraction": min(1.0, completed / denominator) if denominator else 0.0,
        "latest": latest,
    }


def _pid_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except (OSError, ProcessLookupError):
        return False
    return True


def _campaign_report(job_directory: Path) -> Path | None:
    reports = sorted((job_directory / "output").glob("optimization-campaign-*/campaign.json"))
    return reports[-1] if reports else None


def _perceptual_report(job_directory: Path, output_root: str | Path | None = None) -> Path | None:
    root = Path(output_root) if output_root else job_directory / "perceptual"
    reports = list(root.glob("**/validation.json"))
    return max(reports, key=lambda item: item.stat().st_mtime_ns) if reports else None


def build_perceptual_command(
    payload: dict[str, object],
    config: SonyaConfig,
    programme_path: Path,
    campaign_path: Path,
    output_root: Path,
    *,
    python_executable: str | Path | None = None,
    control_path: str | Path | None = None,
    event_path: str | Path | None = None,
) -> tuple[list[str], dict[str, object]]:
    if not campaign_path.is_file():
        raise ValueError("a campanha precisa estar concluída antes da validação perceptual")
    campaign = json.loads(campaign_path.read_text(encoding="utf-8"))
    backend_id = str(campaign.get("simulator_backend", ""))
    if backend_id not in {"ngspice", "ltspice"}:
        raise ValueError("a validação musical requer uma campanha ngspice ou LTspice")
    selection = str(payload.get("selection", "final"))
    role = str(payload.get("role", "validation"))
    metric = str(payload.get("metric", "all"))
    peaq_model = str(payload.get("peaq_model", "both"))
    if selection not in {"online", "final"}:
        raise ValueError("seleção perceptual inválida")
    if role not in {"development", "validation"}:
        raise ValueError("partição do corpus inválida")
    if metric not in {"all", "visqol", "gstpeaq"}:
        raise ValueError("métrica perceptual inválida")
    if peaq_model not in {"basic", "advanced", "both"}:
        raise ValueError("modelo PEAQ inválido")
    levels_raw = payload.get("levels", ["nominal", "limit"])
    if not isinstance(levels_raw, list):
        raise ValueError("os níveis perceptuais devem formar uma lista")
    levels = list(dict.fromkeys(str(item) for item in levels_raw))
    if not levels or any(item not in {"nominal", "limit"} for item in levels):
        raise ValueError("selecione nominal, limit ou ambos")
    simulation_sample_rate = int(payload.get("simulation_sample_rate_hz", 48000))
    timeout_seconds = _payload_float(payload, "timeout_seconds", 1200.0)
    if simulation_sample_rate < 48000 or simulation_sample_rate > 384000:
        raise ValueError("a taxa de simulação deve ficar entre 48 e 384 kHz")
    if timeout_seconds < 10 or timeout_seconds > 86400:
        raise ValueError("o timeout por caso deve ficar entre 10 s e 24 h")

    sampling = campaign.get("perceptual_sampling")
    ids = sampling.get(f"{selection}_candidate_ids") if isinstance(sampling, dict) else None
    if not isinstance(ids, list) or not ids:
        raise ValueError(f"a campanha não possui candidatos na seleção {selection}")
    programme = programme_report(load_programme_manifest(programme_path))
    role_count = int(dict(programme.get("role_counts", {})).get(role, 0))
    if role_count < 1:
        raise ValueError(f"o corpus não possui trechos para {role}")
    available_items = {
        str(item["id"]): item
        for item in programme.get("items", [])
        if isinstance(item, dict) and role in item.get("roles", ())
    }
    items_raw = payload.get("programme_items")
    if items_raw is None:
        programme_items = list(available_items)
    elif not isinstance(items_raw, list):
        raise ValueError("os trechos perceptuais devem formar uma lista")
    else:
        programme_items = list(dict.fromkeys(str(item) for item in items_raw))
    if not programme_items:
        raise ValueError("selecione ao menos um trecho perceptual")
    unknown_items = [item for item in programme_items if item not in available_items]
    if unknown_items:
        raise ValueError(f"trechos não pertencem à partição {role}: {', '.join(unknown_items)}")

    command = [
        str(python_executable or sys.executable),
        "-m", "sonya.cli",
        "--config", str(config.source),
        "perceptual", "validate", str(campaign_path),
        "--programme", str(programme_path),
        "--selection", selection,
        "--role", role,
        "--metric", metric,
        "--peaq-model", peaq_model,
        "--simulation-sample-rate", str(simulation_sample_rate),
        "--timeout", str(timeout_seconds),
        "--output-root", str(output_root),
    ]
    if control_path is not None:
        command.extend(("--control-file", str(control_path)))
    if event_path is not None:
        command.extend(("--event-log", str(event_path)))
    for level in levels:
        command.extend(("--level", level))
    for item_id in programme_items:
        command.extend(("--item", item_id))
    normalized = {
        "simulator_backend": backend_id,
        "selection": selection,
        "role": role,
        "levels": levels,
        "metric": metric,
        "peaq_model": peaq_model,
        "candidate_ids": [str(item) for item in ids],
        "candidate_count": len(ids),
        "programme_item_ids": programme_items,
        "programme_item_count": len(programme_items),
        "estimated_cases": len(ids) * len(programme_items) * len(levels),
        "simulation_sample_rate_hz": simulation_sample_rate,
        "timeout_seconds": timeout_seconds,
    }
    return command, normalized


def _archive_progress(job_directory: Path) -> tuple[int, int]:
    archives = sorted((job_directory / "output").glob("optimization-campaign-*/candidate-archive.jsonl"))
    if not archives:
        return 0, 0
    screening: set[str] = set()
    engineering: set[str] = set()
    for line in archives[-1].read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        candidate_id = record.get("candidate_id")
        if not isinstance(candidate_id, str):
            continue
        if record.get("stage") == "screening":
            screening.add(candidate_id)
        elif record.get("stage") == "engineering":
            engineering.add(candidate_id)
    return len(screening), len(engineering)


def _report_summary(report_path: Path) -> dict[str, object]:
    report = json.loads(report_path.read_text(encoding="utf-8"))
    screening = report.get("screening", {})
    records = screening.get("records", []) if isinstance(screening, dict) else []
    search_front = set(screening.get("search_front_candidate_ids", [])) if isinstance(screening, dict) else set()
    engineering = report.get("engineering", {})
    engineering_records = engineering.get("records", []) if isinstance(engineering, dict) else []
    engineering_front = set(engineering.get("front_candidate_ids", [])) if isinstance(engineering, dict) else set()
    promoted = set(dict(report.get("promotion", {})).get("candidate_ids", []))
    engineering_by_id = {
        str(item.get("candidate_id")): item
        for item in engineering_records
        if isinstance(item, dict) and item.get("candidate_id") is not None
    }
    points: list[dict[str, object]] = []
    objective_vectors: list[list[float]] = []
    failed_candidates: list[dict[str, object]] = []
    feasibility_by_evaluation: list[bool] = []
    if isinstance(records, list):
        for evaluation, record in enumerate(records, start=1):
            if not isinstance(record, dict) or not isinstance(record.get("metrics"), dict):
                continue
            metrics = dict(record["metrics"])
            candidate_id = str(record.get("candidate_id", record.get("id", "")))
            engineering_record = engineering_by_id.get(candidate_id)
            feasible = bool(record.get("feasible", True))
            feasibility_by_evaluation.append(feasible)
            if not feasible:
                failed_candidates.append({
                    "id": candidate_id,
                    "values": record.get("values", {}),
                    "evaluation": evaluation,
                    "failure": record.get("failure"),
                })
                continue
            if engineering_record and isinstance(engineering_record.get("metrics"), dict):
                metrics.update(engineering_record["metrics"])
            # Read old campaign files after the F8 nomenclature alignment.
            for suffix in ("vce_v", "collector_current_a", "dissipation_w"):
                old_key = f"mje340_q4_{suffix}"
                new_key = f"mje340_q2_{suffix}"
                if old_key in metrics and new_key not in metrics:
                    metrics[new_key] = metrics[old_key]
            points.append({
                "id": candidate_id,
                "values": record.get("values", {}),
                "metrics": metrics,
                "scalar_score": record.get("scalar_score"),
                "search_front": candidate_id in search_front,
                "promoted": candidate_id in promoted,
                "engineering_front": candidate_id in engineering_front,
                "feasible": bool(engineering_record.get("feasible", True)) if engineering_record else True,
                "evaluation": evaluation,
            })
            vector = record.get("objectives_minimization")
            if isinstance(vector, list) and vector and all(isinstance(value, (int, float)) for value in vector):
                objective_vectors.append([float(value) for value in vector])
    hypervolume = normalized_hypervolume_trace(objective_vectors) if len(objective_vectors) == len(points) else None
    if hypervolume is not None and failed_candidates and len(hypervolume["values"]) == len(objective_vectors):
        successful_values = iter(hypervolume["values"])
        expanded_values: list[dict[str, object]] = []
        previous = {"hypervolume": 0.0, "coverage_fraction": 0.0, "coverage_percent": 0.0, "front_size": 0}
        for evaluation, feasible in enumerate(feasibility_by_evaluation, start=1):
            if feasible:
                current = dict(next(successful_values))
                previous = current
            else:
                current = dict(previous)
            current["evaluation"] = evaluation
            expanded_values.append(current)
        hypervolume["values"] = expanded_values
    elif hypervolume is not None and failed_candidates:
        successful_evaluations = [
            evaluation for evaluation, feasible in enumerate(feasibility_by_evaluation, start=1) if feasible
        ]
        for item in hypervolume["values"]:
            item["evaluation"] = successful_evaluations[int(item["evaluation"]) - 1]
    return {
        "status": report.get("status"),
        "partial": False,
        "algorithm": report.get("algorithm"),
        "backend": report.get("simulator_backend"),
        "budget": report.get("budget"),
        "accounting": report.get("accounting"),
        "pareto_fronts": report.get("pareto_fronts"),
        "promotion": report.get("promotion"),
        "perceptual_sampling": report.get("perceptual_sampling"),
        "programme": report.get("programme"),
        "screening_objectives": screening.get("objectives") if isinstance(screening, dict) else None,
        "gm_crowe_in_search": "minimize_gm_crowe" in (screening.get("objectives", []) if isinstance(screening, dict) else []),
        "engineering_objectives": engineering.get("objectives") if isinstance(engineering, dict) else None,
        "validation_blockers": report.get("validation_blockers"),
        "points": points,
        "failed_candidates": failed_candidates,
        "baseline_values": dict(report.get("search_space", {})).get("baseline", {}),
        "hypervolume": hypervolume,
        "report_path": str(report_path),
    }


def _perceptual_report_summary(report_path: Path) -> dict[str, object]:
    report = json.loads(report_path.read_text(encoding="utf-8"))
    return {
        "status": report.get("status"),
        "scientific_scope": report.get("scientific_scope"),
        "selection": report.get("selection"),
        "role": report.get("role"),
        "levels": report.get("levels"),
        "case_count": report.get("case_count"),
        "failed_case_count": report.get("failed_case_count"),
        "planned_case_count": report.get("planned_case_count"),
        "elapsed_seconds": report.get("elapsed_seconds"),
        "candidate_records": report.get("candidate_records"),
        "perceptual_pareto_audit": report.get("perceptual_pareto_audit"),
        "report_path": str(report_path),
    }


def _archive_report_summary(
    records: list[dict[str, object]],
    request: dict[str, object],
    *,
    simulator_runs: int = 0,
) -> dict[str, object] | None:
    """Build the same result projection from screening records still in flight."""

    screening = [record for record in records if record.get("stage") == "screening"]
    if not screening:
        return None
    feasible_vectors = [
        tuple(float(value) for value in record["objectives"])
        for record in screening
        if bool(record.get("feasible", True))
        and isinstance(record.get("objectives"), list)
        and record["objectives"]
        and all(isinstance(value, (int, float)) and math.isfinite(float(value)) for value in record["objectives"])
    ]
    front_vectors = set(nondominated(feasible_vectors)) if feasible_vectors else set()
    points: list[dict[str, object]] = []
    failed_candidates: list[dict[str, object]] = []
    feasibility_by_evaluation: list[bool] = []
    objective_vectors: list[list[float]] = []
    front_ids: list[str] = []
    for evaluation, record in enumerate(screening, start=1):
        candidate_id = str(record.get("candidate_id", ""))
        feasible = bool(record.get("feasible", True))
        vector_raw = record.get("objectives")
        vector = (
            tuple(float(value) for value in vector_raw)
            if isinstance(vector_raw, list) and vector_raw
            and all(isinstance(value, (int, float)) and math.isfinite(float(value)) for value in vector_raw)
            else None
        )
        usable = feasible and vector is not None
        feasibility_by_evaluation.append(usable)
        if not usable:
            failed_candidates.append({
                "id": candidate_id,
                "values": record.get("values", {}),
                "evaluation": evaluation,
                "failure": record.get("failure"),
            })
            continue
        assert vector is not None
        is_front = vector in front_vectors
        if is_front:
            front_ids.append(candidate_id)
        objective_vectors.append(list(vector))
        points.append({
            "id": candidate_id,
            "values": record.get("values", {}),
            "metrics": record.get("metrics", {}),
            "scalar_score": record.get("scalar_score"),
            "search_front": is_front,
            "promoted": False,
            "engineering_front": False,
            "feasible": True,
            "evaluation": evaluation,
        })
    hypervolume = normalized_hypervolume_trace(objective_vectors, max_trace_points=12) if objective_vectors else None
    if hypervolume is not None and failed_candidates and len(hypervolume["values"]) == len(objective_vectors):
        successful_values = iter(hypervolume["values"])
        expanded_values: list[dict[str, object]] = []
        previous = {"hypervolume": 0.0, "coverage_fraction": 0.0, "coverage_percent": 0.0, "front_size": 0}
        for evaluation, feasible in enumerate(feasibility_by_evaluation, start=1):
            current = dict(next(successful_values)) if feasible else dict(previous)
            if feasible:
                previous = current
            current["evaluation"] = evaluation
            expanded_values.append(current)
        hypervolume["values"] = expanded_values
    elif hypervolume is not None and failed_candidates:
        successful_evaluations = [
            evaluation for evaluation, feasible in enumerate(feasibility_by_evaluation, start=1) if feasible
        ]
        for item in hypervolume["values"]:
            item["evaluation"] = successful_evaluations[int(item["evaluation"]) - 1]
    multiobjective = bool(request.get("multiobjective", True))
    objective_names = (
        ["maximize_output_power_w", "maximize_slew_rate_v_per_us", "minimize_frequency_std_db", "minimize_gm_crowe"]
        if multiobjective else ["minimize_legacy_score"]
    )
    return {
        "status": "electrical_pareto_in_progress",
        "partial": True,
        "algorithm": request.get("algorithm"),
        "backend": request.get("backend"),
        "budget": request.get("budget"),
        "accounting": {
            "simulator_runs": simulator_runs,
            "successful_candidates": len(points),
            "failed_candidates": len(failed_candidates),
        },
        "pareto_fronts": {"search": front_ids, "engineering": [], "perceptual_validation": [], "scientifically_validated": []},
        "promotion": {"candidate_ids": []},
        "perceptual_sampling": request.get("perceptual_sampling", {}),
        "programme": None,
        "screening_objectives": objective_names[: len(objective_vectors[0])] if objective_vectors else objective_names,
        "gm_crowe_in_search": multiobjective and (not objective_vectors or len(objective_vectors[0]) >= 4),
        "engineering_objectives": None,
        "validation_blockers": ["campaign_in_progress"],
        "points": points,
        "failed_candidates": failed_candidates,
        "baseline_values": {},
        "hypervolume": hypervolume,
        "report_path": None,
    }


class JobStore:
    def __init__(self, root: str | Path, config: SonyaConfig, programme_path: str | Path):
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.config = config
        self.programme_path = Path(programme_path).expanduser().resolve()
        self._processes: dict[str, subprocess.Popen[bytes]] = {}
        self._perceptual_processes: dict[str, subprocess.Popen[bytes]] = {}
        self._archive_snapshots: dict[str, dict[str, object]] = {}
        self._report_summaries: dict[str, dict[str, object]] = {}
        self._lock = threading.Lock()

    def _partial_result(
        self,
        directory: Path,
        record: dict[str, object],
        events: list[dict[str, object]],
    ) -> dict[str, object] | None:
        archives = sorted((directory / "output").glob("optimization-campaign-*/candidate-archive.jsonl"))
        if not archives:
            return None
        archive = archives[-1]
        key = str(archive)
        size = archive.stat().st_size
        with self._lock:
            snapshot = self._archive_snapshots.get(key)
            if snapshot is None or size < int(snapshot.get("offset", 0)):
                snapshot = {"offset": 0, "tail": b"", "records": []}
            previous_count = len(snapshot["records"])
            cached_result = snapshot.get("result")
            offset = int(snapshot["offset"])
            with archive.open("rb") as stream:
                stream.seek(offset)
                payload = bytes(snapshot["tail"]) + stream.read()
                next_offset = stream.tell()
            lines = payload.splitlines(keepends=True)
            tail = b""
            if lines and not lines[-1].endswith((b"\n", b"\r")):
                tail = lines.pop()
            parsed = list(snapshot["records"])
            for line in lines:
                try:
                    candidate = json.loads(line)
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
                if isinstance(candidate, dict) and candidate.get("stage") == "screening":
                    parsed.append(candidate)
            self._archive_snapshots[key] = {
                "offset": next_offset,
                "tail": tail,
                "records": parsed,
                "result": cached_result,
            }
        if len(parsed) == previous_count and isinstance(cached_result, dict):
            return cached_result
        simulator_runs = max(
            (int(item.get("simulator_runs", 0)) for item in events if isinstance(item.get("simulator_runs"), int)),
            default=0,
        )
        result = _archive_report_summary(parsed, dict(record.get("request", {})), simulator_runs=simulator_runs)
        with self._lock:
            current = self._archive_snapshots.get(key)
            if current is not None and len(current.get("records", [])) == len(parsed):
                current["result"] = result
        return result

    def _final_result(self, report_path: Path) -> dict[str, object]:
        key = str(report_path)
        with self._lock:
            cached = self._report_summaries.get(key)
        if cached is not None:
            return cached
        result = _report_summary(report_path)
        with self._lock:
            self._report_summaries[key] = result
        return result

    def _job_path(self, job_id: str) -> Path:
        if not JOB_ID.fullmatch(job_id):
            raise ValueError("identificador de execução inválido")
        return self.root / job_id

    def _read(self, job_id: str) -> dict[str, object]:
        path = self._job_path(job_id) / "job.json"
        if not path.is_file():
            raise FileNotFoundError(f"execução não encontrada: {job_id}")
        return json.loads(path.read_text(encoding="utf-8"))

    def _write(self, job_id: str, record: dict[str, object]) -> None:
        _atomic_json(self._job_path(job_id) / "job.json", record)

    def create(self, payload: dict[str, object]) -> dict[str, object]:
        job_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ-") + uuid.uuid4().hex[:8]
        directory = self._job_path(job_id)
        directory.mkdir(parents=True)
        control_path = directory / "campaign-control.json"
        event_path = directory / "campaign-events.jsonl"
        _write_control(control_path, "run")
        command, normalized = build_campaign_command(
            payload,
            self.config,
            self.programme_path,
            directory / "output",
            control_path=control_path,
            event_path=event_path,
        )
        record: dict[str, object] = {
            "id": job_id,
            "name": str(payload.get("name", "Campanha sem nome")).strip() or "Campanha sem nome",
            "status": "starting",
            "created_at": _utc_now(),
            "updated_at": _utc_now(),
            "request": normalized,
            "command": command,
            "log_path": str(directory / "run.log"),
            "output_root": str(directory / "output"),
            "control_path": str(control_path),
            "event_path": str(event_path),
        }
        self._write(job_id, record)
        log_stream = (directory / "run.log").open("ab", buffering=0)
        environment = dict(os.environ)
        environment["PYTHONUNBUFFERED"] = "1"
        try:
            process = subprocess.Popen(
                command,
                cwd=self.config.source.parent.parent,
                stdout=log_stream,
                stderr=subprocess.STDOUT,
                env=environment,
                start_new_session=os.name != "nt",
            )
        except Exception:
            log_stream.close()
            record.update({"status": "failed_to_start", "updated_at": _utc_now()})
            self._write(job_id, record)
            raise
        log_stream.close()
        record.update({"status": "running", "pid": process.pid, "started_at": _utc_now(), "updated_at": _utc_now()})
        self._write(job_id, record)
        with self._lock:
            self._processes[job_id] = process
        threading.Thread(target=self._wait_for_job, args=(job_id, process), daemon=True).start()
        return self.detail(job_id)

    def _wait_for_job(self, job_id: str, process: subprocess.Popen[bytes]) -> None:
        return_code = process.wait()
        try:
            record = self._read(job_id)
            report = _campaign_report(self._job_path(job_id))
            events = _read_events(record.get("event_path"))
            cancelled = return_code == 130 or any(item.get("event") == "cancelled_at_boundary" for item in events)
            record.update({
                "status": "cancelled" if cancelled else ("completed" if return_code == 0 and report else "failed"),
                "return_code": return_code,
                "finished_at": _utc_now(),
                "updated_at": _utc_now(),
                "report_path": str(report) if report else None,
            })
            self._write(job_id, record)
        finally:
            with self._lock:
                self._processes.pop(job_id, None)

    def start_perceptual(self, job_id: str, payload: dict[str, object]) -> dict[str, object]:
        record = self._refresh(self._read(job_id))
        if record.get("status") != "completed":
            raise ValueError("a campanha precisa estar concluída antes da validação perceptual")
        current = record.get("perceptual_run")
        if isinstance(current, dict) and current.get("status") in {"starting", "running", "pause_requested", "paused", "cancel_requested"}:
            raise ValueError("já existe uma validação perceptual em execução")
        directory = self._job_path(job_id)
        campaign = _campaign_report(directory)
        if campaign is None:
            raise ValueError("relatório da campanha não encontrado")
        run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ-") + uuid.uuid4().hex[:8]
        output_root = directory / "perceptual" / run_id
        control_path = directory / "perceptual" / run_id / "control.json"
        event_path = directory / "perceptual" / run_id / "events.jsonl"
        _write_control(control_path, "run")
        command, normalized = build_perceptual_command(
            payload,
            self.config,
            self.programme_path,
            campaign,
            output_root,
            control_path=control_path,
            event_path=event_path,
        )
        log_path = directory / "perceptual.log"
        perceptual_run: dict[str, object] = {
            "status": "starting",
            "request": normalized,
            "command": command,
            "log_path": str(log_path),
            "output_root": str(output_root),
            "started_at": _utc_now(),
            "control_path": str(control_path),
            "event_path": str(event_path),
        }
        record.update({"perceptual_run": perceptual_run, "updated_at": _utc_now()})
        self._write(job_id, record)
        log_stream = log_path.open("ab", buffering=0)
        environment = dict(os.environ)
        environment["PYTHONUNBUFFERED"] = "1"
        try:
            process = subprocess.Popen(
                command,
                cwd=self.config.source.parent.parent,
                stdout=log_stream,
                stderr=subprocess.STDOUT,
                env=environment,
                start_new_session=os.name != "nt",
            )
        except Exception:
            log_stream.close()
            perceptual_run.update({"status": "failed_to_start", "finished_at": _utc_now()})
            record.update({"perceptual_run": perceptual_run, "updated_at": _utc_now()})
            self._write(job_id, record)
            raise
        log_stream.close()
        perceptual_run.update({"status": "running", "pid": process.pid})
        record.update({"perceptual_run": perceptual_run, "updated_at": _utc_now()})
        self._write(job_id, record)
        with self._lock:
            self._perceptual_processes[job_id] = process
        threading.Thread(target=self._wait_for_perceptual, args=(job_id, process), daemon=True).start()
        return self.detail(job_id)

    def _wait_for_perceptual(self, job_id: str, process: subprocess.Popen[bytes]) -> None:
        return_code = process.wait()
        try:
            record = self._read(job_id)
            current = dict(record.get("perceptual_run", {}))
            report = _perceptual_report(self._job_path(job_id), current.get("output_root"))
            events = _read_events(current.get("event_path"))
            cancelled = return_code == 130 or any(item.get("event") == "cancelled_at_boundary" for item in events)
            summary = _perceptual_report_summary(report) if report else {}
            current.update({
                "status": "cancelled" if cancelled else ("completed" if return_code == 0 and report else "failed"),
                "return_code": return_code,
                "finished_at": _utc_now(),
                "report_path": str(report) if report else None,
                "result_status": summary.get("status"),
                "scientific_scope": summary.get("scientific_scope"),
                "case_count": summary.get("case_count"),
                "failed_case_count": summary.get("failed_case_count"),
            })
            record.update({"perceptual_run": current, "updated_at": _utc_now()})
            self._write(job_id, record)
        finally:
            with self._lock:
                self._perceptual_processes.pop(job_id, None)

    def control(self, job_id: str, payload: dict[str, object]) -> dict[str, object]:
        target = str(payload.get("target", "campaign"))
        action = str(payload.get("action", ""))
        if target not in {"campaign", "perceptual"}:
            raise ValueError("alvo de execução inválido")
        if action not in {"pause", "resume", "cancel"}:
            raise ValueError("use pause, resume ou cancel")
        record = self._refresh(self._read(job_id))
        run = record if target == "campaign" else record.get("perceptual_run")
        if not isinstance(run, dict):
            raise ValueError("a validação perceptual ainda não foi iniciada")
        active = {"starting", "running", "pause_requested", "paused", "cancel_requested"}
        if run.get("status") not in active:
            raise ValueError("esta execução já terminou")
        control_path = Path(str(run.get("control_path", "")))
        if not control_path.name:
            raise ValueError("esta execução antiga não oferece controle cooperativo")
        _write_control(control_path, "run" if action == "resume" else action)
        next_status = {"pause": "pause_requested", "resume": "running", "cancel": "cancel_requested"}[action]
        if target == "campaign":
            record.update({"status": next_status, "updated_at": _utc_now()})
        else:
            run.update({"status": next_status})
            record.update({"perceptual_run": run, "updated_at": _utc_now()})
        self._write(job_id, record)
        return self.detail(job_id)

    def _refresh(self, record: dict[str, object]) -> dict[str, object]:
        job_id = str(record["id"])
        directory = self._job_path(job_id)
        report = _campaign_report(directory)
        campaign_events = _read_events(record.get("event_path"))
        campaign_latest = campaign_events[-1] if campaign_events else {}
        if campaign_latest.get("event") == "paused_at_boundary" and record.get("status") == "pause_requested":
            record["status"] = "paused"
        elif campaign_latest.get("event") == "resumed" and record.get("status") == "paused":
            record["status"] = "running"
        if report and record.get("status") not in {"completed", "failed", "cancelled"}:
            record.update({"status": "completed", "report_path": str(report), "updated_at": _utc_now()})
            self._write(job_id, record)
        elif record.get("status") in {"running", "pause_requested", "paused", "cancel_requested"} and not _pid_running(int(record.get("pid", 0))):
            record.update({"status": "interrupted", "updated_at": _utc_now()})
            self._write(job_id, record)
        perceptual = record.get("perceptual_run")
        if isinstance(perceptual, dict):
            perceptual_events = _read_events(perceptual.get("event_path"))
            perceptual_latest = perceptual_events[-1] if perceptual_events else {}
            if perceptual_latest.get("event") == "paused_at_boundary" and perceptual.get("status") == "pause_requested":
                perceptual["status"] = "paused"
            elif perceptual_latest.get("event") == "resumed" and perceptual.get("status") == "paused":
                perceptual["status"] = "running"
            perceptual_report = _perceptual_report(directory, perceptual.get("output_root"))
            if perceptual_report and perceptual.get("status") not in {"completed", "failed", "cancelled"}:
                perceptual_summary = _perceptual_report_summary(perceptual_report)
                perceptual.update({
                    "status": "completed",
                    "report_path": str(perceptual_report),
                    "result_status": perceptual_summary.get("status"),
                    "scientific_scope": perceptual_summary.get("scientific_scope"),
                    "case_count": perceptual_summary.get("case_count"),
                    "failed_case_count": perceptual_summary.get("failed_case_count"),
                })
                record.update({"perceptual_run": perceptual, "updated_at": _utc_now()})
                self._write(job_id, record)
            elif perceptual_report and not perceptual.get("scientific_scope"):
                perceptual_summary = _perceptual_report_summary(perceptual_report)
                perceptual.update({
                    "report_path": str(perceptual_report),
                    "result_status": perceptual_summary.get("status"),
                    "scientific_scope": perceptual_summary.get("scientific_scope"),
                    "case_count": perceptual_summary.get("case_count"),
                    "failed_case_count": perceptual_summary.get("failed_case_count"),
                })
                record.update({"perceptual_run": perceptual, "updated_at": _utc_now()})
                self._write(job_id, record)
            elif perceptual.get("status") in {"running", "pause_requested", "paused", "cancel_requested"} and not _pid_running(int(perceptual.get("pid", 0))):
                perceptual.update({"status": "interrupted", "finished_at": _utc_now()})
                record.update({"perceptual_run": perceptual, "updated_at": _utc_now()})
                self._write(job_id, record)
        screening, engineering = _archive_progress(directory)
        budget = int(dict(record.get("request", {})).get("budget", 0))
        progress = {
            "screening_completed": screening,
            "engineering_completed": engineering,
            "budget": budget,
            "fraction": min(1.0, screening / budget) if budget else 0.0,
            "events": _event_progress(campaign_events, total=budget),
        }
        return {**record, "progress": progress}

    def list(self) -> list[dict[str, object]]:
        records: list[dict[str, object]] = []
        for path in sorted(self.root.glob("*/job.json"), reverse=True):
            try:
                records.append(self._refresh(json.loads(path.read_text(encoding="utf-8"))))
            except (OSError, ValueError, json.JSONDecodeError):
                continue
        return records

    def detail(self, job_id: str) -> dict[str, object]:
        record = self._refresh(self._read(job_id))
        log_path = Path(str(record["log_path"]))
        log_tail = ""
        if log_path.is_file():
            log_tail = "\n".join(log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-80:])
        campaign_events = _read_events(record.get("event_path"))
        report_path = _campaign_report(self._job_path(job_id))
        summary = (
            self._final_result(report_path)
            if report_path
            else self._partial_result(self._job_path(job_id), record, campaign_events)
        )
        perceptual_log_tail = ""
        perceptual = record.get("perceptual_run")
        if isinstance(perceptual, dict):
            perceptual_log_path = Path(str(perceptual.get("log_path", "")))
            if perceptual_log_path.is_file():
                perceptual_log_tail = "\n".join(perceptual_log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-80:])
        perceptual_output = perceptual.get("output_root") if isinstance(perceptual, dict) else None
        perceptual_report = _perceptual_report(self._job_path(job_id), perceptual_output)
        perceptual_result = _perceptual_report_summary(perceptual_report) if perceptual_report else None
        perceptual_events = _read_events(perceptual.get("event_path")) if isinstance(perceptual, dict) else []
        return {
            **record,
            "log_tail": log_tail,
            "result": summary,
            "perceptual_log_tail": perceptual_log_tail,
            "perceptual_result": perceptual_result,
            "events": campaign_events,
            "perceptual_events": perceptual_events,
            "perceptual_progress": _event_progress(
                perceptual_events,
                total=int(dict(perceptual.get("request", {})).get("estimated_cases", 0)) if isinstance(perceptual, dict) else 0,
            ),
        }


class SonyaGuiServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], config: SonyaConfig, programme_path: Path, state_root: Path):
        self.config = config
        self.programme_path = programme_path
        programme = load_programme_manifest(programme_path)
        self.corpus_audio = {
            item.id: item.canonical_path if item.canonical_path and item.canonical_path.is_file() else item.path
            for item in programme.items
        }
        self.topology_diagrams = {
            item.id: Path(item.diagram)
            for item in topology_specs(config)
            if item.diagram
        }
        self.jobs = JobStore(state_root, config, programme_path)
        self.bootstrap = gui_bootstrap(config, programme_path)
        super().__init__(address, SonyaGuiHandler)


class SonyaGuiHandler(BaseHTTPRequestHandler):
    server: SonyaGuiServer

    def _send(self, body: bytes, content_type: str, status: HTTPStatus = HTTPStatus.OK) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; media-src 'self'; style-src 'self'; script-src 'self'")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, value: object, status: HTTPStatus = HTTPStatus.OK) -> None:
        self._send(json.dumps(value, default=str).encode("utf-8"), "application/json; charset=utf-8", status)

    def _asset(self, name: str, content_type: str) -> None:
        resource = files("sonya.gui_assets").joinpath(name)
        self._send(resource.read_bytes(), content_type)

    def _local_file(self, path: Path, content_type: str | None = None) -> None:
        if not path.is_file():
            raise FileNotFoundError(str(path))
        guessed = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        self._send(path.read_bytes(), content_type or guessed)

    def do_GET(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        try:
            path = urlsplit(self.path).path
            if path == "/":
                self._asset("index.html", "text/html; charset=utf-8")
                return
            if path == "/app.css":
                self._asset("app.css", "text/css; charset=utf-8")
                return
            if path == "/app.js":
                self._asset("app.js", "text/javascript; charset=utf-8")
                return
            if path in {"/sonya-icon.png", "/favicon.ico"}:
                self._asset("sonya-icon.png", "image/png")
                return
            if path == "/sonya-favicon-v4.svg":
                self._asset("sonya-favicon-v4.svg", "image/svg+xml")
                return
            if path == "/sonya-favicon-v4.png":
                self._asset("sonya-icon.png", "image/png")
                return
            if path == "/healthz":
                self._json({"status": "ok", "local_only": True})
                return
            if path == "/api/bootstrap":
                self._json({**self.server.bootstrap, "jobs": self.server.jobs.list()})
                return
            if path == "/api/jobs":
                self._json({"jobs": self.server.jobs.list()})
                return
            match = re.fullmatch(r"/api/jobs/([^/]+)", path)
            if match:
                self._json(self.server.jobs.detail(match.group(1)))
                return
            match = re.fullmatch(r"/api/topologies/([^/]+)/diagram", path)
            if match:
                topology_id = unquote(match.group(1))
                diagram = self.server.topology_diagrams.get(topology_id)
                if diagram is None:
                    raise FileNotFoundError(f"diagrama indisponível para {topology_id}")
                self._local_file(diagram)
                return
            match = re.fullmatch(r"/api/corpus/([^/]+)/audio", path)
            if match:
                item_id = unquote(match.group(1))
                audio = self.server.corpus_audio.get(item_id)
                if audio is None:
                    raise FileNotFoundError(f"áudio indisponível para {item_id}")
                self._local_file(audio, "audio/wav")
                return
            self._json({"error": "rota não encontrada"}, HTTPStatus.NOT_FOUND)
        except FileNotFoundError as exc:
            self._json({"error": str(exc)}, HTTPStatus.NOT_FOUND)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)

    def do_POST(self) -> None:  # noqa: N802 - required by BaseHTTPRequestHandler
        path = urlsplit(self.path).path
        perceptual_match = re.fullmatch(r"/api/jobs/([^/]+)/perceptual", path)
        control_match = re.fullmatch(r"/api/jobs/([^/]+)/control", path)
        if path != "/api/jobs" and not perceptual_match and not control_match:
            self._json({"error": "rota não encontrada"}, HTTPStatus.NOT_FOUND)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 256_000:
                raise ValueError("corpo da requisição inválido")
            payload = json.loads(self.rfile.read(length))
            if not isinstance(payload, dict):
                raise ValueError("a configuração deve ser um objeto")
            if perceptual_match:
                self._json(self.server.jobs.start_perceptual(perceptual_match.group(1), payload), HTTPStatus.CREATED)
            elif control_match:
                self._json(self.server.jobs.control(control_match.group(1), payload))
            else:
                self._json(self.server.jobs.create(payload), HTTPStatus.CREATED)
        except (OSError, ValueError, json.JSONDecodeError, subprocess.SubprocessError) as exc:
            self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)

    def log_message(self, fmt: str, *args: object) -> None:
        sys.stderr.write("[sonya-gui] " + fmt % args + "\n")


def serve_gui(
    config: SonyaConfig,
    programme_path: str | Path,
    *,
    host: str = "127.0.0.1",
    port: int = 8765,
    open_browser: bool = True,
    state_root: str | Path | None = None,
) -> int:
    if host not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("a primeira versão da GUI aceita somente endereços locais")
    if not 0 <= port <= 65535:
        raise ValueError("a porta deve ficar entre 0 e 65535")
    programme = Path(programme_path).expanduser().resolve()
    root = Path(state_root).expanduser().resolve() if state_root else config.processed_root / "gui-jobs"
    try:
        server = SonyaGuiServer((host, port), config, programme, root)
    except OSError as exc:
        if exc.errno != errno.EADDRINUSE:
            raise
        url = f"http://127.0.0.1:{port}/"
        print(
            f"A porta {port} já está em uso. Uma GUI pode continuar ativa mesmo depois de fechar a aba.\n"
            f"Abra a instância existente em {url}, encerre o processo anterior, ou use "
            f"'sonya gui --port {port + 1}'.",
            file=sys.stderr,
        )
        return 2
    actual_port = int(server.server_address[1])
    url = f"http://127.0.0.1:{actual_port}/"
    print(f"Sonya GUI disponível em {url}")
    print("As campanhas continuam no backend mesmo se esta aba do navegador for fechada.")
    if open_browser:
        threading.Timer(0.25, webbrowser.open, args=(url,)).start()
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print("\nEncerrando a interface; campanhas em execução não são interrompidas.")
    finally:
        server.server_close()
    return 0
