from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Callable, Sequence

import numpy as np

from .config import ParameterSpec


@dataclass(frozen=True)
class SearchEvaluation:
    """Result returned by the circuit evaluator.

    Objectives are always represented in minimization form.  Scalar scores are
    required only by the historical PSO and SAM references.
    """

    objectives: tuple[float, ...]
    scalar_score: float | None
    feasible: bool = True
    metadata: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class SearchRecord:
    id: str
    vector: tuple[float, ...]
    values: dict[str, float]
    evaluation: SearchEvaluation


@dataclass(frozen=True)
class SearchResult:
    algorithm: str
    records: tuple[SearchRecord, ...]
    final_population: tuple[SearchRecord, ...]
    pareto_front: tuple[SearchRecord, ...]
    requested_budget: int
    candidate_evaluations: int


@dataclass(frozen=True)
class SearchDimension:
    id: str
    members: tuple[str, ...]
    minimum: float
    maximum: float


class ParameterSpace:
    """Normalized bounded parameter space with fixed/symmetric seams enforced."""

    def __init__(
        self,
        baseline: dict[str, float],
        specs: Sequence[ParameterSpec],
        symmetry_groups: Sequence[Sequence[str]],
        fixed_parameters: Sequence[dict[str, object]],
        vary: Sequence[str] | None = None,
    ) -> None:
        self.baseline = {name: float(value) for name, value in baseline.items()}
        spec_by_id = {spec.id: spec for spec in specs}
        if set(spec_by_id) != set(self.baseline):
            missing = sorted(set(spec_by_id) - set(self.baseline))
            extra = sorted(set(self.baseline) - set(spec_by_id))
            raise ValueError(f"parameter-space mismatch; missing={missing}, extra={extra}")
        fixed = {str(item["id"]) for item in fixed_parameters}
        requested = list(dict.fromkeys(vary if vary is not None else (spec.id for spec in specs if spec.id not in fixed)))
        unknown = [name for name in requested if name not in spec_by_id]
        if unknown:
            raise ValueError(f"unknown parameter(s): {', '.join(unknown)}")
        forbidden = [name for name in requested if name in fixed]
        if forbidden:
            raise ValueError(f"fixed parameter(s) cannot be varied: {', '.join(forbidden)}")
        if not requested:
            raise ValueError("at least one non-fixed parameter must be varied")

        group_by_member: dict[str, tuple[str, ...]] = {}
        for raw_group in symmetry_groups:
            members = tuple(str(name) for name in raw_group)
            for member in members:
                if member in group_by_member:
                    raise ValueError(f"parameter appears in more than one symmetry group: {member}")
                group_by_member[member] = members

        dimensions: list[SearchDimension] = []
        consumed: set[str] = set()
        for parameter_id in requested:
            members = group_by_member.get(parameter_id, (parameter_id,))
            if any(member in fixed for member in members):
                raise ValueError(f"symmetry group contains a fixed parameter: {', '.join(members)}")
            if members[0] in consumed:
                continue
            # Selecting one symmetric member necessarily selects the complete group.
            lower = max(spec_by_id[member].minimum for member in members)
            upper = min(spec_by_id[member].maximum for member in members)
            if lower >= upper:
                raise ValueError(f"symmetry group has no common bounds: {', '.join(members)}")
            dimensions.append(SearchDimension("_".join(members), members, lower, upper))
            consumed.update(members)
        self.dimensions = tuple(dimensions)

    @property
    def size(self) -> int:
        return len(self.dimensions)

    def encode(self, values: dict[str, float] | None = None) -> np.ndarray:
        selected = values or self.baseline
        result = []
        for dimension in self.dimensions:
            value = float(selected[dimension.members[0]])
            result.append((value - dimension.minimum) / (dimension.maximum - dimension.minimum))
        return np.clip(np.asarray(result, dtype=float), 0.0, 1.0)

    def decode(self, vector: Sequence[float]) -> dict[str, float]:
        array = np.asarray(vector, dtype=float)
        if array.shape != (self.size,) or not np.all(np.isfinite(array)):
            raise ValueError(f"expected a finite normalized vector with {self.size} entries")
        values = dict(self.baseline)
        for coordinate, dimension in zip(np.clip(array, 0.0, 1.0), self.dimensions):
            value = dimension.minimum + float(coordinate) * (dimension.maximum - dimension.minimum)
            for member in dimension.members:
                values[member] = value
        return values


Evaluator = Callable[[dict[str, float]], SearchEvaluation]


MULTIOBJECTIVE_ALGORITHMS = frozenset({"nsga2", "gde3"})


def _dominates(left: SearchRecord, right: SearchRecord) -> bool:
    if left.evaluation.feasible != right.evaluation.feasible:
        return left.evaluation.feasible
    if not left.evaluation.feasible:
        return False
    a, b = left.evaluation.objectives, right.evaluation.objectives
    return all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))


def nondominated_sort(records: Sequence[SearchRecord]) -> list[list[SearchRecord]]:
    remaining = list(records)
    fronts: list[list[SearchRecord]] = []
    while remaining:
        front = [item for item in remaining if not any(_dominates(other, item) for other in remaining if other is not item)]
        if not front:  # Defensive seam for malformed/non-finite custom evaluators.
            front = [remaining[0]]
        fronts.append(front)
        front_ids = {id(item) for item in front}
        remaining = [item for item in remaining if id(item) not in front_ids]
    return fronts


def crowding_distances(front: Sequence[SearchRecord]) -> dict[str, float]:
    distances = {record.id: 0.0 for record in front}
    if len(front) <= 2:
        return {record.id: math.inf for record in front}
    objective_count = len(front[0].evaluation.objectives)
    for objective_index in range(objective_count):
        ordered = sorted(front, key=lambda item: item.evaluation.objectives[objective_index])
        distances[ordered[0].id] = distances[ordered[-1].id] = math.inf
        low = ordered[0].evaluation.objectives[objective_index]
        high = ordered[-1].evaluation.objectives[objective_index]
        if not math.isfinite(low) or not math.isfinite(high) or high == low:
            continue
        for index in range(1, len(ordered) - 1):
            if math.isfinite(distances[ordered[index].id]):
                previous = ordered[index - 1].evaluation.objectives[objective_index]
                following = ordered[index + 1].evaluation.objectives[objective_index]
                distances[ordered[index].id] += (following - previous) / (high - low)
    return distances


def _environmental_select(records: Sequence[SearchRecord], size: int) -> list[SearchRecord]:
    selected: list[SearchRecord] = []
    for front in nondominated_sort(records):
        if len(selected) + len(front) <= size:
            selected.extend(front)
            continue
        distances = crowding_distances(front)
        selected.extend(sorted(front, key=lambda item: distances[item.id], reverse=True)[: size - len(selected)])
        break
    return selected


def _record_factory(space: ParameterSpace, evaluator: Evaluator, budget: int):
    records: list[SearchRecord] = []
    cache: dict[tuple[float, ...], SearchRecord] = {}
    objective_count: int | None = None

    def evaluate(vector: Sequence[float]) -> SearchRecord | None:
        nonlocal objective_count
        clipped = np.clip(np.asarray(vector, dtype=float), 0.0, 1.0)
        key = tuple(round(float(value), 14) for value in clipped)
        if key in cache:
            return cache[key]
        if len(records) >= budget:
            return None
        values = space.decode(clipped)
        result = evaluator(values)
        if not result.objectives or not all(math.isfinite(float(value)) for value in result.objectives):
            raise ValueError("optimizer evaluator returned missing or non-finite objectives")
        if objective_count is None:
            objective_count = len(result.objectives)
        elif len(result.objectives) != objective_count:
            raise ValueError("optimizer evaluator changed the number of objectives")
        if result.scalar_score is not None and not math.isfinite(float(result.scalar_score)):
            raise ValueError("optimizer evaluator returned a non-finite scalar score")
        record = SearchRecord(f"candidate-{len(records):05d}", key, values, result)
        records.append(record)
        cache[key] = record
        return record

    return records, evaluate


def run_nsga2(
    space: ParameterSpace,
    evaluator: Evaluator,
    budget: int,
    population_size: int = 40,
    seed: int = 0,
) -> SearchResult:
    if budget < 4 or population_size < 4:
        raise ValueError("NSGA-II requires budget and population size of at least 4")
    rng = np.random.default_rng(seed)
    records, evaluate = _record_factory(space, evaluator, budget)
    target_size = min(population_size, budget)
    population: list[SearchRecord] = []
    for vector in [space.encode(), *(rng.random(space.size) for _ in range(target_size - 1))]:
        record = evaluate(vector)
        if record is not None:
            population.append(record)

    while len(records) < budget:
        fronts = nondominated_sort(population)
        rank = {record.id: index for index, front in enumerate(fronts) for record in front}
        crowding = {record_id: value for front in fronts for record_id, value in crowding_distances(front).items()}

        def tournament() -> SearchRecord:
            left, right = rng.choice(population, size=2, replace=False)
            left_key = (rank[left.id], -crowding[left.id])
            right_key = (rank[right.id], -crowding[right.id])
            return left if left_key <= right_key else right

        children: list[SearchRecord] = []
        attempts = 0
        while len(children) < target_size and len(records) < budget:
            attempts += 1
            first, second = tournament(), tournament()
            a, b = np.asarray(first.vector), np.asarray(second.vector)
            blend = rng.uniform(-0.25, 1.25, size=space.size)
            child = blend * a + (1.0 - blend) * b
            mutation_mask = rng.random(space.size) < max(1.0 / space.size, 0.05)
            child += mutation_mask * rng.normal(0.0, 0.1, size=space.size)
            record = evaluate(child)
            if record is not None and record not in population and record not in children:
                children.append(record)
            if attempts > 1000:
                record = evaluate(rng.random(space.size))
                if record is not None and record not in population and record not in children:
                    children.append(record)
                attempts = 0
        if not children:
            break
        population = _environmental_select([*population, *children], target_size)

    front = nondominated_sort(population)[0]
    return SearchResult("nsga2", tuple(records), tuple(population), tuple(front), budget, len(records))


def _de_trial(
    rng: np.random.Generator,
    population: Sequence[SearchRecord],
    target_index: int,
    mutation_factor: float,
    crossover_probability: float,
) -> np.ndarray:
    available = [index for index in range(len(population)) if index != target_index]
    first, second, third = rng.choice(available, size=3, replace=False)
    a = np.asarray(population[int(first)].vector)
    b = np.asarray(population[int(second)].vector)
    c = np.asarray(population[int(third)].vector)
    mutant = np.clip(a + mutation_factor * (b - c), 0.0, 1.0)
    target = np.asarray(population[target_index].vector)
    crossover = rng.random(target.size) < crossover_probability
    crossover[int(rng.integers(target.size))] = True
    return np.where(crossover, mutant, target)


def _validate_de_settings(
    budget: int,
    population_size: int,
    mutation_factor: float,
    crossover_probability: float,
) -> None:
    if budget < 4 or population_size < 4:
        raise ValueError("differential evolution requires budget and population size of at least 4")
    if not 0.0 < mutation_factor <= 2.0:
        raise ValueError("mutation factor must be in (0, 2]")
    if not 0.0 <= crossover_probability <= 1.0:
        raise ValueError("crossover probability must be in [0, 1]")


def _initial_population(
    space: ParameterSpace,
    evaluate: Callable[[Sequence[float]], SearchRecord | None],
    rng: np.random.Generator,
    size: int,
) -> list[SearchRecord]:
    population: list[SearchRecord] = []
    for vector in [space.encode(), *(rng.random(space.size) for _ in range(size - 1))]:
        record = evaluate(vector)
        if record is not None:
            population.append(record)
    return population


def run_differential_evolution(
    space: ParameterSpace,
    evaluator: Evaluator,
    budget: int,
    population_size: int = 20,
    seed: int = 0,
    mutation_factor: float = 0.8,
    crossover_probability: float = 0.9,
) -> SearchResult:
    """Run bounded DE/rand/1/bin against the historical scalar score."""

    _validate_de_settings(budget, population_size, mutation_factor, crossover_probability)
    rng = np.random.default_rng(seed)
    records, evaluate = _record_factory(space, evaluator, budget)
    size = min(population_size, budget)
    population = _initial_population(space, evaluate, rng, size)
    if any(item.evaluation.scalar_score is None for item in population):
        raise ValueError("differential evolution requires scalar scores")

    while len(records) < budget:
        before_generation = len(records)
        parents = list(population)
        for target_index, parent in enumerate(parents):
            if len(records) >= budget:
                break
            trial: SearchRecord | None = None
            for _ in range(100):
                candidate = evaluate(
                    _de_trial(
                        rng,
                        parents,
                        target_index,
                        mutation_factor,
                        crossover_probability,
                    )
                )
                if candidate is not None and candidate.id != parent.id:
                    trial = candidate
                    break
            if trial is None:
                continue
            if trial.evaluation.scalar_score is None:
                raise ValueError("differential evolution requires scalar scores")
            parent_key = (
                not parent.evaluation.feasible,
                float(parent.evaluation.scalar_score),
            )
            trial_key = (
                not trial.evaluation.feasible,
                float(trial.evaluation.scalar_score),
            )
            if trial_key <= parent_key:
                population[target_index] = trial
        if len(records) == before_generation:
            for _ in range(100):
                candidate = evaluate(rng.random(space.size))
                if candidate is not None and len(records) > before_generation:
                    worst = max(
                        range(size),
                        key=lambda index: (
                            not population[index].evaluation.feasible,
                            float(population[index].evaluation.scalar_score),
                        ),
                    )
                    if candidate.evaluation.scalar_score is None:
                        raise ValueError("differential evolution requires scalar scores")
                    population[worst] = candidate
                    break
            else:
                raise RuntimeError("differential evolution could not generate a new candidate within the requested budget")

    ordered = sorted(
        population,
        key=lambda item: (
            not item.evaluation.feasible,
            float(item.evaluation.scalar_score) if item.evaluation.scalar_score is not None else math.inf,
        ),
    )
    return SearchResult("differential_evolution", tuple(records), tuple(population), tuple(ordered[:1]), budget, len(records))


def run_gde3(
    space: ParameterSpace,
    evaluator: Evaluator,
    budget: int,
    population_size: int = 40,
    seed: int = 0,
    mutation_factor: float = 0.8,
    crossover_probability: float = 0.9,
) -> SearchResult:
    """Run a GDE3-style multiobjective differential evolution search."""

    _validate_de_settings(budget, population_size, mutation_factor, crossover_probability)
    rng = np.random.default_rng(seed)
    records, evaluate = _record_factory(space, evaluator, budget)
    size = min(population_size, budget)
    population = _initial_population(space, evaluate, rng, size)

    while len(records) < budget:
        before_generation = len(records)
        parents = list(population)
        candidates: list[SearchRecord] = []
        processed = 0
        for target_index, parent in enumerate(parents):
            if len(records) >= budget:
                break
            trial: SearchRecord | None = None
            for _ in range(100):
                candidate = evaluate(
                    _de_trial(
                        rng,
                        parents,
                        target_index,
                        mutation_factor,
                        crossover_probability,
                    )
                )
                if candidate is not None and candidate.id != parent.id:
                    trial = candidate
                    break
            processed += 1
            if trial is None or _dominates(parent, trial):
                candidates.append(parent)
            elif _dominates(trial, parent):
                candidates.append(trial)
            else:
                candidates.extend((parent, trial))
        candidates.extend(parents[processed:])
        if len(records) == before_generation:
            fallback = evaluate(rng.random(space.size))
            if fallback is None or len(records) == before_generation:
                raise RuntimeError("GDE3 could not generate a new candidate within the requested budget")
            candidates.append(fallback)
        population = _environmental_select(candidates, size)

    front = nondominated_sort(population)[0]
    return SearchResult("gde3", tuple(records), tuple(population), tuple(front), budget, len(records))


def run_legacy_pso(
    space: ParameterSpace,
    evaluator: Evaluator,
    budget: int,
    population_size: int = 20,
    seed: int = 0,
) -> SearchResult:
    if budget < 2 or population_size < 2:
        raise ValueError("legacy PSO requires budget and population size of at least 2")
    rng = np.random.default_rng(seed)
    records, evaluate = _record_factory(space, evaluator, budget)
    size = min(population_size, budget)
    positions = np.vstack([space.encode(), *(rng.random(space.size) for _ in range(size - 1))])
    velocities = rng.uniform(-0.1, 0.1, size=positions.shape)
    current = [evaluate(position) for position in positions]
    if any(item is None or item.evaluation.scalar_score is None for item in current):
        raise ValueError("legacy PSO requires scalar scores")
    current_records = [item for item in current if item is not None]
    personal_positions = positions.copy()
    personal_scores = np.asarray([float(item.evaluation.scalar_score) for item in current_records])
    global_index = int(np.argmin(personal_scores))
    global_position = personal_positions[global_index].copy()
    global_score = float(personal_scores[global_index])
    while len(records) < budget:
        before_generation = len(records)
        for index in range(size):
            if len(records) >= budget:
                break
            r1, r2 = rng.random(space.size), rng.random(space.size)
            velocities[index] = 0.7298 * (
                velocities[index]
                + 2.05 * r1 * (personal_positions[index] - positions[index])
                + 2.05 * r2 * (global_position - positions[index])
            )
            positions[index] = np.clip(positions[index] + velocities[index], 0.0, 1.0)
            record = evaluate(positions[index])
            if record is None or record.evaluation.scalar_score is None:
                continue
            score = float(record.evaluation.scalar_score)
            if score < personal_scores[index]:
                personal_scores[index] = score
                personal_positions[index] = positions[index]
                if score < global_score:
                    global_index = index
                    global_position = positions[index].copy()
                    global_score = score
        if len(records) == before_generation:
            for _ in range(100):
                record = evaluate(rng.random(space.size))
                if record is not None and len(records) > before_generation:
                    break
            else:
                raise RuntimeError("legacy PSO could not generate a new candidate within the requested budget")
    ordered = sorted(records, key=lambda item: float(item.evaluation.scalar_score) if item.evaluation.scalar_score is not None else math.inf)
    return SearchResult("legacy_pso", tuple(records), tuple(ordered[:size]), tuple(ordered[:1]), budget, len(records))


def run_legacy_sam(
    space: ParameterSpace,
    evaluator: Evaluator,
    budget: int,
    seed: int = 0,
    initial_temperature: float = 50.0,
    cooling: float = 0.9,
    sigma: float = 0.15,
) -> SearchResult:
    if budget < 2 or initial_temperature <= 0 or not 0 < cooling < 1 or sigma <= 0:
        raise ValueError("invalid legacy SAM settings")
    rng = np.random.default_rng(seed)
    records, evaluate = _record_factory(space, evaluator, budget)
    current_vector = space.encode()
    current = evaluate(current_vector)
    if current is None or current.evaluation.scalar_score is None:
        raise ValueError("legacy SAM requires scalar scores")
    best = current
    temperature = initial_temperature
    block = max(5, space.size)
    duplicate_attempts = 0
    while len(records) < budget:
        if len(records) % block == 0 and len(records) > 1:
            elite = min(records, key=lambda item: float(item.evaluation.scalar_score) if item.evaluation.scalar_score is not None else math.inf)
            mix = rng.random()
            proposal = mix * current_vector + (1.0 - mix) * np.asarray(elite.vector)
            proposal += rng.normal(0.0, sigma * 0.25, size=space.size)
        else:
            proposal = current_vector + rng.normal(0.0, sigma, size=space.size)
        before_evaluation = len(records)
        candidate = evaluate(proposal)
        if candidate is None or candidate.evaluation.scalar_score is None:
            continue
        if len(records) == before_evaluation:
            duplicate_attempts += 1
            if duplicate_attempts >= 100:
                raise RuntimeError("legacy SAM could not generate a new candidate within the requested budget")
            continue
        duplicate_attempts = 0
        current_score = float(current.evaluation.scalar_score)
        candidate_score = float(candidate.evaluation.scalar_score)
        delta = candidate_score - current_score
        if delta <= 0 or rng.random() < math.exp(-delta / max(temperature, 1e-12)):
            current = candidate
            current_vector = np.asarray(candidate.vector)
        if candidate_score < float(best.evaluation.scalar_score):
            best = candidate
        if len(records) % block == 0:
            temperature *= cooling
    ordered = sorted(records, key=lambda item: float(item.evaluation.scalar_score) if item.evaluation.scalar_score is not None else math.inf)
    return SearchResult("legacy_sam", tuple(records), (best,), tuple(ordered[:1]), budget, len(records))


def run_search(
    algorithm: str,
    space: ParameterSpace,
    evaluator: Evaluator,
    budget: int,
    population_size: int,
    seed: int,
    mutation_factor: float = 0.8,
    crossover_probability: float = 0.9,
) -> SearchResult:
    if algorithm == "nsga2":
        return run_nsga2(space, evaluator, budget, population_size, seed)
    if algorithm == "legacy_pso":
        return run_legacy_pso(space, evaluator, budget, population_size, seed)
    if algorithm == "legacy_sam":
        return run_legacy_sam(space, evaluator, budget, seed)
    if algorithm == "differential_evolution":
        return run_differential_evolution(
            space,
            evaluator,
            budget,
            population_size,
            seed,
            mutation_factor,
            crossover_probability,
        )
    if algorithm == "gde3":
        return run_gde3(
            space,
            evaluator,
            budget,
            population_size,
            seed,
            mutation_factor,
            crossover_probability,
        )
    raise ValueError(f"unsupported campaign algorithm: {algorithm}")


def select_for_promotion(result: SearchResult, count: int) -> list[SearchRecord]:
    if count < 1:
        raise ValueError("promotion count must be positive")
    feasible = [item for item in result.records if item.evaluation.feasible]
    if result.algorithm not in MULTIOBJECTIVE_ALGORITHMS:
        return sorted(
            feasible,
            key=lambda item: float(item.evaluation.scalar_score) if item.evaluation.scalar_score is not None else math.inf,
        )[:count]
    selected: list[SearchRecord] = []
    for front in nondominated_sort(feasible):
        distances = crowding_distances(front)
        ordered = sorted(front, key=lambda item: distances[item.id], reverse=True)
        selected.extend(ordered[: count - len(selected)])
        if len(selected) >= count:
            break
    return selected
