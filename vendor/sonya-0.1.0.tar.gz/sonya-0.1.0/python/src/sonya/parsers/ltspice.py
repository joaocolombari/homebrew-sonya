from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

import numpy as np
from numpy.typing import NDArray

from .legacy import _read_text_any_encoding


@dataclass(frozen=True)
class LTspiceRawHeader:
    path: Path
    title: str
    plot_name: str
    flags: tuple[str, ...]
    variable_count: int
    point_count: int
    variables: tuple[tuple[str, str], ...]
    payload_format: str


@dataclass(frozen=True)
class LTspiceRawData:
    header: LTspiceRawHeader
    values: dict[str, NDArray[np.float64] | NDArray[np.complex128]]


@dataclass(frozen=True)
class FourierResult:
    harmonics: tuple[tuple[float, float, float, float, float, float], ...]
    thd_percent: float | None


def read_fourier_result(path: str | Path) -> FourierResult:
    text = _read_text_any_encoding(Path(path)).replace("\x00", "")
    match = re.search(r"(?im)^\s*Total Harmonic Distortion:\s*([\d.Ee+\-]+)%", text)
    thd = float(match.group(1)) if match else None
    lines = text.splitlines()
    header_index = next((index for index, line in enumerate(lines) if "Harmonic" in line and "Frequency" in line), None)
    rows: list[tuple[float, float, float, float, float, float]] = []
    if header_index is not None:
        for line in lines[header_index + 1 :]:
            if not line.strip() or line.lstrip().startswith("Total"):
                break
            numbers = re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", line)
            if len(numbers) >= 6:
                rows.append(tuple(float(item) for item in numbers[:6]))
    return FourierResult(tuple(rows), thd)


def read_ac_measurements(path: str | Path) -> dict[str, float]:
    text = _read_text_any_encoding(Path(path)).replace("\x00", "")
    values: dict[str, float] = {}
    for line in text.splitlines():
        match = re.match(r"\s*([A-Za-z_]\w*):.*?\(\s*([-+\d.Ee]+)dB", line)
        if match:
            values[match.group(1).lower()] = float(match.group(2))
    return values


def read_raw_header(path: str | Path, maximum_header_bytes: int = 1024 * 1024) -> LTspiceRawHeader:
    """Read LTspice RAW metadata without loading the waveform payload.

    Both the UTF-16LE form written by LTspice on this Mac and ASCII headers are
    accepted. Binary sample decoding is intentionally deferred to a later slice.
    """
    source = Path(path)
    with source.open("rb") as stream:
        payload = stream.read(maximum_header_bytes)
    if not payload:
        raise ValueError(f"empty LTspice RAW file: {source}")
    probe = payload[:512]
    utf16 = probe.count(b"\x00") / len(probe) > 0.1
    text = payload.decode("utf-16-le" if utf16 else "ascii", errors="replace")
    marker_match = re.search(r"(?m)^(Binary|Values):\s*$", text)
    if marker_match is None:
        raise ValueError(f"LTspice RAW payload marker not found in first {maximum_header_bytes} bytes: {source}")
    header = text[: marker_match.start()]
    payload_format = marker_match.group(1).lower()

    def field(name: str) -> str:
        match = re.search(rf"(?mi)^{re.escape(name)}:\s*(.*?)\s*$", header)
        if match is None:
            raise ValueError(f"LTspice RAW header is missing {name!r}: {source}")
        return match.group(1)

    variables_block = header.split("Variables:", 1)[1] if "Variables:" in header else ""
    variables: list[tuple[str, str]] = []
    for line in variables_block.splitlines():
        match = re.match(r"\s*\d+\s+([^\s]+)\s+([^\s]+)", line)
        if match:
            variables.append((match.group(1), match.group(2)))
    variable_count = int(field("No. Variables"))
    if len(variables) != variable_count:
        raise ValueError(f"RAW header declares {variable_count} variables but lists {len(variables)}")
    return LTspiceRawHeader(
        path=source,
        title=field("Title"),
        plot_name=field("Plotname"),
        flags=tuple(field("Flags").split()),
        variable_count=variable_count,
        point_count=int(field("No. Points")),
        variables=tuple(variables),
        payload_format=payload_format,
    )


def read_raw(path: str | Path) -> LTspiceRawData:
    """Decode common LTspice binary RAW layouts used by this project."""
    source = Path(path)
    header = read_raw_header(source)
    payload = source.read_bytes()
    utf16_marker = "Binary:\n".encode("utf-16-le")
    ascii_marker = b"Binary:\n"
    marker = utf16_marker if utf16_marker in payload else ascii_marker
    offset = payload.find(marker)
    if offset < 0:
        raise ValueError(f"only binary LTspice RAW payloads are supported: {source}")
    binary = payload[offset + len(marker) :]
    variables = [name for name, _ in header.variables]
    count, points = header.variable_count, header.point_count
    flags = set(header.flags)
    values: dict[str, NDArray[np.float64] | NDArray[np.complex128]] = {}
    if "complex" in flags:
        expected = points * count
        data = np.frombuffer(binary, dtype="<c16", count=expected)
        if data.size != expected:
            raise ValueError(f"truncated complex RAW payload in {source}")
        matrix = data.reshape(points, count)
        values = {name: matrix[:, index].copy() for index, name in enumerate(variables)}
    elif "double" in flags:
        expected = points * count
        data = np.frombuffer(binary, dtype="<f8", count=expected)
        if data.size != expected:
            raise ValueError(f"truncated double RAW payload in {source}")
        matrix = data.reshape(points, count)
        values = {name: matrix[:, index].copy() for index, name in enumerate(variables)}
    elif variables and variables[0].lower() == "time":
        row_bytes = 8 + 4 * (count - 1)
        if len(binary) != points * row_bytes:
            raise ValueError(f"unexpected transient RAW payload size in {source}")
        rows = np.ndarray(
            shape=(points,),
            dtype=np.dtype([("axis", "<f8"), ("traces", "<f4", (count - 1,))]),
            buffer=binary,
        )
        axis = rows["axis"].astype(float, copy=True)
        # LTspice encodes some compressed transient time stamps as negative.
        values[variables[0]] = np.abs(axis) if variables[0].lower() == "time" else axis
        for index, name in enumerate(variables[1:]):
            values[name] = rows["traces"][:, index].astype(float, copy=True)
    else:
        scalar_bytes = points * count * 4
        indexed_bytes = points * (4 + count * 4)
        if len(binary) == scalar_bytes:
            matrix = np.frombuffer(binary, dtype="<f4").reshape(points, count)
        elif len(binary) == indexed_bytes:
            rows = np.ndarray(
                shape=(points,),
                dtype=np.dtype([("index", "<i4"), ("traces", "<f4", (count,))]),
                buffer=binary,
            )
            matrix = rows["traces"]
        else:
            raise ValueError(f"unsupported real RAW payload size in {source}")
        values = {name: matrix[:, index].astype(float, copy=True) for index, name in enumerate(variables)}
    return LTspiceRawData(header, values)
