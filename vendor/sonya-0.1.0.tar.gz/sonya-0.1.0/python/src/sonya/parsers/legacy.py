from __future__ import annotations

from pathlib import Path
import re


_NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?"
_SPICE_NUMBER = rf"{_NUMBER}(?:meg|[tgkmunpf])?"


def parse_spice_number(value: str) -> float:
    match = re.fullmatch(rf"({_NUMBER})(meg|[tgkmunpf])?", value.strip(), re.IGNORECASE)
    if match is None:
        raise ValueError(f"invalid SPICE number: {value!r}")
    suffix = (match.group(2) or "").lower()
    scales = {"": 1.0, "t": 1e12, "g": 1e9, "meg": 1e6, "k": 1e3, "m": 1e-3, "u": 1e-6, "n": 1e-9, "p": 1e-12, "f": 1e-15}
    return float(match.group(1)) * scales[suffix]


def _read_text_any_encoding(path: Path) -> str:
    payload = path.read_bytes()
    if payload.startswith((b"\xff\xfe", b"\xfe\xff")) or (payload and payload.count(b"\x00") / len(payload) > 0.1):
        return payload.decode("utf-16")
    for encoding in ("utf-8-sig", "utf-16-le", "latin-1"):
        try:
            return payload.decode(encoding)
        except UnicodeError:
            pass
    return payload.decode("utf-8", errors="replace")


def read_legacy_parameters(path: str | Path) -> dict[str, float]:
    source = Path(path)
    text = _read_text_any_encoding(source)
    result = {
        match.group(1).upper(): parse_spice_number(match.group(2))
        for match in re.finditer(rf"(?im)^\s*\.param\s+(X\d+)\s*=\s*({_SPICE_NUMBER})", text)
    }
    if not result:
        vector = re.search(r"(?is)\*\s*Best Solution Vector:\s*\n([^\n]+)", text)
        if vector:
            values = [float(token) for token in vector.group(1).split()]
            result = {f"X{index}": value for index, value in enumerate(values, start=1)}
    if not result:
        raise ValueError(f"no legacy parameters found in {source}")
    return dict(sorted(result.items(), key=lambda item: int(item[0][1:])))


def read_legacy_results(path: str | Path) -> dict[str, float]:
    text = _read_text_any_encoding(Path(path))
    aliases = {
        "score": "score",
        "vaa": "vaa_v",
        "gain": "gain_db",
        "output power": "output_power_w",
        "std dev (freq response)": "frequency_std_db",
        "low cutoff": "low_cutoff_hz",
        "high cutoff": "high_cutoff_hz",
        "slew rate": "slew_rate_v_per_us",
        "gedlee": "legacy_gm",
        "thd": "thd_percent",
        "thd was": "thd_percent",
        "thd deu": "thd_percent",
        "gedlee score": "legacy_gm",
    }
    result: dict[str, float] = {}
    for label, value in re.findall(rf"(?im)^\s*\*\s*([^=\n]+?)\s*=\s*({_NUMBER})", text):
        clean = re.sub(r"\s+", " ", label.strip()).lower()
        if clean in aliases:
            result[aliases[clean]] = float(value)
    legacy_thd = re.search(rf"(?im)^\s*\*\s*THD\s+deu\s+({_NUMBER})", text)
    if legacy_thd:
        result["thd_percent"] = float(legacy_thd.group(1))
    if not result:
        raise ValueError(f"no result summary found in {path}")
    return result


def read_ltspice_measurements(path: str | Path) -> dict[str, float]:
    text = _read_text_any_encoding(Path(path))
    measurements: dict[str, float] = {}
    for line in text.replace("\x00", "").splitlines():
        match = re.match(rf"\s*([A-Za-z_]\w*)\s*=\s*({_NUMBER})", line)
        if match is None:
            match = re.match(rf"\s*([A-Za-z_]\w*)\s*:.*?=\s*({_NUMBER})", line)
        if match:
            measurements[match.group(1).lower()] = float(match.group(2))
    return measurements
