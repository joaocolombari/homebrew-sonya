from __future__ import annotations

from pathlib import Path
import re

import numpy as np
from numpy.typing import NDArray


def read_wrdata(path: str | Path) -> tuple[tuple[str, ...], NDArray[np.float64]]:
    source = Path(path)
    lines = source.read_text(encoding="utf-8", errors="replace").splitlines()
    if len(lines) < 2:
        raise ValueError(f"ngspice wrdata file has no samples: {source}")
    names = tuple(lines[0].split())
    values = np.loadtxt(source, skiprows=1, ndmin=2)
    if values.ndim != 2 or values.shape[1] != len(names):
        raise ValueError(f"ngspice wrdata columns do not match header: {source}")
    if values.shape[0] == 0 or not np.all(np.isfinite(values)):
        raise ValueError(f"ngspice wrdata contains no finite samples: {source}")
    return names, np.asarray(values, dtype=float)


def read_ngspice_fourier_thd(log_text: str) -> float | None:
    match = re.search(r"Fourier analysis.*?THD:\s*([+\-\d.eE]+)\s*%", log_text, re.IGNORECASE | re.DOTALL)
    return float(match.group(1)) if match else None
