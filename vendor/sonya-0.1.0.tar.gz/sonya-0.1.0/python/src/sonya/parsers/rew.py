from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True)
class FrequencyResponse:
    path: Path
    frequency_hz: NDArray[np.float64]
    magnitude_db: NDArray[np.float64]
    phase_deg: NDArray[np.float64]


@dataclass(frozen=True)
class ScopeTrace:
    path: Path
    time_s: NDArray[np.float64]
    voltage_v: NDArray[np.float64]
    sample_rate_hz: float
    volts_scale_factor: float


@dataclass(frozen=True)
class Spectrum:
    path: Path
    frequency_hz: NDArray[np.float64]
    magnitude_dbfs: NDArray[np.float64]


@dataclass(frozen=True)
class THDTable:
    path: Path
    columns: tuple[str, ...]
    data: NDArray[np.float64]

    def column(self, name: str) -> NDArray[np.float64]:
        try:
            return self.data[:, self.columns.index(name)]
        except ValueError as exc:
            raise KeyError(name) from exc


def _numeric_rows(path: Path, minimum_columns: int) -> NDArray[np.float64]:
    rows: list[list[float]] = []
    for line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("*"):
            continue
        try:
            values = [float(token) for token in stripped.split()]
        except ValueError:
            continue
        if len(values) >= minimum_columns:
            rows.append(values)
    if not rows:
        raise ValueError(f"no numeric rows with {minimum_columns} columns in {path}")
    widths = {len(row) for row in rows}
    if len(widths) != 1:
        raise ValueError(f"inconsistent numeric column count in {path}: {sorted(widths)}")
    return np.asarray(rows, dtype=float)


def read_rew_measurement(path: str | Path) -> FrequencyResponse:
    source = Path(path)
    data = _numeric_rows(source, 3)
    return FrequencyResponse(source, data[:, 0], data[:, 1], data[:, 2])


def read_rew_scope(path: str | Path) -> ScopeTrace:
    source = Path(path)
    lines = source.read_text(encoding="utf-8-sig", errors="replace").splitlines()
    scale = 1.0
    start: int | None = None
    for index, line in enumerate(lines):
        match = re.search(r"CH1 one volt\s*:\s*([\d.Ee+\-]+)", line)
        if match:
            scale = float(match.group(1))
        if "Time CH1" in line:
            start = index + 1
            break
    if start is None:
        raise ValueError(f"REW scope header 'Time CH1' not found in {source}")
    rows: list[tuple[float, float]] = []
    for line in lines[start:]:
        tokens = line.split()
        if len(tokens) < 2:
            continue
        try:
            rows.append((float(tokens[0]), float(tokens[1])))
        except ValueError:
            continue
    if len(rows) < 2:
        raise ValueError(f"not enough REW scope samples in {source}")
    values = np.asarray(rows, dtype=float)
    time_s = values[:, 0]
    sample_rate = float(1.0 / np.mean(np.diff(time_s)))
    return ScopeTrace(source, time_s, values[:, 1] / scale, sample_rate, scale)


def read_rew_spectrum(path: str | Path) -> Spectrum:
    source = Path(path)
    data = _numeric_rows(source, 2)
    return Spectrum(source, data[:, 0], data[:, 1])


def _normalise_column(label: str) -> str:
    label = label.replace("%", "percent").replace("+", "_plus_")
    label = re.sub(r"[()]", " ", label)
    return re.sub(r"_+", "_", re.sub(r"[^a-zA-Z0-9]+", "_", label).strip("_")).lower()


def read_rew_thd(path: str | Path) -> THDTable:
    source = Path(path)
    lines = source.read_text(encoding="utf-8-sig", errors="replace").splitlines()
    header = next((line[1:].strip() for line in lines if line.startswith("*") and "THD (%)" in line), None)
    if header is None:
        raise ValueError(f"THD column header not found in {source}")
    labels = re.findall(r"[A-Za-z][A-Za-z0-9+]*(?:\s+\([^)]+\))?", header)
    columns = tuple(_normalise_column(label) for label in labels)
    data = _numeric_rows(source, len(columns))
    if data.shape[1] != len(columns):
        raise ValueError(f"THD header has {len(columns)} columns but data has {data.shape[1]}")
    return THDTable(source, columns, data)

