from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import tempfile
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

from .config import SonyaConfig
from .ltspice import LTspiceRunner
from .netlist import validate_parameter_vector
from .parsers.ltspice import read_raw
from .parsers.ngspice import read_wrdata
from .provenance import write_provenance
from .topology import TopologyManifest, stage_topology


def benchmark_signal(sample_rate_hz: int, duration_seconds: float) -> np.ndarray:
    if sample_rate_hz < 8000 or duration_seconds <= 0:
        raise ValueError("invalid benchmark signal settings")
    samples = max(2, round(sample_rate_hz * duration_seconds))
    time_axis = np.arange(samples, dtype=float) / sample_rate_hz
    tones = 0.55 * np.sin(2 * np.pi * 997 * time_axis) + 0.2 * np.sin(2 * np.pi * 3011 * time_axis)
    sweep = 0.15 * signal.chirp(time_axis, f0=80, f1=min(18000, sample_rate_hz * 0.4), t1=duration_seconds, method="logarithmic")
    attack = np.exp(-35.0 * np.mod(time_axis, max(duration_seconds / 4.0, 1.0 / sample_rate_hz)))
    waveform = (tones + sweep) * (0.55 + 0.45 * attack)
    waveform -= float(np.mean(waveform))
    rms = float(np.sqrt(np.mean(np.square(waveform))))
    return waveform * (10.0 ** (-10.0 / 20.0) / rms)


def render_ngspice_programme_parameter_file(
    values: dict[str, float],
    input_voltage: np.ndarray,
    input_sample_rate_hz: int,
    simulation_sample_rate_hz: int,
    reltol: float = 0.001,
    input_filename: str = "programme-input.txt",
) -> str:
    parameters = validate_parameter_vector(values)
    samples = np.asarray(input_voltage, dtype=float)
    if samples.ndim != 1 or samples.size < 2 or not np.all(np.isfinite(samples)):
        raise ValueError("programme input must be a finite one-dimensional waveform")
    if input_sample_rate_hz <= 0 or simulation_sample_rate_hz < input_sample_rate_hz or reltol <= 0:
        raise ValueError("invalid programme simulation rates or tolerance")
    duration = (samples.size - 1) / input_sample_rate_hz
    step = 1.0 / simulation_sample_rate_hz
    lines = ["* Derived ngspice programme-audio adapter"]
    lines.extend(f".param X{index} = {parameters[f'X{index}']:.15g}" for index in range(1, 26))
    lines.extend((
        "V4 V_PP 0 {X24}",
        "V1 V_grid 0 {X25}",
        "Aprogramme %vd([V_in 0]) programme_source",
        f'.model programme_source filesource(file="{input_filename}" amploffset=[0] amplscale=[1] timeoffset=0 timescale=1 timerelative=false amplstep=false)',
        f".option reltol={reltol:.15g}",
        ".control",
        "set wr_vecnames",
        "set wr_singlescale",
        f"tran {step:.15g} {duration:.15g} 0 {step:.15g}",
        "wrdata sonya-programme.dat V(out) V(V_in)",
        "quit",
        ".endc",
    ))
    return "\n".join(lines) + "\n"


def render_ltspice_programme_parameter_file(
    values: dict[str, float],
    input_voltage: np.ndarray,
    input_sample_rate_hz: int,
    simulation_sample_rate_hz: int,
    reltol: float = 0.001,
    input_filename: str = "programme-input.wav",
) -> str:
    parameters = validate_parameter_vector(values)
    samples = np.asarray(input_voltage, dtype=float)
    if samples.ndim != 1 or samples.size < 2 or not np.all(np.isfinite(samples)):
        raise ValueError("programme input must be a finite one-dimensional waveform")
    if input_sample_rate_hz <= 0 or simulation_sample_rate_hz < input_sample_rate_hz or reltol <= 0:
        raise ValueError("invalid programme simulation rates or tolerance")
    duration = (samples.size - 1) / input_sample_rate_hz
    step = 1.0 / simulation_sample_rate_hz
    lines = ["* Derived LTspice programme-audio adapter"]
    lines.extend(f".param X{index} = {parameters[f'X{index}']:.15g}" for index in range(1, 26))
    lines.extend((
        "V4 V_PP 0 {X24}",
        "V1 V_grid 0 {X25}",
        f'V5 V_in 0 wavefile="{input_filename}" chan=0',
        ".save V(out) V(V_in)",
        f".options reltol={reltol:.15g} plotwinsize=0",
        f".tran 0 {duration:.15g} 0 {step:.15g}",
    ))
    return "\n".join(lines) + "\n"


def _write_programme_input(path: Path, input_voltage: np.ndarray, sample_rate_hz: int) -> Path:
    samples = np.asarray(input_voltage, dtype=float)
    if samples.ndim != 1 or samples.size < 2 or not np.all(np.isfinite(samples)) or sample_rate_hz <= 0:
        raise ValueError("programme input must be a finite one-dimensional waveform")
    with path.open("w", encoding="ascii") as stream:
        for index, value in enumerate(samples):
            stream.write(f"{index / sample_rate_hz:.12g} {value:.12g}\n")
    return path


def _write_ltspice_programme_wav(path: Path, input_voltage: np.ndarray, sample_rate_hz: int) -> Path:
    """Write the voltage waveform as the PCM WAV consumed by LTspice.

    LTspice maps full-scale PCM to +/-1 V for a ``wavefile`` voltage source.
    The declared programme levels therefore fit directly without a separate
    gain expression.  Quantizing once here is also representative of the
    audio source used by the final perceptual metrics.
    """

    samples = np.asarray(input_voltage, dtype=float)
    if samples.ndim != 1 or samples.size < 2 or not np.all(np.isfinite(samples)) or sample_rate_hz <= 0:
        raise ValueError("programme input must be a finite one-dimensional waveform")
    peak = float(np.max(np.abs(samples)))
    if peak > 1.0 + 1e-9:
        raise ValueError("LTspice WAV programme input exceeds the +/-1 V PCM range")
    pcm = np.rint(np.clip(samples, -1.0, 1.0) * np.iinfo(np.int16).max).astype(np.int16)
    wavfile.write(path, sample_rate_hz, pcm)
    return path


def _raw_trace(values: dict[str, np.ndarray], name: str) -> np.ndarray:
    selected = next((value for key, value in values.items() if key.lower() == name.lower()), None)
    if selected is None:
        raise RuntimeError(f"LTspice programme RAW is missing {name}")
    result = np.real(np.asarray(selected, dtype=float))
    if result.ndim != 1 or result.size < 2 or not np.all(np.isfinite(result)):
        raise RuntimeError(f"LTspice programme RAW contains invalid {name}")
    return result


def run_ngspice_programme(
    config: SonyaConfig,
    topology: TopologyManifest,
    parameters: dict[str, float],
    input_voltage: np.ndarray,
    input_sample_rate_hz: int,
    simulation_sample_rate_hz: int,
    output_root: str | Path,
    reltol: float = 0.001,
    timeout_seconds: float | None = None,
) -> dict[str, object]:
    from .simulators import NgspiceBackend

    backend = NgspiceBackend(config, topology)
    doctor = backend.doctor()
    if not doctor.ready or backend.executable is None:
        raise RuntimeError("ngspice is not ready")
    root = Path(output_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="ngspice-programme-", dir=root))
    input_path = _write_programme_input(work / "programme-input.txt", input_voltage, input_sample_rate_hz)
    parameter_path = work / "param"
    parameter_path.write_text(
        render_ngspice_programme_parameter_file(
            parameters, input_voltage, input_sample_rate_hz, simulation_sample_rate_hz, reltol
        ),
        encoding="ascii",
    )
    staged = stage_topology(topology, "ngspice", work / "run", parameter_path)
    staged_input = staged.working_directory / input_path.name
    staged_input.write_bytes(input_path.read_bytes())
    log_path = staged.circuit.with_suffix(".log")
    command = (str(backend.executable), "-b", "-o", str(log_path), staged.circuit.name)
    started = time.perf_counter()
    effective_timeout = timeout_seconds or max(float(config.raw["simulator"]["timeout_seconds"]), 600.0)
    try:
        completed = subprocess.run(
            command,
            cwd=staged.working_directory,
            capture_output=True,
            text=True,
            timeout=effective_timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        elapsed = time.perf_counter() - started
        timeout_record = {
            "status": "timed_out",
            "timeout_seconds": effective_timeout,
            "elapsed_seconds": elapsed,
            "command": list(command),
            "log": str(log_path),
        }
        (staged.working_directory / "programme-simulation-timeout.json").write_text(
            json.dumps(timeout_record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        raise RuntimeError(
            f"ngspice programme simulation exceeded {effective_timeout:g} s; inspect {log_path}"
        ) from exc
    elapsed = time.perf_counter() - started
    log_text = log_path.read_text(encoding="utf-8", errors="replace") if log_path.exists() else ""
    if completed.returncode != 0 or "simulation(s) aborted" in log_text.lower() or re.search(r"(?im)^\s*fatal\s+error", log_text):
        raise RuntimeError(f"ngspice programme simulation failed; inspect {log_path}")
    data_path = staged.working_directory / "sonya-programme.dat"
    _, data = read_wrdata(data_path)
    if data.shape[1] < 3:
        raise RuntimeError("ngspice programme export is incomplete")
    waveform_path = staged.working_directory / "waveforms.npz"
    np.savez_compressed(waveform_path, time=data[:, 0], output=data[:, 1], input=data[:, 2])
    provenance = write_provenance(
        staged.working_directory / "provenance.json",
        [*staged.inputs, config.source, input_path],
        "ngspice_programme_audio",
        {
            "backend": "ngspice",
            "backend_version": doctor.version,
            "topology": topology.id,
            "input_sample_rate_hz": input_sample_rate_hz,
            "simulation_sample_rate_hz": simulation_sample_rate_hz,
            "input_samples": int(np.asarray(input_voltage).size),
            "elapsed_seconds": elapsed,
            "command": list(command),
        },
    )
    record = {
        "backend": "ngspice",
        "input_adapter": "ngspice_filesource_text",
        "backend_version": doctor.version,
        "working_directory": str(staged.working_directory),
        "waveforms": str(waveform_path),
        "log": str(log_path),
        "provenance": str(provenance),
        "elapsed_seconds": elapsed,
        "input_sample_rate_hz": input_sample_rate_hz,
        "simulation_sample_rate_hz": simulation_sample_rate_hz,
        "input_samples": int(np.asarray(input_voltage).size),
        "output_samples": int(data.shape[0]),
        "data_bytes": data_path.stat().st_size,
    }
    (staged.working_directory / "programme-simulation.json").write_text(
        json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return {**record, "time": data[:, 0], "output": data[:, 1], "input": data[:, 2]}


def run_ltspice_programme(
    config: SonyaConfig,
    topology: TopologyManifest,
    parameters: dict[str, float],
    input_voltage: np.ndarray,
    input_sample_rate_hz: int,
    simulation_sample_rate_hz: int,
    output_root: str | Path,
    reltol: float = 0.001,
    timeout_seconds: float | None = None,
) -> dict[str, object]:
    runner = LTspiceRunner(config, topology)
    doctor = runner.doctor()
    if not doctor.ready:
        raise RuntimeError("LTspice is not ready")
    root = Path(output_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="ltspice-programme-", dir=root))
    input_path = _write_ltspice_programme_wav(
        work / "programme-input.wav", input_voltage, input_sample_rate_hz
    )
    parameter_path = work / "param"
    parameter_path.write_text(
        render_ltspice_programme_parameter_file(
            parameters, input_voltage, input_sample_rate_hz, simulation_sample_rate_hz, reltol
        ),
        encoding="ascii",
    )
    staged = stage_topology(topology, "ltspice", work / "run", parameter_path)
    staged_input = staged.working_directory / input_path.name
    staged_input.write_bytes(input_path.read_bytes())
    started = time.perf_counter()
    effective_timeout = timeout_seconds or max(float(config.raw["simulator"]["timeout_seconds"]), 600.0)
    try:
        completed = runner.run(staged.circuit, timeout_seconds=effective_timeout)
    except subprocess.TimeoutExpired as exc:
        elapsed = time.perf_counter() - started
        timeout_record = {
            "status": "timed_out",
            "timeout_seconds": effective_timeout,
            "elapsed_seconds": elapsed,
            "command": list(exc.cmd) if isinstance(exc.cmd, (list, tuple)) else str(exc.cmd),
            "log": str(staged.circuit.with_suffix(".log")),
        }
        (staged.working_directory / "programme-simulation-timeout.json").write_text(
            json.dumps(timeout_record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        raise RuntimeError(
            f"LTspice programme simulation exceeded {effective_timeout:g} s; inspect {staged.circuit.with_suffix('.log')}"
        ) from exc
    elapsed = time.perf_counter() - started
    raw_path = staged.circuit.with_suffix(".raw")
    if not raw_path.is_file():
        raise RuntimeError(f"LTspice programme simulation did not produce {raw_path}")
    raw = read_raw(raw_path)
    time_axis = _raw_trace(raw.values, "time")  # type: ignore[arg-type]
    output = _raw_trace(raw.values, "V(out)")  # type: ignore[arg-type]
    delivered_input = _raw_trace(raw.values, "V(V_in)")  # type: ignore[arg-type]
    waveform_path = staged.working_directory / "waveforms.npz"
    np.savez_compressed(waveform_path, time=time_axis, output=output, input=delivered_input)
    provenance = write_provenance(
        staged.working_directory / "provenance.json",
        [*staged.inputs, config.source, input_path],
        "ltspice_programme_audio",
        {
            "backend": "ltspice",
            "backend_version": doctor.bundle_version,
            "topology": topology.id,
            "input_sample_rate_hz": input_sample_rate_hz,
            "simulation_sample_rate_hz": simulation_sample_rate_hz,
            "input_samples": int(np.asarray(input_voltage).size),
            "elapsed_seconds": elapsed,
            "command": list(completed.command),
        },
    )
    record = {
        "backend": "ltspice",
        "input_adapter": "ltspice_wavefile_pcm16",
        "backend_version": doctor.bundle_version,
        "working_directory": str(staged.working_directory),
        "waveforms": str(waveform_path),
        "raw": str(raw_path),
        "log": str(completed.log_path) if completed.log_path else None,
        "provenance": str(provenance),
        "elapsed_seconds": elapsed,
        "input_sample_rate_hz": input_sample_rate_hz,
        "simulation_sample_rate_hz": simulation_sample_rate_hz,
        "input_samples": int(np.asarray(input_voltage).size),
        "output_samples": int(time_axis.size),
        "data_bytes": raw_path.stat().st_size,
    }
    (staged.working_directory / "programme-simulation.json").write_text(
        json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return {**record, "time": time_axis, "output": output, "input": delivered_input}


def run_programme(
    backend_id: str,
    config: SonyaConfig,
    topology: TopologyManifest,
    parameters: dict[str, float],
    input_voltage: np.ndarray,
    input_sample_rate_hz: int,
    simulation_sample_rate_hz: int,
    output_root: str | Path,
    reltol: float = 0.001,
    timeout_seconds: float | None = None,
) -> dict[str, object]:
    runners = {"ngspice": run_ngspice_programme, "ltspice": run_ltspice_programme}
    try:
        runner = runners[backend_id]
    except KeyError as exc:
        raise ValueError(f"programme audio is not implemented for simulator {backend_id!r}") from exc
    return runner(
        config,
        topology,
        parameters,
        input_voltage,
        input_sample_rate_hz,
        simulation_sample_rate_hz,
        output_root,
        reltol=reltol,
        timeout_seconds=timeout_seconds,
    )
