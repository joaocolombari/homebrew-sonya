from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from typing import Literal

import yaml


class TopologyError(ValueError):
    pass


BackendStatus = Literal["validated", "experimental", "planned"]


@dataclass(frozen=True)
class ModelDependency:
    source: Path
    target: str


@dataclass(frozen=True)
class TopologyParameter:
    id: str
    name: str
    unit: str
    minimum: float
    maximum: float
    baseline: float


@dataclass(frozen=True)
class TopologyObjective:
    analysis: Literal["op"]
    expression: str
    goal: Literal["minimize", "maximize", "target"]
    target: float | None


@dataclass(frozen=True)
class TopologyBackend:
    status: BackendStatus
    dependencies: tuple[ModelDependency, ...]
    include_map: dict[str, str]


@dataclass(frozen=True)
class TopologyManifest:
    source: Path
    id: str
    name: str
    description: str
    circuit: Path
    diagram: Path | None
    diagram_caption: str | None
    parameter_file: str | None
    parameter_ids: tuple[str, ...]
    parameters: tuple[TopologyParameter, ...]
    objective: TopologyObjective | None
    analyses: tuple[str, ...]
    transforms: tuple[str, ...]
    backends: dict[str, TopologyBackend]


@dataclass(frozen=True)
class StagedTopology:
    topology_id: str
    backend: str
    working_directory: Path
    circuit: Path
    manifest: Path
    changes: tuple[str, ...]
    inputs: tuple[Path, ...]


@dataclass(frozen=True)
class TopologyExecution:
    topology_id: str
    backend: str
    executable: Path
    command: tuple[str, ...]
    return_code: int
    working_directory: Path
    circuit: Path
    log: Path
    passed: bool


_TRANSFORMS = {"drop_backanno", "unwrap_int_parameters"}


def _safe_target(value: object) -> str:
    target = str(value)
    if not target or Path(target).name != target or target in {".", ".."}:
        raise TopologyError(f"dependency target must be a plain filename: {target!r}")
    return target


def _resolve(source: Path, value: object) -> Path:
    path = Path(str(value)).expanduser()
    return path.resolve() if path.is_absolute() else (source.parent / path).resolve()


def load_topology_manifest(path: str | Path) -> TopologyManifest:
    source = Path(path).expanduser().resolve()
    try:
        raw = yaml.safe_load(source.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise TopologyError(f"cannot read topology manifest {source}: {exc}") from exc
    if not isinstance(raw, dict) or raw.get("schema_version") != 1:
        raise TopologyError("topology manifest must use schema_version 1")
    for field in ("id", "name", "circuit", "backends"):
        if field not in raw:
            raise TopologyError(f"topology manifest is missing {field!r}")
    topology_id = str(raw["id"])
    if not re.fullmatch(r"[a-z][a-z0-9_-]*", topology_id):
        raise TopologyError("topology id must start with a lowercase letter and contain only a-z, 0-9, _ or -")
    circuit = _resolve(source, raw["circuit"])
    diagram = _resolve(source, raw["diagram"]) if raw.get("diagram") else None
    parameter_file = _safe_target(raw["parameter_file"]) if raw.get("parameter_file") else None
    parameters_raw = raw.get("parameters", [])
    if not isinstance(parameters_raw, list):
        raise TopologyError("parameters must be a list")
    parameters: list[TopologyParameter] = []
    for item in parameters_raw:
        if not isinstance(item, dict) or not {"id", "name", "unit", "minimum", "maximum", "baseline"} <= item.keys():
            raise TopologyError("each topology parameter requires id, name, unit, minimum, maximum and baseline")
        parameter = TopologyParameter(
            str(item["id"]),
            str(item["name"]),
            str(item["unit"]),
            float(item["minimum"]),
            float(item["maximum"]),
            float(item["baseline"]),
        )
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", parameter.id):
            raise TopologyError(f"invalid topology parameter id: {parameter.id}")
        if not parameter.minimum <= parameter.baseline <= parameter.maximum:
            raise TopologyError(f"baseline for {parameter.id} is outside its bounds")
        parameters.append(parameter)
    parameter_ids = tuple(str(item) for item in raw.get("parameter_ids", [])) or tuple(item.id for item in parameters)
    if len(set(parameter_ids)) != len(parameter_ids):
        raise TopologyError("parameter_ids must be unique")
    if parameters and parameter_ids != tuple(item.id for item in parameters):
        raise TopologyError("parameter_ids and parameters must declare the same ids in the same order")
    optimization_raw = raw.get("optimization")
    objective: TopologyObjective | None = None
    if optimization_raw is not None:
        if not isinstance(optimization_raw, dict):
            raise TopologyError("optimization must be a mapping")
        analysis = str(optimization_raw.get("analysis", ""))
        expression = str(optimization_raw.get("expression", ""))
        goal = str(optimization_raw.get("goal", ""))
        if analysis != "op" or goal not in {"minimize", "maximize", "target"} or not expression or "\n" in expression:
            raise TopologyError("optimization requires analysis=op, one-line expression and goal minimize, maximize or target")
        target_value = optimization_raw.get("target")
        if goal == "target" and target_value is None:
            raise TopologyError("target optimization requires a target value")
        objective = TopologyObjective(analysis, expression, goal, float(target_value) if target_value is not None else None)  # type: ignore[arg-type]
        if not parameters or parameter_file is None:
            raise TopologyError("generic optimization requires parameters and parameter_file")
    transforms = tuple(str(item) for item in raw.get("transforms", []))
    unknown_transforms = set(transforms) - _TRANSFORMS
    if unknown_transforms:
        raise TopologyError(f"unknown topology transforms: {', '.join(sorted(unknown_transforms))}")
    backends_raw = raw["backends"]
    if not isinstance(backends_raw, dict) or not backends_raw:
        raise TopologyError("backends must be a non-empty mapping")
    backends: dict[str, TopologyBackend] = {}
    for backend_id, backend_raw in backends_raw.items():
        if not isinstance(backend_raw, dict):
            raise TopologyError(f"backend {backend_id!r} must be a mapping")
        status = str(backend_raw.get("status", "planned"))
        if status not in {"validated", "experimental", "planned"}:
            raise TopologyError(f"invalid status for backend {backend_id!r}: {status}")
        dependencies_raw = backend_raw.get("dependencies", [])
        if not isinstance(dependencies_raw, list):
            raise TopologyError(f"backend {backend_id!r} dependencies must be a list")
        dependencies: list[ModelDependency] = []
        targets: set[str] = set()
        for item in dependencies_raw:
            if not isinstance(item, dict) or "source" not in item:
                raise TopologyError(f"each {backend_id} dependency requires source")
            dependency_source = _resolve(source, item["source"])
            target = _safe_target(item.get("target", dependency_source.name))
            if target.lower() in targets:
                raise TopologyError(f"duplicate dependency target for {backend_id}: {target}")
            targets.add(target.lower())
            dependencies.append(ModelDependency(dependency_source, target))
        include_map_raw = backend_raw.get("include_map", {})
        if not isinstance(include_map_raw, dict):
            raise TopologyError(f"backend {backend_id!r} include_map must be a mapping")
        include_map = {Path(str(key)).name.lower(): _safe_target(value) for key, value in include_map_raw.items()}
        missing_targets = {target for target in include_map.values() if target.lower() not in targets}
        if missing_targets:
            raise TopologyError(f"include_map for {backend_id} references unstaged files: {', '.join(sorted(missing_targets))}")
        backends[str(backend_id)] = TopologyBackend(status, tuple(dependencies), include_map)  # type: ignore[arg-type]
    manifest = TopologyManifest(
        source=source,
        id=topology_id,
        name=str(raw["name"]),
        description=str(raw.get("description", "")),
        circuit=circuit,
        diagram=diagram,
        diagram_caption=str(raw["diagram_caption"]) if raw.get("diagram_caption") else None,
        parameter_file=parameter_file,
        parameter_ids=parameter_ids,
        parameters=tuple(parameters),
        objective=objective,
        analyses=tuple(str(item) for item in raw.get("analyses", [])),
        transforms=transforms,
        backends=backends,
    )
    validate_topology_manifest(manifest)
    return manifest


def validate_topology_manifest(manifest: TopologyManifest) -> None:
    if not manifest.circuit.is_file():
        raise TopologyError(f"circuit does not exist: {manifest.circuit}")
    if manifest.diagram is not None:
        if not manifest.diagram.is_file():
            raise TopologyError(f"circuit diagram does not exist: {manifest.diagram}")
        if manifest.diagram.suffix.lower() not in {".png", ".jpg", ".jpeg", ".svg", ".webp"}:
            raise TopologyError("circuit diagram must be PNG, JPEG, SVG or WebP")
    for backend_id, backend in manifest.backends.items():
        for dependency in backend.dependencies:
            if not dependency.source.is_file():
                raise TopologyError(f"dependency for {backend_id} does not exist: {dependency.source}")


def _translate_netlist(text: str, manifest: TopologyManifest, backend_id: str) -> tuple[str, tuple[str, ...]]:
    backend = manifest.backends[backend_id]
    changes: list[str] = []
    target_by_source = {item.source.name.lower(): item.target for item in backend.dependencies}
    include_map = {**target_by_source, **backend.include_map}
    include_pattern = re.compile(r"(?im)^(\s*\.(?:include|lib)\s+)(?:\"([^\"]+)\"|'([^']+)'|(\S+))(\s*)$")

    def replace_include(match: re.Match[str]) -> str:
        original = match.group(2) or match.group(3) or match.group(4) or ""
        replacement = include_map.get(Path(original.replace("\\", "/")).name.lower())
        if replacement is None:
            return match.group(0)
        prefix = match.group(1)
        if backend_id == "ngspice" and re.search(r"\.lib\s+$", prefix, re.IGNORECASE):
            prefix = re.sub(r"\.lib", ".include", prefix, flags=re.IGNORECASE)
            changes.append(f"translated .lib for {original!r} to ngspice .include")
        if original != replacement:
            changes.append(f"mapped include {original!r} to staged file {replacement!r}")
        return f"{prefix}{replacement}{match.group(5)}"

    text = include_pattern.sub(replace_include, text)
    if "drop_backanno" in manifest.transforms and re.search(r"(?im)^\s*\.backanno\s*$", text):
        text = re.sub(r"(?im)^\s*\.backanno\s*\n?", "", text)
        changes.append("removed LTspice .backanno directive")
    if "unwrap_int_parameters" in manifest.transforms:
        pattern = r"\{int\(([A-Za-z_]\w*)\)(?=\s*[*+/\-}])"
        if re.search(pattern, text, flags=re.IGNORECASE):
            text = re.sub(pattern, r"{\1", text, flags=re.IGNORECASE)
            changes.append("removed int() wrappers from component parameter expressions")
    if not text.endswith("\n"):
        text += "\n"
    return text, tuple(dict.fromkeys(changes))


def _looks_encrypted(path: Path) -> bool:
    prefix = path.read_bytes()[:512].decode("ascii", errors="ignore").lower()
    return "encrypted file" in prefix and "begin:" in prefix


def _read_simulator_log(path: Path) -> str:
    if not path.exists():
        return ""
    payload = path.read_bytes()
    if payload.startswith((b"\xff\xfe", b"\xfe\xff")) or (payload and payload.count(b"\x00") / len(payload) > 0.1):
        return payload.decode("utf-16", errors="replace")
    return payload.decode("utf-8-sig", errors="replace")


def stage_topology(
    manifest: TopologyManifest,
    backend_id: str,
    destination: str | Path,
    parameter_file: str | Path | None = None,
) -> StagedTopology:
    if backend_id not in manifest.backends:
        raise TopologyError(f"topology {manifest.id!r} has no backend {backend_id!r}")
    backend = manifest.backends[backend_id]
    if backend.status == "planned":
        raise TopologyError(f"backend {backend_id!r} is only planned for topology {manifest.id!r}")
    target = Path(destination).expanduser().resolve()
    target.mkdir(parents=True, exist_ok=False)
    inputs: list[Path] = [manifest.source, manifest.circuit]
    for dependency in backend.dependencies:
        if backend_id == "ngspice" and _looks_encrypted(dependency.source):
            raise TopologyError(f"ngspice cannot use encrypted dependency: {dependency.source}")
        shutil.copy2(dependency.source, target / dependency.target)
        inputs.append(dependency.source)
    selected_parameter_file = Path(parameter_file).expanduser().resolve() if parameter_file is not None else None
    if selected_parameter_file is None and manifest.parameter_file is not None:
        default_parameters = manifest.source.parent / manifest.parameter_file
        selected_parameter_file = default_parameters.resolve() if default_parameters.is_file() else None
    if selected_parameter_file is not None:
        if manifest.parameter_file is None:
            raise TopologyError(f"topology {manifest.id!r} does not declare parameter_file")
        parameters = selected_parameter_file
        if not parameters.is_file():
            raise TopologyError(f"parameter file does not exist: {parameters}")
        shutil.copy2(parameters, target / manifest.parameter_file)
        inputs.append(parameters)
    translated, changes = _translate_netlist(manifest.circuit.read_text(encoding="utf-8", errors="replace"), manifest, backend_id)
    staged_circuit = target / manifest.circuit.name
    staged_circuit.write_text(translated, encoding="utf-8")
    staging_manifest = target / "translation.json"
    staging_manifest.write_text(
        json.dumps(
            {
                "topology": manifest.id,
                "backend": backend_id,
                "source_manifest": str(manifest.source),
                "source_circuit": str(manifest.circuit),
                "staged_circuit": str(staged_circuit),
                "changes": list(changes),
                "inputs": [
                    {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                    for path in inputs
                ],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    return StagedTopology(manifest.id, backend_id, target, staged_circuit, staging_manifest, changes, tuple(inputs))


def topology_record(manifest: TopologyManifest) -> dict[str, object]:
    return {
        "id": manifest.id,
        "name": manifest.name,
        "description": manifest.description,
        "manifest": str(manifest.source),
        "circuit": str(manifest.circuit),
        "diagram": str(manifest.diagram) if manifest.diagram else None,
        "diagram_caption": manifest.diagram_caption,
        "parameter_file": manifest.parameter_file,
        "parameter_ids": list(manifest.parameter_ids),
        "parameter_count": len(manifest.parameter_ids),
        "parameters": [asdict(item) for item in manifest.parameters],
        "optimization": asdict(manifest.objective) if manifest.objective else None,
        "analyses": list(manifest.analyses),
        "backends": {
            backend_id: {
                "status": backend.status,
                "dependencies": [asdict(item) for item in backend.dependencies],
            }
            for backend_id, backend in manifest.backends.items()
        },
    }


def create_topology_scaffold(topology_id: str, directory: str | Path) -> tuple[Path, Path]:
    if not re.fullmatch(r"[a-z][a-z0-9_-]*", topology_id):
        raise TopologyError("topology id must start with a lowercase letter and contain only a-z, 0-9, _ or -")
    target = Path(directory).expanduser().resolve()
    target.mkdir(parents=True, exist_ok=False)
    circuit = target / "circuit.cir"
    circuit.write_text(
        f"* {topology_id} portable SPICE circuit\n"
        "* Replace this divider with the circuit to optimize.\n"
        ".include parameters.inc\n"
        "V1 in 0 DC 1\n"
        "R1 in out {R_TOP}\n"
        "R2 out 0 {R_BOTTOM}\n"
        ".op\n"
        ".end\n",
        encoding="utf-8",
    )
    manifest = target / "topology.yaml"
    (target / "parameters.inc").write_text(".param R_TOP=1000\n.param R_BOTTOM=1000\n", encoding="ascii")
    manifest.write_text(
        "schema_version: 1\n"
        f"id: {topology_id}\n"
        f"name: {topology_id.replace('_', ' ').title()}\n"
        "description: Portable topology created by sonya topology init.\n"
        "circuit: circuit.cir\n"
        "parameter_file: parameters.inc\n"
        "parameters:\n"
        "  - {id: R_TOP, name: Top resistor, unit: ohm, minimum: 100, maximum: 10000, baseline: 1000}\n"
        "  - {id: R_BOTTOM, name: Bottom resistor, unit: ohm, minimum: 100, maximum: 10000, baseline: 1000}\n"
        "analyses: [op]\n"
        "transforms: [drop_backanno, unwrap_int_parameters]\n"
        "optimization:\n"
        "  analysis: op\n"
        "  expression: V(out)\n"
        "  goal: target\n"
        "  target: 0.5\n"
        "backends:\n"
        "  ltspice:\n"
        "    status: experimental\n"
        "    dependencies: []\n"
        "  ngspice:\n"
        "    status: experimental\n"
        "    dependencies: []\n",
        encoding="utf-8",
    )
    return manifest, circuit


def _discover_executable(backend_id: str) -> Path | None:
    if backend_id == "ngspice":
        candidate = os.environ.get("SONYA_NGSPICE") or shutil.which("ngspice")
    elif backend_id == "ltspice":
        candidate = os.environ.get("SONYA_LTSPICE") or shutil.which("ltspice") or shutil.which("LTspice")
        if not candidate:
            macos = Path("/Applications/LTspice.app/Contents/MacOS/LTspice")
            candidate = str(macos) if macos.is_file() else None
    else:
        raise TopologyError(f"unsupported simulator backend: {backend_id}")
    return Path(candidate).expanduser().resolve() if candidate else None


def execute_staged_topology(
    staged: StagedTopology,
    executable: str | Path | None = None,
    timeout_seconds: float = 30.0,
) -> TopologyExecution:
    selected = Path(executable).expanduser().resolve() if executable else _discover_executable(staged.backend)
    if selected is None or not selected.is_file():
        env_name = "SONYA_NGSPICE" if staged.backend == "ngspice" else "SONYA_LTSPICE"
        raise TopologyError(f"{staged.backend} executable not found; install it or set {env_name}")
    log = staged.circuit.with_suffix(".log")
    if staged.backend == "ngspice":
        command = (str(selected), "-b", "-o", str(log), staged.circuit.name)
    else:
        command = (str(selected), "-b", staged.circuit.name)
    completed = subprocess.run(
        command,
        cwd=staged.working_directory,
        capture_output=True,
        text=True,
        timeout=timeout_seconds,
        check=False,
    )
    log_text = _read_simulator_log(log)
    failed = completed.returncode != 0 or bool(re.search(r"(?im)^\s*(?:fatal\s+)?error\s*:", log_text))
    return TopologyExecution(
        staged.topology_id,
        staged.backend,
        selected,
        command,
        completed.returncode,
        staged.working_directory,
        staged.circuit,
        log,
        not failed,
    )
