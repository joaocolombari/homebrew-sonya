from __future__ import annotations

from collections.abc import Mapping
import math
from pathlib import Path
import re


LEGACY_FREQUENCIES_HZ = (20, 30, 40, 50.05, 70, 100, 200, 500, 700, 1000, 2000, 2122, 5000, 7000, 10000, 20000)
MODES = ("op", "tran", "ac", "slew", "gedlee", "crowe")


def validate_parameter_vector(values: Mapping[str, float]) -> dict[str, float]:
    expected = {f"X{index}" for index in range(1, 26)}
    missing = expected - values.keys()
    if missing:
        raise ValueError(f"missing circuit parameters: {', '.join(sorted(missing))}")
    clean = {name: float(values[name]) for name in expected}
    if not all(math.isfinite(value) for value in clean.values()):
        raise ValueError("circuit parameters must be finite")
    return clean


def render_legacy_parameter_file(
    values: Mapping[str, float],
    mode: str,
    reltol: float = 0.001,
    input_rms_v: float = 10.0 ** (-10.0 / 20.0),
    crowe_timestep_s: float = 2.5e-7,
) -> str:
    """Render the legacy paramAC modes without modifying the MATLAB file."""
    if mode not in MODES:
        raise ValueError(f"mode must be one of: {', '.join(MODES)}")
    if reltol <= 0 or input_rms_v <= 0 or crowe_timestep_s <= 0 or not math.isfinite(input_rms_v):
        raise ValueError("reltol, input_rms_v and crowe_timestep_s must be positive")
    parameters = validate_parameter_vector(values)
    input_peak_v = input_rms_v * math.sqrt(2.0)
    lines = [
        "***************************************",
        "*** GAGABIRO VALVE POWER AMPLIFIER ***",
        "*** Python migration: derived file  ***",
        "***************************************",
        "",
        "* RESISTORS",
    ]
    lines.extend(f".param X{index} = {parameters[f'X{index}']:.15g}" for index in range(1, 19))
    lines.extend(("", "* CAPACITORS"))
    lines.extend(f".param X{index} = {parameters[f'X{index}']:.15g}" for index in range(19, 24))
    lines.extend(("", "* VOLTAGE SOURCES"))
    lines.extend(f".param X{index} = {parameters[f'X{index}']:.15g}" for index in range(24, 26))

    if mode in {"op", "tran", "ac", "crowe"}:
        source = [
            "V4 V_PP 0 {int(X24)}",
            f"V5 V_in 0 SINE(0 {input_peak_v:.15g} 1k) AC 1" if mode != "op" else "V5 V_in 0 0",
            "V1 V_grid 0 {int(X25)}",
        ]
    elif mode == "slew":
        source = [
            "V4 V_PP 0 {int(X24)}",
            f"V5 V_in 0 PULSE(-{input_peak_v:.15g} {input_peak_v:.15g} 0 100n 100n 1m 2m) AC 1",
            "V1 V_grid 0 {int(X25)}",
        ]
    else:
        source = [
            "V2 V_PP 0 {int(X24)}",
            "V6 V_grid 0 {int(X25)}",
            "B1 V_in 0 V=v(amp)*sin(2*pi*1000*time)",
            # Removing braces is the macOS portability correction: time is a runtime variable.
            "B2 amp 0 V=10m*ceil(time*500)-10m",
            "B3 tref 0 V=1*time",
        ]
    lines.extend(("", "* SOURCES", *source, "", "* COMMANDS", f".option reltol={reltol:.15g}"))

    if mode == "op":
        lines.extend((
            ".op",
            ".meas op vaa_v PARAM V(V_PP)",
            ".meas op bias_supply_current_a PARAM abs(I(V1))",
            ".meas op bplus_supply_current_a PARAM abs(I(V4))",
            ".meas op bplus_input_power_w PARAM -V(V_PP)*I(V4)",
            ".meas op el84a_plate_v PARAM V(N001)",
            ".meas op el84b_plate_v PARAM V(N018)",
            ".meas op el84a_grid_v PARAM V(N005)",
            ".meas op el84b_grid_v PARAM V(N016)",
            ".meas op el84a_plate_current_a PARAM abs(Ix(U2:P))",
            ".meas op el84b_plate_current_a PARAM abs(Ix(U3:P))",
            ".meas op el84a_screen_current_a PARAM abs(Ix(U2:G2))",
            ".meas op el84b_screen_current_a PARAM abs(Ix(U3:G2))",
            ".meas op el84a_plate_dissipation_w PARAM V(N001)*abs(Ix(U2:P))",
            ".meas op el84b_plate_dissipation_w PARAM V(N018)*abs(Ix(U3:P))",
            ".meas op mje340_q1_vce_v PARAM V(N013,N023)",
            ".meas op mje340_q2_vce_v PARAM V(N021)",
            ".meas op mje340_q1_collector_current_a PARAM abs(Ic(Q1))",
            ".meas op mje340_q2_collector_current_a PARAM abs(Ic(Q2))",
            ".meas op mje340_q1_dissipation_w PARAM V(N013,N023)*abs(Ic(Q1))",
            ".meas op mje340_q2_dissipation_w PARAM V(N021)*abs(Ic(Q2))",
        ))
    elif mode == "tran":
        lines.extend((
            ".OPTIONS numdgt=15",
            ".OPTIONS plotwinsize=0",
            ".four 1k 10 V(out)",
            ".tran 0 100m 0 5u",
            ".probe v(out) i(Rload) v(v_in)",
            ".meas tran output_power AVG -I(RLoad)*v(out)",
            ".meas TRAN Vout_rms RMS V(out)",
            ".meas TRAN Vin_rms RMS V(v_in)",
            ".meas TRAN Gain_rms PARAM Vout_rms/Vin_rms",
        ))
    elif mode == "crowe":
        lines.extend((
            ".OPTIONS numdgt=15",
            ".OPTIONS plotwinsize=0",
            f".tran 0 100m 0 {crowe_timestep_s:.15g}",
            ".probe v(out) v(v_in)",
        ))
    elif mode == "ac":
        lines.extend((
            ".ac dec 100 0.01 100meg",
            ".probe v(out)",
            ".meas gmax max(mag(V(out)))",
            ".meas AC fchi FROM 0 TARG mag(V(out))=gmax/sqrt(2) FALL=1",
            ".meas AC fclo FROM 0 TARG mag(V(out))=gmax/sqrt(2) RISE=1",
        ))
        for frequency in LEGACY_FREQUENCIES_HZ:
            lines.append(f".meas AC f{round(frequency)}hz find v(out) at={frequency:g}")
    elif mode == "slew":
        lines.extend((
            ".tran 0 0.2 0.19 1u",
            ".probe v(out)",
            ".MEASURE TRAN MAXSLEW MAX V(OUT)",
            ".MEASURE TRAN MINSLEW MIN V(OUT)",
            ".MEASURE TRAN SLEW DERIV V(OUT) WHEN V(OUT)=(MAXSLEW+MINSLEW)/2",
        ))
    else:
        lines.extend((".OPTIONS plotwinsize=0", ".tran 0 0.202 0 2u", ".probe v(out)"))
        for index in range(101):
            start_ms, stop_ms = (1, 2) if index == 0 else (2 * index, 2 * (index + 1))
            lines.extend((
                f".MEAS TRAN MIN{index} MIN V(out) FROM={start_ms}m TO={stop_ms}m",
                f".MEAS TRAN MAX{index} MAX V(out) FROM={start_ms}m TO={stop_ms}m",
            ))
    return "\n".join(lines) + "\n"


def normalise_legacy_netlist(text: str) -> tuple[str, tuple[str, ...]]:
    """Apply only documented portability fixes to a derived netlist copy."""
    changes: list[str] = []
    windows_pattern = r"(?im)^\.lib\s+[A-Za-z]:\\.*?standard\.bjt\s*$"
    if re.search(windows_pattern, text):
        text = re.sub(windows_pattern, ".lib standard.bjt", text)
        changes.append("replaced absolute Windows standard.bjt path with staged local file")
    integer_parameter_pattern = r"\{int\((X(?:[1-9]|1[0-9]|2[0-3]))\)\*"
    if re.search(integer_parameter_pattern, text, flags=re.IGNORECASE):
        text = re.sub(integer_parameter_pattern, r"{\1*", text, flags=re.IGNORECASE)
        changes.append("removed legacy int() wrappers from derived component parameters")
    if not text.endswith("\n"):
        text += "\n"
    return text, tuple(changes)


def write_parameter_file(
    path: str | Path,
    values: Mapping[str, float],
    mode: str,
    reltol: float = 0.001,
    input_rms_v: float = 10.0 ** (-10.0 / 20.0),
    crowe_timestep_s: float = 2.5e-7,
) -> Path:
    target = Path(path)
    target.write_text(render_legacy_parameter_file(values, mode, reltol, input_rms_v, crowe_timestep_s), encoding="ascii")
    return target


def render_ngspice_legacy_parameter_file(
    values: Mapping[str, float],
    mode: str,
    reltol: float = 0.001,
    input_rms_v: float = 10.0 ** (-10.0 / 20.0),
    crowe_timestep_s: float = 2.5e-7,
) -> str:
    """Render the legacy analysis using ngspice control commands and portable data files."""
    if mode not in MODES:
        raise ValueError(f"mode must be one of: {', '.join(MODES)}")
    if reltol <= 0 or input_rms_v <= 0 or crowe_timestep_s <= 0 or not math.isfinite(input_rms_v):
        raise ValueError("reltol, input_rms_v and crowe_timestep_s must be positive")
    parameters = validate_parameter_vector(values)
    input_peak_v = input_rms_v * math.sqrt(2.0)
    lines = ["* Derived ngspice analysis adapter for the legacy Gagabiro topology"]
    lines.extend(f".param X{index} = {parameters[f'X{index}']:.15g}" for index in range(1, 26))
    if mode in {"op", "tran", "ac", "crowe"}:
        lines.extend((
            "V4 V_PP 0 {X24}",
            f"V5 V_in 0 SINE(0 {input_peak_v:.15g} 1k) AC 1" if mode != "op" else "V5 V_in 0 0",
            "V1 V_grid 0 {X25}",
        ))
    elif mode == "slew":
        lines.extend((
            "V4 V_PP 0 {X24}",
            f"V5 V_in 0 PULSE(-{input_peak_v:.15g} {input_peak_v:.15g} 0 100n 100n 1m 2m) AC 1",
            "V1 V_grid 0 {X25}",
        ))
    else:
        lines.extend((
            "V2 V_PP 0 {X24}",
            "V6 V_grid 0 {X25}",
            "B1 V_in 0 V=V(amp)*SIN(2*PI*1000*TIME)",
            "B2 amp 0 V=10m*CEIL(TIME*500)-10m",
            "B3 tref 0 V=TIME",
        ))
    lines.extend((f".option reltol={reltol:.15g}", ".control", "set wr_vecnames", "set wr_singlescale"))
    if mode == "op":
        lines.extend((
            "op",
            "wrdata sonya-op.dat V(V_PP) I(V4) V(N001) V(N018) V(N005) V(N016) @g.xu2.gplate[i] @g.xu3.gplate[i] @g.xu2.gg2[i] @g.xu3.gg2[i] V(N013,N023) V(N021) @q1[ic] @q2[ic]",
        ))
    elif mode == "tran":
        lines.extend(("tran 5u 100m 0 5u", "wrdata sonya-tran.dat V(out) V(V_in)", "fourier 1k V(out)"))
    elif mode == "crowe":
        lines.extend((
            f"tran {crowe_timestep_s:.15g} 100m 0 {crowe_timestep_s:.15g}",
            "wrdata sonya-crowe.dat V(out) V(V_in)",
        ))
    elif mode == "ac":
        lines.extend(("ac dec 100 0.01 100meg", "wrdata sonya-ac.dat DB(V(out))"))
    elif mode == "slew":
        lines.extend(("tran 1u 200m 190m 1u", "wrdata sonya-slew.dat V(out)"))
    else:
        lines.extend(("tran 2u 202m 0 2u", "wrdata sonya-gedlee.dat V(out)"))
    lines.extend(("quit", ".endc"))
    return "\n".join(lines) + "\n"


def write_ngspice_legacy_parameter_file(
    path: str | Path,
    values: Mapping[str, float],
    mode: str,
    reltol: float = 0.001,
    input_rms_v: float = 10.0 ** (-10.0 / 20.0),
    crowe_timestep_s: float = 2.5e-7,
) -> Path:
    target = Path(path)
    target.write_text(render_ngspice_legacy_parameter_file(values, mode, reltol, input_rms_v, crowe_timestep_s), encoding="ascii")
    return target
