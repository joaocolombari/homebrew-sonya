from __future__ import annotations

from dataclasses import dataclass

from .config import ParameterSpec


@dataclass(frozen=True)
class CircuitParameters:
    values: dict[str, float]
    specs: tuple[ParameterSpec, ...]

    def validate_bounds(self) -> list[str]:
        violations: list[str] = []
        for spec in self.specs:
            value = self.values.get(spec.id)
            if value is None:
                violations.append(f"{spec.id} is missing")
            elif not spec.minimum <= value <= spec.maximum:
                violations.append(f"{spec.id}={value:g} {spec.unit} is outside [{spec.minimum:g}, {spec.maximum:g}]")
        return violations

    def with_symmetry(self, groups: list[list[str]]) -> "CircuitParameters":
        values = dict(self.values)
        for group in groups:
            if not group or any(item not in values for item in group):
                continue
            shared = values[group[0]]
            for item in group[1:]:
                values[item] = shared
        return CircuitParameters(values, self.specs)

