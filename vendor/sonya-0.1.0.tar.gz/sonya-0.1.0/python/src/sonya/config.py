from __future__ import annotations

from dataclasses import dataclass
import math
import os
from pathlib import Path
import re
import shutil
from typing import Any

import yaml


class ConfigError(ValueError):
    """Raised when a configuration does not satisfy the Sonya schema."""


@dataclass(frozen=True)
class ParameterSpec:
    id: str
    name: str
    unit: str
    minimum: float
    maximum: float
    baseline: float


@dataclass(frozen=True)
class SonyaConfig:
    source: Path
    raw: dict[str, Any]
    parameters: tuple[ParameterSpec, ...]

    def resolve(self, value: str) -> Path:
        path = Path(value).expanduser()
        return path.resolve() if path.is_absolute() else (self.source.parent / path).resolve()

    @property
    def simulator_executable(self) -> Path:
        configured = str(self.raw["simulator"].get("executable", "auto"))
        if configured != "auto":
            return self.resolve(configured)
        override = os.environ.get("SONYA_LTSPICE")
        if override:
            return Path(override).expanduser().resolve()
        discovered = shutil.which("ltspice") or shutil.which("LTspice")
        if discovered:
            return Path(discovered).resolve()
        return Path("/Applications/LTspice.app/Contents/MacOS/LTspice")

    @property
    def processed_root(self) -> Path:
        return self.resolve(self.raw["data"]["processed_root"])

    @property
    def topology_manifest_paths(self) -> tuple[Path, ...]:
        return tuple(self.resolve(item) for item in self.raw["topologies"]["manifests"])

    @property
    def default_topology_id(self) -> str:
        return str(self.raw["topologies"]["default"])


_TOP_LEVEL = {
    "schema_version",
    "project",
    "topologies",
    "data",
    "simulator",
    "legacy_evaluation",
    "parameters",
    "future_methodology",
}


def _require_mapping(parent: dict[str, Any], key: str) -> dict[str, Any]:
    value = parent.get(key)
    if not isinstance(value, dict):
        raise ConfigError(f"{key!r} must be a mapping")
    return value


def _require_keys(mapping: dict[str, Any], label: str, keys: set[str]) -> None:
    missing = keys - mapping.keys()
    if missing:
        raise ConfigError(f"{label} is missing: {', '.join(sorted(missing))}")


def load_config(path: str | Path) -> SonyaConfig:
    source = Path(path).expanduser().resolve()
    try:
        document = yaml.safe_load(source.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise ConfigError(f"cannot read YAML config {source}: {exc}") from exc
    if not isinstance(document, dict):
        raise ConfigError("configuration root must be a mapping")
    unknown = document.keys() - _TOP_LEVEL
    missing = _TOP_LEVEL - document.keys()
    if unknown:
        raise ConfigError(f"unknown top-level fields: {', '.join(sorted(unknown))}")
    if missing:
        raise ConfigError(f"missing top-level fields: {', '.join(sorted(missing))}")
    if document["schema_version"] != 1:
        raise ConfigError("only schema_version 1 is supported")

    project = _require_mapping(document, "project")
    topologies = _require_mapping(document, "topologies")
    data = _require_mapping(document, "data")
    simulator = _require_mapping(document, "simulator")
    legacy = _require_mapping(document, "legacy_evaluation")
    future = _require_mapping(document, "future_methodology")
    _require_keys(project, "project", {"name", "legacy_root"})
    _require_keys(topologies, "topologies", {"default", "manifests"})
    _require_keys(data, "data", {"raw_roots", "processed_root"})
    _require_keys(simulator, "simulator", {"executable", "batch_arguments", "timeout_seconds"})
    _require_keys(legacy, "legacy_evaluation", {"input_rms_v", "input_level_dbv", "drive", "load_ohm", "frequency_points_hz", "cutoff_mode", "gm"})
    _require_keys(future, "future_methodology", {"hard_constraints", "fixed_parameters", "symmetry_groups", "gm_is_primary_objective"})
    if not isinstance(data["raw_roots"], list) or not data["raw_roots"]:
        raise ConfigError("data.raw_roots must be a non-empty list")
    if not isinstance(topologies["manifests"], list) or not topologies["manifests"]:
        raise ConfigError("topologies.manifests must be a non-empty list")
    if float(legacy["input_rms_v"]) <= 0 or float(legacy["load_ohm"]) <= 0:
        raise ConfigError("input_rms_v and load_ohm must be positive")
    expected_input_rms = 10.0 ** (float(legacy["input_level_dbv"]) / 20.0)
    if not math.isclose(float(legacy["input_rms_v"]), expected_input_rms, rel_tol=1e-9):
        raise ConfigError("input_rms_v must match input_level_dbv")
    drive = _require_mapping(legacy, "drive")
    _require_keys(
        drive,
        "legacy_evaluation.drive",
        {
            "default_mode",
            "matched_output_power_w",
            "calibration_relative_tolerance",
            "calibration_max_iterations",
            "calibration_min_input_rms_v",
            "calibration_max_input_rms_v",
        },
    )
    if drive["default_mode"] not in {"fixed_input", "matched_output_power"}:
        raise ConfigError("unsupported drive default_mode")
    if float(drive["matched_output_power_w"]) <= 0 or float(drive["calibration_relative_tolerance"]) <= 0:
        raise ConfigError("matched output power and calibration tolerance must be positive")
    if int(drive["calibration_max_iterations"]) < 1:
        raise ConfigError("calibration_max_iterations must be positive")
    if not 0 < float(drive["calibration_min_input_rms_v"]) < float(drive["calibration_max_input_rms_v"]):
        raise ConfigError("invalid input calibration bounds")
    if legacy["cutoff_mode"] not in {"legacy_db_divided_by_sqrt2", "corrected_minus_3.0103_db"}:
        raise ConfigError("unsupported cutoff_mode")
    gm = _require_mapping(legacy, "gm")
    _require_keys(gm, "legacy_evaluation.gm", {"window_seconds", "extraction_seconds", "input_step_v", "interpolation_points", "status", "crowe"})
    if gm["status"] != "baseline_only":
        raise ConfigError("the legacy GM must remain marked baseline_only")
    crowe = _require_mapping(gm, "crowe")
    _require_keys(
        crowe,
        "legacy_evaluation.gm.crowe",
        {
            "fundamental_hz",
            "input_peak_v",
            "harmonic_orders",
            "cycles",
            "samples_per_cycle",
            "convergence_tolerance",
            "consecutive_converged_steps",
        },
    )
    if float(crowe["fundamental_hz"]) <= 0 or float(crowe["input_peak_v"]) <= 0 or int(crowe["cycles"]) < 1:
        raise ConfigError("invalid GM-Crowe frequency, input peak or cycle count")
    harmonic_orders = crowe["harmonic_orders"]
    if not isinstance(harmonic_orders, list) or len(harmonic_orders) < 2:
        raise ConfigError("GM-Crowe harmonic_orders must contain at least two entries")
    harmonic_orders = [int(value) for value in harmonic_orders]
    if any(value < 2 for value in harmonic_orders) or any(right <= left for left, right in zip(harmonic_orders, harmonic_orders[1:])):
        raise ConfigError("GM-Crowe harmonic_orders must be strictly increasing and at least 2")
    if int(crowe["samples_per_cycle"]) < 2 * harmonic_orders[-1] + 1:
        raise ConfigError("GM-Crowe samples_per_cycle cannot resolve the maximum configured harmonic order")
    if float(crowe["convergence_tolerance"]) < 0 or int(crowe["consecutive_converged_steps"]) < 1:
        raise ConfigError("invalid GM-Crowe adaptive convergence settings")
    if "robust" in gm:
        robust = _require_mapping(gm, "robust")
        _require_keys(robust, "legacy_evaluation.gm.robust", {"method", "smoothing_strength", "stability_strides"})
        if robust["method"] not in {"cubic_analytic", "pchip_analytic", "smoothing_spline"}:
            raise ConfigError("unsupported robust GM method")
        if float(robust["smoothing_strength"]) < 0:
            raise ConfigError("GM smoothing_strength must be non-negative")
        if not isinstance(robust["stability_strides"], list) or not robust["stability_strides"] or any(int(value) < 1 for value in robust["stability_strides"]):
            raise ConfigError("GM stability_strides must be a non-empty list of positive integers")
    if future["gm_is_primary_objective"] is not False:
        raise ConfigError("GM cannot be enabled as the primary objective in this migration stage")
    for key in ("hard_constraints", "fixed_parameters", "symmetry_groups"):
        if not isinstance(future[key], list):
            raise ConfigError(f"future_methodology.{key} must be a list")
    for rule in future["hard_constraints"]:
        if not isinstance(rule, dict):
            raise ConfigError("each hard constraint must be a mapping")
        _require_keys(rule, "hard constraint", {"name", "metric", "relation", "limit", "unit"})
        if rule["relation"] not in {"min", "max", "equal"}:
            raise ConfigError(f"unsupported hard-constraint relation: {rule['relation']}")
    for fixed in future["fixed_parameters"]:
        if not isinstance(fixed, dict):
            raise ConfigError("each fixed parameter must be a mapping")
        _require_keys(fixed, "fixed parameter", {"id", "value", "unit", "purpose"})

    raw_parameters = document["parameters"]
    if not isinstance(raw_parameters, list) or not raw_parameters:
        raise ConfigError("parameters must be a non-empty list")
    specs: list[ParameterSpec] = []
    seen_parameter_ids: set[str] = set()
    for index, item in enumerate(raw_parameters, start=1):
        if not isinstance(item, dict):
            raise ConfigError(f"parameters[{index}] must be a mapping")
        _require_keys(item, f"parameters[{index}]", {"id", "name", "unit", "minimum", "maximum", "baseline"})
        spec = ParameterSpec(
            id=str(item["id"]),
            name=str(item["name"]),
            unit=str(item["unit"]),
            minimum=float(item["minimum"]),
            maximum=float(item["maximum"]),
            baseline=float(item["baseline"]),
        )
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", spec.id):
            raise ConfigError(f"invalid parameter id: {spec.id}")
        if spec.id in seen_parameter_ids:
            raise ConfigError(f"duplicate parameter id: {spec.id}")
        seen_parameter_ids.add(spec.id)
        if not spec.unit:
            raise ConfigError(f"{spec.id} has no explicit unit")
        if not spec.minimum <= spec.baseline <= spec.maximum:
            raise ConfigError(f"{spec.id} baseline is outside its bounds")
        specs.append(spec)

    config = SonyaConfig(source=source, raw=document, parameters=tuple(specs))
    ids = {spec.id for spec in specs}
    for fixed in future["fixed_parameters"]:
        if fixed["id"] not in ids:
            raise ConfigError(f"fixed parameter does not exist: {fixed['id']}")
    for group in future["symmetry_groups"]:
        if not isinstance(group, list) or len(group) < 2 or any(item not in ids for item in group):
            raise ConfigError(f"invalid symmetry group: {group!r}")
    raw_paths = [config.resolve(item) for item in data["raw_roots"]]
    processed = config.processed_root
    for raw_path in raw_paths:
        if processed == raw_path or raw_path in processed.parents:
            raise ConfigError("processed_root must not be inside a raw-data root")
    missing_manifests = [path for path in config.topology_manifest_paths if not path.is_file()]
    if missing_manifests:
        raise ConfigError(f"topology manifest does not exist: {missing_manifests[0]}")
    return config
