from __future__ import annotations

from dataclasses import asdict
import json
import math
from pathlib import Path
import re
import tempfile
import time
from typing import Literal, Sequence

import numpy as np

from .config import SonyaConfig
from .perceptual import (
    perceptual_doctors,
    active_rms,
    prepare_peak_excerpt,
    prepare_metric_pair,
    read_wav_mono,
    run_gstpeaq,
    run_visqol,
)
from .programme import ProgrammeItem, ProgrammeLevel, ProgrammeManifest, ProgrammeRole, pareto_audit, programme_report
from .programme_simulation import run_programme
from .provenance import write_provenance
from .run_control import RunControl
from .topology import TopologyManifest


def select_programme_levels(programme: ProgrammeManifest, level_ids: Sequence[str] | None = None) -> tuple[ProgrammeLevel, ...]:
    by_id = {item.id: item for item in programme.levels}
    if level_ids is None:
        return programme.levels
    if not level_ids:
        raise ValueError("at least one programme level is required")
    if len(set(level_ids)) != len(level_ids):
        raise ValueError("duplicate programme level")
    unknown = [level_id for level_id in level_ids if level_id not in by_id]
    if unknown:
        raise ValueError(f"levels are not declared by the programme manifest: {', '.join(sorted(unknown))}")
    return tuple(by_id[level_id] for level_id in level_ids)


def select_programme_items(
    programme: ProgrammeManifest,
    role: ProgrammeRole,
    item_ids: Sequence[str] | None = None,
) -> tuple[ProgrammeItem, ...]:
    eligible = {item.id: item for item in programme.items if role in item.roles}
    if item_ids is None:
        return tuple(eligible.values())
    if not item_ids:
        raise ValueError("at least one programme item is required")
    if len(set(item_ids)) != len(item_ids):
        raise ValueError("duplicate programme item")
    unknown = [item_id for item_id in item_ids if item_id not in eligible]
    if unknown:
        raise ValueError(
            f"programme items are not declared for role {role}: {', '.join(sorted(unknown))}"
        )
    return tuple(eligible[item_id] for item_id in item_ids)


def campaign_candidates(campaign: dict[str, object], selection: Literal["online", "final"]) -> list[dict[str, object]]:
    sampling = campaign.get("perceptual_sampling")
    screening = campaign.get("screening")
    records = screening.get("records") if isinstance(screening, dict) else None
    ids = sampling.get(f"{selection}_candidate_ids") if isinstance(sampling, dict) else None
    if not isinstance(records, list) or not isinstance(ids, list) or not ids:
        raise ValueError(f"campaign has no {selection} perceptual selection")
    by_id = {
        str(record.get("candidate_id")): record
        for record in records
        if isinstance(record, dict) and record.get("candidate_id") is not None
    }
    selected: list[dict[str, object]] = []
    for candidate_id in ids:
        record = by_id.get(str(candidate_id))
        if record is None or not isinstance(record.get("values"), dict):
            raise ValueError(f"selected candidate {candidate_id} has no parameter vector")
        selected.append(record)
    return selected


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("._") or "item"


def _input_delivery_diagnostics(
    source: np.ndarray,
    source_sample_rate_hz: int,
    simulation_time: np.ndarray,
    delivered: np.ndarray,
    target_peak_v: float,
) -> dict[str, float]:
    source_values = np.asarray(source, dtype=float)
    time_values = np.asarray(simulation_time, dtype=float)
    delivered_values = np.asarray(delivered, dtype=float)
    if (
        source_values.ndim != 1
        or source_values.size < 2
        or source_sample_rate_hz <= 0
        or time_values.ndim != 1
        or delivered_values.shape != time_values.shape
        or time_values.size < 2
        or not np.all(np.isfinite(source_values))
        or not np.all(np.isfinite(time_values))
        or not np.all(np.isfinite(delivered_values))
        or np.any(np.diff(time_values) < 0)
    ):
        raise ValueError("invalid source or delivered programme waveform")

    source_peak_v = float(np.max(np.abs(source_values)))
    source_peak_error_relative = abs(source_peak_v - target_peak_v) / target_peak_v
    if source_peak_error_relative > 1e-9:
        raise RuntimeError(
            f"calibrated programme source peak is {source_peak_v:.9g} V, "
            f"expected {target_peak_v:.9g} V "
            f"(relative error {source_peak_error_relative:.6%})"
        )

    source_time = np.arange(source_values.size, dtype=float) / source_sample_rate_hz
    expected = np.interp(time_values, source_time, source_values)
    expected_energy = float(np.dot(expected, expected))
    if expected_energy <= 0.0:
        raise RuntimeError("programme source has no energy on the simulator time grid")
    fitted_gain = float(np.dot(expected, delivered_values) / expected_energy)
    gain_error_relative = abs(fitted_gain - 1.0)
    waveform_error = delivered_values - expected
    waveform_error_rms_v = float(np.sqrt(np.mean(np.square(waveform_error))))
    waveform_error_rms_relative = waveform_error_rms_v / target_peak_v
    # Compare like-for-like values on the simulator's own adaptive grid.  The
    # sampled maximum is deliberately not a pass/fail condition: a narrow peak
    # may fall between two accepted transient-solution timestamps.
    if gain_error_relative > 5e-4 or waveform_error_rms_relative > 5e-4:
        raise RuntimeError(
            "simulator input does not reproduce the calibrated programme source "
            f"(gain error {gain_error_relative:.6%}, "
            f"normalized RMS error {waveform_error_rms_relative:.6%})"
        )

    delivered_peak_v = float(np.max(np.abs(delivered_values)))
    return {
        "source_peak_v": source_peak_v,
        "source_peak_error_relative": source_peak_error_relative,
        "delivered_peak_v": delivered_peak_v,
        "delivered_peak_error_relative": abs(delivered_peak_v - target_peak_v) / target_peak_v,
        "fitted_gain": fitted_gain,
        "gain_error_relative": gain_error_relative,
        "waveform_error_rms_v": waveform_error_rms_v,
        "waveform_error_rms_relative": waveform_error_rms_relative,
    }


def _write_partial_report(
    root: Path,
    *,
    backend: str,
    total_cases: int,
    completed_cases: list[dict[str, object]],
    failed_cases: list[dict[str, object]],
    started: float,
) -> Path:
    path = root / "validation.partial.json"
    path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "status": "perceptual_validation_in_progress",
                "simulator_backend": backend,
                "total_cases": total_cases,
                "completed_case_count": len(completed_cases),
                "failed_case_count": len(failed_cases),
                "processed_case_count": len(completed_cases) + len(failed_cases),
                "elapsed_seconds": time.perf_counter() - started,
                "cases": completed_cases,
                "failures": failed_cases,
            },
            indent=2,
            sort_keys=True,
            default=str,
        )
        + "\n",
        encoding="utf-8",
    )
    return path


def run_programme_validation(
    config: SonyaConfig,
    topology: TopologyManifest,
    campaign_path: str | Path,
    programme: ProgrammeManifest,
    output_root: str | Path,
    *,
    selection: Literal["online", "final"] = "final",
    role: Literal["development", "validation"] = "validation",
    item_ids: Sequence[str] | None = None,
    level_ids: Sequence[str] | None = None,
    metric: Literal["all", "visqol", "gstpeaq"] = "all",
    peaq_model: Literal["basic", "advanced", "both"] = "both",
    input_channel: int = 0,
    preroll_seconds: float = 0.1,
    simulation_sample_rate_hz: int = 48000,
    reltol: float = 0.001,
    timeout_seconds: float = 1200.0,
    run_control: RunControl | None = None,
) -> Path:
    campaign_source = Path(campaign_path).expanduser().resolve()
    campaign = json.loads(campaign_source.read_text(encoding="utf-8"))
    backend_id = str(campaign.get("simulator_backend", ""))
    if backend_id not in {"ngspice", "ltspice"}:
        raise ValueError("programme validation requires an ngspice or LTspice campaign")
    if backend_id not in topology.backends or topology.backends[backend_id].status == "planned":
        raise ValueError(f"topology {topology.id!r} cannot run programme audio with {backend_id}")
    if campaign.get("topology") != topology.id:
        raise ValueError("campaign and selected topology do not match")
    manifest_report = programme_report(programme)
    if not manifest_report["programme_ready"]:
        raise ValueError("programme corpus is not ready; canonical paths, hashes, levels and category coverage must pass")
    selected_levels = select_programme_levels(programme, level_ids)
    all_role_items = tuple(item for item in programme.items if role in item.roles)
    items = select_programme_items(programme, role, item_ids)
    if not items:
        raise ValueError(f"programme corpus has no {role} items")
    selected_categories = {category for item in items for category in item.categories}
    missing_categories = set(programme.required_categories) - selected_categories
    complete_validation_split = role == "validation" and {item.id for item in items} == {
        item.id for item in all_role_items
    }
    complete_validation_protocol = complete_validation_split and {level.id for level in selected_levels} == {
        level.id for level in programme.levels
    }
    if complete_validation_split and missing_categories:
        raise ValueError(f"validation split lacks categories: {', '.join(sorted(missing_categories))}")

    doctors = {item.id: item for item in perceptual_doctors()}
    if metric in {"all", "visqol"} and not doctors["visqol_audio"].ready:
        raise RuntimeError("ViSQOL is required for the requested validation")
    if metric in {"all", "gstpeaq"} and not doctors["gstpeaq_odg"].ready:
        raise RuntimeError("GstPEAQ is required for the requested validation")
    candidates = campaign_candidates(campaign, selection)
    base = Path(output_root).expanduser().resolve()
    base.mkdir(parents=True, exist_ok=True)
    root = Path(tempfile.mkdtemp(prefix=f"perceptual-{selection}-", dir=base))
    results: list[dict[str, object]] = []
    failures: list[dict[str, object]] = []
    started = time.perf_counter()
    control = run_control or RunControl(run_kind="perceptual")
    total_cases = len(candidates) * len(items) * len(selected_levels)
    control.emit(
        "validation_started",
        selection=selection,
        role=role,
        total_cases=total_cases,
        candidate_count=len(candidates),
        item_count=len(items),
        level_count=len(selected_levels),
        simulator_backend=backend_id,
    )

    case_index = 0
    for candidate_index, candidate in enumerate(candidates, start=1):
        candidate_id = str(candidate["candidate_id"])
        parameters = {str(key): float(value) for key, value in candidate["values"].items()}  # type: ignore[union-attr]
        for item in items:
            assert item.canonical_path is not None
            sample_rate, audio = read_wav_mono(item.canonical_path, input_channel)
            for level in selected_levels:
                case_index += 1
                context = {
                    "case_index": case_index,
                    "total_cases": total_cases,
                    "candidate_index": candidate_index,
                    "candidate_count": len(candidates),
                    "candidate_id": candidate_id,
                    "programme_item_id": item.id,
                    "level_id": level.id,
                }
                control.checkpoint("before_programme_case", **context)
                control.emit("case_started", **context)
                waveform = prepare_peak_excerpt(
                    audio,
                    sample_rate,
                    item.duration_seconds,
                    target_peak_v=level.target_peak_v,
                    preroll_seconds=preroll_seconds,
                )
                case_root = root / _safe_name(candidate_id) / _safe_name(item.id) / _safe_name(level.id)
                try:
                    control.emit("simulation_started", **context)
                    simulation = run_programme(
                        backend_id,
                        config,
                        topology,
                        parameters,
                        waveform,
                        sample_rate,
                        simulation_sample_rate_hz,
                        case_root,
                        reltol=reltol,
                        timeout_seconds=timeout_seconds,
                    )
                    control.emit(
                        "simulation_completed",
                        **context,
                        elapsed_seconds=simulation.get("elapsed_seconds"),
                        output_samples=simulation.get("output_samples"),
                    )
                except Exception as exc:
                    failure = {
                        **context,
                        "simulator_backend": backend_id,
                        "stage": "simulation",
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    }
                    failures.append(failure)
                    control.emit("case_failed", **failure)
                    _write_partial_report(
                        root,
                        backend=backend_id,
                        total_cases=total_cases,
                        completed_cases=results,
                        failed_cases=failures,
                        started=started,
                    )
                    continue
                metric_started = time.perf_counter()
                try:
                    delivered_input = np.asarray(simulation["input"], dtype=float)
                    input_diagnostics = _input_delivery_diagnostics(
                        waveform,
                        sample_rate,
                        np.asarray(simulation["time"], dtype=float),
                        delivered_input,
                        level.target_peak_v,
                    )
                    delivered_rms_v = active_rms(delivered_input)
                    pair = prepare_metric_pair(
                        simulation["time"],  # type: ignore[arg-type]
                        waveform,
                        simulation["output"],  # type: ignore[arg-type]
                        case_root / "metric-pair",
                        reference_time=np.arange(waveform.size, dtype=float) / sample_rate,
                    )
                    metric_results: list[dict[str, object]] = []
                    control.emit("metrics_started", **context, metric=metric, peaq_model=peaq_model)
                    if metric in {"all", "visqol"}:
                        metric_results.append(run_visqol(pair.reference, pair.degraded).record())
                    if metric in {"all", "gstpeaq"}:
                        models = ("basic", "advanced") if peaq_model == "both" else (peaq_model,)
                        metric_results.extend(run_gstpeaq(pair.reference, pair.degraded, model).record() for model in models)
                    results.append({
                        "candidate_id": candidate_id,
                        "programme_item_id": item.id,
                        "roles": list(item.roles),
                        "level_id": level.id,
                        "level": asdict(level),
                        "input_target_peak_v": level.target_peak_v,
                        "input_source_peak_v": input_diagnostics["source_peak_v"],
                        "input_source_peak_error_relative": input_diagnostics["source_peak_error_relative"],
                        "input_delivered_peak_v": input_diagnostics["delivered_peak_v"],
                        "input_peak_error_relative": input_diagnostics["delivered_peak_error_relative"],
                        "input_fitted_gain": input_diagnostics["fitted_gain"],
                        "input_gain_error_relative": input_diagnostics["gain_error_relative"],
                        "input_waveform_error_rms_v": input_diagnostics["waveform_error_rms_v"],
                        "input_waveform_error_rms_relative": input_diagnostics["waveform_error_rms_relative"],
                        "input_active_rms_v": delivered_rms_v,
                        "input_active_rms_dbv": 20.0 * math.log10(delivered_rms_v),
                        "simulation": {key: value for key, value in simulation.items() if key not in {"time", "input", "output"}},
                        "metric_pair": pair.record(),
                        "metric_elapsed_seconds": time.perf_counter() - metric_started,
                        "metrics": metric_results,
                    })
                except Exception as exc:
                    failure = {
                        **context,
                        "simulator_backend": backend_id,
                        "stage": "metric_preparation_or_execution",
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    }
                    failures.append(failure)
                    control.emit("case_failed", **failure)
                    _write_partial_report(
                        root,
                        backend=backend_id,
                        total_cases=total_cases,
                        completed_cases=results,
                        failed_cases=failures,
                        started=started,
                    )
                    continue
                control.emit(
                    "case_completed",
                    **context,
                    metric_elapsed_seconds=time.perf_counter() - metric_started,
                    metrics={str(item["id"]): item["value"] for item in metric_results},
                )
                _write_partial_report(
                    root,
                    backend=backend_id,
                    total_cases=total_cases,
                    completed_cases=results,
                    failed_cases=failures,
                    started=started,
                )

    control.checkpoint("after_programme_cases", case_index=case_index, total_cases=total_cases)

    candidate_records: list[dict[str, object]] = []
    expected_cases_per_candidate = len(items) * len(selected_levels)
    for candidate in candidates:
        candidate_id = str(candidate["candidate_id"])
        candidate_results = [item for item in results if item["candidate_id"] == candidate_id]
        grouped: dict[str, list[float]] = {}
        grouped_by_level: dict[str, dict[str, list[float]]] = {}
        for result in candidate_results:
            level_group = grouped_by_level.setdefault(str(result["level_id"]), {})
            for measurement in result["metrics"]:  # type: ignore[union-attr]
                metric_id = str(measurement["id"])
                value = float(measurement["value"])
                grouped.setdefault(metric_id, []).append(value)
                level_group.setdefault(metric_id, []).append(value)
        aggregate = {metric_id: float(np.mean(values)) for metric_id, values in grouped.items()}
        metric_statistics = {
            metric_id: {
                "mean": float(np.mean(values)),
                "minimum": float(np.min(values)),
                "maximum": float(np.max(values)),
                "standard_deviation": float(np.std(values)),
                "sample_count": len(values),
            }
            for metric_id, values in grouped.items()
        }
        metrics_by_level = {
            level_id: {metric_id: float(np.mean(values)) for metric_id, values in metric_values.items()}
            for level_id, metric_values in grouped_by_level.items()
        }
        metric_statistics_by_level = {
            level_id: {
                metric_id: {
                    "mean": float(np.mean(values)),
                    "minimum": float(np.min(values)),
                    "maximum": float(np.max(values)),
                    "standard_deviation": float(np.std(values)),
                    "sample_count": len(values),
                }
                for metric_id, values in metric_values.items()
            }
            for level_id, metric_values in grouped_by_level.items()
        }
        nominal = metrics_by_level.get("nominal", {})
        limit = metrics_by_level.get("limit", {})
        limit_minus_nominal = {
            metric_id: limit[metric_id] - nominal[metric_id]
            for metric_id in sorted(nominal.keys() & limit.keys())
        }
        candidate_records.append({
            "candidate_id": candidate_id,
            "feasible": len(candidate_results) == expected_cases_per_candidate,
            "metrics": aggregate,
            "metric_statistics": metric_statistics,
            "metrics_by_level": metrics_by_level,
            "metric_statistics_by_level": metric_statistics_by_level,
            "limit_minus_nominal": limit_minus_nominal,
            "sample_counts": {metric_id: len(values) for metric_id, values in grouped.items()},
            "completed_case_count": len(candidate_results),
            "expected_case_count": expected_cases_per_candidate,
            "failed_case_count": sum(1 for item in failures if item["candidate_id"] == candidate_id),
            "evidence": {
                "programme_validation_split": complete_validation_protocol,
                "perceptual_adapter_versions": True,
                "reproducible_provenance": True,
            },
        })

    objectives = {"visqol_audio": "maximize"} if metric in {"all", "visqol"} else {}
    audit = pareto_audit(
        candidate_records,
        objectives,  # type: ignore[arg-type]
        ("programme_validation_split", "perceptual_adapter_versions", "reproducible_provenance"),
    ) if objectives else None
    provenance = write_provenance(
        root / "provenance.json",
        [
            campaign_source,
            programme.source,
            config.source,
            topology.source,
            topology.circuit,
            *(item.path for item in items if item.path),
            *(item.canonical_path for item in items if item.canonical_path),
        ],
        "programme_audio_perceptual_validation",
        {
            "simulator_backend": backend_id,
            "selection": selection,
            "role": role,
            "programme_item_ids": [item.id for item in items],
            "levels": [asdict(item) for item in selected_levels],
            "metric": metric,
            "peaq_model": peaq_model,
            "candidate_ids": [str(item["candidate_id"]) for item in candidates],
        },
    )
    report = {
        "schema_version": 1,
        "status": "perceptual_validation_complete" if not failures else "perceptual_validation_complete_with_failures",
        "simulator_backend": backend_id,
        "scientific_scope": (
            "validation" if complete_validation_protocol
            else "partial_validation_only" if role == "validation"
            else "development_only"
        ),
        "campaign": str(campaign_source),
        "programme": manifest_report,
        "selection": selection,
        "role": role,
        "programme_item_ids": [item.id for item in items],
        "levels": [asdict(item) for item in selected_levels],
        "metric_doctors": [asdict(item) for item in doctors.values()],
        "case_count": len(results),
        "failed_case_count": len(failures),
        "planned_case_count": total_cases,
        "elapsed_seconds": time.perf_counter() - started,
        "cases": results,
        "failures": failures,
        "candidate_records": candidate_records,
        "perceptual_pareto_audit": None if audit is None else {key: value for key, value in audit.items() if key != "front"},
        "provenance": str(provenance),
    }
    report_path = root / "validation.json"
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
    control.emit(
        "validation_completed",
        case_count=len(results),
        failed_case_count=len(failures),
        total_cases=total_cases,
        elapsed_seconds=report["elapsed_seconds"],
        report_path=str(report_path),
    )
    return report_path
