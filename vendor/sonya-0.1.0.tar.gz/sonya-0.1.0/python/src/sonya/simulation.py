from __future__ import annotations

from dataclasses import asdict
import math

import numpy as np

from .config import SonyaConfig
from .feasibility import evaluate_declared_constraints, evaluate_parameter_constraints
from .metrics.gedlee_legacy import legacy_gedlee_metric, robust_gedlee_metric, robust_gedlee_stability
from .netlist import LEGACY_FREQUENCIES_HZ
from .scoring import legacy_score_breakdown


def summarize_legacy_runs(
    runs: list[dict[str, object]],
    parameters: dict[str, float],
    config: SonyaConfig,
    *,
    require_crowe: bool = True,
    require_gedlee: bool = True,
) -> dict[str, object]:
    by_mode = {str(run["mode"]): run for run in runs}
    required_modes = {"op", "tran", "ac", "slew"}
    if require_gedlee:
        required_modes.add("gedlee")
    if require_crowe:
        required_modes.add("crowe")
    missing = required_modes - by_mode.keys()
    if missing:
        raise ValueError(f"cannot summarize incomplete simulation; missing: {', '.join(sorted(missing))}")
    op = by_mode["op"]["measurements"]
    tran = by_mode["tran"]["measurements"]
    ac = by_mode["ac"]["measurements"]
    ac_db = by_mode["ac"]["ac_db"]
    slew = by_mode["slew"]["measurements"]
    gm_values = by_mode["gedlee"]["measurements"] if "gedlee" in by_mode else None
    crowe_values = by_mode["crowe"]["measurements"] if "crowe" in by_mode else None
    assert isinstance(op, dict) and isinstance(tran, dict) and isinstance(ac, dict) and isinstance(ac_db, dict) and isinstance(slew, dict)
    assert gm_values is None or isinstance(gm_values, dict)
    assert crowe_values is None or isinstance(crowe_values, dict)
    gain_ratio = float(tran["gain_rms"])
    gm_stability: dict[str, object] | None = None
    gm_legacy: float | None = None
    if gm_values is not None:
        minima = [float(gm_values[f"min{index}"]) for index in range(101)]
        maxima = [float(gm_values[f"max{index}"]) for index in range(101)]
        gm_cfg = config.raw["legacy_evaluation"]["gm"]
        robust_cfg = gm_cfg.get("robust", {})
        robust_method = str(robust_cfg.get("method", "cubic_analytic"))
        smoothing_strength = float(robust_cfg.get("smoothing_strength", 5e-4))
        stability_strides = tuple(int(value) for value in robust_cfg.get("stability_strides", (1, 2, 4)))
        gm_stability = robust_gedlee_stability(
            minima,
            maxima,
            gain_ratio,
            float(gm_cfg["input_step_v"]),
            method=robust_method,
            smoothing_strength=smoothing_strength,
            strides=stability_strides,
        )
        gm_stability["options"] = {
            method: {
                "value": robust_gedlee_metric(
                    minima,
                    maxima,
                    gain_ratio,
                    float(gm_cfg["input_step_v"]),
                    method=method,
                    smoothing_strength=smoothing_strength,
                ),
                "stability": robust_gedlee_stability(
                    minima,
                    maxima,
                    gain_ratio,
                    float(gm_cfg["input_step_v"]),
                    method=method,
                    smoothing_strength=smoothing_strength,
                    strides=stability_strides,
                ),
            }
            for method in ("cubic_analytic", "pchip_analytic", "smoothing_spline")
        }
        gm_legacy = legacy_gedlee_metric(
            minima,
            maxima,
            gain_ratio,
            float(gm_cfg["input_step_v"]),
            int(gm_cfg["interpolation_points"]),
        )
    measurements = {
        "vaa_v": float(op["vaa_v"]),
        "gain_db": 20.0 * math.log10(gain_ratio),
        "output_power_w": abs(float(tran["output_power"])),
        "frequency_std_db": float(np.std([float(ac_db[f"f{round(frequency)}hz"]) for frequency in LEGACY_FREQUENCIES_HZ], ddof=1)),
        "low_cutoff_hz": float(ac["fclo"]),
        "high_cutoff_hz": float(ac["fchi"]),
        "slew_rate_v_per_us": abs(float(slew["slew"])) * 1e-6,
        "thd_percent": float(by_mode["tran"]["fourier_thd_percent"]),
        "bplus_supply_current_a": float(op["bplus_supply_current_a"]),
        "bplus_input_power_w": float(op["bplus_input_power_w"]),
        "el84a_plate_current_a": float(op.get("el84a_plate_current_a", math.nan)),
        "el84b_plate_current_a": float(op.get("el84b_plate_current_a", math.nan)),
        "el84a_plate_dissipation_w": float(op.get("el84a_plate_dissipation_w", math.nan)),
        "el84b_plate_dissipation_w": float(op.get("el84b_plate_dissipation_w", math.nan)),
        "mje340_q1_vce_v": float(op.get("mje340_q1_vce_v", math.nan)),
        "mje340_q2_vce_v": float(op.get("mje340_q2_vce_v", math.nan)),
        "mje340_q1_collector_current_a": float(op.get("mje340_q1_collector_current_a", math.nan)),
        "mje340_q2_collector_current_a": float(op.get("mje340_q2_collector_current_a", math.nan)),
        "mje340_q1_dissipation_w": float(op.get("mje340_q1_dissipation_w", math.nan)),
        "mje340_q2_dissipation_w": float(op.get("mje340_q2_dissipation_w", math.nan)),
    }
    if gm_legacy is not None:
        measurements["gm_legacy"] = gm_legacy
    if crowe_values is not None:
        measurements.update({
            "gm_crowe": float(crowe_values["gm_crowe"]),
            "gm_crowe_memory_ratio": float(crowe_values["gm_crowe_memory_ratio"]),
            "gm_crowe_fit_residual_rms_relative": float(crowe_values["gm_crowe_fit_residual_rms_relative"]),
            "gm_crowe_input_peak_v": float(crowe_values["gm_crowe_input_peak_v"]),
            "gm_crowe_selected_harmonics": float(crowe_values["gm_crowe_selected_harmonics"]),
        })
    specs = config.raw["legacy_evaluation"]["score_specs"]
    score_parts = legacy_score_breakdown(measurements, specs) if gm_legacy is not None else None
    declared_ok, declared = evaluate_declared_constraints(measurements, config.raw["future_methodology"]["hard_constraints"])
    parameters_ok, parameter_results = evaluate_parameter_constraints(
        parameters,
        config.parameters,
        config.raw["future_methodology"]["symmetry_groups"],
        config.raw["future_methodology"]["fixed_parameters"],
    )
    critical_physical_metrics = (
        "el84a_plate_current_a",
        "el84b_plate_current_a",
        "el84a_plate_dissipation_w",
        "el84b_plate_dissipation_w",
        "mje340_q1_vce_v",
        "mje340_q2_vce_v",
        "mje340_q1_collector_current_a",
        "mje340_q2_collector_current_a",
        "mje340_q1_dissipation_w",
        "mje340_q2_dissipation_w",
    )
    physical_measurements_complete = all(math.isfinite(float(measurements[name])) for name in critical_physical_metrics)
    soa_configured = config.raw["future_methodology"]["soa_limits_status"] == "configured"
    optimization_eligible = declared_ok and parameters_ok and physical_measurements_complete and soa_configured
    return {
        "measurements": measurements,
        "legacy_score": sum(score_parts.values()) if score_parts is not None else None,
        "legacy_score_parts": score_parts,
        "legacy_score_status": "reproduction_only_not_new_objective" if score_parts is not None else "not_computed_for_multiobjective_screening",
        "gm_robustness": gm_stability,
        "gm_crowe_details": by_mode["crowe"].get("gm_crowe_details") if "crowe" in by_mode else None,
        "gm_crowe_stability": by_mode["crowe"].get("gm_crowe_stability") if "crowe" in by_mode else None,
        "drive": {
            "input_rms_v": float(tran["vin_rms"]),
            "input_dbv": 20.0 * math.log10(float(tran["vin_rms"])),
            "output_power_w": abs(float(tran["output_power"])),
            "gm_crowe_input_peak_v": float(crowe_values["gm_crowe_input_peak_v"]) if crowe_values is not None else None,
        },
        "declared_constraints_feasible": declared_ok,
        "parameter_constraints_feasible": parameters_ok,
        "physical_measurements_complete": physical_measurements_complete,
        "optimization_eligible": optimization_eligible,
        "hard_constraints": [asdict(item) for item in declared],
        "parameter_constraints": [asdict(item) for item in parameter_results],
        "soa_status": config.raw["future_methodology"]["soa_limits_status"],
    }
