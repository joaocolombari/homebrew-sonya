from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class ObjectiveTerm:
    name: str
    weight: float


def weighted_objective(measurements: Mapping[str, float], terms: list[ObjectiveTerm]) -> float:
    if any(term.name in {"legacy_gm", "robust_gm", "gm_legacy", "gm_crowe"} for term in terms):
        raise ValueError("GM is screening/baseline only and cannot be enabled as the new primary objective")
    return sum(measurements[term.name] * term.weight for term in terms)
