from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path
import re
from typing import Any

import yaml


class TransformerProfileError(ValueError):
    pass


_LINEAR_REQUIRED = (
    "primary_inductance_h",
    "leakage_inductance_h",
    "primary_impedance_ohm",
    "secondary_impedance_ohm",
    "ultralinear_tap_fraction",
    "primary_capacitance_f",
)
_LOSS_FIELDS = ("primary_dcr_ohm", "secondary_dcr_ohm", "core_loss_resistance_ohm")


@dataclass(frozen=True)
class TransformerProfile:
    source: Path
    id: str
    name: str
    description: str
    values: dict[str, float | None]
    statuses: dict[str, str]
    design_specification: dict[str, Any]
    nonlinear: dict[str, Any]

    @property
    def linear_ready(self) -> bool:
        return all(self.values[name] is not None for name in _LINEAR_REQUIRED)

    @property
    def losses_identified(self) -> bool:
        return all(self.values[name] is not None for name in _LOSS_FIELDS)

    @property
    def nonlinear_ready(self) -> bool:
        return self.nonlinear.get("status") == "identified"


def load_transformer_profile(path: str | Path) -> TransformerProfile:
    source = Path(path).expanduser().resolve()
    try:
        raw = yaml.safe_load(source.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise TransformerProfileError(f"cannot read transformer profile {source}: {exc}") from exc
    if not isinstance(raw, dict) or raw.get("schema_version") != 1:
        raise TransformerProfileError("transformer profile must use schema_version 1")
    for field in ("id", "name", "linear", "nonlinear"):
        if field not in raw:
            raise TransformerProfileError(f"transformer profile is missing {field!r}")
    profile_id = str(raw["id"])
    if not re.fullmatch(r"[a-z][a-z0-9_-]*", profile_id):
        raise TransformerProfileError("transformer id must start with a lowercase letter and contain only a-z, 0-9, _ or -")
    linear = raw["linear"]
    nonlinear = raw["nonlinear"]
    design_specification = raw.get("design_specification", {})
    if (
        not isinstance(linear, dict)
        or not isinstance(nonlinear, dict)
        or not isinstance(design_specification, dict)
    ):
        raise TransformerProfileError("linear, nonlinear and design_specification must be mappings")
    values: dict[str, float | None] = {}
    statuses: dict[str, str] = {}
    for name in (*_LINEAR_REQUIRED, *_LOSS_FIELDS):
        entry = linear.get(name)
        if not isinstance(entry, dict) or "value" not in entry or "status" not in entry:
            raise TransformerProfileError(f"linear.{name} requires value and status")
        value = entry["value"]
        numeric = None if value is None else float(value)
        if numeric is not None and (not math.isfinite(numeric) or numeric < 0):
            raise TransformerProfileError(f"linear.{name} must be finite and non-negative")
        values[name] = numeric
        statuses[name] = str(entry["status"])
    tap = values["ultralinear_tap_fraction"]
    if tap is not None and not 0 < tap < 1:
        raise TransformerProfileError("ultralinear_tap_fraction must be between zero and one")
    for name in ("primary_inductance_h", "primary_impedance_ohm", "secondary_impedance_ohm"):
        if values[name] == 0:
            raise TransformerProfileError(f"linear.{name} must be positive")
    return TransformerProfile(
        source,
        profile_id,
        str(raw["name"]),
        str(raw.get("description", "")),
        values,
        statuses,
        design_specification,
        nonlinear,
    )


def transformer_record(profile: TransformerProfile) -> dict[str, object]:
    return {
        "id": profile.id,
        "name": profile.name,
        "description": profile.description,
        "profile": str(profile.source),
        "linear_ready": profile.linear_ready,
        "losses_identified": profile.losses_identified,
        "nonlinear_ready": profile.nonlinear_ready,
        "linear_parameters": {
            name: {"value": value, "status": profile.statuses[name]}
            for name, value in profile.values.items()
        },
        "design_specification": profile.design_specification,
        "nonlinear": profile.nonlinear,
    }


def render_linear_include(profile: TransformerProfile) -> str:
    if not profile.linear_ready:
        missing = [name for name in _LINEAR_REQUIRED if profile.values[name] is None]
        raise TransformerProfileError(f"linear transformer profile is incomplete: {', '.join(missing)}")
    value = profile.values
    rpri = value["primary_dcr_ohm"] or 0.0
    rsec = value["secondary_dcr_ohm"] or 0.0
    rcore = value["core_loss_resistance_ohm"] or 1e12
    return "\n".join((
        f"* Generated from {profile.source.name}; profile {profile.id}",
        f"* losses_identified={str(profile.losses_identified).lower()}",
        *(f"* {name}.status={profile.statuses[name]}" for name in (*_LINEAR_REQUIRED, *_LOSS_FIELDS)),
        f".param TX_LPRIM={value['primary_inductance_h']:.15g}",
        f".param TX_LLEAK={value['leakage_inductance_h']:.15g}",
        f".param TX_ZPRI={value['primary_impedance_ohm']:.15g}",
        f".param TX_ZSEC={value['secondary_impedance_ohm']:.15g}",
        f".param TX_ULTAP={value['ultralinear_tap_fraction']:.15g}",
        f".param TX_CPRI={value['primary_capacitance_f']:.15g}",
        f".param TX_RPRI={rpri:.15g}",
        f".param TX_RSEC={rsec:.15g}",
        f".param TX_RCORE={rcore:.15g}",
        "",
    ))


def create_transformer_profile(transformer_id: str, output: str | Path) -> Path:
    if not re.fullmatch(r"[a-z][a-z0-9_-]*", transformer_id):
        raise TransformerProfileError("transformer id must start with a lowercase letter and contain only a-z, 0-9, _ or -")
    target = Path(output).expanduser().resolve()
    if target.exists():
        raise FileExistsError(f"refusing to overwrite existing file: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    fields = {name: {"value": None, "status": "measurement_required"} for name in (*_LINEAR_REQUIRED, *_LOSS_FIELDS)}
    payload = {
        "schema_version": 1,
        "id": transformer_id,
        "name": transformer_id,
        "description": "Terminal-measured output-transformer profile.",
        "linear": fields,
        "nonlinear": {
            "status": "measurement_required",
            "preferred_model": "portable_terminal_identified_behavioral",
            "required_measurements": [
                "no_load_primary_current_waveforms_at_multiple_voltage_frequency_points",
                "incremental_primary_inductance_versus_ac_level_and_dc_bias",
                "loaded_transfer_and_distortion_versus_level_and_frequency",
            ],
        },
    }
    target.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    return target
