from __future__ import annotations

from datetime import datetime, timezone
import hashlib
from pathlib import Path
import re


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def audit_data(raw_roots: list[Path], source_roots: list[Path] | None = None) -> dict[str, object]:
    files: list[dict[str, object]] = []
    by_digest: dict[str, list[str]] = {}
    seen_paths: set[Path] = set()
    for root in raw_roots:
        for path in sorted(item for item in root.rglob("*") if item.is_file()):
            resolved = path.resolve()
            if resolved in seen_paths:
                continue
            seen_paths.add(resolved)
            digest = _hash(resolved)
            record = {"path": str(resolved), "size_bytes": resolved.stat().st_size, "sha256": digest}
            files.append(record)
            by_digest.setdefault(digest, []).append(str(resolved))
    duplicates = [
        {"sha256": digest, "paths": paths, "count": len(paths)}
        for digest, paths in by_digest.items()
        if len(paths) > 1
    ]
    duplicates.sort(key=lambda item: (-int(item["count"]), str(item["sha256"])))
    manual_overrides: list[dict[str, object]] = []
    for root in source_roots or []:
        for path in root.rglob("*.m"):
            text = path.read_text(encoding="utf-8", errors="replace")
            for line_number, line in enumerate(text.splitlines(), start=1):
                if re.search(r"\bPrms\s*\(\s*2\s*\)\s*=\s*11\.16\b", line):
                    manual_overrides.append({"path": str(path.resolve()), "line": line_number, "text": line.strip()})
    return {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "raw_roots": [str(path.resolve()) for path in raw_roots],
        "file_count": len(files),
        "files": files,
        "duplicate_group_count": len(duplicates),
        "duplicate_groups": duplicates,
        "manual_numeric_overrides": manual_overrides,
    }
