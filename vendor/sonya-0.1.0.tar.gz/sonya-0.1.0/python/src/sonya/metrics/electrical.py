from __future__ import annotations

import math
import numpy as np
from numpy.typing import ArrayLike


def rms(values: ArrayLike) -> float:
    data = np.asarray(values, dtype=float)
    if data.size == 0 or not np.all(np.isfinite(data)):
        raise ValueError("RMS requires finite samples")
    return float(np.sqrt(np.mean(np.square(data))))


def gain_and_power(output_v: ArrayLike, input_rms_v: float, load_ohm: float) -> dict[str, float]:
    if input_rms_v <= 0 or load_ohm <= 0:
        raise ValueError("input voltage and load must be positive")
    output_rms = rms(output_v)
    gain_ratio = output_rms / input_rms_v
    return {
        "output_rms_v": output_rms,
        "gain_ratio": gain_ratio,
        "gain_db": 20.0 * math.log10(gain_ratio),
        "output_power_w": output_rms * output_rms / load_ohm,
    }


def harmonic_distortion_percent(
    values: ArrayLike,
    sample_rate_hz: float,
    fundamental_hz: float,
    harmonics: int = 10,
) -> float:
    """Estimate THD by least-squares sinusoid fitting.

    This is a Python diagnostic, not claimed as parity with MATLAB's ``thd``.
    """
    signal = np.asarray(values, dtype=float)
    if signal.size < 4 or sample_rate_hz <= 0 or fundamental_hz <= 0:
        raise ValueError("invalid waveform or sampling parameters")
    time = np.arange(signal.size, dtype=float) / sample_rate_hz
    columns = [np.ones(signal.size)]
    valid_harmonics: list[int] = []
    for harmonic in range(1, harmonics + 1):
        frequency = harmonic * fundamental_hz
        if frequency >= sample_rate_hz / 2:
            break
        columns.extend((np.sin(2 * np.pi * frequency * time), np.cos(2 * np.pi * frequency * time)))
        valid_harmonics.append(harmonic)
    coefficients, *_ = np.linalg.lstsq(np.column_stack(columns), signal, rcond=None)
    amplitudes = np.asarray([
        math.hypot(coefficients[1 + 2 * index], coefficients[2 + 2 * index])
        for index, _ in enumerate(valid_harmonics)
    ])
    if amplitudes.size < 2 or amplitudes[0] == 0:
        raise ValueError("fundamental could not be estimated")
    return float(100.0 * np.sqrt(np.sum(amplitudes[1:] ** 2)) / amplitudes[0])

