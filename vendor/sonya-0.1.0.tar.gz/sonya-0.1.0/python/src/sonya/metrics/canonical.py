from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
from numpy.typing import ArrayLike, NDArray

from .frequency import FrequencyMetrics, corrected_frequency_metrics


@dataclass(frozen=True)
class TransientMetrics:
    output_rms: float
    input_rms: float
    gain_rms: float
    output_power_w: float
    thd_percent: float
    harmonic_amplitudes: tuple[float, ...]


@dataclass(frozen=True)
class SlewMetrics:
    slew_v_per_s: float
    rising_v_per_s: float
    falling_v_per_s: float
    crossing_count: int
    minimum_v: float
    maximum_v: float


def _waveform(time: ArrayLike, values: ArrayLike) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    x = np.asarray(time, dtype=float)
    y = np.asarray(values, dtype=float)
    if x.ndim != 1 or y.shape != x.shape or x.size < 3:
        raise ValueError("waveform must contain matching one-dimensional arrays")
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
        raise ValueError("waveform contains non-finite values")
    keep = np.concatenate(([True], np.diff(x) > 0))
    x, y = x[keep], y[keep]
    if x.size < 3 or np.any(np.diff(x) <= 0):
        raise ValueError("waveform time must be strictly increasing")
    return x, y


def _time_mean_square(time: NDArray[np.float64], values: NDArray[np.float64]) -> float:
    duration = float(time[-1] - time[0])
    if duration <= 0:
        raise ValueError("waveform has zero duration")
    return float(np.trapezoid(values * values, time) / duration)


def harmonic_fit(
    time: ArrayLike,
    values: ArrayLike,
    fundamental_hz: float,
    harmonics: int = 10,
    cycles: int = 10,
    samples_per_cycle: int = 1000,
) -> tuple[float, tuple[float, ...]]:
    """Fit harmonics on a fixed steady-state grid shared by every backend."""
    x, y = _waveform(time, values)
    if fundamental_hz <= 0 or harmonics < 2 or cycles < 1 or samples_per_cycle < 2 * harmonics + 1:
        raise ValueError("invalid harmonic-fit settings")
    duration = cycles / fundamental_hz
    stop = float(x[-1])
    start = stop - duration
    if start < x[0]:
        raise ValueError("waveform is too short for the requested harmonic window")
    count = cycles * samples_per_cycle
    grid = np.linspace(start, stop, count, endpoint=False)
    signal = np.interp(grid, x, y)
    columns: list[NDArray[np.float64]] = [np.ones(count)]
    for order in range(1, harmonics + 1):
        angle = 2.0 * np.pi * fundamental_hz * order * grid
        columns.extend((np.sin(angle), np.cos(angle)))
    coefficients = np.linalg.lstsq(np.column_stack(columns), signal, rcond=None)[0]
    amplitudes = tuple(
        float(np.hypot(coefficients[2 * order - 1], coefficients[2 * order]))
        for order in range(1, harmonics + 1)
    )
    if amplitudes[0] == 0:
        return math.inf, amplitudes
    thd = 100.0 * math.sqrt(sum(value * value for value in amplitudes[1:])) / amplitudes[0]
    return thd, amplitudes


def transient_metrics(
    time: ArrayLike,
    output: ArrayLike,
    input_signal: ArrayLike,
    load_ohm: float,
    fundamental_hz: float,
    harmonics: int = 10,
    thd_cycles: int = 10,
    samples_per_cycle: int = 1000,
) -> TransientMetrics:
    x, out = _waveform(time, output)
    input_time, source = _waveform(time, input_signal)
    if not np.array_equal(x, input_time):
        source = np.interp(x, input_time, source)
    if load_ohm <= 0:
        raise ValueError("load resistance must be positive")
    output_rms = math.sqrt(_time_mean_square(x, out))
    input_rms = math.sqrt(_time_mean_square(x, source))
    thd, amplitudes = harmonic_fit(x, out, fundamental_hz, harmonics, thd_cycles, samples_per_cycle)
    return TransientMetrics(
        output_rms=output_rms,
        input_rms=input_rms,
        gain_rms=output_rms / input_rms,
        output_power_w=(output_rms * output_rms) / load_ohm,
        thd_percent=thd,
        harmonic_amplitudes=amplitudes,
    )


def frequency_metrics(frequency_hz: ArrayLike, magnitude_db: ArrayLike, targets_hz: ArrayLike) -> FrequencyMetrics:
    """Use the physical -3.0103 dB definition for every simulator."""
    return corrected_frequency_metrics(frequency_hz, magnitude_db, targets_hz)


def slew_metrics(
    time: ArrayLike,
    output: ArrayLike,
    fit_fraction: tuple[float, float] = (0.2, 0.8),
    resample_interval_s: float = 1e-7,
) -> SlewMetrics:
    """Estimate rising and falling slew from central-range linear fits.

    Using a fixed grid and a 20--80% fit avoids selecting one simulator-specific
    derivative sample. The conservative result is the slower median edge.
    """
    x, y = _waveform(time, output)
    lower_fraction, upper_fraction = fit_fraction
    if not 0 <= lower_fraction < upper_fraction <= 1 or resample_interval_s <= 0:
        raise ValueError("invalid slew extraction settings")
    count = max(3, int(math.floor((x[-1] - x[0]) / resample_interval_s)) + 1)
    grid = np.linspace(x[0], x[-1], count)
    signal = np.interp(grid, x, y)
    minimum, maximum = float(np.min(signal)), float(np.max(signal))
    span = maximum - minimum
    if span <= 0:
        raise ValueError("slew waveform has no voltage span")
    low = minimum + lower_fraction * span
    high = minimum + upper_fraction * span
    midpoint = (low + high) / 2.0
    crossings = np.flatnonzero((signal[:-1] - midpoint) * (signal[1:] - midpoint) <= 0)
    rising: list[float] = []
    falling: list[float] = []
    for crossing in crossings:
        left = crossing
        while left > 0 and low <= signal[left - 1] <= high:
            left -= 1
        right = crossing + 1
        while right + 1 < signal.size and low <= signal[right + 1] <= high:
            right += 1
        if right - left + 1 < 3:
            continue
        slope = float(np.polyfit(grid[left : right + 1], signal[left : right + 1], 1)[0])
        (rising if slope > 0 else falling).append(slope)
    if not rising or not falling:
        raise ValueError("slew waveform does not contain both rising and falling transitions")
    rising_value = float(np.median(rising))
    falling_value = float(np.median(falling))
    conservative = min(rising_value, abs(falling_value))
    return SlewMetrics(conservative, rising_value, falling_value, len(rising) + len(falling), minimum, maximum)


def window_extrema(
    time: ArrayLike,
    output: ArrayLike,
    window_seconds: float,
    window_count: int,
    resample_interval_s: float,
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Extract GM extrema on a backend-independent, fixed time grid."""
    x, y = _waveform(time, output)
    if window_seconds <= 0 or window_count < 1 or resample_interval_s <= 0:
        raise ValueError("invalid GM extraction settings")
    stop = window_count * window_seconds
    if x[0] > 0 or x[-1] < stop:
        raise ValueError("waveform does not cover all GM windows")
    count = int(round(stop / resample_interval_s)) + 1
    grid = np.linspace(0.0, stop, count)
    signal = np.interp(grid, x, y)
    minima: list[float] = []
    maxima: list[float] = []
    for index in range(window_count):
        start = 0.001 if index == 0 else index * window_seconds
        end = (index + 1) * window_seconds
        mask = (grid >= start) & (grid <= end)
        minima.append(float(np.min(signal[mask])))
        maxima.append(float(np.max(signal[mask])))
    return np.asarray(minima), np.asarray(maxima)
