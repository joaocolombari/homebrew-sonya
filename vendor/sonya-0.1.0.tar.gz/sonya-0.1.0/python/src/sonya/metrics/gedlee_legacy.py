from __future__ import annotations

import math
import warnings

import numpy as np
from numpy.typing import ArrayLike
from scipy.integrate import quad
from scipy.interpolate import CubicSpline, PchipInterpolator, UnivariateSpline


def _transfer_curve(
    minimum_values: ArrayLike,
    maximum_values: ArrayLike,
    gain_reference: float,
    input_step_v: float,
) -> tuple[np.ndarray, np.ndarray]:
    minima = np.asarray(minimum_values, dtype=float)
    maxima = np.asarray(maximum_values, dtype=float)
    if minima.size == 0 or minima.shape != maxima.shape or not math.isfinite(gain_reference) or gain_reference == 0:
        raise ValueError("invalid GM transfer-curve data")
    minima = minima[::-1]
    centre = 0.5 * (maxima[0] + minima[-1])
    values = np.concatenate((minima[:-1], [centre], maxima[1:]))
    inputs = np.arange(-(values.size - 1) / 2, (values.size - 1) / 2 + 1) * input_step_v
    gain_applied = gain_reference * np.max(np.abs(inputs))
    if gain_applied == 0 or not math.isfinite(gain_applied):
        raise ValueError("invalid GM gain normalization")
    return inputs, values / gain_applied


def _integrated_second_derivative(inputs: np.ndarray, spline: object) -> tuple[float, float]:
    derivative = spline.derivative(2)  # type: ignore[attr-defined]

    def integrand(value: float) -> float:
        second = float(derivative(value))
        return math.cos(value * math.pi / 2.0) ** 2 * second * second

    internal_knots = [float(value) for value in inputs if -1.0 < value < 1.0]
    integral, error = quad(integrand, -1.0, 1.0, points=internal_knots, epsabs=1e-10, epsrel=1e-8, limit=1000)
    return math.sqrt(max(0.0, integral)), error


def robust_gedlee_metric(
    minimum_values: ArrayLike,
    maximum_values: ArrayLike,
    gain_reference: float = 1.0,
    input_step_v: float = 0.01,
    method: str = "cubic_analytic",
    smoothing_strength: float = 5e-4,
) -> float:
    """GM with analytic derivatives and optional shape preservation/smoothing.

    ``cubic_analytic`` keeps the legacy cubic interpolation but removes its
    dependence on an arbitrary dense evaluation grid. ``pchip_analytic``
    prevents spline overshoot. ``smoothing_spline`` additionally attenuates
    small extrema errors before taking the noise-amplifying second derivative.
    The smoothing strength is an RMS residual target in normalized output.
    """
    inputs, values = _transfer_curve(minimum_values, maximum_values, gain_reference, input_step_v)
    if inputs[0] > -1.0 or inputs[-1] < 1.0:
        raise ValueError("robust GM requires measurements spanning the normalized -1..1 domain")
    selected = method.lower()
    if selected == "cubic_analytic":
        spline = CubicSpline(inputs, values, bc_type="not-a-knot", extrapolate=False)
    elif selected == "pchip_analytic":
        spline = PchipInterpolator(inputs, values, extrapolate=False)
    elif selected == "smoothing_spline":
        if smoothing_strength < 0:
            raise ValueError("smoothing_strength must be non-negative")
        residual_budget = values.size * smoothing_strength * smoothing_strength
        spline = UnivariateSpline(inputs, values, k=3, s=residual_budget, ext=2)
    else:
        raise ValueError(f"unknown robust GM method: {method}")
    value, _ = _integrated_second_derivative(inputs, spline)
    return value


def robust_gedlee_stability(
    minimum_values: ArrayLike,
    maximum_values: ArrayLike,
    gain_reference: float = 1.0,
    input_step_v: float = 0.01,
    method: str = "cubic_analytic",
    smoothing_strength: float = 5e-4,
    strides: tuple[int, ...] = (1, 2, 4),
) -> dict[str, object]:
    """Evaluate GM after deterministic thinning of the amplitude sweep."""
    inputs, values = _transfer_curve(minimum_values, maximum_values, gain_reference, input_step_v)
    estimates: dict[str, float] = {}
    for stride in strides:
        if stride < 1:
            raise ValueError("GM stability strides must be positive")
        indices = np.arange(0, inputs.size, stride)
        if indices[-1] != inputs.size - 1:
            indices = np.append(indices, inputs.size - 1)
        selected_inputs = inputs[indices]
        selected_values = values[indices]
        if method == "cubic_analytic":
            spline = CubicSpline(selected_inputs, selected_values, bc_type="not-a-knot", extrapolate=False)
        elif method == "pchip_analytic":
            spline = PchipInterpolator(selected_inputs, selected_values, extrapolate=False)
        elif method == "smoothing_spline":
            residual_budget = selected_values.size * smoothing_strength * smoothing_strength
            spline = UnivariateSpline(selected_inputs, selected_values, k=3, s=residual_budget, ext=2)
        else:
            raise ValueError(f"unknown robust GM method: {method}")
        estimates[str(stride)] = _integrated_second_derivative(selected_inputs, spline)[0]
    values_array = np.asarray(tuple(estimates.values()), dtype=float)
    median = float(np.median(values_array))
    relative_span = math.inf if median == 0 else float((np.max(values_array) - np.min(values_array)) / abs(median))
    return {
        "method": method,
        "smoothing_strength": smoothing_strength if method == "smoothing_spline" else None,
        "estimates_by_stride": estimates,
        "median": median,
        "relative_span": relative_span,
        "stable": relative_span <= 0.05,
    }


def extract_window_extrema(values: ArrayLike, sample_rate_hz: float, window_seconds: float = 0.002) -> tuple[np.ndarray, np.ndarray]:
    data = np.asarray(values, dtype=float)
    window_samples = round(sample_rate_hz * window_seconds)
    if window_samples <= 0:
        raise ValueError("window size is less than one sample")
    count = data.size // window_samples
    if count == 0:
        raise ValueError("waveform is shorter than one GM window")
    blocks = data[: count * window_samples].reshape(count, window_samples)
    return np.min(blocks, axis=1), np.max(blocks, axis=1)


def legacy_gedlee_metric(
    minimum_values: ArrayLike,
    maximum_values: ArrayLike,
    gain_reference: float = 1.0,
    input_step_v: float = 0.01,
    interpolation_points: int = 1000,
) -> float:
    """Port of ``gedlee_from_meas.m`` for baseline/ablation comparisons only.

    It reconstructs a memoryless transfer curve from window extrema. It does
    not establish periodic steady state or test history, recovery, or memory.
    """
    try:
        inputs, values = _transfer_curve(minimum_values, maximum_values, gain_reference, input_step_v)
    except ValueError:
        return math.inf
    dense_x = np.linspace(-1.0, 1.0, interpolation_points)
    if inputs[0] > -1.0 or inputs[-1] < 1.0:
        warnings.warn("legacy GM spline extrapolates beyond the measured input range", RuntimeWarning, stacklevel=2)
    dense_y = CubicSpline(inputs, values, bc_type="not-a-knot", extrapolate=True)(dense_x)
    first = np.gradient(dense_y, dense_x)
    second = np.gradient(first, dense_x)
    integrand = np.cos(dense_x * np.pi / 2.0) ** 2 * second**2
    return float(np.sqrt(np.trapezoid(integrand, dense_x)))
