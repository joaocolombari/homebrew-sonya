from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
from numpy.typing import ArrayLike
from scipy.interpolate import PchipInterpolator


@dataclass(frozen=True)
class FrequencyMetrics:
    low_cutoff_hz: float
    high_cutoff_hz: float
    sampled_std_db: float
    peak_db: float
    cutoff_level_db: float
    method: str


def _crossing(x1: float, y1: float, x2: float, y2: float, target: float) -> float:
    if y2 == y1:
        return float((x1 + x2) / 2.0)
    return float(x1 + (target - y1) * (x2 - x1) / (y2 - y1))


def _metrics(frequency_hz: ArrayLike, magnitude_db: ArrayLike, targets_hz: ArrayLike, cutoff_level: float, method: str) -> FrequencyMetrics:
    frequency = np.asarray(frequency_hz, dtype=float)
    magnitude = np.asarray(magnitude_db, dtype=float)
    targets = np.asarray(targets_hz, dtype=float)
    if frequency.ndim != 1 or magnitude.shape != frequency.shape or frequency.size < 3:
        raise ValueError("frequency response must contain matching one-dimensional arrays")
    if np.any(frequency <= 0) or np.any(np.diff(frequency) <= 0):
        raise ValueError("frequency values must be positive and strictly increasing")
    peak_index = int(np.argmax(magnitude))
    low_candidates = np.flatnonzero(magnitude[: peak_index + 1] <= cutoff_level)
    if low_candidates.size == 0 or low_candidates[-1] >= peak_index:
        low = math.nan
    else:
        index = int(low_candidates[-1])
        low = _crossing(frequency[index], magnitude[index], frequency[index + 1], magnitude[index + 1], cutoff_level)
    high_relative = np.flatnonzero(magnitude[peak_index:] <= cutoff_level)
    if high_relative.size == 0 or high_relative[0] == 0:
        high = math.inf
    else:
        index = peak_index + int(high_relative[0])
        high = _crossing(frequency[index - 1], magnitude[index - 1], frequency[index], magnitude[index], cutoff_level)
    interpolator = PchipInterpolator(np.log10(frequency), magnitude, extrapolate=True)
    sampled = interpolator(np.log10(targets))
    return FrequencyMetrics(low, high, float(np.std(sampled, ddof=1)), float(magnitude[peak_index]), cutoff_level, method)


def legacy_frequency_metrics(frequency_hz: ArrayLike, magnitude_db: ArrayLike, targets_hz: ArrayLike) -> FrequencyMetrics:
    """Reproduce the MATLAB evaluation, including its dB-domain cutoff bug."""
    peak = float(np.max(np.asarray(magnitude_db, dtype=float)))
    return _metrics(frequency_hz, magnitude_db, targets_hz, peak / math.sqrt(2.0), "legacy_db_divided_by_sqrt2")


def corrected_frequency_metrics(frequency_hz: ArrayLike, magnitude_db: ArrayLike, targets_hz: ArrayLike) -> FrequencyMetrics:
    peak = float(np.max(np.asarray(magnitude_db, dtype=float)))
    return _metrics(frequency_hz, magnitude_db, targets_hz, peak - 3.01029995664, "corrected_minus_3.0103_db")

