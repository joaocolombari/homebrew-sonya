from __future__ import annotations

from dataclasses import asdict, dataclass
import math

import numpy as np
from numpy.polynomial import Chebyshev
from numpy.typing import ArrayLike, NDArray
from scipy.integrate import quad


@dataclass(frozen=True)
class CroweGedleeResult:
    """Spectral, phase-aware approximation of the static GedLee transfer curve.

    The fundamental is normalized to unity.  Harmonic phases are referred to
    the fundamental in cosine convention.  Quadrature terms are reported as a
    memory diagnostic and are not folded into the static transfer curve.
    """

    value: float
    fundamental_amplitude_v: float
    harmonic_orders: tuple[int, ...]
    relative_amplitudes: tuple[float, ...]
    relative_phases_deg: tuple[float, ...]
    chebyshev_coefficients: tuple[float, ...]
    quadrature_coefficients: tuple[float, ...]
    memory_ratio: float
    fit_residual_rms_relative: float
    cycles: int
    samples_per_cycle: int

    def record(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class _CroweSpectrum:
    dc: float
    amplitudes: NDArray[np.float64]
    phases: NDArray[np.float64]
    signal_variance: float
    cycles: int
    samples_per_cycle: int


def _steady_grid(
    time: ArrayLike,
    values: ArrayLike,
    fundamental_hz: float,
    cycles: int,
    samples_per_cycle: int,
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    x = np.asarray(time, dtype=float)
    y = np.asarray(values, dtype=float)
    if x.ndim != 1 or y.shape != x.shape or x.size < 3:
        raise ValueError("waveform must contain matching one-dimensional arrays")
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
        raise ValueError("waveform contains non-finite values")
    keep = np.concatenate(([True], np.diff(x) > 0))
    x, y = x[keep], y[keep]
    if fundamental_hz <= 0 or cycles < 1 or samples_per_cycle < 3:
        raise ValueError("invalid spectral GM sampling settings")
    duration = cycles / fundamental_hz
    stop = float(x[-1])
    start = stop - duration
    if start < x[0]:
        raise ValueError("waveform is too short for the requested spectral GM window")
    count = cycles * samples_per_cycle
    grid = np.linspace(start, stop, count, endpoint=False)
    return grid, np.interp(grid, x, y)


def _harmonic_spectrum(
    values: NDArray[np.float64],
    harmonics: int,
    cycles: int,
    samples_per_cycle: int,
) -> _CroweSpectrum:
    if harmonics < 2 or values.size < 2 * harmonics + 1:
        raise ValueError("spectral GM requires at least two resolvable harmonics")
    # The grid contains an integer number of cycles, so the requested Fourier
    # components fall exactly on DFT bins.  Computing the spectrum once avoids
    # repeated, large least-squares systems during adaptive-order convergence.
    spectrum = np.fft.rfft(values) / values.size
    bins = np.arange(1, harmonics + 1, dtype=int) * cycles
    if bins[-1] >= spectrum.size:
        raise ValueError("samples_per_cycle cannot resolve the requested harmonic order")
    components = spectrum[bins]
    amplitudes = 2.0 * np.abs(components)
    phases = np.angle(components)
    dc = float(np.real(spectrum[0]))
    signal_variance = float(np.mean((values - dc) ** 2))
    return _CroweSpectrum(dc, amplitudes, phases, signal_variance, cycles, samples_per_cycle)


def _result_from_spectrum(spectrum: _CroweSpectrum, harmonics: int) -> CroweGedleeResult:
    amplitudes = spectrum.amplitudes[:harmonics]
    phases = spectrum.phases[:harmonics]
    fundamental = float(amplitudes[0])
    if not math.isfinite(fundamental) or fundamental <= np.finfo(float).eps:
        raise ValueError("spectral GM fundamental amplitude is zero")
    orders = np.arange(1, harmonics + 1, dtype=float)
    relative_amplitudes = amplitudes / fundamental
    relative_phases = np.angle(np.exp(1j * (phases - orders * phases[0])))
    static = relative_amplitudes * np.cos(relative_phases)
    quadrature = relative_amplitudes * np.sin(relative_phases)
    static[0] = 1.0
    quadrature[0] = 0.0
    chebyshev = np.concatenate(([spectrum.dc / fundamental], static))
    nonlinear_static_energy = float(np.sum(static[1:] ** 2))
    quadrature_energy = float(np.sum(quadrature[1:] ** 2))
    denominator = math.sqrt(max(nonlinear_static_energy + quadrature_energy, np.finfo(float).eps))
    explained_variance = 0.5 * float(np.sum(amplitudes * amplitudes))
    residual_rms = math.sqrt(max(0.0, spectrum.signal_variance - explained_variance))
    return CroweGedleeResult(
        value=_gm_from_chebyshev(chebyshev),
        fundamental_amplitude_v=fundamental,
        harmonic_orders=tuple(range(1, harmonics + 1)),
        relative_amplitudes=tuple(float(value) for value in relative_amplitudes),
        relative_phases_deg=tuple(float(np.degrees(value)) for value in relative_phases),
        chebyshev_coefficients=tuple(float(value) for value in chebyshev),
        quadrature_coefficients=tuple(float(value) for value in quadrature),
        memory_ratio=math.sqrt(quadrature_energy) / denominator,
        fit_residual_rms_relative=residual_rms / fundamental,
        cycles=spectrum.cycles,
        samples_per_cycle=spectrum.samples_per_cycle,
    )


def _gm_from_chebyshev(coefficients: ArrayLike) -> float:
    curve = Chebyshev(np.asarray(coefficients, dtype=float))
    second = curve.deriv(2)

    def integrand(value: float) -> float:
        curvature = float(second(value))
        return math.cos(value * math.pi / 2.0) ** 2 * curvature * curvature

    integral, _ = quad(integrand, -1.0, 1.0, epsabs=1e-11, epsrel=1e-9, limit=1000)
    return math.sqrt(max(0.0, integral))


def crowe_gedlee_metric(
    time: ArrayLike,
    output: ArrayLike,
    fundamental_hz: float,
    harmonics: int = 20,
    cycles: int = 20,
    samples_per_cycle: int = 1000,
) -> CroweGedleeResult:
    """Calculate phase-aware spectral GM from one steady sinusoidal test.

    A fixed-amplitude sine traverses the complete normalized input range.  The
    output is fitted as a harmonic series, amplitudes are divided by H1 and
    phases are referred to H1.  The in-phase terms form a Chebyshev expansion
    of the best static transfer curve.  The remaining quadrature energy is
    exposed as ``memory_ratio`` instead of being mistaken for static curvature.
    """
    _, signal = _steady_grid(time, output, fundamental_hz, cycles, samples_per_cycle)
    spectrum = _harmonic_spectrum(signal, harmonics, cycles, samples_per_cycle)
    return _result_from_spectrum(spectrum, harmonics)


def crowe_gedlee_adaptive(
    time: ArrayLike,
    output: ArrayLike,
    fundamental_hz: float,
    harmonic_orders: tuple[int, ...] = (10, 20, 40, 60, 80, 100, 120, 150, 200, 250, 300, 400),
    cycles: int = 20,
    samples_per_cycle: int = 4000,
    convergence_tolerance: float = 0.005,
    consecutive_converged_steps: int = 2,
) -> tuple[CroweGedleeResult, dict[str, object]]:
    """Increase harmonic order until successive GM estimates reach a plateau.

    Convergence is accepted only after ``consecutive_converged_steps`` relative
    changes meet the tolerance.  The highest configured order is returned with
    ``converged=false`` when no plateau is found, so callers can retain the
    diagnostic without silently treating a truncated result as stable.
    """
    orders = tuple(int(value) for value in harmonic_orders)
    if len(orders) < 2 or any(value < 2 for value in orders) or any(right <= left for left, right in zip(orders, orders[1:])):
        raise ValueError("adaptive harmonic orders must be a strictly increasing sequence with at least two entries")
    if convergence_tolerance < 0 or consecutive_converged_steps < 1:
        raise ValueError("invalid adaptive GM convergence settings")
    if samples_per_cycle < 2 * orders[-1] + 1:
        raise ValueError("samples_per_cycle cannot resolve the maximum adaptive harmonic order")

    _, signal = _steady_grid(time, output, fundamental_hz, cycles, samples_per_cycle)
    spectrum = _harmonic_spectrum(signal, orders[-1], cycles, samples_per_cycle)
    estimates: dict[str, float] = {}
    relative_changes: dict[str, float | None] = {}
    selected: CroweGedleeResult | None = None
    previous: float | None = None
    passing = 0
    converged = False
    for order in orders:
        result = _result_from_spectrum(spectrum, order)
        estimates[str(order)] = result.value
        change = None if previous is None else abs(result.value - previous) / max(abs(result.value), np.finfo(float).eps)
        relative_changes[str(order)] = change
        passing = passing + 1 if change is not None and change <= convergence_tolerance else 0
        selected = result
        previous = result.value
        if passing >= consecutive_converged_steps:
            converged = True
            break
    assert selected is not None
    return selected, {
        "method": "adaptive_harmonic_order",
        "configured_orders": list(orders),
        "estimates_by_max_harmonic": estimates,
        "relative_changes": relative_changes,
        "selected_harmonics": selected.harmonic_orders[-1],
        "convergence_tolerance": convergence_tolerance,
        "consecutive_converged_steps": consecutive_converged_steps,
        "converged": converged,
        "stable": converged,
    }


def crowe_gedlee_stability(
    time: ArrayLike,
    output: ArrayLike,
    fundamental_hz: float,
    harmonic_limits: tuple[int, ...] = (5, 10, 15, 20),
    cycles: int = 20,
    samples_per_cycle: int = 1000,
    tolerance: float = 0.05,
) -> dict[str, object]:
    """Report convergence as the retained harmonic order increases."""
    if not harmonic_limits or any(value < 2 for value in harmonic_limits) or tolerance < 0:
        raise ValueError("invalid spectral GM stability settings")
    estimates = {
        str(limit): crowe_gedlee_metric(
            time,
            output,
            fundamental_hz,
            harmonics=limit,
            cycles=cycles,
            samples_per_cycle=samples_per_cycle,
        ).value
        for limit in harmonic_limits
    }
    values = np.asarray(tuple(estimates.values()), dtype=float)
    median = float(np.median(values))
    relative_span = math.inf if median == 0 else float((np.max(values) - np.min(values)) / abs(median))
    return {
        "estimates_by_max_harmonic": estimates,
        "median": median,
        "relative_span": relative_span,
        "stable": relative_span <= tolerance,
        "tolerance": tolerance,
    }
