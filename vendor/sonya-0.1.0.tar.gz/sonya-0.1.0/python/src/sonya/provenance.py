from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import Iterable


def sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_provenance(output: str | Path, inputs: Iterable[str | Path], operation: str, metadata: dict[str, object] | None = None) -> Path:
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "operation": operation,
        "inputs": [{"path": str(Path(item).resolve()), "sha256": sha256(item)} for item in inputs],
        "metadata": metadata or {},
    }
    target.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return target

