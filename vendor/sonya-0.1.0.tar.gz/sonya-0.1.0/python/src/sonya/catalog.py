from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal

from .config import SonyaConfig
from .topology import load_topology_manifest


ImplementationStatus = Literal["implemented", "experimental", "planned", "protocol_pending"]


@dataclass(frozen=True)
class AlgorithmParameter:
    id: str
    kind: Literal["integer", "number", "parameter_list"]
    default: object
    minimum: float | None = None
    maximum: float | None = None
    description: str = ""


@dataclass(frozen=True)
class AlgorithmSpec:
    id: str
    name: str
    status: ImplementationStatus
    multiobjective: bool
    description: str
    parameters: tuple[AlgorithmParameter, ...]


@dataclass(frozen=True)
class TopologySpec:
    id: str
    name: str
    status: ImplementationStatus
    description: str
    parameter_count: int
    analyses: tuple[str, ...]
    simulator_support: dict[str, str]
    circuit: str
    diagram: str | None
    diagram_caption: str | None
    manifest: str


@dataclass(frozen=True)
class MetricSpec:
    id: str
    name: str
    tier: Literal["screening", "engineering", "programme", "subjective"]
    status: ImplementationStatus
    direction: Literal["minimize", "maximize", "diagnostic"]
    captures_memory: Literal["no", "indirect"]
    description: str


ALGORITHMS = (
    AlgorithmSpec(
        id="bounded_grid",
        name="Bounded grid smoke search",
        status="implemented",
        multiobjective=False,
        description="Busca determinística reduzida usada para validar o pipeline completo de otimização.",
        parameters=(
            AlgorithmParameter("count", "integer", 3, 1, 8, "Candidate count including the baseline."),
            AlgorithmParameter("step", "number", 0.05, 0.0001, 0.25, "Fractional perturbation step."),
            AlgorithmParameter("vary", "parameter_list", ["X1"], description="Circuit parameters to perturb."),
        ),
    ),
    AlgorithmSpec(
        id="differential_evolution",
        name="Differential evolution",
        status="implemented",
        multiobjective=False,
        description="Baseline escalar DE/rand/1/bin para ablação e identificação de parâmetros; não é a busca Pareto principal.",
        parameters=(
            AlgorithmParameter("population_size", "integer", 20, 4, None, "Candidatos mantidos por geração; populações maiores aumentam a diversidade, mas consomem mais do orçamento antes de evoluir."),
            AlgorithmParameter("evaluation_budget", "integer", 200, 4, None, "Número de circuitos únicos, independente da quantidade de gerações."),
            AlgorithmParameter("mutation_factor", "number", 0.8, 0.000001, 2.0, "Peso diferencial F: escala a diferença entre dois vetores; valores maiores produzem passos mais largos."),
            AlgorithmParameter("crossover_probability", "number", 0.9, 0.0, 1.0, "Probabilidade binomial CR: fração esperada de coordenadas herdadas do vetor mutante."),
            AlgorithmParameter("seed", "integer", 0, description="Semente aleatória que reproduz a população inicial e as decisões estocásticas."),
        ),
    ),
    AlgorithmSpec(
        id="gde3",
        name="GDE3 multiobjective differential evolution",
        status="implemented",
        multiobjective=True,
        description="Segunda heurística Pareto, baseada em evolução diferencial, usada para conferir a cobertura do NSGA-II sem escalarizar objetivos.",
        parameters=(
            AlgorithmParameter("population_size", "integer", 40, 4, None, "Candidatos mantidos por geração; populações maiores cobrem melhor a frente, mas deixam menos gerações no mesmo orçamento."),
            AlgorithmParameter("evaluation_budget", "integer", 200, 4, None, "Número de circuitos únicos, independente da quantidade de gerações."),
            AlgorithmParameter("mutation_factor", "number", 0.8, 0.000001, 2.0, "Peso diferencial F: escala a diferença entre dois vetores; valores maiores exploram de forma mais agressiva."),
            AlgorithmParameter("crossover_probability", "number", 0.9, 0.0, 1.0, "Probabilidade binomial CR: fração esperada de parâmetros herdados do vetor mutante."),
            AlgorithmParameter("seed", "integer", 0, description="Semente aleatória que reproduz a população inicial e as decisões estocásticas."),
        ),
    ),
    AlgorithmSpec(
        id="nsga2",
        name="NSGA-II",
        status="implemented",
        multiobjective=True,
        description="Busca Pareto principal em potência, slew rate, uniformidade e GM-Crowe; THD permanece registrada como diagnóstico.",
        parameters=(
            AlgorithmParameter("population_size", "integer", 40, 4, None, "Pais mantidos por geração; populações maiores aumentam diversidade e cobertura, mas deixam menos gerações no orçamento fixo."),
            AlgorithmParameter("evaluation_budget", "integer", 200, 4, None, "Número de circuitos únicos, independente da quantidade de gerações."),
            AlgorithmParameter("seed", "integer", 0, description="Semente que reproduz inicialização, torneios, crossover e mutação."),
        ),
    ),
    AlgorithmSpec(
        id="legacy_pso",
        name="Legacy particle swarm reference",
        status="implemented",
        multiobjective=False,
        description="Referência de compatibilidade comportamental com o PSO do MATLAB, usando o score escalar histórico.",
        parameters=(
            AlgorithmParameter("population_size", "integer", 20, 2, None, "Número de partículas que percorrem simultaneamente o espaço de projeto."),
            AlgorithmParameter("evaluation_budget", "integer", 200, 2, None, "Máximo de circuitos únicos; os coeficientes do enxame permanecem fixos na implementação histórica."),
            AlgorithmParameter("seed", "integer", 0, description="Semente que reproduz posições iniciais e atualizações de velocidade."),
        ),
    ),
    AlgorithmSpec(
        id="legacy_sam",
        name="Legacy simulated annealing reference",
        status="implemented",
        multiobjective=False,
        description="Port comportamental do SAM histórico, com resfriamento e crossover com a elite, para comparação pelo score escalar.",
        parameters=(
            AlgorithmParameter("evaluation_budget", "integer", 200, 2, None, "Máximo de circuitos únicos avaliados."),
            AlgorithmParameter("initial_temperature", "number", 50.0, 0.000001, None, "Tolerância inicial para aceitar pioras do score; fixa em 50 no adaptador atual de campanha."),
            AlgorithmParameter("cooling", "number", 0.9, 0.000001, 0.999999, "Multiplicador de temperatura após cada bloco; fixo em 0,9 no adaptador atual de campanha."),
            AlgorithmParameter("seed", "integer", 0, description="Semente que reproduz propostas e aceitações probabilísticas."),
        ),
    ),
)


METRICS = (
    MetricSpec(
        "gm_legacy",
        "GM-Legacy",
        "screening",
        "implemented",
        "diagnostic",
        "no",
        "Fast psychoacoustically motivated baseline metric; not a complete model of memory.",
    ),
    MetricSpec(
        "gm_crowe",
        "GM-Crowe",
        "engineering",
        "implemented",
        "diagnostic",
        "no",
        "Single-tone spectral GM using normalized harmonic magnitude and phase, with harmonic-order convergence and a quadrature-residual diagnostic.",
    ),
    MetricSpec(
        "visqol_audio",
        "ViSQOLAudio",
        "programme",
        "implemented",
        "maximize",
        "indirect",
        "Full-reference programme-audio quality metric over the complete simulated waveform, including consequences of modeled time-dependent behavior.",
    ),
    MetricSpec(
        "gstpeaq_basic_odg",
        "GstPEAQ basic ODG",
        "programme",
        "implemented",
        "maximize",
        "indirect",
        "Confirmation metric from GstPEAQ; its authors do not claim BS.1387 tolerance conformance.",
    ),
    MetricSpec(
        "gstpeaq_advanced_odg",
        "GstPEAQ advanced ODG",
        "programme",
        "implemented",
        "maximize",
        "indirect",
        "Advanced-model confirmation metric, reported separately from the ViSQOL Pareto objective.",
    ),
    MetricSpec(
        "webmushra_listening_test",
        "WebMUSHRA listening validation",
        "subjective",
        "planned",
        "maximize",
        "indirect",
        "Final subjective validation using the exact reference excerpts from objective validation.",
    ),
)


def algorithm_specs() -> tuple[AlgorithmSpec, ...]:
    return ALGORITHMS


def algorithm_spec(algorithm_id: str) -> AlgorithmSpec:
    for spec in ALGORITHMS:
        if spec.id == algorithm_id:
            return spec
    raise ValueError(f"unknown algorithm: {algorithm_id}")


def metric_specs() -> tuple[MetricSpec, ...]:
    return METRICS


def topology_specs(config: SonyaConfig) -> tuple[TopologySpec, ...]:
    specs: list[TopologySpec] = []
    for manifest_path in config.topology_manifest_paths:
        manifest = load_topology_manifest(manifest_path)
        support = {backend_id: backend.status for backend_id, backend in manifest.backends.items()}
        specs.append(
            TopologySpec(
                id=manifest.id,
                name=manifest.name,
                status="implemented" if any(status in {"validated", "experimental"} for status in support.values()) else "planned",
                description=manifest.description,
                parameter_count=len(manifest.parameter_ids),
                analyses=manifest.analyses,
                simulator_support=support,
                circuit=str(manifest.circuit),
                diagram=str(manifest.diagram) if manifest.diagram else None,
                diagram_caption=manifest.diagram_caption,
                manifest=str(manifest.source),
            )
        )
    return tuple(specs)


def topology_spec(config: SonyaConfig, topology_id: str) -> TopologySpec:
    for spec in topology_specs(config):
        if spec.id == topology_id:
            return spec
    raise ValueError(f"unknown topology: {topology_id}")


def catalog_record(value: object) -> dict[str, object]:
    return asdict(value)  # type: ignore[arg-type]
