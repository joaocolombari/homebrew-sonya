from __future__ import annotations

import argparse
from dataclasses import asdict, replace
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

import numpy as np

from .catalog import algorithm_spec, algorithm_specs, catalog_record, metric_specs, topology_spec, topology_specs
from .campaign import CandidateArchive, candidate_cache_key
from .config import ConfigError, SonyaConfig, load_config
from .corpus import prepare_corpus_audition
from .data import audit_data
from .drive import calibrate_input_for_output_power, rms_to_dbv
from .legacy import evaluate_measurement_directory
from .feasibility import evaluate_declared_constraints, evaluate_parameter_constraints
from .ltspice import LTspiceRunner
from .manifest_optimization import optimize_manifest
from .heuristics import ParameterSpace, SearchEvaluation, run_search, select_for_promotion
from .installation import installation_report
from .optimization import generate_test_candidates, pipeline_test_score
from .parameters import CircuitParameters
from .parsers.legacy import read_legacy_parameters, read_legacy_results
from .perceptual import perceptual_doctors, prepare_metric_pair, run_gstpeaq, run_visqol
from .perceptual_sampling import SamplingCandidate, build_sampling_plan
from .perceptual_validation import run_programme_validation
from .programme import ProgrammeConfigError, load_programme_manifest, pareto_audit, programme_report
from .programme_simulation import benchmark_signal, run_programme
from .simulation import summarize_legacy_runs
from .provenance import sha256, write_provenance
from .run_control import RunCancelled, RunControl
from .simulators import SimulatorBackend, simulator_backend, simulator_backends
from .topology import TopologyError, create_topology_scaffold, execute_staged_topology, load_topology_manifest, stage_topology, topology_record
from .transformer import TransformerProfileError, create_transformer_profile, load_transformer_profile, render_linear_include, transformer_record


SCREENING_OBJECTIVES = (
    "maximize_output_power_w",
    "maximize_slew_rate_v_per_us",
    "minimize_frequency_std_db",
    "minimize_gm_crowe",
)


def _default_config() -> Path:
    candidates = [
        Path(os.environ["SONYA_CONFIG"]) if "SONYA_CONFIG" in os.environ else None,
        Path.cwd() / "configs" / "legacy.yaml",
        Path.cwd() / "python" / "configs" / "legacy.yaml",
        Path(__file__).resolve().parents[2] / "configs" / "legacy.yaml",
    ]
    for candidate in candidates:
        if candidate is not None and candidate.is_file():
            return candidate
    return Path("configs/legacy.yaml")


def _json(value: object) -> None:
    print(json.dumps(value, indent=2, sort_keys=True, allow_nan=True, default=str))


def _default_programme() -> Path:
    candidates = [
        Path(os.environ["SONYA_PROGRAMME"]) if "SONYA_PROGRAMME" in os.environ else None,
        Path.cwd() / "configs" / "programme.yaml",
        Path.cwd() / "python" / "configs" / "programme.yaml",
        Path(__file__).resolve().parents[2] / "configs" / "programme.yaml",
    ]
    return next((candidate for candidate in candidates if candidate is not None and candidate.is_file()), Path("configs/programme.yaml"))


def _default_corpus_audition(programme: Path) -> Path:
    source = programme.expanduser().resolve()
    project = source.parent.parent if source.parent.name == "configs" else source.parent
    return project / "corpus" / "audition"


def _parameter_bound(value: str) -> tuple[str, float, float]:
    """Parse ID:MINIMUM:MAXIMUM for campaign-specific search bounds."""
    try:
        parameter_id, minimum, maximum = value.split(":", 2)
        lower, upper = float(minimum), float(maximum)
    except (ValueError, TypeError) as exc:
        raise argparse.ArgumentTypeError("use ID:MINIMUM:MAXIMUM, for example X1:50:120") from exc
    if not parameter_id or not math.isfinite(lower) or not math.isfinite(upper) or lower >= upper:
        raise argparse.ArgumentTypeError("parameter bounds require finite MINIMUM < MAXIMUM")
    return parameter_id, lower, upper


def _default_corpus_lock(programme: Path) -> Path:
    source = programme.expanduser().resolve()
    return source.with_name(f"{source.stem}-audition.lock.json")


def _resolve_drive(
    config: SonyaConfig,
    backend: SimulatorBackend,
    parameters: dict[str, float],
    requested_mode: str | None,
    requested_target_w: float | None,
    output_root: Path,
    parameter_source: Path,
    reltol: float,
) -> tuple[float, dict[str, object]]:
    drive_cfg = config.raw["legacy_evaluation"]["drive"]
    mode = (requested_mode or str(drive_cfg["default_mode"])).replace("-", "_")
    fixed_input_rms = float(config.raw["legacy_evaluation"]["input_rms_v"])
    if mode == "fixed_input":
        return fixed_input_rms, {
            "mode": "fixed_input",
            "input_rms_v": fixed_input_rms,
            "input_dbv": rms_to_dbv(fixed_input_rms),
        }
    if mode != "matched_output_power":
        raise ValueError(f"unsupported drive mode: {mode}")
    target_w = float(requested_target_w if requested_target_w is not None else drive_cfg["matched_output_power_w"])
    calibration_root = output_root / "drive-calibration"

    def evaluate(input_rms_v: float) -> float:
        report = backend.run_legacy_mode(
            parameters,
            "tran",
            output_root=calibration_root,
            parameter_source=parameter_source,
            reltol=reltol,
            input_rms_v=input_rms_v,
        )
        measurements = report["measurements"]
        assert isinstance(measurements, dict)
        return abs(float(measurements["output_power"]))

    calibration = calibrate_input_for_output_power(
        evaluate,
        target_w,
        float(drive_cfg["calibration_min_input_rms_v"]),
        float(drive_cfg["calibration_max_input_rms_v"]),
        float(drive_cfg["calibration_relative_tolerance"]),
        int(drive_cfg["calibration_max_iterations"]),
    )
    if not calibration.converged:
        raise RuntimeError(
            f"output-power calibration did not converge: target={target_w:g} W, "
            f"achieved={calibration.achieved_output_power_w:g} W"
        )
    record = calibration.record()
    record["input_dbv"] = rms_to_dbv(calibration.input_rms_v)
    return calibration.input_rms_v, record


def _validate_data(config: SonyaConfig) -> dict[str, object]:
    roots = [config.resolve(item) for item in config.raw["data"]["raw_roots"]]
    statuses = []
    total_files = 0
    for root in roots:
        files = sum(1 for item in root.rglob("*") if item.is_file()) if root.is_dir() else 0
        total_files += files
        statuses.append({"path": str(root), "exists": root.is_dir(), "files": files})
    return {
        "config": str(config.source),
        "schema_version": config.raw["schema_version"],
        "parameters": len(config.parameters),
        "raw_roots": statuses,
        "raw_file_count": total_files,
        "processed_root": str(config.processed_root),
        "valid": all(item["exists"] for item in statuses),
    }


def _sampling_candidates_from_campaign(path: Path) -> list[SamplingCandidate]:
    report = json.loads(path.expanduser().resolve().read_text(encoding="utf-8"))
    screening = report.get("screening")
    records = screening.get("records") if isinstance(screening, dict) else None
    if not isinstance(records, list) or not records:
        raise ValueError("campaign report has no screening records")
    candidates: list[SamplingCandidate] = []
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("campaign screening record is invalid")
        candidate_id = record.get("candidate_id")
        objectives = record.get("objectives_minimization")
        if not isinstance(candidate_id, str) or not isinstance(objectives, list):
            raise ValueError("campaign screening record lacks candidate id or objectives")
        candidates.append(SamplingCandidate(candidate_id, tuple(float(value) for value in objectives)))
    return candidates


def _sampling_plan_from_args(candidates: list[SamplingCandidate], args: argparse.Namespace) -> dict[str, object]:
    wall_seconds = math.inf if args.perceptual_wall_time_hours <= 0 else 3600.0 * args.perceptual_wall_time_hours
    plan = build_sampling_plan(
        candidates,
        half_life_candidates=args.perceptual_half_life,
        seed=args.perceptual_seed if args.perceptual_seed is not None else args.seed,
        eligible_ranks=args.perceptual_eligible_ranks,
        online_max_candidates=args.perceptual_online_max,
        wall_time_budget_seconds=wall_seconds,
        estimated_cost_per_candidate_seconds=args.perceptual_estimated_cost_seconds,
        final_max_candidates=args.perceptual_final_max,
        epsilon=args.perceptual_epsilon,
        near_front_finalists=args.perceptual_near_front,
    ).record()
    plan["wall_time_budget_seconds"] = None if math.isinf(wall_seconds) else wall_seconds
    plan["status"] = "selection_plan_only_perceptual_execution_is_separate"
    return plan


def _run_perceptual_benchmark(args: argparse.Namespace, config: SonyaConfig) -> int:
    if args.duration <= 0 or args.projection_duration <= 0:
        raise ValueError("benchmark and projection durations must be positive")
    if args.projection_candidates < 1 or args.projection_clips < 1 or args.projection_levels < 1:
        raise ValueError("projection counts must be positive")
    selected = topology_spec(config, args.topology or config.default_topology_id)
    manifest = load_topology_manifest(selected.manifest)
    values = read_legacy_parameters(args.parameters)
    waveform = benchmark_signal(args.input_sample_rate, args.duration)
    if args.preroll > 0:
        waveform = np.concatenate((np.zeros(round(args.preroll * args.input_sample_rate)), waveform))
    base = args.output_root.resolve() if args.output_root else config.processed_root
    base.mkdir(parents=True, exist_ok=True)
    benchmark_root = Path(tempfile.mkdtemp(prefix="perceptual-benchmark-", dir=base))
    simulation = run_programme(
        args.backend,
        config,
        manifest,
        values,
        waveform,
        args.input_sample_rate,
        args.simulation_sample_rate,
        benchmark_root,
        reltol=args.reltol,
        timeout_seconds=args.timeout,
    )
    pair = prepare_metric_pair(
        simulation["time"],  # type: ignore[arg-type]
        simulation["input"],  # type: ignore[arg-type]
        simulation["output"],  # type: ignore[arg-type]
        benchmark_root / "metric-pair",
    )
    metrics: list[dict[str, object]] = []
    doctors = perceptual_doctors()
    if args.run_metrics:
        if next(item for item in doctors if item.id == "visqol_audio").ready:
            metrics.append(run_visqol(pair.reference, pair.degraded).record())
        if next(item for item in doctors if item.id == "gstpeaq_odg").ready:
            metrics.append(run_gstpeaq(pair.reference, pair.degraded, "basic").record())
            metrics.append(run_gstpeaq(pair.reference, pair.degraded, "advanced").record())
    elapsed = float(simulation["elapsed_seconds"])
    simulated_seconds = waveform.size / args.input_sample_rate
    projected_run_seconds = elapsed * args.projection_duration / simulated_seconds
    estimate = projected_run_seconds * args.projection_candidates * args.projection_clips * args.projection_levels
    report = {
        "status": "cost_benchmark_not_perceptual_validation",
        "topology": selected.id,
        "backend": args.backend,
        "simulation": {key: value for key, value in simulation.items() if key not in {"time", "input", "output"}},
        "metric_pair": pair.record(),
        "metric_doctors": [asdict(item) for item in doctors],
        "metrics": metrics,
        "cost": {
            "simulated_audio_seconds": simulated_seconds,
            "wall_seconds": elapsed,
            "realtime_factor": elapsed / simulated_seconds,
            "projection_candidates": args.projection_candidates,
            "projection_clips": args.projection_clips,
            "projection_levels": args.projection_levels,
            "projection_audio_seconds_per_run": args.projection_duration,
            "projected_wall_seconds_per_run": projected_run_seconds,
            "projected_serial_seconds": estimate,
            "projection_warning": "short-run initialization cost and solver nonlinearity make this an empirical estimate, not a guarantee",
        },
    }
    report_path = benchmark_root / "benchmark.json"
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
    _json({**report, "report_path": str(report_path)})
    return 0


def _run_optimization_campaign(args: argparse.Namespace, config: SonyaConfig) -> int:
    selected_topology = topology_spec(config, args.topology or config.default_topology_id)
    selected_algorithm = algorithm_spec(args.algorithm)
    if selected_algorithm.id not in {"nsga2", "gde3", "differential_evolution", "legacy_pso", "legacy_sam"} or selected_algorithm.status != "implemented":
        raise ValueError(f"algorithm {selected_algorithm.id} is not available for multi-fidelity campaigns")
    topology_manifest = load_topology_manifest(selected_topology.manifest)
    if args.backend not in topology_manifest.backends:
        raise ValueError(f"topology {selected_topology.id} does not declare backend {args.backend}")
    backend_status = topology_manifest.backends[args.backend].status
    if backend_status == "planned":
        raise ValueError(f"backend {args.backend} is not implemented for topology {selected_topology.id}")
    backend = simulator_backend(config, args.backend, topology_manifest)
    if not backend.doctor().ready:
        raise RuntimeError(f"{args.backend} is not ready; run `sonya simulator doctor --backend {args.backend}` for details")

    baseline = read_legacy_parameters(args.parameters)
    bound_overrides: dict[str, tuple[float, float]] = {}
    for parameter_id, minimum, maximum in args.parameter_bound:
        if parameter_id in bound_overrides:
            raise ValueError(f"duplicate parameter bound: {parameter_id}")
        bound_overrides[parameter_id] = (minimum, maximum)
    known_parameter_ids = {item.id for item in config.parameters}
    unknown_bounds = sorted(set(bound_overrides) - known_parameter_ids)
    if unknown_bounds:
        raise ValueError(f"unknown parameter bound(s): {', '.join(unknown_bounds)}")
    effective_parameters = tuple(
        replace(item, minimum=bound_overrides[item.id][0], maximum=bound_overrides[item.id][1])
        if item.id in bound_overrides else item
        for item in config.parameters
    )
    outside = [
        item.id for item in effective_parameters
        if not item.minimum <= float(baseline[item.id]) <= item.maximum
    ]
    if outside:
        raise ValueError(f"baseline is outside campaign bounds: {', '.join(outside)}")
    space = ParameterSpace(
        baseline,
        effective_parameters,
        config.raw["future_methodology"]["symmetry_groups"],
        config.raw["future_methodology"]["fixed_parameters"],
        args.vary,
    )
    base = args.output_root.resolve() if args.output_root else config.processed_root
    base.mkdir(parents=True, exist_ok=True)
    campaign_root = Path(tempfile.mkdtemp(prefix="optimization-campaign-", dir=base))
    archive = CandidateArchive(args.archive or campaign_root / "candidate-archive.jsonl")
    control = RunControl(args.control_file, args.event_log, run_kind="campaign")
    drive_mode = (args.drive_mode or str(config.raw["legacy_evaluation"]["drive"]["default_mode"])).replace("-", "_")
    # GM-Crowe is intentionally part of every candidate evaluation.  Unlike the
    # historical GM-Legacy sweep, it adds one inexpensive steady-state tone and
    # is therefore a practical fourth Pareto objective during the search. THD
    # remains reported, but slew rate replaces it in the electrical Pareto set.
    screening_modes = (
        ("op", "tran", "ac", "slew", "crowe")
        if selected_algorithm.multiobjective
        else ("op", "tran", "ac", "slew", "gedlee", "crowe")
    )
    input_paths = [
        config.source,
        topology_manifest.source,
        topology_manifest.circuit,
        *(dependency.source for dependency in topology_manifest.backends[args.backend].dependencies),
    ]
    protocol = {
        "topology": selected_topology.id,
        "backend": args.backend,
        "backend_status": backend_status,
        "drive_mode": drive_mode,
        "target_output_power_w": args.target_output_power,
        "reltol": args.reltol,
        "screening_modes": list(screening_modes),
        "screening_objectives": list(SCREENING_OBJECTIVES),
        "parameter_bounds": {
            item.id: {"minimum": item.minimum, "maximum": item.maximum, "unit": item.unit}
            for item in effective_parameters
        },
        "input_hashes": {str(path): sha256(path) for path in input_paths},
    }
    counters = {"simulator_runs": 0, "screening_cache_hits": 0, "engineering_cache_hits": 0}
    candidate_sequence = 0
    control.emit(
        "campaign_started",
        algorithm=selected_algorithm.id,
        backend=args.backend,
        budget=args.budget,
        population_size=args.population_size,
        campaign_root=str(campaign_root),
    )

    def screening_evaluator(values: dict[str, float]) -> SearchEvaluation:
        nonlocal candidate_sequence
        candidate_sequence += 1
        cache_key = candidate_cache_key("screening", values, protocol)
        candidate_id = cache_key[:12]
        event_context = {
            "candidate_index": candidate_sequence,
            "budget": args.budget,
            "candidate_id": candidate_id,
        }
        control.checkpoint("before_candidate", **event_context)
        control.emit("candidate_started", **event_context, values=values)
        cached = archive.get(cache_key)
        if cached is not None:
            counters["screening_cache_hits"] += 1
            cached_event = "candidate_completed" if bool(cached.get("feasible", True)) else "candidate_failed"
            control.emit(
                cached_event,
                **event_context,
                cached=True,
                objectives=cached.get("objectives"),
                metrics=cached.get("metrics"),
                failure=cached.get("failure"),
                simulator_runs=counters["simulator_runs"],
            )
            return SearchEvaluation(
                tuple(float(value) for value in cached["objectives"]),
                float(cached["scalar_score"]) if cached.get("scalar_score") is not None else None,
                bool(cached.get("feasible", True)),
                cached,
            )
        parameter_ok, parameter_results = evaluate_parameter_constraints(
            values,
            effective_parameters,
            config.raw["future_methodology"]["symmetry_groups"],
            config.raw["future_methodology"]["fixed_parameters"],
        )
        declared_ok, declared_results = evaluate_declared_constraints(
            {"vaa_v": values["X24"]}, config.raw["future_methodology"]["hard_constraints"]
        )
        if not (parameter_ok and declared_ok):
            raise ValueError("parameter-space candidate failed hard preflight")
        candidate_root = campaign_root / f"screening-{candidate_id}"
        candidate_root.mkdir(parents=True, exist_ok=True)
        candidate_input = candidate_root / "candidate.json"
        candidate_input.write_text(
            json.dumps({"id": candidate_id, "values": values}, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        reports: list[dict[str, object]] = []
        drive_record: dict[str, object] = {}
        active_analysis: str | None = None
        active_analysis_index: int | None = None
        try:
            input_rms_v, drive_record = _resolve_drive(
                config,
                backend,
                values,
                args.drive_mode,
                args.target_output_power,
                candidate_root,
                candidate_input,
                args.reltol,
            )
            calibration_evaluations = drive_record.get("evaluations", ())
            if isinstance(calibration_evaluations, (list, tuple)):
                counters["simulator_runs"] += len(calibration_evaluations)
            for analysis_index, mode in enumerate(screening_modes, start=1):
                active_analysis = mode
                active_analysis_index = analysis_index
                control.emit(
                    "analysis_started",
                    **event_context,
                    analysis=mode,
                    analysis_index=analysis_index,
                    analysis_count=len(screening_modes),
                )
                analysis_started = time.perf_counter()
                # Count attempted simulator invocations, including runs whose
                # output later proves non-finite or otherwise unusable.
                counters["simulator_runs"] += 1
                report = backend.run_legacy_mode(
                    values,
                    mode,
                    output_root=candidate_root,
                    parameter_source=candidate_input,
                    reltol=args.reltol,
                    input_rms_v=input_rms_v,
                )
                reports.append(report)
                control.emit(
                    "analysis_completed",
                    **event_context,
                    analysis=mode,
                    analysis_index=analysis_index,
                    analysis_count=len(screening_modes),
                    elapsed_seconds=time.perf_counter() - analysis_started,
                )
                active_analysis = None
                active_analysis_index = None
            summary = summarize_legacy_runs(
                reports,
                values,
                config,
                require_crowe=True,
                require_gedlee=not selected_algorithm.multiobjective,
            )
            metrics = summary["measurements"]
            assert isinstance(metrics, dict)
            objectives = (
                -float(metrics["output_power_w"]),
                -float(metrics["slew_rate_v_per_us"]),
                float(metrics["frequency_std_db"]),
                float(metrics["gm_crowe"]),
            )
            if not all(math.isfinite(value) for value in objectives):
                raise ValueError("candidate objectives contain non-finite values")
            scalar_score = float(summary["legacy_score"]) if summary["legacy_score"] is not None else None
            if scalar_score is not None and not math.isfinite(scalar_score):
                raise ValueError("candidate scalar score is non-finite")
        except (ValueError, RuntimeError, TimeoutError, subprocess.TimeoutExpired) as exc:
            if isinstance(exc, RunCancelled):
                raise
            penalty = 1.0e30
            failure = {
                "error_type": type(exc).__name__,
                "message": str(exc),
                "analysis": active_analysis,
                "analysis_index": active_analysis_index,
                "completed_analyses": [str(item.get("mode")) for item in reports],
                "candidate_root": str(candidate_root),
            }
            if active_analysis is not None:
                control.emit(
                    "analysis_failed",
                    **event_context,
                    analysis=active_analysis,
                    analysis_index=active_analysis_index,
                    analysis_count=len(screening_modes),
                    error_type=type(exc).__name__,
                    error=str(exc),
                )
            objectives = (penalty, penalty, penalty, penalty)
            stored = archive.put(cache_key, {
                "stage": "screening",
                "status": "failed",
                "candidate_id": candidate_id,
                "values": values,
                "feasible": False,
                "objectives": list(objectives),
                "scalar_score": penalty,
                "metrics": {},
                "summary": {
                    "status": "candidate_failed",
                    "optimization_eligible": False,
                    "failure": failure,
                },
                "runs": reports,
                "drive": drive_record,
                "failure": failure,
                "parameter_constraints": [asdict(item) for item in parameter_results],
                "hard_constraints": [asdict(item) for item in declared_results],
            })
            control.emit(
                "candidate_failed",
                **event_context,
                cached=False,
                failed_analysis=active_analysis,
                error_type=type(exc).__name__,
                error=str(exc),
                objectives=list(objectives),
                simulator_runs=counters["simulator_runs"],
            )
            return SearchEvaluation(objectives, penalty, False, stored)
        stored = archive.put(cache_key, {
            "stage": "screening",
            "candidate_id": candidate_id,
            "values": values,
            "feasible": True,
            "objectives": list(objectives),
            "scalar_score": scalar_score,
            "metrics": metrics,
            "summary": summary,
            "runs": reports,
            "drive": drive_record,
            "parameter_constraints": [asdict(item) for item in parameter_results],
            "hard_constraints": [asdict(item) for item in declared_results],
        })
        control.emit(
            "candidate_completed",
            **event_context,
            cached=False,
            objectives=list(objectives),
            metrics=metrics,
            simulator_runs=counters["simulator_runs"],
        )
        return SearchEvaluation(objectives, scalar_score, True, stored)

    search = run_search(
        selected_algorithm.id,
        space,
        screening_evaluator,
        args.budget,
        args.population_size,
        args.seed,
        args.mutation_factor,
        args.crossover_probability,
    )
    control.checkpoint(
        "after_search",
        completed_candidates=search.candidate_evaluations,
        budget=args.budget,
    )
    control.emit(
        "search_completed",
        completed_candidates=search.candidate_evaluations,
        front_size=len(search.pareto_front),
    )
    feasible_search_records = [record for record in search.records if record.evaluation.feasible]
    failed_search_records = [record for record in search.records if not record.evaluation.feasible]
    sampling_candidates = [SamplingCandidate(
            str(record.evaluation.metadata.get("candidate_id", record.id)),
            tuple(float(value) for value in record.evaluation.objectives),
        ) for record in feasible_search_records]
    perceptual_sampling = (
        _sampling_plan_from_args(sampling_candidates, args)
        if sampling_candidates
        else {
            "status": "not_planned_no_feasible_candidates",
            "decisions": [],
            "online_candidate_ids": [],
            "final_candidate_ids": [],
        }
    )
    promoted = (
        select_for_promotion(search, min(args.promote, len(feasible_search_records)))
        if feasible_search_records else []
    )
    promoted_ids = {
        str(item.evaluation.metadata.get("candidate_id"))
        for item in promoted
    }
    engineering_records: list[dict[str, object]] = []
    # The engineering record is now a consolidation of the complete screening
    # evidence, not an extra GM simulation.  Keeping it for every candidate
    # makes the four-dimensional Pareto audit explicit and auditable.
    for search_record in search.records:
        if not search_record.evaluation.feasible:
            continue
        values = search_record.values
        cache_key = candidate_cache_key("engineering", values, protocol)
        cached = archive.get(cache_key)
        if cached is not None:
            counters["engineering_cache_hits"] += 1
            engineering_records.append(cached)
            continue
        screening = search_record.evaluation.metadata
        reports = screening.get("runs")
        if not isinstance(reports, list):
            raise ValueError("screening archive record has no reusable simulator runs")
        candidate_id = str(screening["candidate_id"])
        summary = summarize_legacy_runs(
            reports,
            values,
            config,
            require_gedlee=not selected_algorithm.multiobjective,
        )
        metrics = summary["measurements"]
        assert isinstance(metrics, dict)
        engineering_records.append(archive.put(cache_key, {
            "stage": "engineering",
            "candidate_id": candidate_id,
            "screening_cache_key": screening.get("cache_key"),
            "values": values,
            "feasible": bool(summary["declared_constraints_feasible"] and summary["parameter_constraints_feasible"]),
            "metrics": metrics,
            "summary": summary,
            "runs": [],
            "screening_reused": True,
            "approval_eligible": bool(summary["optimization_eligible"]),
            "selected_for_shortlist": candidate_id in promoted_ids,
        }))

    engineering_objectives = {
        "output_power_w": "maximize",
        "slew_rate_v_per_us": "maximize",
        "frequency_std_db": "minimize",
        "gm_crowe": "minimize",
    }
    engineering_audit = pareto_audit(engineering_records, engineering_objectives)  # type: ignore[arg-type]
    engineering_front = engineering_audit["front"]
    assert isinstance(engineering_front, list)
    programme = programme_report(load_programme_manifest(args.programme))
    pending_layers = ["programme_metric_execution"]
    if not programme["programme_ready"]:
        pending_layers.append("programme_corpus")
    if config.raw["future_methodology"]["soa_limits_status"] != "configured":
        pending_layers.append("dynamic_soa_limits")

    perceptual_objectives = {
        "visqol_audio": "maximize",
    }
    validated_objectives = {**engineering_objectives, **perceptual_objectives}
    perceptual_evidence = (
        "programme_validation_split",
        "perceptual_adapter_versions",
        "reproducible_provenance",
    )
    scientific_evidence = (
        "dynamic_soa_validated",
        *perceptual_evidence,
    )
    # No programme adapter is executed yet.  Keeping these records empty is a
    # validity gate, not a placeholder score: development-only or incomplete
    # perceptual results must never leak into the scientifically validated front.
    programme_records: list[dict[str, object]] = []
    perceptual_audit = pareto_audit(programme_records, perceptual_objectives, perceptual_evidence)
    validated_audit = pareto_audit(programme_records, validated_objectives, scientific_evidence)

    screening_records = []
    for record in search.records:
        metadata = record.evaluation.metadata
        screening_records.append({
            "id": record.id,
            "candidate_id": metadata.get("candidate_id"),
            "values": record.values,
            "objectives_minimization": list(record.evaluation.objectives),
            "scalar_score": record.evaluation.scalar_score,
            "metrics": metadata.get("metrics"),
            "cache_key": metadata.get("cache_key"),
            "feasible": record.evaluation.feasible,
            "status": metadata.get("status", "completed" if record.evaluation.feasible else "failed"),
            "failure": metadata.get("failure"),
        })
    feasible_search_front = [item for item in search.pareto_front if item.evaluation.feasible]
    report_status = "electrical_pareto_complete" if feasible_search_records else "completed_no_feasible_candidates"
    report = {
        "schema_version": 1,
        "status": report_status,
        "scientific_claim_status": "pilot_not_fully_validated",
        "topology": selected_topology.id,
        "algorithm": selected_algorithm.id,
        "simulator_backend": args.backend,
        "simulator_backend_status": backend_status,
        "cross_backend_equivalence": "not_assumed",
        "search_space": {
            "dimensions": [asdict(item) for item in space.dimensions],
            "dimension_count": space.size,
            "baseline": baseline,
        },
        "protocol": protocol,
        "budget": {
            "requested_candidate_evaluations": args.budget,
            "used_candidate_evaluations": search.candidate_evaluations,
            "population_size": args.population_size,
            "seed": args.seed,
            "mutation_factor": args.mutation_factor if selected_algorithm.id in {"gde3", "differential_evolution"} else None,
            "crossover_probability": args.crossover_probability if selected_algorithm.id in {"gde3", "differential_evolution"} else None,
            "comparison_unit": "unique_circuit_candidates_not_generations",
        },
        "accounting": {
            **counters,
            "successful_candidates": len(feasible_search_records),
            "failed_candidates": len(failed_search_records),
            "archive_records": len(archive),
            "archive_cache_hits_total": archive.cache_hits,
            "archive_writes": archive.writes,
        },
        "screening": {
            "modes": list(screening_modes),
            "objectives": list(SCREENING_OBJECTIVES),
            "historical_scalar_score": "legacy_score_including_gm_legacy" if not selected_algorithm.multiobjective else "not_computed",
            "records": screening_records,
            "search_front_candidate_ids": [item.evaluation.metadata.get("candidate_id") for item in feasible_search_front],
        },
        "promotion": {
            "requested": args.promote,
            "selected": len(promoted),
            "policy": "representative_pareto_then_crowding_shortlist" if selected_algorithm.multiobjective else "lowest_historical_scalar_score_shortlist",
            "purpose": "representative_highlights_for_review_only_perceptual_online_and_final_selections_are_separate",
            "candidate_ids": [item.evaluation.metadata.get("candidate_id") for item in promoted],
        },
        "engineering": {
            "objectives": engineering_objectives,
            "records": engineering_records,
            "front_candidate_ids": [item["candidate_id"] for item in engineering_front],
            "pareto_audit": {key: value for key, value in engineering_audit.items() if key != "front"},
        },
        "programme": {
            "manifest": programme,
            "status": "not_run_use_perceptual_metric_command" if programme["programme_ready"] else "not_run_corpus_not_ready",
            "objectives": perceptual_objectives,
            "confirmation_metrics": ["gstpeaq_basic_odg", "gstpeaq_advanced_odg"],
            "required_validation_evidence": list(perceptual_evidence),
            "records": programme_records,
            "pareto_audit": {key: value for key, value in perceptual_audit.items() if key != "front"},
        },
        "perceptual_sampling": perceptual_sampling,
        "pareto_fronts": {
            "search": [item.evaluation.metadata.get("candidate_id") for item in feasible_search_front],
            "engineering": [item["candidate_id"] for item in engineering_front],
            "perceptual_validation": perceptual_audit["front_candidate_ids"],
            "scientifically_validated": validated_audit["front_candidate_ids"],
        },
        "scientifically_validated_front": validated_audit["front_candidate_ids"],
        "scientifically_validated_objectives": validated_objectives,
        "scientifically_validated_required_evidence": list(scientific_evidence),
        "scientifically_validated_pareto_audit": {key: value for key, value in validated_audit.items() if key != "front"},
        "validation_blockers": pending_layers,
        "candidate_archive": str(archive.path),
    }
    report_path = campaign_root / "campaign.json"
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=True, default=str) + "\n", encoding="utf-8")
    provenance = write_provenance(
        campaign_root / "provenance.json",
        [args.parameters, *input_paths, args.programme],
        "multi_fidelity_optimization_campaign",
        {
            "algorithm": selected_algorithm.id,
            "candidate_evaluation_budget": args.budget,
            "promoted_candidates": len(promoted),
            "report_path": str(report_path),
        },
    )
    control.emit(
        "campaign_completed",
        completed_candidates=search.candidate_evaluations,
        successful_candidates=len(feasible_search_records),
        failed_candidates=len(failed_search_records),
        simulator_runs=counters["simulator_runs"],
        front_size=len(engineering_front),
        report_path=str(report_path),
    )
    _json({
        "status": report["status"],
        "scientific_claim_status": report["scientific_claim_status"],
        "algorithm": selected_algorithm.id,
        "candidate_evaluations": search.candidate_evaluations,
        "simulator_runs": counters["simulator_runs"],
        "promoted_candidate_ids": report["promotion"]["candidate_ids"],
        "engineering_front_candidate_ids": report["engineering"]["front_candidate_ids"],
        "scientifically_validated_front": validated_audit["front_candidate_ids"],
        "validation_blockers": pending_layers,
        "report_path": str(report_path),
        "candidate_archive": str(archive.path),
        "provenance_path": str(provenance),
    })
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sonya", description="Sonya/JAES migration CLI")
    parser.add_argument("--config", type=Path, default=_default_config(), help="YAML configuration")
    commands = parser.add_subparsers(dest="command", required=True)

    data = commands.add_parser("data", help="validate raw data and configuration")
    data_sub = data.add_subparsers(dest="data_command", required=True)
    data_sub.add_parser("validate")
    audit = data_sub.add_parser("audit")
    audit.add_argument("--output", type=Path)

    topology = commands.add_parser("topology", help="inspect circuit topologies")
    topology_sub = topology.add_subparsers(dest="topology_command", required=True)
    topology_sub.add_parser("list")
    topology_show = topology_sub.add_parser("show")
    topology_show.add_argument("topology_id")
    topology_init = topology_sub.add_parser("init", help="create a portable topology manifest and starter circuit")
    topology_init.add_argument("topology_id")
    topology_init.add_argument("--directory", type=Path, required=True)
    topology_validate = topology_sub.add_parser("validate", help="validate a topology manifest without project configuration")
    topology_validate.add_argument("manifest", type=Path)
    topology_translate = topology_sub.add_parser("translate", help="stage a topology for one simulator backend")
    topology_translate.add_argument("manifest", type=Path)
    topology_translate.add_argument("--backend", choices=("ltspice", "ngspice"), required=True)
    topology_translate.add_argument("--output", type=Path, required=True)
    topology_translate.add_argument("--parameters", type=Path)
    topology_run = topology_sub.add_parser("run", help="stage and execute a standalone topology manifest")
    topology_run.add_argument("manifest", type=Path)
    topology_run.add_argument("--backend", choices=("ltspice", "ngspice"), required=True)
    topology_run.add_argument("--output", type=Path, required=True)
    topology_run.add_argument("--parameters", type=Path)
    topology_run.add_argument("--executable", type=Path)
    topology_run.add_argument("--timeout", type=float, default=30.0)

    transformer = commands.add_parser("transformer", help="manage measurable output-transformer profiles")
    transformer_sub = transformer.add_subparsers(dest="transformer_command", required=True)
    transformer_show = transformer_sub.add_parser("show", help="validate and inspect a transformer profile")
    transformer_show.add_argument("profile", type=Path)
    transformer_init = transformer_sub.add_parser("init", help="create an empty measurement profile")
    transformer_init.add_argument("transformer_id")
    transformer_init.add_argument("--output", type=Path, required=True)
    transformer_render = transformer_sub.add_parser("render", help="render the portable linear SPICE parameters")
    transformer_render.add_argument("profile", type=Path)
    transformer_render.add_argument("--output", type=Path, required=True)

    algorithm = commands.add_parser("algorithm", help="inspect optimization algorithms")
    algorithm_sub = algorithm.add_subparsers(dest="algorithm_command", required=True)
    algorithm_sub.add_parser("list")
    algorithm_show = algorithm_sub.add_parser("show")
    algorithm_show.add_argument("algorithm_id")

    objective = commands.add_parser("objective", help="inspect screening, engineering and perceptual metrics")
    objective_sub = objective.add_subparsers(dest="objective_command", required=True)
    objective_sub.add_parser("list")

    install = commands.add_parser("install", help="verify an installed Sonya environment")
    install_sub = install.add_subparsers(dest="install_command", required=True)
    install_doctor = install_sub.add_parser("doctor", help="check package, simulator and perceptual dependencies")
    install_doctor.add_argument("--programme", type=Path, default=_default_programme())
    install_doctor.add_argument("--strict", choices=("package", "core", "perceptual", "all"))

    simulator = commands.add_parser("simulator", help="inspect and test simulator backends")
    simulator_sub = simulator.add_subparsers(dest="simulator_command", required=True)
    simulator_sub.add_parser("list")
    simulator_doctor = simulator_sub.add_parser("doctor")
    simulator_doctor.add_argument("--backend", choices=("ltspice", "ngspice"))
    simulator_smoke = simulator_sub.add_parser("smoke")
    simulator_smoke.add_argument("--backend", choices=("ltspice", "ngspice"), required=True)
    simulator_smoke.add_argument("--output-root", type=Path)
    simulator_compare = simulator_sub.add_parser("compare", help="compare configured topology metrics across LTspice and ngspice")
    simulator_compare.add_argument("parameters", type=Path)
    simulator_compare.add_argument("--topology", help="configured topology id (default: project default)")
    simulator_compare.add_argument("--output-root", type=Path)
    simulator_compare.add_argument("--reltol", type=float, default=0.001)
    simulator_compare.add_argument("--drive-mode", choices=("fixed-input", "matched-output-power"))
    simulator_compare.add_argument("--target-output-power", type=float, help="watts; used with matched-output-power")

    evaluation = commands.add_parser("evaluation", help="inspect the multi-fidelity evaluation plan")
    evaluation_sub = evaluation.add_subparsers(dest="evaluation_command", required=True)
    evaluation_plan = evaluation_sub.add_parser("plan")
    evaluation_plan.add_argument("--programme", type=Path, default=_default_programme())
    evaluation_corpus = evaluation_sub.add_parser("corpus")
    evaluation_corpus.add_argument("--programme", type=Path, default=_default_programme())

    corpus = commands.add_parser("corpus", help="prepare and preserve programme-material audition assets")
    corpus_sub = corpus.add_subparsers(dest="corpus_command", required=True)
    corpus_prepare = corpus_sub.add_parser("prepare", help="render canonical WAV excerpts and a listening page")
    corpus_prepare.add_argument("--programme", type=Path, default=_default_programme())
    corpus_prepare.add_argument("--output", type=Path)
    corpus_prepare.add_argument("--lock", type=Path)
    corpus_prepare.add_argument(
        "--role",
        choices=("all", "candidate", "development", "validation", "subjective", "reserve"),
        default="all",
        help="render all declared items or only items assigned to one cumulative role",
    )
    corpus_prepare.add_argument("--sample-rate", type=int, default=48000)
    corpus_prepare.add_argument("--target-active-rms-dbfs", type=float, default=-20.0)
    corpus_prepare.add_argument("--peak-dbfs", type=float, default=-1.0)
    corpus_prepare.add_argument("--fade-ms", type=float, default=10.0)
    corpus_prepare.add_argument("--ffmpeg", type=Path)

    perceptual = commands.add_parser("perceptual", help="plan and execute programme-audio validation")
    perceptual_sub = perceptual.add_subparsers(dest="perceptual_command", required=True)
    perceptual_sub.add_parser("doctor", help="inspect optional ViSQOL and GstPEAQ tools")
    perceptual_metric = perceptual_sub.add_parser("metric", help="evaluate an already prepared reference/degraded WAV pair")
    perceptual_metric.add_argument("reference", type=Path)
    perceptual_metric.add_argument("degraded", type=Path)
    perceptual_metric.add_argument("--metric", choices=("all", "visqol", "gstpeaq"), default="all")
    perceptual_metric.add_argument("--peaq-model", choices=("basic", "advanced", "both"), default="both")
    perceptual_sample = perceptual_sub.add_parser("sample", help="build a reproducible stochastic/final shortlist from a campaign")
    perceptual_sample.add_argument("campaign", type=Path)
    perceptual_sample.add_argument("--output", type=Path)
    perceptual_sample.add_argument("--seed", type=int, default=0)
    perceptual_sample.add_argument("--perceptual-seed", type=int)
    perceptual_sample.add_argument("--perceptual-half-life", type=float, default=50.0)
    perceptual_sample.add_argument("--perceptual-eligible-ranks", type=int, default=2)
    perceptual_sample.add_argument("--perceptual-online-max", type=int, default=10)
    perceptual_sample.add_argument("--perceptual-final-max", type=int, default=20)
    perceptual_sample.add_argument("--perceptual-near-front", type=int, default=2)
    perceptual_sample.add_argument("--perceptual-epsilon", type=float, default=0.02)
    perceptual_sample.add_argument("--perceptual-estimated-cost-seconds", type=float, default=0.0)
    perceptual_sample.add_argument("--perceptual-wall-time-hours", type=float, default=0.0)
    perceptual_benchmark = perceptual_sub.add_parser("benchmark", help="measure programme-audio simulator cost on a deterministic fixture")
    perceptual_benchmark.add_argument("parameters", type=Path)
    perceptual_benchmark.add_argument("--backend", choices=("ngspice", "ltspice"), default="ngspice")
    perceptual_benchmark.add_argument("--topology")
    perceptual_benchmark.add_argument("--duration", type=float, default=0.1)
    perceptual_benchmark.add_argument("--preroll", type=float, default=0.02)
    perceptual_benchmark.add_argument("--input-sample-rate", type=int, default=48000)
    perceptual_benchmark.add_argument("--simulation-sample-rate", type=int, default=192000)
    perceptual_benchmark.add_argument("--reltol", type=float, default=0.001)
    perceptual_benchmark.add_argument("--timeout", type=float, default=1200.0)
    perceptual_benchmark.add_argument("--run-metrics", action="store_true")
    perceptual_benchmark.add_argument("--projection-candidates", type=int, default=8)
    perceptual_benchmark.add_argument("--projection-clips", type=int, default=3)
    perceptual_benchmark.add_argument("--projection-levels", type=int, default=2)
    perceptual_benchmark.add_argument("--projection-duration", type=float, default=5.0, help="audio seconds per projected simulator run")
    perceptual_benchmark.add_argument("--output-root", type=Path)
    perceptual_validate = perceptual_sub.add_parser("validate", help="simulate and score a campaign perceptual shortlist")
    perceptual_validate.add_argument("campaign", type=Path)
    perceptual_validate.add_argument("--programme", type=Path, default=_default_programme())
    perceptual_validate.add_argument("--selection", choices=("online", "final"), default="final")
    perceptual_validate.add_argument("--role", choices=("development", "validation"), default="validation")
    perceptual_validate.add_argument(
        "--item",
        action="append",
        metavar="ID",
        help="run only a declared corpus item; repeat to select several (default: every item in the role)",
    )
    perceptual_validate.add_argument(
        "--level",
        action="append",
        metavar="ID",
        help="run only a declared fixed level; repeat to select several (default: every manifest level)",
    )
    perceptual_validate.add_argument("--metric", choices=("all", "visqol", "gstpeaq"), default="all")
    perceptual_validate.add_argument("--peaq-model", choices=("basic", "advanced", "both"), default="both")
    perceptual_validate.add_argument("--input-channel", type=int, default=0)
    perceptual_validate.add_argument("--preroll", type=float, default=0.1)
    perceptual_validate.add_argument("--simulation-sample-rate", type=int, default=48000)
    perceptual_validate.add_argument("--reltol", type=float, default=0.001)
    perceptual_validate.add_argument("--timeout", type=float, default=1200.0)
    perceptual_validate.add_argument("--output-root", type=Path)
    perceptual_validate.add_argument("--control-file", type=Path, help=argparse.SUPPRESS)
    perceptual_validate.add_argument("--event-log", type=Path, help=argparse.SUPPRESS)

    legacy = commands.add_parser("legacy", help="legacy baseline operations")
    legacy_sub = legacy.add_subparsers(dest="legacy_command", required=True)
    evaluate = legacy_sub.add_parser("evaluate")
    evaluate.add_argument("directory", type=Path)
    evaluate.add_argument("--vaa", type=float, required=True, help="measured plate supply in volts")

    params = commands.add_parser("params", help="read and validate legacy parameter files")
    params_sub = params.add_subparsers(dest="params_command", required=True)
    read = params_sub.add_parser("read")
    read.add_argument("path", type=Path)

    simulate = commands.add_parser("simulate", help="local LTspice integration")
    simulate_sub = simulate.add_subparsers(dest="simulate_command", required=True)
    simulate_sub.add_parser("doctor")
    smoke = simulate_sub.add_parser("smoke")
    smoke.add_argument("--output-root", type=Path)
    legacy_run = simulate_sub.add_parser("legacy", help="run one or all legacy modes in an isolated derived directory")
    legacy_run.add_argument("parameters", type=Path, help="legacy .param or result file containing X1..X25")
    legacy_run.add_argument("--mode", choices=("op", "tran", "ac", "slew", "gedlee", "crowe", "all"), default="op")
    legacy_run.add_argument("--output-root", type=Path)
    legacy_run.add_argument("--reltol", type=float, default=0.001)
    legacy_run.add_argument("--allow-infeasible", action="store_true", help="allow historical reproduction despite failed hard preflight")
    legacy_run.add_argument("--reference", type=Path, help="legacy result summary used only for numeric deltas")

    figure = commands.add_parser("figure", help="generate figures from derived data")
    figure_sub = figure.add_subparsers(dest="figure_command", required=True)
    evaluation_figure = figure_sub.add_parser("evaluation")
    evaluation_figure.add_argument("evaluation", type=Path)
    evaluation_figure.add_argument("--output", type=Path, required=True)

    optimize = commands.add_parser("optimize", help="run bounded optimization experiments")
    optimize_sub = optimize.add_subparsers(dest="optimize_command", required=True)
    optimize_test = optimize_sub.add_parser("test", help="exercise the full optimization pipeline on a tiny batch")
    optimize_test.add_argument("parameters", type=Path, help="feasible legacy parameter file used as the baseline")
    optimize_test.add_argument("--vary", action="append", default=None, help="parameter to perturb; repeat for more than one (default: X1)")
    optimize_test.add_argument("--count", type=int, default=3, help="candidate count including the baseline (1..8)")
    optimize_test.add_argument("--step", type=float, default=0.05, help="fractional perturbation step (default: 0.05)")
    optimize_test.add_argument("--output-root", type=Path)
    optimize_test.add_argument("--reltol", type=float, default=0.001)
    optimize_test.add_argument("--topology", help="configured topology id (default: project default)")
    optimize_test.add_argument("--algorithm", default="bounded_grid")
    optimize_test.add_argument("--backend", choices=("ltspice", "ngspice"), default="ltspice")
    optimize_test.add_argument("--drive-mode", choices=("fixed-input", "matched-output-power"))
    optimize_test.add_argument("--target-output-power", type=float, help="watts; used with matched-output-power")
    optimize_campaign = optimize_sub.add_parser("campaign", help="run a budgeted multi-fidelity optimization campaign")
    optimize_campaign.add_argument("parameters", type=Path, help="feasible legacy parameter file used as the baseline")
    optimize_campaign.add_argument(
        "--algorithm",
        choices=("nsga2", "gde3", "differential_evolution", "legacy_pso", "legacy_sam"),
        default="nsga2",
    )
    optimize_campaign.add_argument("--backend", choices=("ltspice", "ngspice"), default="ltspice")
    optimize_campaign.add_argument("--topology", help="configured topology id (default: project default)")
    optimize_campaign.add_argument("--vary", action="append", help="parameter to optimize; repeat as needed (default: all non-fixed)")
    optimize_campaign.add_argument("--budget", type=int, default=8, help="unique screening candidate evaluations")
    optimize_campaign.add_argument("--population-size", type=int, default=4)
    optimize_campaign.add_argument("--seed", type=int, default=0)
    optimize_campaign.add_argument("--mutation-factor", type=float, default=0.8, help="DE/GDE3 differential weight F")
    optimize_campaign.add_argument("--crossover-probability", type=float, default=0.9, help="DE/GDE3 binomial crossover CR")
    optimize_campaign.add_argument("--promote", type=int, default=2, help="representative candidates retained as a review/perceptual shortlist")
    optimize_campaign.add_argument("--output-root", type=Path)
    optimize_campaign.add_argument("--archive", type=Path, help="optional reusable candidate archive (JSONL)")
    optimize_campaign.add_argument("--reltol", type=float, default=0.001)
    optimize_campaign.add_argument("--drive-mode", choices=("fixed-input", "matched-output-power"))
    optimize_campaign.add_argument("--target-output-power", type=float, help="watts; used with matched-output-power")
    optimize_campaign.add_argument("--programme", type=Path, default=_default_programme())
    optimize_campaign.add_argument(
        "--parameter-bound",
        action="append",
        type=_parameter_bound,
        default=[],
        metavar="ID:MIN:MAX",
        help="override one search bound for this campaign; repeat for multiple X parameters",
    )
    optimize_campaign.add_argument("--perceptual-seed", type=int)
    optimize_campaign.add_argument("--perceptual-half-life", type=float, default=50.0)
    optimize_campaign.add_argument("--perceptual-eligible-ranks", type=int, default=2)
    optimize_campaign.add_argument("--perceptual-online-max", type=int, default=10)
    optimize_campaign.add_argument("--perceptual-final-max", type=int, default=20)
    optimize_campaign.add_argument("--perceptual-near-front", type=int, default=2)
    optimize_campaign.add_argument("--perceptual-epsilon", type=float, default=0.02)
    optimize_campaign.add_argument("--perceptual-estimated-cost-seconds", type=float, default=0.0)
    optimize_campaign.add_argument("--perceptual-wall-time-hours", type=float, default=0.0)
    optimize_campaign.add_argument("--control-file", type=Path, help=argparse.SUPPRESS)
    optimize_campaign.add_argument("--event-log", type=Path, help=argparse.SUPPRESS)
    optimize_manifest_command = optimize_sub.add_parser("manifest", help="run a generic reduced optimization declared by a topology manifest")
    optimize_manifest_command.add_argument("manifest", type=Path)
    optimize_manifest_command.add_argument("--backend", choices=("ltspice", "ngspice"), required=True)
    optimize_manifest_command.add_argument("--output-root", type=Path, required=True)
    optimize_manifest_command.add_argument("--vary", action="append")
    optimize_manifest_command.add_argument("--count", type=int, default=3)
    optimize_manifest_command.add_argument("--step", type=float, default=0.05)
    optimize_manifest_command.add_argument("--executable", type=Path)
    optimize_manifest_command.add_argument("--timeout", type=float, default=30.0)

    gui = commands.add_parser("gui", help="open the installable local optimization interface")
    gui.add_argument("--host", default="127.0.0.1", help="local bind address (default: 127.0.0.1)")
    gui.add_argument("--port", type=int, default=8765, help="local HTTP port; use 0 to select a free port")
    gui.add_argument("--no-open", action="store_true", help="do not open the default browser automatically")
    gui.add_argument("--programme", type=Path, default=_default_programme())
    gui.add_argument(
        "--state-root",
        type=Path,
        default=Path(os.environ["SONYA_STATE_ROOT"]) if "SONYA_STATE_ROOT" in os.environ else None,
        help="persistent GUI job directory",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "topology" and args.topology_command == "init":
            manifest_path, circuit_path = create_topology_scaffold(args.topology_id, args.directory)
            _json({"topology": args.topology_id, "manifest": manifest_path, "circuit": circuit_path})
            return 0
        if args.command == "transformer":
            if args.transformer_command == "init":
                output = create_transformer_profile(args.transformer_id, args.output)
                _json({"transformer": args.transformer_id, "profile": output})
                return 0
            profile = load_transformer_profile(args.profile)
            if args.transformer_command == "render":
                output = args.output.expanduser().resolve()
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(render_linear_include(profile), encoding="ascii")
                _json({"transformer": profile.id, "output": output, "losses_identified": profile.losses_identified})
                return 0
            _json(transformer_record(profile))
            return 0
        if args.command == "topology" and args.topology_command in {"validate", "translate", "run"}:
            manifest = load_topology_manifest(args.manifest)
            if args.topology_command == "validate":
                _json({"valid": True, "topology": topology_record(manifest)})
                return 0
            staged = stage_topology(manifest, args.backend, args.output, args.parameters)
            if args.topology_command == "run":
                execution = execute_staged_topology(staged, args.executable, args.timeout)
                _json(asdict(execution))
                return 0 if execution.passed else 1
            _json(asdict(staged))
            return 0
        if args.command == "optimize" and args.optimize_command == "manifest":
            manifest = load_topology_manifest(args.manifest)
            report_path = optimize_manifest(
                manifest,
                args.backend,
                args.output_root,
                vary=args.vary,
                count=args.count,
                step=args.step,
                executable=args.executable,
                timeout_seconds=args.timeout,
            )
            report = json.loads(report_path.read_text(encoding="utf-8"))
            _json({
                "status": report["status"],
                "topology": report["topology"],
                "backend": report["backend"],
                "objective": report["objective"],
                "winner": report["winner"],
                "ranking": [
                    {"rank": item["rank"], "id": item["id"], "changes": item["changes"], "objective_value": item["objective_value"]}
                    for item in sorted(report["results"], key=lambda item: item["rank"])
                ],
                "report_path": report_path,
                "provenance_path": report_path.parent / "provenance.json",
            })
            return 0
        if args.command == "corpus" and args.corpus_command == "prepare":
            programme = load_programme_manifest(args.programme)
            output = args.output.expanduser().resolve() if args.output else _default_corpus_audition(args.programme)
            index_path = prepare_corpus_audition(
                programme,
                output,
                role=args.role,
                sample_rate_hz=args.sample_rate,
                target_active_rms_dbfs=args.target_active_rms_dbfs,
                peak_dbfs=args.peak_dbfs,
                fade_seconds=args.fade_ms / 1000.0,
                ffmpeg_executable=args.ffmpeg,
                lock_path=args.lock or _default_corpus_lock(args.programme),
            )
            index = json.loads(index_path.read_text(encoding="utf-8"))
            _json({
                "status": index["status"],
                "item_count": len(index["items"]),
                "audition_page": index_path.parent / "index.html",
                "playlist": index_path.parent / "audition.m3u",
                "index": index_path,
                "lock": args.lock or _default_corpus_lock(args.programme),
                "items": [
                    {
                        "id": item["id"],
                        "title": item["title"],
                        "canonical_path": item["canonical_path"],
                        "canonical_sha256": item["canonical_sha256"],
                        "crest_factor_db": item["crest_factor_db"],
                    }
                    for item in index["items"]
                ],
            })
            return 0
        config = load_config(args.config)
        if args.command == "install" and args.install_command == "doctor":
            report = installation_report(config, args.programme)
            _json(report)
            return 0 if args.strict is None or bool(report["scopes"][args.strict]) else 1
        if args.command == "gui":
            from .gui import serve_gui

            return serve_gui(
                config,
                args.programme,
                host=args.host,
                port=args.port,
                open_browser=not args.no_open,
                state_root=args.state_root,
            )
        if args.command == "perceptual":
            if args.perceptual_command == "doctor":
                reports = [asdict(item) for item in perceptual_doctors()]
                _json({"metrics": reports})
                return 0 if all(bool(item["ready"]) for item in reports) else 1
            if args.perceptual_command == "sample":
                candidates = _sampling_candidates_from_campaign(args.campaign)
                plan = _sampling_plan_from_args(candidates, args)
                if args.output:
                    output = args.output.expanduser().resolve()
                    output.parent.mkdir(parents=True, exist_ok=True)
                    output.write_text(json.dumps(plan, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
                    plan["output"] = str(output)
                _json(plan)
                return 0
            if args.perceptual_command == "metric":
                doctors = {item.id: item for item in perceptual_doctors()}
                results: list[dict[str, object]] = []
                if args.metric in {"all", "visqol"} and doctors["visqol_audio"].ready:
                    results.append(run_visqol(args.reference, args.degraded).record())
                if args.metric in {"all", "gstpeaq"} and doctors["gstpeaq_odg"].ready:
                    models = ("basic", "advanced") if args.peaq_model == "both" else (args.peaq_model,)
                    results.extend(run_gstpeaq(args.reference, args.degraded, model).record() for model in models)
                if not results:
                    raise RuntimeError("none of the requested perceptual metric adapters is ready")
                _json({"reference": args.reference.resolve(), "degraded": args.degraded.resolve(), "results": results})
                return 0
            if args.perceptual_command == "validate":
                run_control = RunControl(
                    args.control_file,
                    args.event_log,
                    run_kind="perceptual",
                )
                campaign = json.loads(args.campaign.expanduser().resolve().read_text(encoding="utf-8"))
                topology_id = campaign.get("topology")
                if not isinstance(topology_id, str):
                    raise ValueError("campaign does not declare its topology")
                selected_topology = topology_spec(config, topology_id)
                topology = load_topology_manifest(selected_topology.manifest)
                report_path = run_programme_validation(
                    config,
                    topology,
                    args.campaign,
                    load_programme_manifest(args.programme),
                    args.output_root.resolve() if args.output_root else config.processed_root,
                    selection=args.selection,
                    role=args.role,
                    item_ids=args.item,
                    level_ids=args.level,
                    metric=args.metric,
                    peaq_model=args.peaq_model,
                    input_channel=args.input_channel,
                    preroll_seconds=args.preroll,
                    simulation_sample_rate_hz=args.simulation_sample_rate,
                    reltol=args.reltol,
                    timeout_seconds=args.timeout,
                    run_control=run_control,
                )
                report = json.loads(report_path.read_text(encoding="utf-8"))
                _json({
                    "status": report["status"],
                    "scientific_scope": report["scientific_scope"],
                    "case_count": report["case_count"],
                    "failed_case_count": report["failed_case_count"],
                    "elapsed_seconds": report["elapsed_seconds"],
                    "candidate_records": report["candidate_records"],
                    "perceptual_pareto_audit": report["perceptual_pareto_audit"],
                    "report_path": report_path,
                    "provenance": report["provenance"],
                })
                return 0
            return _run_perceptual_benchmark(args, config)
        if args.command == "optimize" and args.optimize_command == "campaign":
            return _run_optimization_campaign(args, config)
        if args.command == "topology":
            if args.topology_command == "show":
                _json(catalog_record(topology_spec(config, args.topology_id)))
            else:
                _json({"topologies": [catalog_record(item) for item in topology_specs(config)]})
            return 0
        if args.command == "algorithm":
            if args.algorithm_command == "show":
                _json(catalog_record(algorithm_spec(args.algorithm_id)))
            else:
                _json({"algorithms": [catalog_record(item) for item in algorithm_specs()]})
            return 0
        if args.command == "objective":
            _json({
                "legacy_score_status": "reproduction_only_not_new_objective",
                "legacy_score_specs": config.raw["legacy_evaluation"]["score_specs"],
                "multi_fidelity_metrics": [catalog_record(item) for item in metric_specs()],
            })
            return 0
        if args.command == "simulator":
            backends = simulator_backends(config)
            if args.simulator_command == "list":
                _json({"backends": [asdict(backend.doctor()) for backend in backends.values()]})
                return 0
            if args.simulator_command == "doctor":
                selected = [backends[args.backend]] if args.backend else list(backends.values())
                reports = [asdict(backend.doctor()) for backend in selected]
                _json({"backends": reports})
                return 0 if all(bool(report["ready"]) for report in reports) else 1
            if args.simulator_command == "compare":
                selected = topology_spec(config, args.topology or config.default_topology_id)
                manifest = load_topology_manifest(selected.manifest)
                missing_backends = {"ltspice", "ngspice"} - manifest.backends.keys()
                if missing_backends:
                    raise ValueError(f"cross-backend comparison requires: {', '.join(sorted(missing_backends))}")
                selected_backends = simulator_backends(config, manifest)
                unavailable = [backend_id for backend_id, backend in selected_backends.items() if not backend.doctor().ready]
                if unavailable:
                    raise RuntimeError(f"simulator backends are not ready: {', '.join(unavailable)}")
                values = read_legacy_parameters(args.parameters)
                base = args.output_root.resolve() if args.output_root else config.processed_root
                base.mkdir(parents=True, exist_ok=True)
                comparison_root = Path(tempfile.mkdtemp(prefix="simulator-comparison-", dir=base))
                modes = ("op", "tran", "ac", "slew", "gedlee", "crowe")
                summaries: dict[str, dict[str, object]] = {}
                drives: dict[str, dict[str, object]] = {}
                for backend_id, backend in selected_backends.items():
                    input_rms_v, drive_record = _resolve_drive(
                        config,
                        backend,
                        values,
                        args.drive_mode,
                        args.target_output_power,
                        comparison_root / backend_id,
                        args.parameters,
                        args.reltol,
                    )
                    reports = [
                        backend.run_legacy_mode(
                            values,
                            mode,
                            output_root=comparison_root / backend_id,
                            parameter_source=args.parameters,
                            reltol=args.reltol,
                            input_rms_v=input_rms_v,
                        )
                        for mode in modes
                    ]
                    summaries[backend_id] = summarize_legacy_runs(reports, values, config)
                    drives[backend_id] = drive_record
                lt_metrics = summaries["ltspice"]["measurements"]
                ng_metrics = summaries["ngspice"]["measurements"]
                assert isinstance(lt_metrics, dict) and isinstance(ng_metrics, dict)
                deltas: dict[str, dict[str, float | None]] = {}
                for name in sorted(lt_metrics.keys() & ng_metrics.keys()):
                    left, right = float(lt_metrics[name]), float(ng_metrics[name])
                    if not (math.isfinite(left) and math.isfinite(right)):
                        continue
                    deltas[name] = {
                        "ltspice": left,
                        "ngspice": right,
                        "absolute": right - left,
                        "relative_percent": None if left == 0 else 100.0 * (right - left) / abs(left),
                    }
                comparison = {
                    "status": "cross_backend_characterization_not_equivalence_proof",
                    "topology": selected.id,
                    "backend_model_status": {backend_id: manifest.backends[backend_id].status for backend_id in selected_backends},
                    "drive": drives,
                    "summaries": summaries,
                    "metric_deltas": deltas,
                }
                report_path = comparison_root / "comparison.json"
                report_path.write_text(json.dumps(comparison, indent=2, sort_keys=True, allow_nan=True) + "\n", encoding="utf-8")
                provenance_path = write_provenance(
                    comparison_root / "provenance.json",
                    [
                        args.parameters,
                        config.source,
                        manifest.source,
                        manifest.circuit,
                        *(dependency.source for backend in manifest.backends.values() for dependency in backend.dependencies),
                    ],
                    "cross_backend_topology_characterization",
                    {"topology": selected.id, "report_path": str(report_path), "backends": sorted(selected_backends)},
                )
                _json({
                    "status": comparison["status"],
                    "topology": selected.id,
                    "report_path": report_path,
                    "provenance_path": provenance_path,
                    "metric_deltas": deltas,
                    "drive": drives,
                })
                return 0
            result = simulator_backend(config, args.backend).smoke_test(args.output_root)
            _json(asdict(result))
            return 0 if result.passed else 1
        if args.command == "evaluation":
            manifest = load_programme_manifest(args.programme)
            report = programme_report(manifest)
            if args.evaluation_command == "plan":
                report["tiers"] = [
                    {"id": "screening", "scope": "all feasible candidates", "metrics": [item.id for item in metric_specs() if item.tier == "screening"]},
                    {"id": "engineering", "scope": "all feasible candidates; promoted subset is only a representative shortlist", "metrics": [item.id for item in metric_specs() if item.tier == "engineering"]},
                    {"id": "programme", "scope": "fully evaluated Pareto shortlist", "metrics": [item.id for item in metric_specs() if item.tier == "programme"]},
                    {"id": "subjective", "scope": "finalists only", "metrics": [item.id for item in metric_specs() if item.tier == "subjective"]},
                ]
                report["policy"] = {
                    "gm_legacy": "screening_and_historical_reference_only",
                    "gm_crowe": "every_candidate_fourth_objective_not_memory_proof",
                    "missing_expensive_metrics": "cannot_enter_validated_front",
                    "simulator_backend": "fixed_for_entire_optimization_run",
                }
                _json(report)
                return 0
            _json(report)
            return 0 if report["programme_ready"] else 1
        if args.command == "data":
            if args.data_command == "audit":
                roots = [config.resolve(item) for item in config.raw["data"]["raw_roots"]]
                legacy_root = config.resolve(config.raw["project"]["legacy_root"])
                report = audit_data(roots, [legacy_root])
                output = args.output.resolve() if args.output else config.processed_root / "data-audit.json"
                raw_roots = [path.resolve() for path in roots]
                if any(output == root or root in output.parents for root in raw_roots):
                    raise ValueError("data audit cannot be written into a raw-data root")
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
                _json({
                    "output": str(output),
                    "file_count": report["file_count"],
                    "duplicate_group_count": report["duplicate_group_count"],
                    "manual_numeric_overrides": report["manual_numeric_overrides"],
                })
                return 0
            report = _validate_data(config)
            _json(report)
            return 0 if report["valid"] else 1
        if args.command == "legacy":
            _json(evaluate_measurement_directory(args.directory, args.vaa, config))
            return 0
        if args.command == "params":
            values = read_legacy_parameters(args.path)
            parameters = CircuitParameters(values, config.parameters)
            parameter_ok, parameter_results = evaluate_parameter_constraints(
                values,
                config.parameters,
                config.raw["future_methodology"]["symmetry_groups"],
                config.raw["future_methodology"]["fixed_parameters"],
            )
            declared_ok, declared_results = evaluate_declared_constraints(
                {"vaa_v": values["X24"]},
                config.raw["future_methodology"]["hard_constraints"],
            )
            feasible = parameter_ok and declared_ok
            _json({
                "values": values,
                "bound_violations": parameters.validate_bounds(),
                "feasible": feasible,
                "parameter_constraints": [asdict(item) for item in parameter_results],
                "hard_constraints": [asdict(item) for item in declared_results],
            })
            return 0 if feasible else 1
        if args.command == "figure":
            from .figures import plot_legacy_evaluation

            raw_roots = [config.resolve(item) for item in config.raw["data"]["raw_roots"]]
            output = plot_legacy_evaluation(args.evaluation, args.output, raw_roots)
            _json({"output": str(output), "provenance": str(output.with_suffix(output.suffix + ".provenance.json"))})
            return 0
        if args.command == "optimize":
            selected_topology = topology_spec(config, args.topology or config.default_topology_id)
            selected_algorithm = algorithm_spec(args.algorithm)
            if selected_algorithm.id != "bounded_grid" or selected_algorithm.status != "implemented":
                raise ValueError(f"algorithm {selected_algorithm.id} is not implemented yet")
            topology_manifest = load_topology_manifest(selected_topology.manifest)
            if args.backend not in topology_manifest.backends:
                raise ValueError(f"topology {selected_topology.id} does not declare backend {args.backend}")
            backend_status = topology_manifest.backends[args.backend].status
            if backend_status == "planned":
                raise ValueError(f"backend {args.backend} is not implemented for topology {selected_topology.id}")
            optimization_backend = simulator_backend(config, args.backend, topology_manifest)
            doctor = optimization_backend.doctor()
            if not doctor.ready:
                raise RuntimeError(f"{args.backend} is not ready; run `sonya simulator doctor --backend {args.backend}` for details")
            baseline = read_legacy_parameters(args.parameters)
            candidates = generate_test_candidates(
                baseline,
                config.parameters,
                config.raw["future_methodology"]["symmetry_groups"],
                config.raw["future_methodology"]["fixed_parameters"],
                args.vary or ["X1"],
                args.count,
                args.step,
            )
            base = args.output_root.resolve() if args.output_root else config.processed_root
            base.mkdir(parents=True, exist_ok=True)
            optimization_root = Path(tempfile.mkdtemp(prefix="optimization-test-", dir=base))
            results: list[dict[str, object]] = []
            modes = ("op", "tran", "ac", "slew", "gedlee", "crowe")
            for index, candidate in enumerate(candidates):
                parameter_ok, parameter_results = evaluate_parameter_constraints(
                    candidate.values,
                    config.parameters,
                    config.raw["future_methodology"]["symmetry_groups"],
                    config.raw["future_methodology"]["fixed_parameters"],
                )
                declared_ok, declared_results = evaluate_declared_constraints(
                    {"vaa_v": candidate.values["X24"]},
                    config.raw["future_methodology"]["hard_constraints"],
                )
                candidate_root = optimization_root / f"candidate-{index:02d}-{candidate.id}"
                candidate_root.mkdir(parents=True)
                candidate_input = candidate_root / "candidate.json"
                candidate_input.write_text(
                    json.dumps({"id": candidate.id, "changes": candidate.changes, "values": candidate.values}, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8",
                )
                feasible = parameter_ok and declared_ok
                record: dict[str, object] = {
                    "id": candidate.id,
                    "changes": candidate.changes,
                    "preflight_feasible": feasible,
                    "parameter_constraints": [asdict(item) for item in parameter_results],
                    "hard_constraints": [asdict(item) for item in declared_results],
                }
                if feasible:
                    input_rms_v, drive_record = _resolve_drive(
                        config,
                        optimization_backend,
                        candidate.values,
                        args.drive_mode,
                        args.target_output_power,
                        candidate_root,
                        candidate_input,
                        args.reltol,
                    )
                    reports = [
                        optimization_backend.run_legacy_mode(
                            candidate.values,
                            mode,
                            output_root=candidate_root,
                            parameter_source=candidate_input,
                            reltol=args.reltol,
                            input_rms_v=input_rms_v,
                        )
                        for mode in modes
                    ]
                    summary = summarize_legacy_runs(reports, candidate.values, config)
                    record.update({
                        "pipeline_test_score": pipeline_test_score(summary),
                        "summary": summary,
                        "runs": reports,
                        "drive": drive_record,
                    })
                results.append(record)
            ranked = sorted(
                (item for item in results if "pipeline_test_score" in item),
                key=lambda item: float(item["pipeline_test_score"]),
            )
            for rank, item in enumerate(ranked, start=1):
                item["rank"] = rank
            report = {
                "status": "engineering_pipeline_test_only",
                "topology": selected_topology.id,
                "algorithm": selected_algorithm.id,
                "simulator_backend": args.backend,
                "simulator_backend_status": backend_status,
                "cross_backend_equivalence": "not_assumed",
                "drive_mode": (args.drive_mode or str(config.raw["legacy_evaluation"]["drive"]["default_mode"])).replace("-", "_"),
                "target_output_power_w": args.target_output_power,
                "objective": "legacy_penalty_without_gm_lower_is_better",
                "candidate_count": len(candidates),
                "winner": ranked[0]["id"] if ranked else None,
                "winner_is_approved_design": False,
                "approval_blocker": config.raw["future_methodology"]["soa_limits_status"],
                "results": results,
            }
            report_path = optimization_root / "optimization.json"
            report_path.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=True) + "\n", encoding="utf-8")
            provenance = write_provenance(
                optimization_root / "provenance.json",
                [args.parameters, config.source, Path(selected_topology.circuit)],
                "bounded_optimization_pipeline_test",
                {
                    "candidate_count": len(candidates),
                    "vary": args.vary or ["X1"],
                    "fractional_step": args.step,
                    "objective": report["objective"],
                    "topology": selected_topology.id,
                    "algorithm": selected_algorithm.id,
                    "simulator_backend": args.backend,
                    "simulator_backend_status": backend_status,
                    "report_path": str(report_path),
                },
            )
            _json({
                "status": report["status"],
                "topology": report["topology"],
                "algorithm": report["algorithm"],
                "simulator_backend": report["simulator_backend"],
                "simulator_backend_status": report["simulator_backend_status"],
                "cross_backend_equivalence": report["cross_backend_equivalence"],
                "objective": report["objective"],
                "winner": report["winner"],
                "winner_is_approved_design": False,
                "approval_blocker": report["approval_blocker"],
                "ranking": [
                    {
                        "rank": item["rank"],
                        "id": item["id"],
                        "changes": item["changes"],
                        "score": item["pipeline_test_score"],
                    }
                    for item in ranked
                ],
                "report_path": str(report_path),
                "provenance_path": str(provenance),
            })
            return 0
        runner = LTspiceRunner(config)
        if args.simulate_command == "doctor":
            report = asdict(runner.doctor())
            _json(report)
            return 0 if report["ready"] else 1
        if args.simulate_command == "legacy":
            values = read_legacy_parameters(args.parameters)
            parameter_ok, parameter_results = evaluate_parameter_constraints(
                values,
                config.parameters,
                config.raw["future_methodology"]["symmetry_groups"],
                config.raw["future_methodology"]["fixed_parameters"],
            )
            declared_ok, declared_results = evaluate_declared_constraints(
                {"vaa_v": values["X24"]},
                config.raw["future_methodology"]["hard_constraints"],
            )
            if not args.allow_infeasible and not (parameter_ok and declared_ok):
                failures = [item.name for item in (*parameter_results, *declared_results) if not item.feasible]
                raise ValueError(f"hard preflight failed before LTspice: {', '.join(failures)}; use --allow-infeasible only for historical reproduction")
            modes = ("op", "tran", "ac", "slew", "gedlee", "crowe") if args.mode == "all" else (args.mode,)
            run_output_root = args.output_root
            evaluation_root: Path | None = None
            if args.mode == "all":
                base = args.output_root.resolve() if args.output_root else config.processed_root
                base.mkdir(parents=True, exist_ok=True)
                evaluation_root = Path(tempfile.mkdtemp(prefix="evaluation-", dir=base))
                run_output_root = evaluation_root
            reports = [
                runner.run_legacy_mode(
                    values,
                    mode,
                    output_root=run_output_root,
                    parameter_source=args.parameters,
                    reltol=args.reltol,
                )
                for mode in modes
            ]
            output: dict[str, object] = {"runs": reports}
            if args.mode == "all":
                summary = summarize_legacy_runs(reports, values, config)
                if args.reference:
                    reference = read_legacy_results(args.reference)
                    current = summary["measurements"]
                    summary["reference"] = reference
                    summary["reference_delta"] = {
                        name: float(current[name]) - float(reference[name])
                        for name in current.keys() & reference.keys()
                    }
                output["summary"] = summary
                assert evaluation_root is not None
                evaluation_path = evaluation_root / "evaluation.json"
                evaluation_path.write_text(json.dumps(output, indent=2, sort_keys=True, allow_nan=True) + "\n", encoding="utf-8")
                provenance = write_provenance(
                    evaluation_root / "provenance.json",
                    [args.parameters, config.source, runner.topology.circuit],
                    "ltspice_complete_legacy_evaluation",
                    {"modes": list(modes), "evaluation_path": str(evaluation_path)},
                )
                output["evaluation_path"] = str(evaluation_path)
                output["evaluation_provenance_path"] = str(provenance)
            _json(output)
            return 0
        result = runner.smoke_test(args.output_root)
        passed = "vout" in result.log_text.lower() and "0.5" in result.log_text
        _json({
            "command": result.command,
            "working_directory": str(result.working_directory),
            "return_code": result.return_code,
            "log_path": str(result.log_path) if result.log_path else None,
            "provenance_path": str(result.provenance_path) if result.provenance_path else None,
            "passed": passed,
        })
        return 0 if passed else 1
    except RunCancelled as exc:
        print(f"cancelled: {exc}", file=sys.stderr)
        return 130
    except (ConfigError, ProgrammeConfigError, TopologyError, TransformerProfileError, FileExistsError, FileNotFoundError, ValueError, RuntimeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
