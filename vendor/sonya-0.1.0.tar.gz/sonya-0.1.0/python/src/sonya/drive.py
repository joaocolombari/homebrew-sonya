from __future__ import annotations

from collections.abc import Callable
from dataclasses import asdict, dataclass
import math


@dataclass(frozen=True)
class DriveCalibration:
    mode: str
    target_output_power_w: float
    input_rms_v: float
    achieved_output_power_w: float
    relative_error: float
    converged: bool
    evaluations: tuple[tuple[float, float], ...]

    def record(self) -> dict[str, object]:
        return asdict(self)


def dbv_to_rms(dbv: float) -> float:
    return 10.0 ** (float(dbv) / 20.0)


def rms_to_dbv(rms_v: float) -> float:
    if rms_v <= 0 or not math.isfinite(rms_v):
        raise ValueError("RMS voltage must be positive and finite")
    return 20.0 * math.log10(rms_v)


def calibrate_input_for_output_power(
    evaluate_power: Callable[[float], float],
    target_output_power_w: float,
    minimum_input_rms_v: float,
    maximum_input_rms_v: float,
    relative_tolerance: float = 0.002,
    max_iterations: int = 12,
) -> DriveCalibration:
    """Find the input RMS that produces a common real load power.

    Bisection is intentionally used instead of a gain estimate so the
    calibration remains valid as the candidate becomes nonlinear.  A
    non-monotonic response is rejected because it cannot define a unique test
    level for fair optimization.
    """
    if target_output_power_w <= 0 or relative_tolerance <= 0 or max_iterations < 1:
        raise ValueError("invalid output-power calibration settings")
    if not 0 < minimum_input_rms_v < maximum_input_rms_v:
        raise ValueError("invalid input calibration bounds")
    evaluations: list[tuple[float, float]] = []

    def measure(input_rms_v: float) -> float:
        value = float(evaluate_power(input_rms_v))
        if value < 0 or not math.isfinite(value):
            raise ValueError("output-power calibration returned an invalid power")
        evaluations.append((input_rms_v, value))
        return value

    low, high = minimum_input_rms_v, maximum_input_rms_v
    low_power, high_power = measure(low), measure(high)
    if high_power <= low_power:
        raise ValueError("output power is not monotonic across the calibration bounds")
    if not low_power <= target_output_power_w <= high_power:
        raise ValueError(
            f"target output power {target_output_power_w:g} W is outside the calibrated "
            f"range {low_power:g}..{high_power:g} W"
        )
    best_input, best_power = min(evaluations, key=lambda item: abs(item[1] - target_output_power_w))
    for _ in range(max_iterations):
        midpoint = 0.5 * (low + high)
        midpoint_power = measure(midpoint)
        if abs(midpoint_power - target_output_power_w) < abs(best_power - target_output_power_w):
            best_input, best_power = midpoint, midpoint_power
        relative_error = abs(midpoint_power - target_output_power_w) / target_output_power_w
        if relative_error <= relative_tolerance:
            return DriveCalibration(
                "matched_output_power",
                target_output_power_w,
                midpoint,
                midpoint_power,
                relative_error,
                True,
                tuple(evaluations),
            )
        if midpoint_power < target_output_power_w:
            low, low_power = midpoint, midpoint_power
        else:
            high, high_power = midpoint, midpoint_power
    relative_error = abs(best_power - target_output_power_w) / target_output_power_w
    return DriveCalibration(
        "matched_output_power",
        target_output_power_w,
        best_input,
        best_power,
        relative_error,
        relative_error <= relative_tolerance,
        tuple(evaluations),
    )
