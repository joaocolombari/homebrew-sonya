from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Mapping

from .config import ParameterSpec


@dataclass(frozen=True)
class ConstraintResult:
    name: str
    feasible: bool
    value: float | None
    limit: str
    detail: str = ""


HardConstraint = Callable[[Mapping[str, float]], ConstraintResult]


def check_hard_constraints(measurements: Mapping[str, float], constraints: list[HardConstraint]) -> tuple[bool, list[ConstraintResult]]:
    results = [constraint(measurements) for constraint in constraints]
    return all(result.feasible for result in results), results


def evaluate_declared_constraints(measurements: Mapping[str, float], declarations: list[dict[str, object]]) -> tuple[bool, list[ConstraintResult]]:
    results: list[ConstraintResult] = []
    for rule in declarations:
        name = str(rule["name"])
        metric = str(rule["metric"])
        relation = str(rule["relation"])
        limit = float(rule["limit"])
        unit = str(rule.get("unit", ""))
        value = measurements.get(metric)
        if value is None:
            results.append(ConstraintResult(name, False, None, f"{relation} {limit:g} {unit}".strip(), f"missing metric {metric}"))
            continue
        feasible = value <= limit if relation == "max" else value >= limit if relation == "min" else value == limit
        results.append(ConstraintResult(name, feasible, float(value), f"{relation} {limit:g} {unit}".strip()))
    return all(item.feasible for item in results), results


def evaluate_parameter_constraints(
    values: Mapping[str, float],
    specs: tuple[ParameterSpec, ...],
    symmetry_groups: list[list[str]],
    fixed_parameters: list[dict[str, object]] | None = None,
    relative_tolerance: float = 1e-12,
) -> tuple[bool, list[ConstraintResult]]:
    results: list[ConstraintResult] = []
    for spec in specs:
        value = values.get(spec.id)
        feasible = value is not None and spec.minimum <= value <= spec.maximum
        results.append(ConstraintResult(f"bounds_{spec.id}", feasible, float(value) if value is not None else None, f"[{spec.minimum:g}, {spec.maximum:g}] {spec.unit}"))
    for group in symmetry_groups:
        group_values = [values.get(name) for name in group]
        present = all(value is not None for value in group_values)
        scale = max((abs(float(value)) for value in group_values if value is not None), default=1.0)
        feasible = present and max(float(value) for value in group_values) - min(float(value) for value in group_values) <= relative_tolerance * max(scale, 1.0)
        results.append(ConstraintResult(f"symmetry_{'_'.join(group)}", feasible, None, "equal", ", ".join(f"{name}={values.get(name)}" for name in group)))
    for fixed in fixed_parameters or []:
        parameter_id = str(fixed["id"])
        expected = float(fixed["value"])
        actual = values.get(parameter_id)
        tolerance = relative_tolerance * max(abs(expected), 1.0)
        feasible = actual is not None and abs(float(actual) - expected) <= tolerance
        results.append(
            ConstraintResult(
                f"fixed_{parameter_id}",
                feasible,
                float(actual) if actual is not None else None,
                f"= {expected:g} {fixed.get('unit', '')}".strip(),
                str(fixed.get("purpose", "")),
            )
        )
    return all(item.feasible for item in results), results
