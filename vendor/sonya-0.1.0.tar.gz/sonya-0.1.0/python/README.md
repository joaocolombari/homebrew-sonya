# Sonya/JAES — plataforma de simulação e otimização

Ferramentas Python para reproduzir, analisar e otimizar circuitos de áudio do projeto Sonya/JAES. A arquitetura separa topologia, algoritmo, simulador e protocolo de avaliação para que a mesma aplicação possa evoluir do LTspice no macOS para ngspice no macOS/Linux sem misturar resultados incompatíveis.

Esta parte do repositório está substituindo gradualmente o fluxo histórico em MATLAB. O objetivo é tornar as simulações reproduzíveis, as restrições físicas explícitas e cada resultado rastreável até os parâmetros, modelos e dados que o produziram.

> **Estado do projeto:** o baseline e a otimização reduzida estão validados com LTspice 17.2.3 no macOS. A topologia EL84 também executa os seis modos no ngspice 46 no Mac, e a instalação limpa, o smoke e uma campanha Pareto de 40 simulações foram validados com ngspice 45.2 no Ubuntu 26.04. NSGA-II e GDE3 executam campanhas Pareto; DE, PSO e SAM fornecem referências escalares sob o mesmo orçamento e arquivo de candidatos. As métricas elétricas usam entrada fixa de −10 dBV por padrão; potência igual na saída continua opcional. A frente elétrica usa potência, slew rate, uniformidade em frequência e `GM-Crowe`; THD continua calculada e exibida como diagnóstico. A preparação de áudio, os adaptadores ViSQOL/GstPEAQ e a execução pós-campanha pela GUI funcionam tanto no LTspice quanto no ngspice. O corpus EBU SQAM está fixado em quatro sentinelas online e oito referências comuns à validação final e ao WebMUSHRA. A validação musical usa `nominal = 0,447213595 Vpk` e `limit = 1 Vpk`. O ngspice continua experimental para campanhas grandes e regiões ainda não percorridas do espaço de projeto. Consulte [STATUS.md](STATUS.md).

O projeto já permite executar e comparar simulações, testar pequenas otimizações multiobjetivo, cadastrar topologias próprias, criar perfis mensuráveis de transformadores e executar a validação perceptual. Ele ainda não declara um circuito ótimo: a SOA dinâmica, o transformador físico não linear e uma campanha perceptual completa continuam pendentes.

## O que existe neste repositório

O repositório combina o projeto original e a nova camada Python:

```text
Sonya/
├── Circuits/          circuitos LTspice e resultados históricos
├── ModelsLTspice/     modelos usados pelas simulações LTspice
├── ModelsHSP/         modelos do fluxo HSPICE histórico
├── Start/             rotinas MATLAB e meta-heurísticas originais
├── CirOp.m / Opt.m    pontos de entrada do fluxo MATLAB
└── python/             implementação nova, testes e resultados derivados
    ├── configs/        configuração do circuito, parâmetros e restrições
    ├── schemas/        contrato da configuração
    ├── src/sonya/      biblioteca e interface de linha de comando
    ├── tests/          testes automatizados e regressões contra dados reais
    └── outputs/        simulações e relatórios gerados localmente
```

Durante a execução, a camada Python trata os diretórios legados na raiz como fontes somente para leitura. Toda simulação é preparada numa pasta isolada dentro de `python/outputs/processed`; nenhuma execução altera o netlist ou os dados de origem.

## Funcionalidades

- execução local do LTspice em modo batch no macOS;
- registro comum de backends LTspice/ngspice, com capacidades, diagnóstico e smoke test;
- manifests de topologia independentes do código, com dependências e mapeamentos de includes por backend;
- criação, validação, tradução e execução de novas topologias sem configuração do projeto Sonya;
- catálogos consultáveis de topologias, algoritmos e métricas;
- interface local instalável com configuração guiada, diagrama do circuito, limites editáveis por variável, seleção de todos os componentes, controles perceptuais, execução desacoplada, biblioteca do corpus, progresso por candidato e inspeção das frentes de Pareto;
- pausa, retomada e cancelamento cooperativos na fronteira segura entre candidatos ou casos musicais, com eventos incrementais por análise, candidato, simulação e métrica;
- isolamento de falhas por candidato: não convergência, timeout e resultados `NaN`/infinitos são arquivados e penalizados sem encerrar a campanha;
- resultados incrementais durante a busca, com eixos e cor selecionáveis, cobertura dominada/hipervolume 4D por avaliação, comparação de candidatos e resumos gráficos elétricos/perceptuais;
- simulações de ponto de operação, transiente, resposta AC, slew rate e GedLee legado;
- `GM-Crowe` espectral a partir de um tom estático, com magnitude, fase, convergência por ordem harmônica e diagnóstico do resíduo em quadratura;
- entrada fixa de −10 dBV por padrão e calibração opcional para potência comum na carga;
- leitura de arquivos LTspice `LOG` e `RAW` e exportações do REW;
- cálculo de ganho, potência, banda, THD, slew e grandezas elétricas de segurança;
- pós-processamento canônico comum aos dois simuladores, sem comparar `.measure` nativo com cálculo Python;
- instrumentação de `VCE`, corrente e dissipação dos MJE340 em ambos os simuladores;
- modelo linear de transformador parametrizado e perfis separados para valores nominais ou medidos;
- criação, inspeção e renderização de perfis de transformador pela CLI;
- validação das 25 variáveis, limites, simetrias e parâmetros fixos antes da simulação;
- reprodução do score MATLAB, mantido separado dos objetivos novos;
- otimização reduzida para testar o fluxo completo com até oito candidatos;
- NSGA-II como caminho multiobjetivo principal e GDE3 como verificação independente da cobertura de Pareto;
- DE como baseline escalar moderno e PSO/SAM como referências escalares históricas;
- orçamento comparável por candidatos de circuito, arquivo JSONL reutilizável e destaques representativos por Pareto/diversidade;
- triagem multiobjetivo com GM-Crowe em todo candidato como quarto eixo; os algoritmos escalares preservam também o GM-Legacy histórico;
- manifesto e lock versionáveis para selecionar o corpus musical e preservar referências exatas sem armazenar material licenciado no Git;
- plano de avaliação em camadas: GM-Crowe na engenharia, ViSQOLAudio sobre programa musical completo como objetivo perceptual, GstPEAQ como confirmação e WebMUSHRA para finalistas;
- preparação de pares WAV em 48 kHz com alinhamento, ajuste apenas de nível escalar e preservação da resposta em frequência;
- amostragem perceptual online reprodutível por meia-vida, com limites de candidatos/tempo e validação final da frente comprimida;
- frentes de busca, engenharia, validação perceptual e validação científica, com auditoria explícita dos critérios de entrada;
- proveniência com hashes de configuração, parâmetros, circuitos e modelos;
- geração de figuras e auditoria dos dados históricos.

## Requisitos

- Python 3.11 ou mais recente;
- [`uv`](https://docs.astral.sh/uv/) para instalar e executar o ambiente.

O ngspice pode ser instalado com `brew install ngspice` no macOS ou pelo gerenciador de pacotes da distribuição Linux. Ele executa a topologia EL84 completa e não depende do LTspice. O LTspice permanece recomendado no macOS como backend de referência para os resultados históricos.

A descoberta dos executáveis é automática. Os caminhos podem ser sobrescritos sem editar YAML:

```bash
export SONYA_LTSPICE=/caminho/para/LTspice
export SONYA_NGSPICE=/caminho/para/ngspice
```

Todos os caminhos de circuitos e modelos nos manifests são relativos ao próprio manifest. Nenhum caminho de usuário é necessário. Os parâmetros e restrições do exemplo ficam em [`configs/legacy.yaml`](configs/legacy.yaml); a topologia fica em [`configs/topologies/gagabiro_el84.yaml`](configs/topologies/gagabiro_el84.yaml).

O próprio `Circuits/Audio/gagabiro_el84/circuit.sp` passou a apontar somente para caminhos relativos. As válvulas 12AU7 e EL84 estão reunidas em `ModelsLTspice/koren_tubes.lib`, compartilhado sem tradução de parâmetros pelos dois simuladores. A 12AU7 usa os parâmetros publicados por Norman Koren; a EL84 usa a parametrização 6BQ5 ajustada ao datasheet Mullard e distribuída para as equações de Koren. A antiga biblioteca EL84 criptografada não participa mais de nenhuma execução.

Os dois BC847C do circuito original foram substituídos por MJE340, com modelo Gummel-Poon portável e medidas explícitas de `VCE`, corrente de coletor e dissipação. O modelo incluído é uma aproximação aberta e conservadora baseada no datasheet, não um modelo de correlação do fabricante. Na montagem TO-225 a pinagem física é **1 emissor, 2/tab coletor, 3 base**; ela não deve ser confundida com a ordem elétrica `C B E` da linha SPICE. Os limites e a pinagem estão no [datasheet MJE340G da onsemi](https://www.onsemi.com/download/data-sheet/pdf/mje340-d.pdf).

O transformador também foi desacoplado de uma peça específica: `ModelsLTspice/output_transformer.lib` contém a estrutura linear portável e um arquivo separado contém o perfil ativo. Esse perfil agora representa o transformador customizado fabricado pela Schatz para o amplificador do TCC e reutilizado no Gagabiro: `5,776 kΩ` no primário e taps físicos de `4/6 Ω` explicitamente citados. O circuito ativo seleciona o tap documentado de `6 Ω` e o termina em `6 Ω`; como o modelo usa `LRATIO = ZSEC/ZPRI`, a impedância refletida permanece `5,776 kΩ`. O tap de `8 Ω` continua apenas como inferência documental, não como configuração ativa. O antigo modelo Koren/PAT4002 permanece somente como baseline histórico. A estratégia para a versão não linear, os ensaios nos exemplares e as limitações atuais estão em [TRANSFORMER_MODEL.md](TRANSFORMER_MODEL.md).

O TCC sustenta a relação e os taps do Schatz, mas não fornece indutância de magnetização, fuga, capacitância, DCR, perda de núcleo nem a posição percentual exata do tap ultralinear. Por isso o modelo linear mantém os valores reativos do PAT4002 como substitutos explicitamente marcados, nunca como medições. Para uma montagem nova, o EDCOR CXPP25-6.6K/8 Ω continua documentado como alternativa, sem substituir os transformadores físicos já disponíveis.

## Instalação

### Homebrew no macOS e no Linux

O canal recomendado para os computadores do laboratório é o tap privado do próprio repositório. O Homebrew funciona tanto no macOS quanto no Linux; cada colaborador precisa primeiro ter acesso ao repositório privado e uma chave SSH autorizada no GitHub. A instalação não depende de um checkout permanente:

```bash
brew tap joaocolombari/sonya git@github.com:joaocolombari/Sonya.git
brew install joaocolombari/sonya/sonya
```

No macOS, instale também o backend de referência:

```bash
brew install --cask ltspice
```

No Linux, o `ngspice` é instalado automaticamente como dependência da fórmula. A mesma fórmula instala Python, ffmpeg, a aplicação, circuitos, modelos e scripts operacionais em caminhos administrados pelo Homebrew. Dados mutáveis não ficam dentro do pacote: campanhas são persistidas em `$(brew --prefix)/var/sonya/gui-jobs` e o corpus privado em `$(brew --prefix)/var/sonya/corpus`.

Toda instalação termina executando um inventário dos componentes. Ele separa quatro níveis para não confundir uma GUI funcional com uma estação científica completa:

```bash
sonya install doctor
sonya install doctor --strict package
sonya install doctor --strict core
sonya install doctor --strict perceptual
sonya install doctor --strict all
```

`package` confere o pacote Python e os arquivos de projeto; `core` acrescenta o simulador esperado para o sistema; `perceptual` confere ffmpeg, ViSQOL, GstPEAQ e o corpus; `all` exige simultaneamente o núcleo elétrico e toda a validação perceptual. Sem `--strict`, o comando sempre imprime o relatório completo e usa `status: partial` quando algo opcional ainda falta. Com `--strict`, o código de saída é diferente de zero se aquele escopo não estiver pronto, o que permite usá-lo em scripts e integração contínua.

O corpus EBU SQAM não é redistribuído pelo Git ou pelo Homebrew. Depois de copiar a árvore já preparada para `$(brew --prefix)/var/sonya/corpus`, repita `sonya install doctor --strict all`. No Ubuntu/Debian x86-64, ViSQOL e GstPEAQ são instalados e verificados pelo instalador versionado:

```bash
sudo "$(brew --prefix sonya)/share/sonya/ops/install-perceptual-ubuntu.sh"
sonya install doctor --strict perceptual
```

Abra a interface diretamente ou como serviço persistente:

```bash
sonya gui
brew services start sonya
```

Atualizações preservam o estado e o corpus porque ambos ficam fora do prefixo versionado:

```bash
brew update
brew upgrade sonya
sonya install doctor --strict all
```

### Ambiente de desenvolvimento

Para modificar a aplicação, partindo da raiz de um checkout:

```bash
cd python
uv sync --extra test --python 3.12
```

Confirme os dados, os simuladores disponíveis e os modelos:

```bash
uv run sonya data validate
uv run sonya simulator list
uv run sonya simulator doctor
uv run sonya simulator smoke --backend ltspice
uv run sonya simulator smoke --backend ngspice
uv run pytest
```

O `doctor` apenas verifica cada instalação. O `smoke` executa um divisor resistivo mínimo no backend escolhido e registra resultado e proveniência em `outputs/processed`.

### Ubuntu e servidor dedicado

Uma instalação limpa a partir do repositório usa somente ferramentas usuais da distribuição:

```bash
sudo apt-get update
sudo apt-get install --yes build-essential ffmpeg git ngspice python3-dev python3-venv
git clone --branch python-migration https://github.com/joaocolombari/Sonya.git
cd Sonya
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install --editable './python[test]'
.venv/bin/sonya --config python/configs/legacy.yaml simulator smoke --backend ngspice
.venv/bin/python -m pytest python/tests
```

O workflow [`.github/workflows/ubuntu.yml`](../.github/workflows/ubuntu.yml) repete esses passos no Ubuntu 24.04 a cada push da branch. Para isolar o servidor dos outros projetos não é necessária uma nova partição: um usuário de serviço sem `sudo`, um diretório próprio e limites de processo/armazenamento são suficientes. A forma recomendada é criar `sonya` com home em `/srv/sonya`, manter código, ambiente e resultados sob essa árvore e acessar a interface apenas por túnel SSH.

O bootstrap versionado automatiza essa instalação inicial. Ele aceita tanto um checkout Git quanto uma release extraída, cria um usuário de sistema `sonya` sem senha, login SSH ou `sudo`, copia uma árvore limpa para `/srv/sonya/app`, cria o ambiente Python, instala o ngspice, roda o smoke test e toda a suíte, e registra uma unidade `systemd`. Por segurança, ele recusa sobrescrever uma instalação existente e não inicia o serviço automaticamente:

```bash
sudo ./ops/bootstrap-ubuntu.sh "$PWD"
sudo systemctl enable --now sonya-gui
```

Depois da instalação inicial, uma release `.tar.gz` recebida de um desenvolvedor pode ser aplicada com um único comando. O atualizador recusa operar enquanto houver campanha ativa, preserva `/srv/sonya/state`, `python/corpus` e `python/outputs`, reinstala o pacote editável, executa os testes e só então reinicia a GUI:

```bash
sudo /srv/sonya/app/ops/update-ubuntu.sh /tmp/sonya-release.tar.gz
```

A GUI continua escutando somente no loopback do servidor. Para usá-la em outra máquina, mantenha o serviço privado e abra um túnel com um usuário SSH normal — o usuário de serviço não recebe acesso SSH. Este exemplo usa `8876` no computador cliente para não conflitar com uma instância local na porta `8765`:

```bash
ssh -N -L 8876:127.0.0.1:8765 usuario@servidor
```

Enquanto o túnel estiver aberto, `http://127.0.0.1:8876` no computador cliente aponta para a aplicação do servidor. Isso separa processos e arquivos do Sonya sem inventar uma partição de disco e sem publicar a GUI diretamente na internet.

Os arquivos EBU SQAM permanecem fora do Git conforme os termos de uso da coleção. Em uma instalação limpa, a aplicação valida o protocolo, os papéis e os hashes esperados, mas informa que o corpus local ainda não está pronto. A busca elétrica e o smoke do simulador continuam disponíveis; a validação perceptual só é habilitada depois que os FLACs e WAVs canônicos são instalados sob `python/corpus` e seus hashes são confirmados.

O bootstrap de servidor continua sendo a opção apropriada para uma instalação isolada sob usuário de serviço e `systemd`. O Homebrew é voltado a estações de trabalho e testes individuais; ambos usam o mesmo comando `sonya install doctor` e os mesmos contratos de simulador, corpus e métricas.

## Onde a aplicação roda

A interface usa HTTP e abre no navegador, mas isso não significa que esteja publicada na internet. Por padrão, `sonya gui` aceita conexões somente em `127.0.0.1`: a própria máquina que executa o processo consegue enxergá-la. O endereço `127.0.0.1` sempre significa **esta máquina**, portanto o mesmo texto representa máquinas diferentes no Mac e no servidor.

### Usar os recursos da própria máquina

Cada desenvolvedor pode clonar o repositório, instalar o ambiente e abrir uma GUI que consome somente sua CPU, memória, simuladores e arquivos locais:

```bash
git clone --branch python-migration https://github.com/joaocolombari/Sonya.git
cd Sonya/python
uv sync --extra test --python 3.12
uv run sonya simulator doctor
uv run sonya gui --port 8765
```

No macOS, LTspice e ngspice podem coexistir; no Linux, ngspice é o backend esperado. O navegador acessa diretamente `http://127.0.0.1:8765` e toda a computação acontece nessa máquina:

```text
Navegador local
    └── http://127.0.0.1:8765
            └── Sonya local
                    └── LTspice/ngspice e recursos locais
```

Fechar a aba não encerra uma campanha já iniciada, mas desligar ou suspender a máquina interrompe sua capacidade de continuar executando. Se a porta `8765` já estiver ocupada, escolha outra com `--port`.

### Usar os recursos de um servidor

No servidor do laboratório, o serviço executa como o usuário isolado `sonya` e escuta em `127.0.0.1:8765` **do servidor**. O navegador do desenvolvedor não consegue acessar diretamente esse loopback. O túnel SSH cria uma porta no computador cliente e transporta seu tráfego, de forma criptografada, até o loopback remoto:

```text
Navegador no computador do desenvolvedor
    └── http://127.0.0.1:8876
            └── porta 8876 local
                    └── túnel SSH pela rede privada
                            └── 127.0.0.1:8765 no servidor
                                    └── Sonya + ngspice + recursos do servidor
```

Em um terminal **local**, não dentro do shell remoto, execute:

```bash
ssh -N -L 8876:127.0.0.1:8765 easn-cloud
```

O alias `easn-cloud` é apenas o exemplo atualmente configurado no laboratório; outro desenvolvedor usa seu próprio alias ou `usuario@servidor`. No argumento `-L`, `8876` é a porta criada localmente, enquanto `127.0.0.1:8765` é interpretado do lado remoto. A aba deve então abrir `http://127.0.0.1:8876`.

O VS Code Remote SSH oferece o mesmo mecanismo pela aba **Ports**: encaminhe a porta remota `8765` e abra o endereço local indicado. Estar conectado pelo Remote SSH torna o servidor alcançável, mas a GUI só aparece no navegador depois que a porta é encaminhada pelo VS Code ou pelo comando `ssh -L`.

O túnel transporta somente a interface. Campanhas iniciadas no servidor continuam executando se o navegador, o túnel ou o computador cliente forem fechados; basta recriar o túnel para voltar a acompanhá-las. O serviço `sonya-gui` volta automaticamente após reinicialização do servidor, pois é habilitado pelo `systemd`.

### Duas GUIs ao mesmo tempo

Uma GUI local e uma GUI remota podem ficar abertas simultaneamente no mesmo computador:

| Endereço aberto no navegador | Processo e simulador usados | Sobrevive ao desligamento do computador cliente? |
|---|---|---|
| `http://127.0.0.1:8765` | instalação local e recursos locais | não |
| `http://127.0.0.1:8876` | instalação do servidor por túnel SSH | sim; somente o acompanhamento fica temporariamente indisponível |

Os jobs, resultados e arquivos das duas instâncias são independentes. Para dar acesso a outro computador sem publicar a aplicação, esse computador deve alcançar a rede privada, autenticar-se por SSH e criar seu próprio túnel. Exposição pública exigiria uma camada adicional de TLS, autenticação e controle de acesso e não faz parte da configuração atual.

## Uso rápido

### Abrir a aplicação local

Depois da instalação, inicie a interface com:

```bash
uv run sonya gui
```

O comando abre `http://127.0.0.1:8765` no navegador. A página, os estilos e o código da interface estão incluídos no pacote: não há CDN, conta externa nem conexão com um serviço web. Para apenas iniciar o servidor sem abrir uma aba:

```bash
uv run sonya gui --no-open
```

A aplicação oferece quatro áreas:

- **Configurar:** topologia, figura do circuito, simulador, arquivo de parâmetros, espaço de projeto, limites mínimo/máximo de cada variável, algoritmo, orçamento, quantidade de destaques representativos, modo de excitação e regularidade da amostragem perceptual;
- **Acompanhar:** estado persistido, candidatos e GM-Crowe concluídos, eventos detalhados e controles de pausa/retomada/cancelamento tanto para a otimização quanto para a validação musical;
- **Resultados:** ainda durante a busca, métricas com unidades, eixos e cor selecionáveis, projeção preliminar da frente elétrica 4D e cobertura dominada ao longo das avaliações; ao final, comparação gráfica/tabular, detalhes por candidato e execução da validação pós-seleção com ViSQOL/GstPEAQ;
- **Corpus musical:** acesso aos quatro trechos online e aos oito trechos comuns à validação final e ao WebMUSHRA, com os níveis `nominal` e `limit` documentados.

Ao expandir o espaço de projeto, cada parâmetro mostra valor-base, unidade, simetria e limites editáveis. Parâmetros fixos permanecem bloqueados. O intervalo precisa conter o valor-base do arquivo selecionado; variáveis simétricas precisam compartilhar uma interseção válida. Os limites efetivos são gravados no protocolo da campanha, de modo que a execução possa ser reproduzida fora da GUI.

Cada campanha é iniciada como processo separado e registrada em `outputs/processed/gui-jobs`. Fechar a aba não encerra a otimização; ao reabrir a GUI, ela recupera o estado pelo PID, pelo arquivo de candidatos e pelo `campaign.json`. A atualização ocorre a cada dois segundos e usa candidatos únicos como unidade de progresso. Pausa e cancelamento são cooperativos: uma simulação já iniciada termina normalmente, e a ação solicitada se efetiva antes do próximo candidato. Isso evita deixar artefatos SPICE parcialmente escritos.

Na lista de campanhas, **elétrica concluída** aparece em azul. Depois que uma execução perceptual termina sem casos falhos, o estado passa a **elétrica + perceptual concluída**, em azul mais escuro. O escopo científico — desenvolvimento, validação parcial ou validação final — permanece discriminado dentro do relatório perceptual; ele não é confundido com sucesso ou falha da execução.

A área **Resultados** lê incrementalmente o `candidate-archive.jsonl`, portanto não precisa aguardar o `campaign.json`: candidatos, frente e convergência aparecem enquanto a campanha está em andamento. Os resultados são marcados como preliminares. Como os extremos usados na normalização são os melhores e piores valores disponíveis naquele instante, um novo extremo pode reescalar também o histórico anterior; a curva só se torna definitiva quando a campanha termina. Em campanhas longas, a curva usa checkpoints exatos espaçados e sempre inclui o candidato mais recente; isso limita o custo do cálculo 4D sem aproximar o valor mostrado em cada checkpoint.

Uma combinação de componentes pode não convergir ou produzir valores `NaN` mesmo quando o simulador termina com código de sucesso. Esse é um resultado inválido do candidato, não uma falha fatal da otimização. A campanha registra a análise e a mensagem, atribui uma penalidade finita, marca o candidato como inviável e continua. O candidato consome uma avaliação do orçamento, mas fica fora das frentes de Pareto, do cálculo do hipervolume, dos destaques e da seleção perceptual. Erros anteriores à campanha, como simulador ausente ou configuração inválida, continuam sendo recusados imediatamente.

Na área **Resultados**, a validação perceptual mostra previamente quantos casos serão executados e permite escolher a seleção `online` ou `final`, a partição e os trechos individuais do corpus, os níveis `nominal`/`limit`, ViSQOL/GstPEAQ, o modelo PEAQ, a taxa da simulação e o timeout por caso. Ela usa o mesmo backend da campanha, LTspice ou ngspice. O LTspice lê diretamente um WAV PCM16 com `wavefile`; o ngspice usa seu `filesource` externo. Assim, nenhum deles recebe centenas de milhares de pontos dentro do netlist. Cada caso concluído ou falho atualiza `validation.partial.json`; uma falha isolada é registrada, o próximo caso continua e somente candidatos com todos os casos entram na frente perceptual. O padrão da GUI é `48 kHz` e `20 min` por caso.

Por segurança, esta etapa aceita somente `localhost`. No servidor, o acesso remoto é feito pelo túnel SSH descrito acima, sem expor a interface diretamente à internet.

### Descobrir as opções disponíveis

Os catálogos são a mesma fonte usada pela interface gráfica para montar seus seletores:

```bash
uv run sonya topology list
uv run sonya topology show gagabiro_el84
uv run sonya algorithm list
uv run sonya algorithm show bounded_grid
uv run sonya objective list
uv run sonya transformer show configs/transformers/pat4002.yaml
uv run sonya transformer show configs/transformers/schatz_custom_5776_4_6_8.yaml
uv run sonya transformer show configs/transformers/edcor_cxpp25_6k6_8.yaml
```

Cada opção informa se está implementada, planejada ou aguardando definição de protocolo. A CLI recusa uma combinação ainda não executável em vez de iniciá-la parcialmente.

Perfis de outros transformadores podem ser criados e convertidos em parâmetros SPICE sem caminhos ou nomes do Sonya:

```bash
uv run sonya transformer init meu_transformador --output ./meu_transformador.yaml
uv run sonya transformer render ./meu_transformador.yaml --output ./meu_transformador.inc
```

### Adicionar uma topologia própria

Crie um exemplo independente — estes comandos não carregam a configuração Sonya:

```bash
uv run sonya topology init meu_amplificador --directory ./meu_amplificador
uv run sonya topology validate ./meu_amplificador/topology.yaml
uv run sonya topology run ./meu_amplificador/topology.yaml \
  --backend ngspice \
  --output ./outputs/meu_amplificador-ngspice
```

Para um circuito existente, edite `topology.yaml` e declare:

- o netlist em `circuit`;
- os nomes dos parâmetros em `parameter_ids`;
- as análises suportadas;
- dependências de modelos por backend;
- `include_map` quando LTspice e ngspice usam arquivos diferentes;
- as transformações portáveis necessárias.

Para apenas preparar e inspecionar a tradução, sem executar:

```bash
uv run sonya topology translate ./meu_amplificador/topology.yaml \
  --backend ngspice \
  --output ./outputs/traduzido
```

O staging recusa modelos criptografados no ngspice, impede nomes de destino que escapem da pasta, fixa hashes de todas as entradas e nunca altera o netlist original. `.lib` locais são convertidos para `.include` no ngspice, caminhos absolutos podem ser remapeados e diretivas LTspice declaradas são removidas apenas na cópia.

O scaffold também declara dois parâmetros, seus limites e um objetivo de exemplo. Isso permite testar o laço de otimização sem qualquer módulo específico do Sonya:

```bash
uv run sonya optimize manifest ./meu_amplificador/topology.yaml \
  --backend ngspice \
  --output-root ./outputs/otimizacao \
  --vary R_TOP \
  --count 3 \
  --step 0.10
```

O mesmo comando aceita `--backend ltspice`. Nesta primeira versão genérica, o objetivo do manifest é uma expressão de ponto de operação com meta `minimize`, `maximize` ou `target`; a busca reduzida continua limitada a oito candidatos. Análises e objetivos mais complexos deverão ser adicionados como adaptadores, sem introduzir nomes de topologias no núcleo.

### Simular o baseline completo

Executa os seis modos do circuito em uma cópia isolada e compara as métricas com o resultado histórico. O sexto modo é o transiente de alta resolução reservado ao GM-Crowe:

```bash
uv run sonya simulate legacy \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --mode all \
  --reference ../Circuits/Audio/gagabiro_el84/results/initial_solution/paramop_initial
```

O comando faz o preflight antes de iniciar o LTspice. Parâmetros fora dos limites, VAA acima do teto, valores fixos alterados ou pares assimétricos interrompem a execução.

### Rodar uma otimização de teste

Este exemplo compara o baseline com `X1` reduzido e aumentado em 5%:

```bash
uv run sonya optimize test \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --topology gagabiro_el84 \
  --algorithm bounded_grid \
  --backend ltspice \
  --vary X1 \
  --count 3 \
  --step 0.05
```

Para explorar mais de uma variável, repita `--vary`:

```bash
uv run sonya optimize test \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --vary X1 \
  --vary X2 \
  --count 5 \
  --step 0.05
```

`--count` inclui o baseline e aceita no máximo oito candidatos. Pares declarados como simétricos são modificados juntos. O ranking usa uma penalidade provisória sem o GM legado; enquanto os limites SOA não estiverem configurados, nenhum vencedor é marcado como projeto aprovado.

Por padrão, todos os candidatos recebem a mesma entrada de linha de consumo, `−10 dBV = 0,316227766 V RMS`. Nesse protocolo, ganho e potência fazem parte do desempenho otimizado. Para reproduzir a comparação alternativa exigida pelo revisor, calibre cada candidato para a mesma potência real na carga:

```bash
uv run sonya optimize test \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --backend ltspice \
  --drive-mode matched-output-power \
  --target-output-power 10 \
  --count 3
```

A calibração usa as simulações transientes do próprio candidato e busca a tensão RMS de entrada até `média(V(out)²)/Rload` atingir o alvo. Ela não presume ganho linear. O relatório registra todas as tentativas, a tensão encontrada, a potência atingida e o erro relativo.

### Rodar uma campanha multiobjetivo

O comando `campaign` é o caminho normal para uma otimização nova. Este piloto varia apenas `X1`, avalia oito circuitos e destaca dois candidatos representativos para inspeção:

```bash
uv run sonya optimize campaign \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --algorithm nsga2 \
  --backend ngspice \
  --vary X1 \
  --budget 8 \
  --population-size 4 \
  --promote 2 \
  --seed 0
```

Sem `--vary`, todas as variáveis não fixas entram no espaço de busca e os pares simétricos continuam sendo uma única dimensão. Para uma exploração com muitas variáveis, aumente orçamento e população; oito candidatos são apenas um teste de integração.

Os mesmos limites disponíveis na interface podem ser definidos pela CLI. Repita `--parameter-bound` para cada variável que quiser restringir:

```bash
uv run sonya optimize campaign \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --algorithm nsga2 --backend ngspice \
  --vary X1 --parameter-bound X1:60:80 \
  --budget 8 --population-size 4 --promote 2
```

O formato é `ID:MÍNIMO:MÁXIMO`. O valor-base deve pertencer ao intervalo e parâmetros fixos não podem ser sobrescritos. Para pares simétricos, os intervalos declarados precisam ter uma região comum.

NSGA-II e GDE3 mantêm quatro objetivos separados: maximizam potência e slew rate e minimizam variação da resposta em frequência e GM-Crowe. THD continua sendo calculada, arquivada e mostrada para cada candidato, mas não participa da dominância. O GM-Crowe usa seu tom de 1 V de pico em todo candidato; somente a escada GM-Legacy fica fora da busca multiobjetivo. `--promote` não dispara uma simulação nem define a validação musical: ele controla apenas quantos representantes da frente/diversidade ficam destacados na interface. As listas perceptuais `online` e `final` são calculadas separadamente por `perceptual_sampling`.

Na GUI, cada um desses quatro objetivos é transformado para minimização e reescalado entre `0` (melhor valor observado) e `1` (pior). O ponto de referência do hipervolume é `(1,1; 1,1; 1,1; 1,1)`: a vírgula aqui é decimal, isto é, `1.1` em cada eixo, 10% além do pior observado. Essa margem mantém a referência estritamente pior que todos os candidatos e evita que um ponto na borda tenha contribuição nula. Em quatro dimensões, a caixa de referência tem volume `1,1⁴ = 1,4641`. A interface usa como indicador principal a **cobertura dominada**, `100 × hipervolume / 1,4641`, e mantém o hipervolume 4D sem unidade como dado técnico. Ambos são adequados para acompanhar a evolução dentro de uma campanha, mas não devem ser comparados cegamente entre campanhas normalizadas por extremos diferentes.

#### Como interpretar os parâmetros dos algoritmos

| Parâmetro | Significado prático |
|---|---|
| Candidatos únicos (`budget`) | Número máximo de circuitos diferentes simulados. É a base correta para comparar o custo dos algoritmos. |
| População | Candidatos mantidos simultaneamente. Uma população maior melhora diversidade/cobertura, mas, com orçamento fixo, deixa menos gerações para evoluir. |
| Seed | Torna reproduzíveis população inicial, sorteios, crossover e mutações. Não muda o espaço de projeto. |
| `F` | Peso da diferença em DE/GDE3. Valores maiores produzem saltos mais largos; `0,8` é o padrão atual. |
| `CR` | Probabilidade de cada coordenada vir do vetor mutante em DE/GDE3. Perto de `1` combina mais parâmetros de uma vez; `0,9` é o padrão. |
| Temperatura inicial | No SAM, controla a aceitação inicial de soluções piores e, portanto, a capacidade de escapar de mínimos locais. O adaptador atual preserva `50`. |
| Resfriamento | Multiplicador periódico da temperatura no SAM; mais próximo de `1` prolonga exploração. O adaptador atual preserva `0,9`. |
| Destaques representativos (`promote`) | Quantidade de pontos realçados para leitura humana; não é orçamento, população nem lista de validação perceptual. |

No PSO legado, inércia e coeficientes cognitivo/social permanecem fixos nos valores históricos. No NSGA-II, seleção por dominância, crowding, crossover e mutação seguem a implementação interna; atualmente a GUI expõe população, orçamento e seed. `sonya algorithm show ID` apresenta o contrato completo de cada opção.

GDE3 é a segunda heurística multiobjetivo. Ela usa a mutação diferencial `a + F(b − c)`, crossover binomial e seleção por dominância/crowding, sem transformar os objetivos em uma soma ponderada:

```bash
uv run sonya optimize campaign \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --algorithm gde3 --backend ngspice \
  --vary X1 --budget 40 --population-size 8 --promote 4 \
  --mutation-factor 0.8 --crossover-probability 0.9
```

Usar NSGA-II e GDE3 com o mesmo orçamento permite verificar se a forma da frente depende excessivamente de uma única heurística. Eles não tornam a frente perceptualmente válida por si: essa validade vem das avaliações e evidências posteriores.

DE escalar, PSO e SAM permanecem executáveis como referências. A DE é um baseline moderno para ablação e identificação de parâmetros; PSO e SAM preservam a comparação histórica com o MATLAB:

```bash
uv run sonya optimize campaign ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --algorithm differential_evolution --backend ltspice --vary X1 \
  --budget 40 --population-size 8 --promote 4

uv run sonya optimize campaign ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --algorithm legacy_pso --backend ltspice --vary X1 --budget 40 --population-size 8 --promote 4

uv run sonya optimize campaign ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --algorithm legacy_sam --backend ltspice --vary X1 --budget 40 --promote 4
```

Essas três referências escalares usam deliberadamente o score histórico, inclusive GM-Legacy. Elas não executam métricas de programa musical dentro do laço. Compare algoritmos por `--budget`, isto é, número de candidatos de circuito únicos, e não por gerações.

Cada campanha produz `campaign.json`, `candidate-archive.jsonl` e `provenance.json`. O arquivo JSONL é um cache comum e somente-acréscimo entre as fidelidades. Ele pode ser reaproveitado sem repetir simulações idênticas:

```bash
uv run sonya optimize campaign ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --algorithm nsga2 --backend ngspice --vary X1 --budget 8 --population-size 4 --promote 2 \
  --archive ./outputs/minha-campanha/candidate-archive.jsonl
```

O relatório diferencia quatro frentes em `pareto_fronts`: `search`, `engineering`, `perceptual_validation` e `scientifically_validated`. A frente perceptual permanece vazia enquanto faltarem resultados da campanha no corpus de validação; a científica exige ainda SOA dinâmica. Portanto, a campanha já seleciona e compara candidatos, mas ainda não declara um circuito ótimo validado.

Cada cálculo de Pareto inclui uma auditoria. Além de exigir métricas finitas e viabilidade, a frente perceptual exige separação do corpus de validação, versões dos adaptadores e proveniência. A frente científica acrescenta evidência explícita de SOA dinâmica. Um resultado obtido apenas no corpus de desenvolvimento pode ser estudado, mas não entra silenciosamente na frente validada.

O núcleo de espaço de parâmetros e heurísticas é independente da topologia. Nesta etapa, o adaptador completo multi-fidelidade da CLI usa as análises elétricas da topologia EL84; topologias externas continuam podendo usar `optimize manifest` e ganharão campanhas multiobjetivo quando declararem adaptadores de métricas equivalentes.

O mesmo ensaio pode ser executado no ngspice:

```bash
uv run sonya optimize test \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --backend ngspice --count 3
```

Esse backend ainda é marcado como `experimental`, embora use exatamente os mesmos modelos Koren de EL84/12AU7, MJE340 e transformador linear que o LTspice. Potência, resposta AC, THD, slew e GM são extraídos pelo mesmo código a partir das formas de onda exportadas. A potência é definida como `média(V(out)²)/Rload`, equivalente a `Vrms²/Rload`, como na medição prática. As medidas nativas dos simuladores continuam registradas apenas para auditoria.

Compare os dois backends sobre o mesmo baseline com:

```bash
uv run sonya simulator compare \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt
```

O relatório preserva os dois resumos e as diferenças absoluta e relativa por métrica. Ele caracteriza a troca de backend/modelos; não declara equivalência.

Para comparar LTspice e ngspice com 10 W em ambos:

```bash
uv run sonya simulator compare \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --drive-mode matched-output-power \
  --target-output-power 10
```

No baseline atual com o Schatz linear, a comparação canônica encontrou aproximadamente `0,049%` de diferença em potência, menos de `0,000004%` nos cutoffs, `0,253%` em THD, `4,76%` em slew, `0,082%` no GM-Crowe adaptativo e `0,050%` no GM-Legacy. Esses números validam o adaptador nesse ponto de operação, não todo o domínio da otimização. O slew passou a ser a maior divergência e deverá ser reavaliado fora do baseline.

### GM-Crowe e GM-Legacy

O relatório mantém dois métodos com nomes e protocolos distintos:

- `gm_crowe`: método principal novo. Usa um transiente senoidal independente de 1 V de pico (`0,7071 V RMS`, `−3,0103 dBV`), o mesmo limite da escada legada. A ordem harmônica cresce adaptativamente, a fase é preservada e a parte estática de `T(x)` é construída como uma expansão de Chebyshev. O Gm é integrado a partir da segunda derivada analítica;
- `gm_legacy`: reprodução histórica do MATLAB. Faz uma sequência de 101 amplitudes, extrai mínimos e máximos, interpola `T(x)` por spline e deriva numericamente.

O `GM-Crowe` registra também:

- valor em cada ordem da sequência configurada, atualmente H10 até H400;
- mudança relativa entre ordens sucessivas, ordem finalmente escolhida e indicador `converged`;
- convergência somente depois de duas mudanças consecutivas de no máximo 0,5%;
- fases relativas e amplitudes normalizadas dos harmônicos;
- resíduo do ajuste espectral;
- `memory_ratio`, nome histórico da parcela em quadratura que não cabe numa única curva estática; é um diagnóstico do ensaio, não um objetivo nem uma prova isolada de memória do amplificador.

A simulação escolhe automaticamente um passo máximo compatível com `samples_per_cycle` e com a maior ordem configurada. Se o platô não for alcançado antes do teto, o maior resultado ainda é preservado para diagnóstico, mas recebe `converged: false` e não deve ser tratado como um GM estável. A FFT é calculada uma única vez por forma de onda; as diferentes ordens reutilizam o mesmo espectro, evitando resolver repetidamente grandes sistemas de mínimos quadrados.

O nome identifica a implementação aberta do protocolo descrito por [Joseph Crowe](https://josephcrowe.com/pages/revisiting-the-gedlee-metric-a-more-reliable-gm-test-in-virtins-multi-instrument) e pela documentação do VIRTINS. Não significa que o código proprietário do VIRTINS foi reproduzido byte a byte. A equivalência numérica com o VIRTINS deverá ser testada posteriormente com sinais sintéticos e exportações harmônicas comuns.

Os antigos cálculos de spline analítica, PCHIP e spline suavizada permanecem no diagnóstico `gm_robustness` para estudar a fragilidade do protocolo legado, mas não são apresentados como um terceiro Gm oficial.

No baseline com o Schatz linear, o `GM-Crowe` convergiu em H200 para `5,01510` no LTspice e `5,01921` no ngspice, diferença de `0,082%`. O `GM-Legacy`, que percorre a mesma amplitude máxima de 1 V de pico, produziu `6,05323/6,05022`. Os métodos agora observam o mesmo intervalo, embora continuem sendo estimadores diferentes. As métricas de potência, ganho e THD permanecem no transiente nominal de −10 dBV e não são substituídas pelo ensaio de GM.

### Inspecionar o plano de avaliação musical

```bash
uv run sonya evaluation plan
uv run sonya evaluation corpus
```

O primeiro comando mostra as camadas e métricas. O segundo valida arquivos, referências canônicas, categorias, hashes, níveis e o contrato de papéis do corpus declarado em [`configs/programme.yaml`](configs/programme.yaml). Os papéis são cumulativos: `development` significa o conjunto online, `validation` a validação objetiva final e `subjective` o WebMUSHRA. O manifesto exige quatro, oito e oito itens, respectivamente; também exige que os oito IDs de `validation` e `subjective` sejam idênticos e que os quatro online sejam um subconjunto deles. A camada de programa musical está pronta.

| Uso | Trechos | Propriedade principal |
|---|---|---|
| Online (4) | castanholas | ataques esparsos, transientes e baixa mascaragem |
| Online (4) | contrabaixo | grave sustentado |
| Online (4) | orquestra/R. Strauss | textura densa e energia de banda larga |
| Online (4) | piano/Schubert | transição forte–fraco e recuperação |
| Final + WebMUSHRA (8) | os quatro acima + cravo, soprano, orquestra/Baird e ABBA | cobertura complementar de harmônicos expostos, voz, dinâmica orquestral e mascaragem densa |

Eddie Rabbitt permanece no manifesto como `reserve`: seu mix vocal denso é o mais redundante com ABBA entre os nove pré-selecionados. O WAV canônico de audição continua disponível na biblioteca da GUI e para análises de sensibilidade, mas não integra silenciosamente os oito itens finais/WebMUSHRA.

Os arquivos originais e derivados ficam em `corpus/` e são ignorados pelo Git. Depois de baixar o EBU SQAM para `corpus/source/ebu-sqam/`, gere os trechos canônicos e a página local de audição com:

```bash
uv run sonya corpus prepare --programme ./configs/programme.yaml --role all
```

O comando verifica o SHA-256 de cada original, seleciona somente o canal declarado — sem somar os canais estéreo —, recorta 12 segundos, remove DC, aplica fades de 10 ms, faz apenas um ajuste escalar de RMS ativo com proteção de pico e grava mono PCM16 a 48 kHz. Não há compressão nem equalização. Os resultados são:

- `corpus/audition/index.html`: página para ouvir e comparar os nove candidatos;
- `corpus/audition/audition-index.json`: proveniência, medidas e caminhos locais;
- `corpus/audition/assets/*.wav`: referências canônicas;
- [`configs/programme-audition.lock.json`](configs/programme-audition.lock.json): hashes portáveis dos nove trechos, incluindo a reserva;
- [`configs/programme-final.lock.json`](configs/programme-final.lock.json): hashes portáveis dos oito WAVs exatos compartilhados pela validação final e pelo WebMUSHRA.

Para reconstruir e conferir somente o conjunto final:

```bash
uv run sonya corpus prepare \
  --programme ./configs/programme.yaml --role validation \
  --output ./corpus/final --lock ./configs/programme-final.lock.json
```

Se uma regeneração produzir conteúdo diferente do lock, o comando falha em vez de aceitar silenciosamente uma nova referência. Os oito itens com papel `validation` são exatamente os mesmos oito com papel `subjective`; portanto o WebMUSHRA reutilizará as referências fixadas, sem novo recorte ou normalização. IDs cegos das condições processadas só serão criados depois que os circuitos finalistas existirem. As condições de uso do SQAM permitem P&D não comercial, mas os áudios não devem ser publicados no repositório ou redistribuídos comercialmente.

ViSQOL e GstPEAQ são ferramentas externas opcionais; não são baixadas silenciosamente pela aplicação. O par entregue às ferramentas é mono, alinhado, normalizado por um único ganho escalar, limitado conjuntamente e gravado como PCM de 16 bits a 48 kHz, formato aceito pelas duas CLIs. Verifique a instalação e, se necessário, informe caminhos portáveis por variável de ambiente:

```bash
uv run sonya perceptual doctor
export SONYA_VISQOL=/caminho/para/visqol
export SONYA_GSTPEAQ=/caminho/para/peaq
```

No Ubuntu/Debian x86-64, o instalador versionado compila as fontes oficiais, fixa ViSQOL `3.3.3`, GstPEAQ `0.6.1` e Bazel `5.1.0`, confere os SHA-256 antes de executar qualquer artefato e termina rodando o próprio diagnóstico do Sonya. Como a URL histórica do Armadillo 9.860.2 usada pelo ViSQOL não existe mais, um patch versionado substitui somente esse repositório Bazel por uma cópia isolada dos cabeçalhos `libarmadillo-dev` da distribuição. A cópia isolada evita reintroduzir `/usr/include` como dependência externa e quebrar a resolução dos cabeçalhos-padrão do C++. No Ubuntu 26.04, o TensorFlow antigo incorporado ao ViSQOL não compila com o GCC 15 padrão; o instalador usa GCC 12 somente durante o build, sem mudar o compilador do sistema. O paralelismo é limitado a quatro processos por padrão e pode ser reduzido, por exemplo com `sudo env SONYA_BUILD_JOBS=2 ...`. Logs completos permanecem em `/var/log/sonya/visqol-build.log` e `/var/log/sonya/gstpeaq-build.log`. A opção `--restart-gui` atualiza imediatamente o cartão da interface, mas recusa o reinício se houver uma campanha ativa:

O arquivo-fonte automático do GstPEAQ publicado pelo GitHub não contém o `ChangeLog` vazio esperado pelo Automake em modo GNU. O instalador recria esse arquivo de metadados antes do `autoreconf`; isso não altera o código nem a métrica.

```bash
sudo /srv/sonya/app/ops/install-perceptual-ubuntu.sh --restart-gui
```

O pacote chamado simplesmente `visqol` no PyPI não é a distribuição oficial do Google e não deve ser instalado. O canal reproduzível do servidor é o script acima; um pacote Python não é adequado para esconder os dois binários nativos e seus modelos.

Um par de WAVs já preparado pode ser medido diretamente:

```bash
uv run sonya perceptual metric ./reference.wav ./degraded.wav --metric all
```

ViSQOL/MOS-LQO é o único eixo perceptual previsto para a frente. `gstpeaq_basic_odg` e `gstpeaq_advanced_odg` são confirmações registradas em separado. O GstPEAQ é uma implementação aberta útil para comparação, mas não deve ser descrito como uma implementação com tolerâncias normativas certificadas da BS.1387.

Antes de comprometer um orçamento grande, meça o custo do circuito completo no computador atual. O comando gera um sinal determinístico, executa o backend escolhido, prepara os WAVs e projeta uma campanha de 8 candidatos, 3 trechos, 2 níveis e 5 segundos por execução. Use `--backend ngspice` ou `--backend ltspice`:

```bash
uv run sonya perceptual benchmark \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt \
  --backend ngspice \
  --duration 0.5 --preroll 0.05 \
  --projection-candidates 8 --projection-clips 3 --projection-levels 2 \
  --projection-duration 5
```

A campanha já grava em `perceptual_sampling` uma seleção online reprodutível. A probabilidade básica é definida por `--perceptual-half-life`: com meia-vida 50, o processo tem aproximadamente 50% de chance acumulada de solicitar uma avaliação ao longo de 50 candidatos elegíveis antes dos pesos. Candidatos da primeira frente recebem peso maior, novidade aumenta a chance, e baseline/extremos são obrigatórios. `--perceptual-online-max` e `--perceptual-wall-time-hours` impõem limites rígidos. A seleção online coleta evidência e custo, mas ainda não altera a busca.

Também é possível recalcular apenas o plano a partir de qualquer `campaign.json`:

```bash
uv run sonya perceptual sample ./outputs/minha-campanha/campaign.json \
  --perceptual-half-life 50 \
  --perceptual-online-max 10 \
  --perceptual-estimated-cost-seconds 700 \
  --perceptual-wall-time-hours 2 \
  --perceptual-final-max 20
```

Ao final, a primeira frente é comprimida por células epsilon e recebe alguns vizinhos próximos. Essa lista final é determinística e deve ser validada integralmente; a regra estocástica serve apenas à amostragem ativa durante a campanha.

O executor percorre a seleção, os trechos e os dois níveis fixados no manifesto, roda o circuito completo e agrega as métricas por candidato e por nível:

```bash
uv run sonya perceptual validate ./outputs/minha-campanha/campaign.json \
  --programme ./configs/programme.yaml \
  --selection final --role validation \
  --metric all --peaq-model both
```

Por padrão são executados todos os trechos do papel escolhido e os níveis `nominal = 0,447213595 Vpk`, pico equivalente a um seno de −10 dBV, e `limit = 1 Vpk`, limite superior histórico do GM sem alegar que seja o clipping do circuito. `--item sqam-double-bass` e `--level nominal` podem restringir um diagnóstico; as duas opções são repetíveis e também aparecem como seletores na GUI. Uma execução que não contenha todos os trechos **e os dois níveis** do papel `validation` recebe o escopo `partial_validation_only` e não satisfaz a evidência necessária para a frente perceptual validada.

O executor escala por pico sem mudar o fator de crista, usa o backend gravado na campanha, verifica a tensão realmente entregue com tolerância de 0,05% para quantização/interpolação da malha temporal e registra o erro observado, as médias separadas e `limit_minus_nominal`. O número principal mostrado para cada métrica/candidato é a média aritmética com peso igual de todos os casos bem-sucedidos `trecho × nível`; não há ponderação por gênero, trecho ou nível. Para não esconder dispersão ou um caso ruim, o relatório e a GUI também apresentam mínimo, máximo, desvio-padrão e quantidade de casos, além das médias por nível. No papel `validation` completo, o comando exige cobertura das categorias e correspondência dos hashes dos originais e dos WAVs canônicos. `--selection online` executa a amostra de custo/correlação; `final` é o padrão para a validação determinística.

A política atual é:

1. executar restrições e os quatro objetivos elétricos — potência, slew rate, uniformidade e GM-Crowe — em todo candidato; THD permanece diagnóstica e GM-Legacy fica apenas nas referências escalares históricas;
2. construir a frente elétrica e realçar alguns representantes por Pareto/crowding apenas para inspeção;
3. executar pela GUI ou CLI a seleção online ou final com ViSQOLAudio e GstPEAQ sobre trechos fixados por hash;
4. construir primeiro uma frente perceptual de validação e depois a frente cientificamente validada, somente com candidatos viáveis, métricas completas e todas as evidências exigidas;
5. reservar o WebMUSHRA para os finalistas, usando os mesmos oito trechos da validação objetiva.

Os detalhes e decisões pendentes estão em [EVALUATION_PROTOCOL.md](EVALUATION_PROTOCOL.md).

### Reproduzir medições antigas do REW

```bash
uv run sonya legacy evaluate \
  ../Circuits/Audio/gagabiro_el84/prototype/test_unnoptimized \
  --vaa 300
```

Esse fluxo lê as exportações históricas, recalcula as métricas e informa as diferenças em relação ao `results.txt`, sem escrever na pasta original.

### Inspecionar um vetor de parâmetros

```bash
uv run sonya params read \
  ../Circuits/Audio/gagabiro_el84/param_unoptimized.txt
```

### Gerar uma figura de avaliação

Depois de uma simulação completa, use o caminho do `evaluation.json` mostrado no terminal:

```bash
uv run sonya figure evaluation \
  outputs/processed/evaluation-.../evaluation.json \
  --output outputs/processed/evaluation-.../baseline-summary.png
```

### Auditar os dados históricos

```bash
uv run sonya data audit
```

A auditoria procura arquivos duplicados por SHA-256 e alterações numéricas manuais no material legado.

## Resultados e proveniência

Os artefatos derivados ficam em `outputs/processed/`, separados por execução:

```text
outputs/processed/
├── evaluation-.../          avaliação completa do baseline
├── optimization-test-.../   lote reduzido e ranking
├── simulator-comparison-.../ comparação LTspice/ngspice
├── ltspice-smoke-.../        diagnóstico mínimo do LTspice
└── ngspice-smoke-.../        diagnóstico mínimo do ngspice
```

Cada execução conserva netlists derivados, parâmetros efetivamente usados, logs, arquivos RAW e um `provenance.json`. Os diretórios têm nomes únicos, então uma nova execução não sobrescreve a anterior.

## Desenvolvimento

Execute a suíte completa com:

```bash
uv run pytest
```

Para ver todos os comandos e opções:

```bash
uv run sonya --help
uv run sonya simulate --help
uv run sonya optimize test --help
```

As principais decisões e separações conceituais estão documentadas em:

- [STATUS.md](STATUS.md): estado atual, capacidades e pendências;
- [IMPLEMENTATION_REPORT.md](IMPLEMENTATION_REPORT.md): resultados numéricos e descobertas da implementação;
- [EVALUATION_PROTOCOL.md](EVALUATION_PROTOCOL.md): avaliação multi-fidelidade e seleção musical;
- [TRANSFORMER_MODEL.md](TRANSFORMER_MODEL.md): modelo linear, candidato físico e plano de identificação não linear;
- [MIGRATION_MAP.md](MIGRATION_MAP.md): correspondência entre o fluxo MATLAB e os módulos Python;
- [configs/legacy.yaml](configs/legacy.yaml): parâmetros, caminhos e restrições vigentes;
- [schemas/config.schema.json](schemas/config.schema.json): estrutura formal da configuração;
- [schemas/topology.schema.json](schemas/topology.schema.json): contrato formal dos manifests portáveis.

## Limites atuais

Esta implementação ainda não autoriza uma campanha extensa nem declara um circuito ótimo. Permanecem em aberto os limites SOA e suas margens, a identificação não linear do transformador físico e a execução da campanha completa. O tap/carga simulados agora são `6 Ω`, preservando os `5,776 kΩ` refletidos; os `6,15 Ω` medidos continuam sendo um pequeno desvio do exemplar real a documentar, não uma incompatibilidade de tap. O modelo MJE340 incluído é provisório e não substitui validação de SOA ou medição dos lotes reais. O GM é preservado para reprodução e triagem; a validação musical sobre a simulação transiente completa cobre as consequências perceptuais da dinâmica representada pelo modelo. PESQ e STOI não fazem parte do método por serem orientados à fala.
