***************************************
*** GAGABIRO VALVE POWER AMPLIFIER 	***
***	AUTHOR:  JOAO CARLET			***
*** CONTACT: JVCCARLET@USP.BR		***
***************************************

*RESISTORS
R1 		0 		N023 	{int(X1)*1R}
R2 		N021 	V_PP 	{int(X2)*1R}
R3 		0 		N010 	{int(X3)*1R}
R4 		N008 	V_PP 	{int(X4)*1R}
R5 		N003 	V_PP 	{int(X5)*1R}
R6 		N009 	N017 	{int(X6)*1R}
R7 		V_in 	N017 	{int(X7)*1R}
R8 		N010 	N011 	{int(X8)*1R}
R9 		0 		N012 	{int(X9)*1R}
R10 	N019 	N020 	{int(X10)*1R}
R11 	N019 	0 		{int(X11)*1R}
R12 	N006 	N007 	{int(X12)*1R}
R13 	N022 	0 		{int(X13)*1R}
R14 	N009 	N006 	{int(X14)*1R}
R15 	V_grid 	N004 	{int(X15)*1R}
R16 	N015 	V_grid 	{int(X16)*1R}
R17 	N016 	N015 	{int(X17)*1R}
R18 	N005 	N004 	{int(X18)*1R}

*LOAD RESISTOR
Rload 	0 		out 	6

*CAPACITORS
C1 		N010 	N009 	{int(X19)*1u}
C2 		N017 	N019 	{int(X20)*1n}
C3 		N022 	0 		{int(X21)*1u}
C4 		N015 	N008 	{int(X22)*1u}
C5 		N004 	N003 	{int(X23)*1u}

*BIPOLARS (SPICE order C B E substrate; TO-225 package is E C B)
Q1 N013 N021 N023 	0 MJE340
Q2 N021 N023 0 		0 MJE340

*OUTPUT TRANSFORMER - portable linear model with an explicit measurement profile
XU1 N001 N002 V_PP N014 N018 out NC_01 0 OUTPUT_TRANSFORMER_UL PARAMS: LPRIM={TX_LPRIM} LLEAK={TX_LLEAK} ZPRI={TX_ZPRI} ZSEC={TX_ZSEC} ULTAP={TX_ULTAP} CPRI={TX_CPRI} RPRI={TX_RPRI} RSEC={TX_RSEC} RCORE={TX_RCORE}

*VALVES
XU2 N001 N002 N005 0 EL84
XU3 N018 N014 N016 0 EL84
XU6 N008 N011 N013 12AU7
XU7 N003 N012 N013 12AU7
XU8 V_PP N007 N009 12AU7
XU9 N006 N020 N022 12AU7

*INCLUDES
.include ./param
.model NPN NPN
.model PNP PNP
.include ../../../python/models/mje340.lib
.include ./transformer_schatz_5776.inc
.include ../../../ModelsLTspice/output_transformer.lib
* Open Koren-form models shared by LTspice and ngspice.
.include ../../../ModelsLTspice/koren_tubes.lib
.backanno
.end
