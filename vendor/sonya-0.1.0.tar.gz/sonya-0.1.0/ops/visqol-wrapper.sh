#!/usr/bin/env sh
set -eu

visqol_binary="${SONYA_VISQOL_BINARY:-/usr/local/libexec/sonya/visqol-3.3.3}"
visqol_model="${SONYA_VISQOL_MODEL:-/usr/local/share/sonya/visqol-3.3.3/model/libsvm_nu_svr_model.txt}"

if [ "${1:-}" = "--version" ]; then
  echo "ViSQOL 3.3.3"
  exit 0
fi

for argument in "$@"; do
  case "$argument" in
    --similarity_to_quality_model|--similarity_to_quality_model=*)
      exec "$visqol_binary" "$@"
      ;;
  esac
done

exec "$visqol_binary" --similarity_to_quality_model "$visqol_model" "$@"
