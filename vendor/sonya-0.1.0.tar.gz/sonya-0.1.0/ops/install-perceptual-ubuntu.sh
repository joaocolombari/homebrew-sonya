#!/usr/bin/env bash

set -euo pipefail

readonly VISQOL_VERSION="3.3.3"
readonly VISQOL_ARCHIVE_SHA256="bce6b077b546f3f384458193cc6573f29b94c5a995a1c9e7575f35ad9791fbf0"
readonly GSTPEAQ_VERSION="0.6.1"
readonly GSTPEAQ_ARCHIVE_SHA256="da1c4e2d572c2e2a8c107d62cdc813eb63cf46f89fc052f0a3ea9026fa867109"
readonly BAZEL_VERSION="5.1.0"
readonly BAZEL_SHA256_X86_64="0440ae4581ea5eac5cb36ed0790b1e942778eb81e3ba9bc1326f189427aef0fd"
readonly CACHE_DIR="${SONYA_PERCEPTUAL_CACHE:-/var/cache/sonya/perceptual}"
readonly LOG_DIR="${SONYA_PERCEPTUAL_LOG_DIR:-/var/log/sonya}"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Execute como root: sudo $0 [--restart-gui]" >&2
  exit 2
fi

restart_gui=false
if [[ "${1:-}" == "--restart-gui" ]]; then
  restart_gui=true
  shift
fi
if [[ "$#" -ne 0 ]]; then
  echo "Uso: sudo $0 [--restart-gui]" >&2
  exit 2
fi

if [[ ! -r /etc/os-release ]]; then
  echo "Não foi possível identificar a distribuição Linux." >&2
  exit 2
fi
# shellcheck disable=SC1091
source /etc/os-release
if [[ "${ID:-}" != "ubuntu" && "${ID_LIKE:-}" != *debian* ]]; then
  echo "Este instalador foi validado para Ubuntu/Debian; distribuição encontrada: ${ID:-desconhecida}." >&2
  exit 2
fi
if [[ "$(uname -m)" != "x86_64" ]]; then
  echo "A compilação fixada do ViSQOL está validada somente para Linux x86_64." >&2
  exit 2
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install --yes \
  autoconf \
  automake \
  build-essential \
  ca-certificates \
  curl \
  g++-12 \
  gcc-12 \
  gstreamer1.0-plugins-base \
  gstreamer1.0-tools \
  gtk-doc-tools \
  libarmadillo-dev \
  libgstreamer-plugins-base1.0-dev \
  libgstreamer1.0-dev \
  libtool \
  patch \
  pkg-config \
  python3 \
  python3-numpy \
  unzip \
  zip

install -d -m 0755 "${CACHE_DIR}"
install -d -m 0755 "${LOG_DIR}"

build_jobs="${SONYA_BUILD_JOBS:-}"
if [[ -z "${build_jobs}" ]]; then
  build_jobs="$(nproc)"
  if (( build_jobs > 4 )); then
    build_jobs=4
  fi
fi
if [[ ! "${build_jobs}" =~ ^[1-9][0-9]*$ ]]; then
  echo "SONYA_BUILD_JOBS deve ser um inteiro positivo; valor recebido: ${build_jobs}" >&2
  exit 2
fi

# ViSQOL 3.3.3 embeds a TensorFlow/Abseil generation that predates GCC 15.
# Ubuntu 26.04 defaults to GCC 15, which cannot compile that source tree. Keep
# the host default untouched and select GCC 12 only for these two local builds.
export CC="${SONYA_BUILD_CC:-/usr/bin/gcc-12}"
export CXX="${SONYA_BUILD_CXX:-/usr/bin/g++-12}"
if [[ ! -x "${CC}" || ! -x "${CXX}" ]]; then
  echo "Compiladores indisponíveis: CC=${CC}, CXX=${CXX}" >&2
  exit 2
fi

fetch_verified() {
  local url="$1"
  local destination="$2"
  local expected_sha256="$3"
  if [[ ! -f "${destination}" ]] || ! echo "${expected_sha256}  ${destination}" | sha256sum --check --status; then
    rm -f "${destination}"
    curl --location --fail --retry 3 --output "${destination}" "${url}"
  fi
  echo "${expected_sha256}  ${destination}" | sha256sum --check
}

visqol_archive="${CACHE_DIR}/visqol-v${VISQOL_VERSION}.tar.gz"
gstpeaq_archive="${CACHE_DIR}/gstpeaq-${GSTPEAQ_VERSION}.tar.gz"
bazel_binary="${CACHE_DIR}/bazel-${BAZEL_VERSION}-linux-x86_64"
fetch_verified \
  "https://github.com/google/visqol/archive/refs/tags/v${VISQOL_VERSION}.tar.gz" \
  "${visqol_archive}" \
  "${VISQOL_ARCHIVE_SHA256}"
fetch_verified \
  "https://github.com/HSU-ANT/gstpeaq/archive/refs/tags/version-${GSTPEAQ_VERSION}.tar.gz" \
  "${gstpeaq_archive}" \
  "${GSTPEAQ_ARCHIVE_SHA256}"
fetch_verified \
  "https://github.com/bazelbuild/bazel/releases/download/${BAZEL_VERSION}/bazel-${BAZEL_VERSION}-linux-x86_64" \
  "${bazel_binary}" \
  "${BAZEL_SHA256_X86_64}"
chmod 0755 "${bazel_binary}"

build_root="$(mktemp -d /tmp/sonya-perceptual-build.XXXXXX)"
trap 'rm -rf "${build_root}"' EXIT

install -d \
  "${build_root}/visqol" \
  "${build_root}/gstpeaq" \
  "${build_root}/armadillo-headers/include"
tar -xzf "${visqol_archive}" --strip-components=1 -C "${build_root}/visqol"
tar -xzf "${gstpeaq_archive}" --strip-components=1 -C "${build_root}/gstpeaq"
cp -a \
  /usr/include/armadillo \
  /usr/include/armadillo_bits \
  "${build_root}/armadillo-headers/include/"
(
  cd "${build_root}/visqol"
  patch --batch --forward --strip=0 < "${SCRIPT_DIR}/visqol-system-armadillo.patch"
)

visqol_log="${LOG_DIR}/visqol-build.log"
echo "Compilando ViSQOL ${VISQOL_VERSION} com Bazel ${BAZEL_VERSION} (${build_jobs} processo(s))."
echo "O primeiro build pode levar vários minutos; log completo: ${visqol_log}"
if ! (
  set -e
  cd "${build_root}/visqol"
  "${bazel_binary}" \
    --output_user_root="${CACHE_DIR}/bazel-output" \
    --output_base="${CACHE_DIR}/bazel-visqol-${VISQOL_VERSION}" \
    build \
    --compilation_mode=opt \
    --jobs="${build_jobs}" \
    --action_env="CC=${CC}" \
    --action_env="CXX=${CXX}" \
    --repo_env="CC=${CC}" \
    --repo_env="CXX=${CXX}" \
    --verbose_failures \
    //:visqol
) >"${visqol_log}" 2>&1; then
  echo "A compilação do ViSQOL falhou. Diagnóstico extraído de ${visqol_log}:" >&2
  grep -nEi '(^ERROR:|error:|fatal error:|killed|terminated|out of memory|no space left|undefined reference)' \
    "${visqol_log}" | tail -n 80 >&2 || true
  echo "Últimas 120 linhas:" >&2
  tail -n 120 "${visqol_log}" >&2
  exit 1
fi
tail -n 20 "${visqol_log}"
install -d -m 0755 /usr/local/libexec/sonya
install -d -m 0755 "/usr/local/share/sonya/visqol-${VISQOL_VERSION}/model"
install -m 0755 "${build_root}/visqol/bazel-bin/visqol" "/usr/local/libexec/sonya/visqol-${VISQOL_VERSION}"
install -m 0644 \
  "${build_root}/visqol/model/libsvm_nu_svr_model.txt" \
  "/usr/local/share/sonya/visqol-${VISQOL_VERSION}/model/libsvm_nu_svr_model.txt"
install -m 0644 "${build_root}/visqol/LICENSE" "/usr/local/share/sonya/visqol-${VISQOL_VERSION}/LICENSE"
install -m 0755 "${SCRIPT_DIR}/visqol-wrapper.sh" /usr/local/bin/visqol

echo "Compilando GstPEAQ ${GSTPEAQ_VERSION}..."
gstpeaq_log="${LOG_DIR}/gstpeaq-build.log"
multiarch="$(dpkg-architecture --query DEB_HOST_MULTIARCH)"
if ! (
  set -e
  cd "${build_root}/gstpeaq"
  # GitHub's generated source archive omits the empty ChangeLog expected by
  # Automake's default "gnu" strictness. It is metadata, not build input.
  touch ChangeLog
  autoreconf --force --install
  ./configure \
    --prefix=/usr/local \
    --libdir="/usr/lib/${multiarch}" \
    --with-gstreamer=1.0 \
    --disable-gtk-doc \
    --disable-man
  make --jobs="${build_jobs}"
  make install
) >"${gstpeaq_log}" 2>&1; then
  echo "A compilação do GstPEAQ falhou. Últimas 120 linhas de ${gstpeaq_log}:" >&2
  tail -n 120 "${gstpeaq_log}" >&2
  exit 1
fi
tail -n 20 "${gstpeaq_log}"
ldconfig

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
visqol --version
peaq --version
gst-inspect-1.0 peaq >/dev/null

if [[ -x /srv/sonya/venv/bin/sonya && -f /srv/sonya/app/python/configs/legacy.yaml ]]; then
  runuser -u sonya -- env PATH="${PATH}" \
    /srv/sonya/venv/bin/sonya \
    --config /srv/sonya/app/python/configs/legacy.yaml \
    perceptual doctor
fi

if [[ "${restart_gui}" == true ]] && systemctl list-unit-files sonya-gui.service >/dev/null 2>&1; then
  active_jobs="$(grep -lE '\"status\": \"(starting|running|pause_requested|paused|cancel_requested)\"' /srv/sonya/state/gui-jobs/*/job.json 2>/dev/null || true)"
  if [[ -n "${active_jobs}" ]]; then
    echo "As ferramentas foram instaladas, mas a GUI não foi reiniciada porque há execução ativa:" >&2
    echo "${active_jobs}" >&2
    echo "Reinicie sonya-gui somente depois que ela terminar ou for cancelada." >&2
    exit 3
  fi
  systemctl restart sonya-gui
fi

echo
echo "ViSQOL ${VISQOL_VERSION} e GstPEAQ ${GSTPEAQ_VERSION} instalados e verificados."
if [[ "${restart_gui}" != true ]]; then
  echo "Para atualizar o diagnóstico da GUI: sudo systemctl restart sonya-gui"
fi
