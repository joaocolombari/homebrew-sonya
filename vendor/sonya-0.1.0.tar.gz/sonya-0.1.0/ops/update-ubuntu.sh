#!/usr/bin/env bash

set -euo pipefail

readonly SONYA_SERVICE_USER="sonya"
readonly SONYA_SERVICE_GROUP="sonya"
readonly SONYA_SERVICE_HOME="/srv/sonya"
readonly SONYA_APP_DIR="${SONYA_SERVICE_HOME}/app"
readonly SONYA_VENV_DIR="${SONYA_SERVICE_HOME}/venv"
readonly SONYA_STATE_DIR="${SONYA_SERVICE_HOME}/state"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Execute como root: sudo $0 /caminho/para/release.tar.gz" >&2
  exit 2
fi
if [[ "$#" -ne 1 ]]; then
  echo "Uso: sudo $0 /caminho/para/release.tar.gz" >&2
  exit 2
fi
if [[ ! -d "${SONYA_APP_DIR}" || ! -x "${SONYA_VENV_DIR}/bin/python" ]]; then
  echo "A instalação em ${SONYA_SERVICE_HOME} não existe; use bootstrap-ubuntu.sh primeiro." >&2
  exit 2
fi

active_jobs="$(grep -lE '\"status\": \"(starting|running|pause_requested|paused|cancel_requested)\"' "${SONYA_STATE_DIR}"/gui-jobs/*/job.json 2>/dev/null || true)"
if [[ -n "${active_jobs}" ]]; then
  echo "Atualização recusada: há execução ativa. Fechar o navegador ou o túnel SSH não exige atualização/reinício." >&2
  echo "${active_jobs}" >&2
  exit 3
fi

source_argument="$(realpath "$1")"
staging="$(mktemp -d /tmp/sonya-update.XXXXXX)"
trap 'rm -rf "${staging}"' EXIT
if [[ -d "${source_argument}" ]]; then
  source_root="${source_argument}"
elif [[ -f "${source_argument}" ]]; then
  tar -tzf "${source_argument}" >/dev/null
  tar -xzf "${source_argument}" -C "${staging}"
  if [[ -f "${staging}/python/pyproject.toml" ]]; then
    source_root="${staging}"
  else
    source_root="$(find "${staging}" -mindepth 1 -maxdepth 2 -type f -path '*/python/pyproject.toml' -print -quit | xargs -r dirname | xargs -r dirname)"
  fi
else
  echo "Fonte de atualização inexistente: ${source_argument}" >&2
  exit 2
fi
if [[ -z "${source_root:-}" || ! -f "${source_root}/python/pyproject.toml" || ! -f "${source_root}/python/configs/legacy.yaml" ]]; then
  echo "O pacote não contém uma árvore Sonya válida." >&2
  exit 2
fi

systemctl stop sonya-gui
if git -C "${source_root}" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git -C "${source_root}" archive --format=tar HEAD | tar -C "${SONYA_APP_DIR}" -xf -
else
  tar \
    --exclude='.git' \
    --exclude='.venv' \
    --exclude='.DS_Store' \
    --exclude='docs' \
    --exclude='python/corpus' \
    --exclude='python/outputs' \
    -C "${source_root}" -cf - . \
    | tar -C "${SONYA_APP_DIR}" -xf -
fi
chown -R "${SONYA_SERVICE_USER}:${SONYA_SERVICE_GROUP}" "${SONYA_APP_DIR}"

runuser -u "${SONYA_SERVICE_USER}" -- \
  "${SONYA_VENV_DIR}/bin/python" -m pip install --editable "${SONYA_APP_DIR}/python[test]"
runuser -u "${SONYA_SERVICE_USER}" -- \
  bash -c 'cd /tmp && exec "$1" -c "import sonya; import sonya.cli"' \
  bash "${SONYA_VENV_DIR}/bin/python"
runuser -u "${SONYA_SERVICE_USER}" -- \
  bash -c 'cd "$1" && exec "$2" -m pytest python/tests' \
  bash "${SONYA_APP_DIR}" "${SONYA_VENV_DIR}/bin/python"
install -m 0644 "${SONYA_APP_DIR}/ops/sonya-gui.service" /etc/systemd/system/sonya-gui.service
systemctl daemon-reload
systemctl start sonya-gui

echo "Sonya atualizado, testado e reiniciado. Estado e corpus foram preservados."
