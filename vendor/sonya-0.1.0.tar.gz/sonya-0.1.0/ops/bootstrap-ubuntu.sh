#!/usr/bin/env bash

set -euo pipefail

readonly SONYA_SERVICE_USER="sonya"
readonly SONYA_SERVICE_GROUP="sonya"
readonly SONYA_SERVICE_HOME="/srv/sonya"
readonly SONYA_APP_DIR="${SONYA_SERVICE_HOME}/app"
readonly SONYA_VENV_DIR="${SONYA_SERVICE_HOME}/venv"
readonly SONYA_STATE_DIR="${SONYA_SERVICE_HOME}/state"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Execute como root: sudo $0 /caminho/para/Sonya" >&2
  exit 2
fi

if [[ "$#" -ne 1 ]]; then
  echo "Uso: sudo $0 /caminho/para/Sonya" >&2
  exit 2
fi

SOURCE_DIR="$(cd "$1" && pwd -P)"
if [[ ! -f "${SOURCE_DIR}/python/pyproject.toml" || ! -f "${SOURCE_DIR}/python/configs/legacy.yaml" ]]; then
  echo "O diretório informado não parece ser um checkout do Sonya: ${SOURCE_DIR}" >&2
  exit 2
fi
if [[ -d "${SONYA_APP_DIR}" ]] && [[ -n "$(find "${SONYA_APP_DIR}" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
  echo "${SONYA_APP_DIR} já contém uma instalação. O bootstrap inicial não sobrescreve dados." >&2
  exit 3
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install --yes \
  build-essential \
  ca-certificates \
  ffmpeg \
  git \
  ngspice \
  python3-dev \
  python3-venv

if ! getent group "${SONYA_SERVICE_GROUP}" >/dev/null; then
  groupadd --system "${SONYA_SERVICE_GROUP}"
fi

if ! id -u "${SONYA_SERVICE_USER}" >/dev/null 2>&1; then
  useradd \
    --system \
    --gid "${SONYA_SERVICE_GROUP}" \
    --create-home \
    --home-dir "${SONYA_SERVICE_HOME}" \
    --shell /usr/sbin/nologin \
    "${SONYA_SERVICE_USER}"
fi

install -d -o "${SONYA_SERVICE_USER}" -g "${SONYA_SERVICE_GROUP}" \
  "${SONYA_APP_DIR}" \
  "${SONYA_STATE_DIR}" \
  "${SONYA_APP_DIR}/python/outputs"

# Em um checkout, copia exatamente o HEAD. Em um release extraído, copia a
# árvore recebida sem carregar metadados, ambientes, resultados ou docs locais.
if git -C "${SOURCE_DIR}" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git -C "${SOURCE_DIR}" archive --format=tar HEAD \
    | tar -C "${SONYA_APP_DIR}" -xf -
else
  tar \
    --exclude='.git' \
    --exclude='.venv' \
    --exclude='.DS_Store' \
    --exclude='docs' \
    --exclude='python/outputs' \
    -C "${SOURCE_DIR}" -cf - . \
    | tar -C "${SONYA_APP_DIR}" -xf -
fi
chown -R "${SONYA_SERVICE_USER}:${SONYA_SERVICE_GROUP}" "${SONYA_SERVICE_HOME}"

runuser -u "${SONYA_SERVICE_USER}" -- python3 -m venv "${SONYA_VENV_DIR}"
runuser -u "${SONYA_SERVICE_USER}" -- \
  "${SONYA_VENV_DIR}/bin/python" -m pip install --upgrade pip
runuser -u "${SONYA_SERVICE_USER}" -- \
  "${SONYA_VENV_DIR}/bin/python" -m pip install --editable "${SONYA_APP_DIR}/python[test]"
runuser -u "${SONYA_SERVICE_USER}" -- \
  bash -c 'cd /tmp && exec "$1" -c "import sonya; import sonya.cli"' \
  bash "${SONYA_VENV_DIR}/bin/python"

runuser -u "${SONYA_SERVICE_USER}" -- \
  "${SONYA_VENV_DIR}/bin/sonya" \
  --config "${SONYA_APP_DIR}/python/configs/legacy.yaml" \
  simulator smoke --backend ngspice
runuser -u "${SONYA_SERVICE_USER}" -- \
  bash -c 'cd "$1" && exec "$2" -m pytest python/tests' \
  bash "${SONYA_APP_DIR}" "${SONYA_VENV_DIR}/bin/python"

install -m 0644 \
  "${SONYA_APP_DIR}/ops/sonya-gui.service" \
  /etc/systemd/system/sonya-gui.service
systemctl daemon-reload

echo
echo "Sonya instalado e validado em ${SONYA_SERVICE_HOME}."
echo "O usuário sonya não possui senha, login SSH nem sudo."
echo "Para iniciar a GUI: sudo systemctl enable --now sonya-gui"
echo "Depois abra um túnel: ssh -L 8765:127.0.0.1:8765 USUARIO@SERVIDOR"
